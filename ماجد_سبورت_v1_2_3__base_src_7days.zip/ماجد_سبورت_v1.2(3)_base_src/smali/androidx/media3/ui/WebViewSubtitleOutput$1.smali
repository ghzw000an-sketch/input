.class public Landroidx/media3/ui/WebViewSubtitleOutput$1;
.super Landroid/webkit/WebView;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/media3/ui/WebViewSubtitleOutput;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic this$0:Landroidx/media3/ui/WebViewSubtitleOutput;


# direct methods
.method public constructor <init>(Landroidx/media3/ui/WebViewSubtitleOutput;Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 0
    .param p1, "this$0"    # Landroidx/media3/ui/WebViewSubtitleOutput;
    .param p2, "arg0"    # Landroid/content/Context;
    .param p3, "arg1"    # Landroid/util/AttributeSet;

    .line 89
    iput-object p1, p0, Landroidx/media3/ui/WebViewSubtitleOutput$1;->this$0:Landroidx/media3/ui/WebViewSubtitleOutput;

    invoke-direct {p0, p2, p3}, Landroid/webkit/WebView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method


# virtual methods
.method public onTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 1
    .param p1, "event"    # Landroid/view/MotionEvent;

    .line 92
    invoke-super {p0, p1}, Landroid/webkit/WebView;->onTouchEvent(Landroid/view/MotionEvent;)Z

    .line 94
    const/4 v0, 0x0

    return v0
.end method

.method public performClick()Z
    .locals 1

    .line 99
    invoke-super {p0}, Landroid/view/View;->performClick()Z

    .line 101
    const/4 v0, 0x0

    return v0
.end method
