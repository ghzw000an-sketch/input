.class public abstract Landroidx/media3/ui/R$drawable;
.super Ljava/lang/Object;


# static fields
.field public static exo_edit_mode_logo:I = 0x7f0800b7

.field public static exo_styled_controls_audiotrack:I = 0x7f0800f0

.field public static exo_styled_controls_fullscreen_enter:I = 0x7f0800f3

.field public static exo_styled_controls_fullscreen_exit:I = 0x7f0800f4

.field public static exo_styled_controls_next:I = 0x7f0800f5

.field public static exo_styled_controls_pause:I = 0x7f0800f8

.field public static exo_styled_controls_play:I = 0x7f0800f9

.field public static exo_styled_controls_previous:I = 0x7f0800fa

.field public static exo_styled_controls_repeat_all:I = 0x7f0800fb

.field public static exo_styled_controls_repeat_off:I = 0x7f0800fc

.field public static exo_styled_controls_repeat_one:I = 0x7f0800fd

.field public static exo_styled_controls_shuffle_off:I = 0x7f080100

.field public static exo_styled_controls_shuffle_on:I = 0x7f080101

.field public static exo_styled_controls_simple_fastforward:I = 0x7f080102

.field public static exo_styled_controls_simple_rewind:I = 0x7f080103

.field public static exo_styled_controls_speed:I = 0x7f080104

.field public static exo_styled_controls_subtitle_off:I = 0x7f080105

.field public static exo_styled_controls_subtitle_on:I = 0x7f080106

.field public static exo_styled_controls_vr:I = 0x7f080107
