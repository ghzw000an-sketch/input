.class public final Landroidx/media3/ui/AspectRatioFrameLayout;
.super Landroid/widget/FrameLayout;
.source ""


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/media3/ui/AspectRatioFrameLayout$AspectRatioListener;,
        Landroidx/media3/ui/AspectRatioFrameLayout$AspectRatioUpdateDispatcher;
    }
.end annotation


# instance fields
.field public final aspectRatioUpdateDispatcher:Landroidx/media3/ui/AspectRatioFrameLayout$AspectRatioUpdateDispatcher;

.field public resizeMode:I

.field public videoAspectRatio:F


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "attrs"    # Landroid/util/AttributeSet;

    .line 114
    invoke-direct {p0, p1, p2}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 115
    const/4 v0, 0x0

    iput v0, p0, Landroidx/media3/ui/AspectRatioFrameLayout;->resizeMode:I

    .line 116
    if-eqz p2, :cond_0

    .line 117
    nop

    .line 119
    invoke-virtual {p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v1

    sget-object v2, Landroidx/media3/ui/R$styleable;->AspectRatioFrameLayout:[I

    .line 120
    invoke-virtual {v1, p2, v2, v0, v0}, Landroid/content/res/Resources$Theme;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    move-result-object v1

    .line 122
    .local v1, "a":Landroid/content/res/TypedArray;
    :try_start_0
    sget v2, Landroidx/media3/ui/R$styleable;->AspectRatioFrameLayout_resize_mode:I

    invoke-virtual {v1, v2, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v0

    iput v0, p0, Landroidx/media3/ui/AspectRatioFrameLayout;->resizeMode:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 124
    invoke-virtual {v1}, Landroid/content/res/TypedArray;->recycle()V

    .line 125
    goto :goto_0

    .line 124
    :catchall_0
    move-exception v0

    invoke-virtual {v1}, Landroid/content/res/TypedArray;->recycle()V

    .line 125
    throw v0

    .line 127
    .end local v1    # "a":Landroid/content/res/TypedArray;
    :cond_0
    :goto_0
    new-instance v0, Landroidx/media3/ui/AspectRatioFrameLayout$AspectRatioUpdateDispatcher;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Landroidx/media3/ui/AspectRatioFrameLayout$AspectRatioUpdateDispatcher;-><init>(Landroidx/media3/ui/AspectRatioFrameLayout;Landroidx/media3/ui/AspectRatioFrameLayout$1;)V

    iput-object v0, p0, Landroidx/media3/ui/AspectRatioFrameLayout;->aspectRatioUpdateDispatcher:Landroidx/media3/ui/AspectRatioFrameLayout$AspectRatioUpdateDispatcher;

    .line 128
    return-void
.end method

.method public static synthetic access$100(Landroidx/media3/ui/AspectRatioFrameLayout;)Landroidx/media3/ui/AspectRatioFrameLayout$AspectRatioListener;
    .locals 1
    .param p0, "x0"    # Landroidx/media3/ui/AspectRatioFrameLayout;

    .line 34
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x0

    return-object v0
.end method


# virtual methods
.method public getResizeMode()I
    .locals 1

    .line 154
    iget v0, p0, Landroidx/media3/ui/AspectRatioFrameLayout;->resizeMode:I

    return v0
.end method

.method public onMeasure(II)V
    .locals 7
    .param p1, "widthMeasureSpec"    # I
    .param p2, "heightMeasureSpec"    # I

    .line 171
    invoke-super {p0, p1, p2}, Landroid/widget/FrameLayout;->onMeasure(II)V

    .line 172
    iget v0, p0, Landroidx/media3/ui/AspectRatioFrameLayout;->videoAspectRatio:F

    const/4 v1, 0x0

    cmpg-float v0, v0, v1

    if-gtz v0, :cond_0

    .line 174
    return-void

    .line 177
    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    move-result v0

    .line 178
    .local v0, "width":I
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    move-result v2

    .line 179
    .local v2, "height":I
    int-to-float v3, v0

    int-to-float v4, v2

    div-float/2addr v3, v4

    .line 180
    .local v3, "viewAspectRatio":F
    iget v4, p0, Landroidx/media3/ui/AspectRatioFrameLayout;->videoAspectRatio:F

    div-float/2addr v4, v3

    const/high16 v5, 0x3f800000    # 1.0f

    sub-float/2addr v4, v5

    .line 181
    .local v4, "aspectDeformation":F
    invoke-static {v4}, Ljava/lang/Math;->abs(F)F

    move-result v5

    const v6, 0x3c23d70a

    cmpg-float v5, v5, v6

    if-gtz v5, :cond_1

    .line 183
    iget-object v1, p0, Landroidx/media3/ui/AspectRatioFrameLayout;->aspectRatioUpdateDispatcher:Landroidx/media3/ui/AspectRatioFrameLayout$AspectRatioUpdateDispatcher;

    iget v5, p0, Landroidx/media3/ui/AspectRatioFrameLayout;->videoAspectRatio:F

    const/4 v6, 0x0

    invoke-virtual {v1, v5, v3, v6}, Landroidx/media3/ui/AspectRatioFrameLayout$AspectRatioUpdateDispatcher;->scheduleUpdate(FFZ)V

    .line 184
    return-void

    .line 187
    :cond_1
    iget v5, p0, Landroidx/media3/ui/AspectRatioFrameLayout;->resizeMode:I

    packed-switch v5, :pswitch_data_0

    :pswitch_0
    goto :goto_0

    .line 195
    :pswitch_1
    cmpl-float v1, v4, v1

    if-lez v1, :cond_2

    .line 196
    int-to-float v1, v2

    iget v5, p0, Landroidx/media3/ui/AspectRatioFrameLayout;->videoAspectRatio:F

    mul-float/2addr v1, v5

    float-to-int v0, v1

    goto :goto_0

    .line 198
    :cond_2
    int-to-float v1, v0

    iget v5, p0, Landroidx/media3/ui/AspectRatioFrameLayout;->videoAspectRatio:F

    div-float/2addr v1, v5

    float-to-int v2, v1

    .line 200
    goto :goto_0

    .line 192
    :pswitch_2
    int-to-float v1, v2

    iget v5, p0, Landroidx/media3/ui/AspectRatioFrameLayout;->videoAspectRatio:F

    mul-float/2addr v1, v5

    float-to-int v0, v1

    .line 193
    goto :goto_0

    .line 189
    :pswitch_3
    int-to-float v1, v0

    iget v5, p0, Landroidx/media3/ui/AspectRatioFrameLayout;->videoAspectRatio:F

    div-float/2addr v1, v5

    float-to-int v2, v1

    .line 190
    goto :goto_0

    .line 202
    :pswitch_4
    cmpl-float v1, v4, v1

    if-lez v1, :cond_3

    .line 203
    int-to-float v1, v0

    iget v5, p0, Landroidx/media3/ui/AspectRatioFrameLayout;->videoAspectRatio:F

    div-float/2addr v1, v5

    float-to-int v2, v1

    goto :goto_0

    .line 205
    :cond_3
    int-to-float v1, v2

    iget v5, p0, Landroidx/media3/ui/AspectRatioFrameLayout;->videoAspectRatio:F

    mul-float/2addr v1, v5

    float-to-int v0, v1

    .line 207
    nop

    .line 213
    :goto_0
    iget-object v1, p0, Landroidx/media3/ui/AspectRatioFrameLayout;->aspectRatioUpdateDispatcher:Landroidx/media3/ui/AspectRatioFrameLayout$AspectRatioUpdateDispatcher;

    iget v5, p0, Landroidx/media3/ui/AspectRatioFrameLayout;->videoAspectRatio:F

    const/4 v6, 0x1

    invoke-virtual {v1, v5, v3, v6}, Landroidx/media3/ui/AspectRatioFrameLayout$AspectRatioUpdateDispatcher;->scheduleUpdate(FFZ)V

    .line 214
    nop

    .line 215
    const/high16 v1, 0x40000000    # 2.0f

    invoke-static {v0, v1}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v5

    .line 216
    invoke-static {v2, v1}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v1

    .line 214
    invoke-super {p0, v5, v1}, Landroid/widget/FrameLayout;->onMeasure(II)V

    .line 217
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_0
        :pswitch_1
    .end packed-switch
.end method

.method public setAspectRatio(F)V
    .locals 1
    .param p1, "widthHeightRatio"    # F

    .line 136
    iget v0, p0, Landroidx/media3/ui/AspectRatioFrameLayout;->videoAspectRatio:F

    cmpl-float v0, v0, p1

    if-eqz v0, :cond_0

    .line 137
    iput p1, p0, Landroidx/media3/ui/AspectRatioFrameLayout;->videoAspectRatio:F

    .line 138
    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    .line 140
    :cond_0
    return-void
.end method

.method public setAspectRatioListener(Landroidx/media3/ui/AspectRatioFrameLayout$AspectRatioListener;)V
    .locals 0
    .param p1, "listener"    # Landroidx/media3/ui/AspectRatioFrameLayout$AspectRatioListener;

    .line 149
    nop

    .line 150
    return-void
.end method

.method public setResizeMode(I)V
    .locals 1
    .param p1, "resizeMode"    # I

    .line 163
    iget v0, p0, Landroidx/media3/ui/AspectRatioFrameLayout;->resizeMode:I

    if-eq v0, p1, :cond_0

    .line 164
    iput p1, p0, Landroidx/media3/ui/AspectRatioFrameLayout;->resizeMode:I

    .line 165
    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    .line 167
    :cond_0
    return-void
.end method
