.class public final synthetic Landroidx/media3/ui/SubtitleViewUtils$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/google/common/base/Predicate;


# direct methods
.method public synthetic constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final apply(Ljava/lang/Object;)Z
    .locals 0

    .line 0
    invoke-static {p1}, Landroidx/media3/ui/SubtitleViewUtils;->$r8$lambda$2KRqBfSJVKt-fgYwRCZOSzqT5Ww(Ljava/lang/Object;)Z

    move-result p1

    return p1
.end method
