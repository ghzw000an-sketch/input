.class public interface abstract Landroidx/media3/ui/AspectRatioFrameLayout$AspectRatioListener;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/media3/ui/AspectRatioFrameLayout;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "AspectRatioListener"
.end annotation
