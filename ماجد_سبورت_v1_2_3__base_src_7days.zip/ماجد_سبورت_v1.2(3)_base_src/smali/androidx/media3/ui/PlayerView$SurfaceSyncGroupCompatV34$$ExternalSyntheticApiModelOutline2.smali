.class public abstract synthetic Landroidx/media3/ui/PlayerView$SurfaceSyncGroupCompatV34$$ExternalSyntheticApiModelOutline2;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static bridge synthetic m(Landroid/window/SurfaceSyncGroup;)V
    .locals 0

    .line 0
    invoke-virtual {p0}, Landroid/window/SurfaceSyncGroup;->markSyncReady()V

    return-void
.end method
