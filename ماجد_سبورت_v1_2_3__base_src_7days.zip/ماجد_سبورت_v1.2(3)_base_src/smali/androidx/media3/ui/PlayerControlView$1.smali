.class public Landroidx/media3/ui/PlayerControlView$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/google/common/util/concurrent/FutureCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/media3/ui/PlayerControlView;->setMediaRouteButtonViewProvider(Landroidx/media3/common/ViewProvider;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic this$0:Landroidx/media3/ui/PlayerControlView;

.field public final synthetic val$mediaRouteButtonPlaceholder:Landroid/view/View;

.field public final synthetic val$parent:Landroid/view/ViewGroup;


# direct methods
.method public constructor <init>(Landroidx/media3/ui/PlayerControlView;Landroid/view/View;Landroid/view/ViewGroup;)V
    .locals 0
    .param p1, "this$0"    # Landroidx/media3/ui/PlayerControlView;

    .line 1143
    iput-object p1, p0, Landroidx/media3/ui/PlayerControlView$1;->this$0:Landroidx/media3/ui/PlayerControlView;

    iput-object p2, p0, Landroidx/media3/ui/PlayerControlView$1;->val$mediaRouteButtonPlaceholder:Landroid/view/View;

    iput-object p3, p0, Landroidx/media3/ui/PlayerControlView$1;->val$parent:Landroid/view/ViewGroup;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onFailure(Ljava/lang/Throwable;)V
    .locals 2
    .param p1, "e"    # Ljava/lang/Throwable;

    .line 1162
    iget-object v0, p0, Landroidx/media3/ui/PlayerControlView$1;->val$mediaRouteButtonPlaceholder:Landroid/view/View;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 1163
    return-void
.end method

.method public onSuccess(Landroid/view/View;)V
    .locals 4
    .param p1, "mediaRouteButtonView"    # Landroid/view/View;

    .line 1146
    iget-object v0, p0, Landroidx/media3/ui/PlayerControlView$1;->val$mediaRouteButtonPlaceholder:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    .line 1147
    .local v0, "layoutParams":Landroid/view/ViewGroup$LayoutParams;
    if-eqz v0, :cond_0

    .line 1151
    sget v1, Landroidx/media3/ui/R$id;->exo_media_route_button_placeholder:I

    invoke-virtual {p1, v1}, Landroid/view/View;->setId(I)V

    .line 1152
    invoke-virtual {p1, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1153
    iget-object v1, p0, Landroidx/media3/ui/PlayerControlView$1;->val$parent:Landroid/view/ViewGroup;

    iget-object v2, p0, Landroidx/media3/ui/PlayerControlView$1;->val$mediaRouteButtonPlaceholder:Landroid/view/View;

    invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    move-result v1

    .line 1154
    .local v1, "mediaRouteButtonIndex":I
    iget-object v2, p0, Landroidx/media3/ui/PlayerControlView$1;->val$parent:Landroid/view/ViewGroup;

    iget-object v3, p0, Landroidx/media3/ui/PlayerControlView$1;->val$mediaRouteButtonPlaceholder:Landroid/view/View;

    invoke-virtual {v2, v3}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 1155
    iget-object v2, p0, Landroidx/media3/ui/PlayerControlView$1;->val$parent:Landroid/view/ViewGroup;

    invoke-virtual {v2, p1, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    .line 1156
    const/4 v2, 0x0

    invoke-virtual {p1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 1157
    iget-object v2, p0, Landroidx/media3/ui/PlayerControlView$1;->this$0:Landroidx/media3/ui/PlayerControlView;

    invoke-static {v2}, Landroidx/media3/ui/PlayerControlView;->access$300(Landroidx/media3/ui/PlayerControlView;)Landroidx/media3/ui/PlayerControlViewLayoutManager;

    move-result-object v2

    const/4 v3, 0x1

    invoke-virtual {v2, p1, v3}, Landroidx/media3/ui/PlayerControlViewLayoutManager;->setShowButton(Landroid/view/View;Z)V

    .line 1158
    return-void

    .line 1148
    .end local v1    # "mediaRouteButtonIndex":I
    :cond_0
    new-instance v1, Ljava/lang/IllegalStateException;

    const-string v2, "The media route button placeholder missing layout params."

    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method public bridge synthetic onSuccess(Ljava/lang/Object;)V
    .locals 0

    .line 1143
    check-cast p1, Landroid/view/View;

    invoke-virtual {p0, p1}, Landroidx/media3/ui/PlayerControlView$1;->onSuccess(Landroid/view/View;)V

    return-void
.end method
