.class public interface abstract Landroidx/media3/ui/PlayerControlView$VisibilityListener;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/media3/ui/PlayerControlView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "VisibilityListener"
.end annotation


# virtual methods
.method public abstract onVisibilityChange(I)V
.end method
