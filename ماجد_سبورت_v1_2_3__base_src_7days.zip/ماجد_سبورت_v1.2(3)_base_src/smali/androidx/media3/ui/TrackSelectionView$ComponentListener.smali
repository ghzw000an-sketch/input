.class public Landroidx/media3/ui/TrackSelectionView$ComponentListener;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/media3/ui/TrackSelectionView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "ComponentListener"
.end annotation


# instance fields
.field public final synthetic this$0:Landroidx/media3/ui/TrackSelectionView;


# direct methods
.method public constructor <init>(Landroidx/media3/ui/TrackSelectionView;)V
    .locals 0

    .line 416
    iput-object p1, p0, Landroidx/media3/ui/TrackSelectionView$ComponentListener;->this$0:Landroidx/media3/ui/TrackSelectionView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Landroidx/media3/ui/TrackSelectionView;Landroidx/media3/ui/TrackSelectionView$1;)V
    .locals 0
    .param p1, "x0"    # Landroidx/media3/ui/TrackSelectionView;
    .param p2, "x1"    # Landroidx/media3/ui/TrackSelectionView$1;

    .line 416
    invoke-direct {p0, p1}, Landroidx/media3/ui/TrackSelectionView$ComponentListener;-><init>(Landroidx/media3/ui/TrackSelectionView;)V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1
    .param p1, "view"    # Landroid/view/View;

    .line 420
    iget-object v0, p0, Landroidx/media3/ui/TrackSelectionView$ComponentListener;->this$0:Landroidx/media3/ui/TrackSelectionView;

    invoke-static {v0, p1}, Landroidx/media3/ui/TrackSelectionView;->access$100(Landroidx/media3/ui/TrackSelectionView;Landroid/view/View;)V

    .line 421
    return-void
.end method
