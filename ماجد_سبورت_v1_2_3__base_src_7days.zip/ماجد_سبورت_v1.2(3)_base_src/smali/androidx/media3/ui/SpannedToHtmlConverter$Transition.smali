.class public final Landroidx/media3/ui/SpannedToHtmlConverter$Transition;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/media3/ui/SpannedToHtmlConverter;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Transition"
.end annotation


# instance fields
.field public final spansAdded:Ljava/util/List;

.field public final spansRemoved:Ljava/util/List;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 379
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 380
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/media3/ui/SpannedToHtmlConverter$Transition;->spansAdded:Ljava/util/List;

    .line 381
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/media3/ui/SpannedToHtmlConverter$Transition;->spansRemoved:Ljava/util/List;

    .line 382
    return-void
.end method

.method public static synthetic access$100(Landroidx/media3/ui/SpannedToHtmlConverter$Transition;)Ljava/util/List;
    .locals 1
    .param p0, "x0"    # Landroidx/media3/ui/SpannedToHtmlConverter$Transition;

    .line 375
    iget-object v0, p0, Landroidx/media3/ui/SpannedToHtmlConverter$Transition;->spansRemoved:Ljava/util/List;

    return-object v0
.end method

.method public static synthetic access$300(Landroidx/media3/ui/SpannedToHtmlConverter$Transition;)Ljava/util/List;
    .locals 1
    .param p0, "x0"    # Landroidx/media3/ui/SpannedToHtmlConverter$Transition;

    .line 375
    iget-object v0, p0, Landroidx/media3/ui/SpannedToHtmlConverter$Transition;->spansAdded:Ljava/util/List;

    return-object v0
.end method
