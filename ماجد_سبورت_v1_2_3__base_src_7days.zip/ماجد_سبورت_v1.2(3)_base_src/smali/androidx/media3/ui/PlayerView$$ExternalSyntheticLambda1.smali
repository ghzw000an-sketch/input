.class public final synthetic Landroidx/media3/ui/PlayerView$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Landroidx/media3/ui/PlayerView;

.field public final synthetic f$1:Landroid/graphics/Bitmap;


# direct methods
.method public synthetic constructor <init>(Landroidx/media3/ui/PlayerView;Landroid/graphics/Bitmap;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/media3/ui/PlayerView$$ExternalSyntheticLambda1;->f$0:Landroidx/media3/ui/PlayerView;

    iput-object p2, p0, Landroidx/media3/ui/PlayerView$$ExternalSyntheticLambda1;->f$1:Landroid/graphics/Bitmap;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 0
    iget-object v0, p0, Landroidx/media3/ui/PlayerView$$ExternalSyntheticLambda1;->f$0:Landroidx/media3/ui/PlayerView;

    iget-object v1, p0, Landroidx/media3/ui/PlayerView$$ExternalSyntheticLambda1;->f$1:Landroid/graphics/Bitmap;

    invoke-static {v0, v1}, Landroidx/media3/ui/PlayerView;->$r8$lambda$LV2d0rIanLI_hEb4XhvJMfhVggk(Landroidx/media3/ui/PlayerView;Landroid/graphics/Bitmap;)V

    return-void
.end method
