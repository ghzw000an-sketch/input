.class public final synthetic Landroidx/media3/ui/DefaultTimeBar$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Landroidx/media3/ui/DefaultTimeBar;


# direct methods
.method public synthetic constructor <init>(Landroidx/media3/ui/DefaultTimeBar;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/media3/ui/DefaultTimeBar$$ExternalSyntheticLambda1;->f$0:Landroidx/media3/ui/DefaultTimeBar;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    .line 0
    iget-object v0, p0, Landroidx/media3/ui/DefaultTimeBar$$ExternalSyntheticLambda1;->f$0:Landroidx/media3/ui/DefaultTimeBar;

    invoke-static {v0}, Landroidx/media3/ui/DefaultTimeBar;->$r8$lambda$4LinnAx1XekvSd8OAvAL0LFnrr0(Landroidx/media3/ui/DefaultTimeBar;)V

    return-void
.end method
