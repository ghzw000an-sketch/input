.class public abstract Landroidx/media3/ui/R$layout;
.super Ljava/lang/Object;


# static fields
.field public static exo_list_divider:I = 0x7f0d0033

.field public static exo_player_control_view:I = 0x7f0d0036

.field public static exo_player_view:I = 0x7f0d0037

.field public static exo_styled_settings_list:I = 0x7f0d0038

.field public static exo_styled_settings_list_item:I = 0x7f0d0039

.field public static exo_styled_sub_settings_list_item:I = 0x7f0d003a
