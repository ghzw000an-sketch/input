.class public interface abstract Landroidx/media3/ui/SubtitleView$Output;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/media3/ui/SubtitleView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "Output"
.end annotation


# virtual methods
.method public abstract update(Ljava/util/List;Landroidx/media3/ui/CaptionStyleCompat;FIF)V
.end method
