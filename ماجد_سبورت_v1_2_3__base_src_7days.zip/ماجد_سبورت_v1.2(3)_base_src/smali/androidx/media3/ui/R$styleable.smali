.class public abstract Landroidx/media3/ui/R$styleable;
.super Ljava/lang/Object;


# static fields
.field public static AspectRatioFrameLayout:[I = null

.field public static AspectRatioFrameLayout_resize_mode:I = 0x0

.field public static DefaultTimeBar:[I = null

.field public static DefaultTimeBar_ad_marker_color:I = 0x0

.field public static DefaultTimeBar_ad_marker_width:I = 0x1

.field public static DefaultTimeBar_bar_gravity:I = 0x2

.field public static DefaultTimeBar_bar_height:I = 0x3

.field public static DefaultTimeBar_buffered_color:I = 0x4

.field public static DefaultTimeBar_played_ad_marker_color:I = 0x5

.field public static DefaultTimeBar_played_color:I = 0x6

.field public static DefaultTimeBar_scrubber_color:I = 0x7

.field public static DefaultTimeBar_scrubber_disabled_size:I = 0x8

.field public static DefaultTimeBar_scrubber_dragged_size:I = 0x9

.field public static DefaultTimeBar_scrubber_drawable:I = 0xa

.field public static DefaultTimeBar_scrubber_enabled_size:I = 0xb

.field public static DefaultTimeBar_touch_target_height:I = 0xc

.field public static DefaultTimeBar_unplayed_color:I = 0xd

.field public static LegacyPlayerControlView:[I = null

.field public static PlayerControlView:[I = null

.field public static PlayerControlView_animation_enabled:I = 0x2

.field public static PlayerControlView_controller_layout_id:I = 0x6

.field public static PlayerControlView_fastforward_icon:I = 0x7

.field public static PlayerControlView_fullscreen_enter_icon:I = 0x8

.field public static PlayerControlView_fullscreen_exit_icon:I = 0x9

.field public static PlayerControlView_next_icon:I = 0xa

.field public static PlayerControlView_pause_icon:I = 0xb

.field public static PlayerControlView_play_icon:I = 0xc

.field public static PlayerControlView_previous_icon:I = 0xf

.field public static PlayerControlView_repeat_all_icon:I = 0x10

.field public static PlayerControlView_repeat_off_icon:I = 0x11

.field public static PlayerControlView_repeat_one_icon:I = 0x12

.field public static PlayerControlView_repeat_toggle_modes:I = 0x13

.field public static PlayerControlView_rewind_icon:I = 0x14

.field public static PlayerControlView_show_fastforward_button:I = 0x1a

.field public static PlayerControlView_show_next_button:I = 0x1b

.field public static PlayerControlView_show_previous_button:I = 0x1c

.field public static PlayerControlView_show_rewind_button:I = 0x1d

.field public static PlayerControlView_show_shuffle_button:I = 0x1e

.field public static PlayerControlView_show_subtitle_button:I = 0x1f

.field public static PlayerControlView_show_timeout:I = 0x20

.field public static PlayerControlView_show_vr_button:I = 0x21

.field public static PlayerControlView_shuffle_off_icon:I = 0x22

.field public static PlayerControlView_shuffle_on_icon:I = 0x23

.field public static PlayerControlView_subtitle_off_icon:I = 0x24

.field public static PlayerControlView_subtitle_on_icon:I = 0x25

.field public static PlayerControlView_time_bar_min_update_interval:I = 0x26

.field public static PlayerControlView_time_bar_scrubbing_enabled:I = 0x27

.field public static PlayerControlView_vr_icon:I = 0x2a

.field public static PlayerView:[I = null

.field public static PlayerView_artwork_display_mode:I = 0x3

.field public static PlayerView_auto_show:I = 0x4

.field public static PlayerView_default_artwork:I = 0x9

.field public static PlayerView_hide_during_ads:I = 0xd

.field public static PlayerView_hide_on_touch:I = 0xe

.field public static PlayerView_image_display_mode:I = 0xf

.field public static PlayerView_keep_content_on_player_reset:I = 0x10

.field public static PlayerView_player_layout_id:I = 0x16

.field public static PlayerView_resize_mode:I = 0x1c

.field public static PlayerView_show_buffering:I = 0x23

.field public static PlayerView_show_timeout:I = 0x26

.field public static PlayerView_shutter_background_color:I = 0x2a

.field public static PlayerView_surface_type:I = 0x2d

.field public static PlayerView_use_artwork:I = 0x32

.field public static PlayerView_use_controller:I = 0x33


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    const v0, 0x7f040394

    filled-new-array {v0}, [I

    move-result-object v0

    sput-object v0, Landroidx/media3/ui/R$styleable;->AspectRatioFrameLayout:[I

    const/16 v0, 0xe

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    sput-object v0, Landroidx/media3/ui/R$styleable;->DefaultTimeBar:[I

    const/16 v0, 0x17

    new-array v0, v0, [I

    fill-array-data v0, :array_1

    sput-object v0, Landroidx/media3/ui/R$styleable;->LegacyPlayerControlView:[I

    const/16 v0, 0x2b

    new-array v0, v0, [I

    fill-array-data v0, :array_2

    sput-object v0, Landroidx/media3/ui/R$styleable;->PlayerControlView:[I

    const/16 v0, 0x35

    new-array v0, v0, [I

    fill-array-data v0, :array_3

    sput-object v0, Landroidx/media3/ui/R$styleable;->PlayerView:[I

    return-void

    :array_0
    .array-data 4
        0x7f040029
        0x7f04002a
        0x7f040069
        0x7f04006a
        0x7f04008e
        0x7f040373
        0x7f040374
        0x7f04039f
        0x7f0403a0
        0x7f0403a1
        0x7f0403a2
        0x7f0403a3
        0x7f0404a2
        0x7f0404ba
    .end array-data

    :array_1
    .array-data 4
        0x7f040029
        0x7f04002a
        0x7f040069
        0x7f04006a
        0x7f04008e
        0x7f040140
        0x7f040373
        0x7f040374
        0x7f040393
        0x7f04039f
        0x7f0403a0
        0x7f0403a1
        0x7f0403a2
        0x7f0403a3
        0x7f0403c4
        0x7f0403c5
        0x7f0403c6
        0x7f0403c7
        0x7f0403c8
        0x7f0403ca
        0x7f040481
        0x7f0404a2
        0x7f0404ba
    .end array-data

    :array_2
    .array-data 4
        0x7f040029
        0x7f04002a
        0x7f040038
        0x7f040069
        0x7f04006a
        0x7f04008e
        0x7f040140
        0x7f0401cf
        0x7f040204
        0x7f040205
        0x7f040348
        0x7f040367
        0x7f040372
        0x7f040373
        0x7f040374
        0x7f04037f
        0x7f040390
        0x7f040391
        0x7f040392
        0x7f040393
        0x7f040396
        0x7f04039f
        0x7f0403a0
        0x7f0403a1
        0x7f0403a2
        0x7f0403a3
        0x7f0403c4
        0x7f0403c5
        0x7f0403c6
        0x7f0403c7
        0x7f0403c8
        0x7f0403c9
        0x7f0403ca
        0x7f0403cb
        0x7f0403cd
        0x7f0403ce
        0x7f040406
        0x7f040407
        0x7f040481
        0x7f040482
        0x7f0404a2
        0x7f0404ba
        0x7f0404c6
    .end array-data

    :array_3
    .array-data 4
        0x7f040029
        0x7f04002a
        0x7f040038
        0x7f04003e
        0x7f040049
        0x7f040069
        0x7f04006a
        0x7f04008e
        0x7f040140
        0x7f04016b
        0x7f0401cf
        0x7f040204
        0x7f040205
        0x7f040216
        0x7f040217
        0x7f04022d
        0x7f04025a
        0x7f040348
        0x7f040367
        0x7f040372
        0x7f040373
        0x7f040374
        0x7f040375
        0x7f04037f
        0x7f040390
        0x7f040391
        0x7f040392
        0x7f040393
        0x7f040394
        0x7f040396
        0x7f04039f
        0x7f0403a0
        0x7f0403a1
        0x7f0403a2
        0x7f0403a3
        0x7f0403c3
        0x7f0403c8
        0x7f0403c9
        0x7f0403ca
        0x7f0403cb
        0x7f0403cd
        0x7f0403ce
        0x7f0403cf
        0x7f040406
        0x7f040407
        0x7f04040c
        0x7f040481
        0x7f040482
        0x7f0404a2
        0x7f0404ba
        0x7f0404be
        0x7f0404bf
        0x7f0404c6
    .end array-data
.end method
