.class public abstract Landroidx/media3/ui/R$dimen;
.super Ljava/lang/Object;


# static fields
.field public static exo_settings_offset:I = 0x7f0700a2

.field public static exo_styled_bottom_bar_height:I = 0x7f0700aa

.field public static exo_styled_progress_bar_height:I = 0x7f0700af

.field public static exo_styled_progress_margin_bottom:I = 0x7f0700b3
