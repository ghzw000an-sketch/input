.class public abstract Landroidx/media3/ui/PlayerView$Api34;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/media3/ui/PlayerView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "Api34"
.end annotation


# direct methods
.method public static setSurfaceLifecycleToFollowsAttachment(Landroid/view/SurfaceView;)V
    .locals 1
    .param p0, "surfaceView"    # Landroid/view/SurfaceView;

    .line 2002
    const/4 v0, 0x2

    invoke-static {p0, v0}, Landroidx/media3/ui/PlayerView$Api34$$ExternalSyntheticApiModelOutline0;->m(Landroid/view/SurfaceView;I)V

    .line 2003
    return-void
.end method
