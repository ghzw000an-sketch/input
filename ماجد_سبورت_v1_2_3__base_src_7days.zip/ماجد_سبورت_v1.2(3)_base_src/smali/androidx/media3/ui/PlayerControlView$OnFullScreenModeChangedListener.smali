.class public interface abstract Landroidx/media3/ui/PlayerControlView$OnFullScreenModeChangedListener;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/media3/ui/PlayerControlView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "OnFullScreenModeChangedListener"
.end annotation


# virtual methods
.method public abstract onFullScreenModeChanged(Z)V
.end method
