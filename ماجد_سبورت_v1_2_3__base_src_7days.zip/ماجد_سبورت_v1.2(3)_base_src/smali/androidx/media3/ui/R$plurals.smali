.class public abstract Landroidx/media3/ui/R$plurals;
.super Ljava/lang/Object;


# static fields
.field public static exo_controls_fastforward_by_amount_description:I = 0x7f100002

.field public static exo_controls_rewind_by_amount_description:I = 0x7f100003
