.class public final Landroidx/media3/common/Format$Builder;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/media3/common/Format;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation


# instance fields
.field public accessibilityChannel:I

.field public auxiliaryTrackType:I

.field public averageBitrate:I

.field public channelCount:I

.field public channelMask:I

.field public codecs:Ljava/lang/String;

.field public colorInfo:Landroidx/media3/common/ColorInfo;

.field public containerMimeType:Ljava/lang/String;

.field public cryptoType:I

.field public cueReplacementBehavior:I

.field public customData:Ljava/lang/Object;

.field public decodedHeight:I

.field public decodedWidth:I

.field public drmInitData:Landroidx/media3/common/DrmInitData;

.field public encoderDelay:I

.field public encoderPadding:I

.field public frameRate:F

.field public hasPrerollSamples:Z

.field public height:I

.field public id:Ljava/lang/String;

.field public initializationData:Ljava/util/List;

.field public label:Ljava/lang/String;

.field public labels:Ljava/util/List;

.field public language:Ljava/lang/String;

.field public maxInputSize:I

.field public maxNumReorderSamples:I

.field public maxSubLayers:I

.field public metadata:Landroidx/media3/common/Metadata;

.field public mirrorHorizontal:Z

.field public pcmEncoding:I

.field public peakBitrate:I

.field public pixelFormat:I

.field public pixelWidthHeightRatio:F

.field public primaryTrackGroupId:Ljava/lang/String;

.field public projectionData:[B

.field public roleFlags:I

.field public rotationDegrees:I

.field public sampleMimeType:Ljava/lang/String;

.field public sampleRate:I

.field public selectionFlags:I

.field public selectionPriority:F

.field public stereoMode:I

.field public subsampleOffsetUs:J

.field public tileCountHorizontal:I

.field public tileCountVertical:I

.field public width:I


# direct methods
.method public constructor <init>()V
    .locals 4

    .line 222
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 223
    invoke-static {}, Lcom/google/common/collect/ImmutableList;->of()Lcom/google/common/collect/ImmutableList;

    move-result-object v0

    iput-object v0, p0, Landroidx/media3/common/Format$Builder;->labels:Ljava/util/List;

    .line 224
    const/high16 v0, -0x40800000    # -1.0f

    iput v0, p0, Landroidx/media3/common/Format$Builder;->selectionPriority:F

    .line 225
    const/4 v1, -0x1

    iput v1, p0, Landroidx/media3/common/Format$Builder;->averageBitrate:I

    .line 226
    iput v1, p0, Landroidx/media3/common/Format$Builder;->peakBitrate:I

    .line 228
    iput v1, p0, Landroidx/media3/common/Format$Builder;->maxInputSize:I

    .line 229
    iput v1, p0, Landroidx/media3/common/Format$Builder;->maxNumReorderSamples:I

    .line 230
    const-wide v2, 0x7fffffffffffffffL

    iput-wide v2, p0, Landroidx/media3/common/Format$Builder;->subsampleOffsetUs:J

    .line 232
    iput v1, p0, Landroidx/media3/common/Format$Builder;->width:I

    .line 233
    iput v1, p0, Landroidx/media3/common/Format$Builder;->height:I

    .line 234
    iput v1, p0, Landroidx/media3/common/Format$Builder;->pixelFormat:I

    .line 235
    iput v1, p0, Landroidx/media3/common/Format$Builder;->decodedWidth:I

    .line 236
    iput v1, p0, Landroidx/media3/common/Format$Builder;->decodedHeight:I

    .line 237
    iput v0, p0, Landroidx/media3/common/Format$Builder;->frameRate:F

    .line 238
    const/high16 v0, 0x3f800000    # 1.0f

    iput v0, p0, Landroidx/media3/common/Format$Builder;->pixelWidthHeightRatio:F

    .line 239
    iput v1, p0, Landroidx/media3/common/Format$Builder;->stereoMode:I

    .line 240
    iput v1, p0, Landroidx/media3/common/Format$Builder;->maxSubLayers:I

    .line 242
    iput v1, p0, Landroidx/media3/common/Format$Builder;->channelCount:I

    .line 243
    iput v1, p0, Landroidx/media3/common/Format$Builder;->channelMask:I

    .line 244
    iput v1, p0, Landroidx/media3/common/Format$Builder;->sampleRate:I

    .line 245
    iput v1, p0, Landroidx/media3/common/Format$Builder;->pcmEncoding:I

    .line 247
    iput v1, p0, Landroidx/media3/common/Format$Builder;->accessibilityChannel:I

    .line 248
    const/4 v0, 0x1

    iput v0, p0, Landroidx/media3/common/Format$Builder;->cueReplacementBehavior:I

    .line 250
    iput v1, p0, Landroidx/media3/common/Format$Builder;->tileCountHorizontal:I

    .line 251
    iput v1, p0, Landroidx/media3/common/Format$Builder;->tileCountVertical:I

    .line 253
    const/4 v0, 0x0

    iput v0, p0, Landroidx/media3/common/Format$Builder;->cryptoType:I

    .line 254
    iput v0, p0, Landroidx/media3/common/Format$Builder;->auxiliaryTrackType:I

    .line 255
    return-void
.end method

.method public constructor <init>(Landroidx/media3/common/Format;)V
    .locals 2
    .param p1, "format"    # Landroidx/media3/common/Format;

    .line 262
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 263
    iget-object v0, p1, Landroidx/media3/common/Format;->id:Ljava/lang/String;

    iput-object v0, p0, Landroidx/media3/common/Format$Builder;->id:Ljava/lang/String;

    .line 264
    iget-object v0, p1, Landroidx/media3/common/Format;->label:Ljava/lang/String;

    iput-object v0, p0, Landroidx/media3/common/Format$Builder;->label:Ljava/lang/String;

    .line 265
    iget-object v0, p1, Landroidx/media3/common/Format;->labels:Ljava/util/List;

    iput-object v0, p0, Landroidx/media3/common/Format$Builder;->labels:Ljava/util/List;

    .line 266
    iget-object v0, p1, Landroidx/media3/common/Format;->language:Ljava/lang/String;

    iput-object v0, p0, Landroidx/media3/common/Format$Builder;->language:Ljava/lang/String;

    .line 267
    iget v0, p1, Landroidx/media3/common/Format;->selectionFlags:I

    iput v0, p0, Landroidx/media3/common/Format$Builder;->selectionFlags:I

    .line 268
    iget v0, p1, Landroidx/media3/common/Format;->roleFlags:I

    iput v0, p0, Landroidx/media3/common/Format$Builder;->roleFlags:I

    .line 269
    iget v0, p1, Landroidx/media3/common/Format;->selectionPriority:F

    iput v0, p0, Landroidx/media3/common/Format$Builder;->selectionPriority:F

    .line 270
    iget v0, p1, Landroidx/media3/common/Format;->averageBitrate:I

    iput v0, p0, Landroidx/media3/common/Format$Builder;->averageBitrate:I

    .line 271
    iget v0, p1, Landroidx/media3/common/Format;->peakBitrate:I

    iput v0, p0, Landroidx/media3/common/Format$Builder;->peakBitrate:I

    .line 272
    iget-object v0, p1, Landroidx/media3/common/Format;->codecs:Ljava/lang/String;

    iput-object v0, p0, Landroidx/media3/common/Format$Builder;->codecs:Ljava/lang/String;

    .line 273
    iget-object v0, p1, Landroidx/media3/common/Format;->metadata:Landroidx/media3/common/Metadata;

    iput-object v0, p0, Landroidx/media3/common/Format$Builder;->metadata:Landroidx/media3/common/Metadata;

    .line 274
    iget-object v0, p1, Landroidx/media3/common/Format;->customData:Ljava/lang/Object;

    iput-object v0, p0, Landroidx/media3/common/Format$Builder;->customData:Ljava/lang/Object;

    .line 275
    iget-object v0, p1, Landroidx/media3/common/Format;->primaryTrackGroupId:Ljava/lang/String;

    iput-object v0, p0, Landroidx/media3/common/Format$Builder;->primaryTrackGroupId:Ljava/lang/String;

    .line 277
    iget-object v0, p1, Landroidx/media3/common/Format;->containerMimeType:Ljava/lang/String;

    iput-object v0, p0, Landroidx/media3/common/Format$Builder;->containerMimeType:Ljava/lang/String;

    .line 279
    iget-object v0, p1, Landroidx/media3/common/Format;->sampleMimeType:Ljava/lang/String;

    iput-object v0, p0, Landroidx/media3/common/Format$Builder;->sampleMimeType:Ljava/lang/String;

    .line 280
    iget v0, p1, Landroidx/media3/common/Format;->maxInputSize:I

    iput v0, p0, Landroidx/media3/common/Format$Builder;->maxInputSize:I

    .line 281
    iget v0, p1, Landroidx/media3/common/Format;->maxNumReorderSamples:I

    iput v0, p0, Landroidx/media3/common/Format$Builder;->maxNumReorderSamples:I

    .line 282
    iget-object v0, p1, Landroidx/media3/common/Format;->initializationData:Ljava/util/List;

    iput-object v0, p0, Landroidx/media3/common/Format$Builder;->initializationData:Ljava/util/List;

    .line 283
    iget-object v0, p1, Landroidx/media3/common/Format;->drmInitData:Landroidx/media3/common/DrmInitData;

    iput-object v0, p0, Landroidx/media3/common/Format$Builder;->drmInitData:Landroidx/media3/common/DrmInitData;

    .line 284
    iget-wide v0, p1, Landroidx/media3/common/Format;->subsampleOffsetUs:J

    iput-wide v0, p0, Landroidx/media3/common/Format$Builder;->subsampleOffsetUs:J

    .line 285
    iget-boolean v0, p1, Landroidx/media3/common/Format;->hasPrerollSamples:Z

    iput-boolean v0, p0, Landroidx/media3/common/Format$Builder;->hasPrerollSamples:Z

    .line 287
    iget v0, p1, Landroidx/media3/common/Format;->width:I

    iput v0, p0, Landroidx/media3/common/Format$Builder;->width:I

    .line 288
    iget v0, p1, Landroidx/media3/common/Format;->height:I

    iput v0, p0, Landroidx/media3/common/Format$Builder;->height:I

    .line 289
    iget v0, p1, Landroidx/media3/common/Format;->pixelFormat:I

    iput v0, p0, Landroidx/media3/common/Format$Builder;->pixelFormat:I

    .line 290
    iget v0, p1, Landroidx/media3/common/Format;->decodedWidth:I

    iput v0, p0, Landroidx/media3/common/Format$Builder;->decodedWidth:I

    .line 291
    iget v0, p1, Landroidx/media3/common/Format;->decodedHeight:I

    iput v0, p0, Landroidx/media3/common/Format$Builder;->decodedHeight:I

    .line 292
    iget v0, p1, Landroidx/media3/common/Format;->frameRate:F

    iput v0, p0, Landroidx/media3/common/Format$Builder;->frameRate:F

    .line 293
    iget v0, p1, Landroidx/media3/common/Format;->rotationDegrees:I

    iput v0, p0, Landroidx/media3/common/Format$Builder;->rotationDegrees:I

    .line 294
    iget-boolean v0, p1, Landroidx/media3/common/Format;->mirrorHorizontal:Z

    iput-boolean v0, p0, Landroidx/media3/common/Format$Builder;->mirrorHorizontal:Z

    .line 295
    iget v0, p1, Landroidx/media3/common/Format;->pixelWidthHeightRatio:F

    iput v0, p0, Landroidx/media3/common/Format$Builder;->pixelWidthHeightRatio:F

    .line 296
    iget-object v0, p1, Landroidx/media3/common/Format;->projectionData:[B

    iput-object v0, p0, Landroidx/media3/common/Format$Builder;->projectionData:[B

    .line 297
    iget v0, p1, Landroidx/media3/common/Format;->stereoMode:I

    iput v0, p0, Landroidx/media3/common/Format$Builder;->stereoMode:I

    .line 298
    iget-object v0, p1, Landroidx/media3/common/Format;->colorInfo:Landroidx/media3/common/ColorInfo;

    iput-object v0, p0, Landroidx/media3/common/Format$Builder;->colorInfo:Landroidx/media3/common/ColorInfo;

    .line 299
    iget v0, p1, Landroidx/media3/common/Format;->maxSubLayers:I

    iput v0, p0, Landroidx/media3/common/Format$Builder;->maxSubLayers:I

    .line 301
    iget v0, p1, Landroidx/media3/common/Format;->channelCount:I

    iput v0, p0, Landroidx/media3/common/Format$Builder;->channelCount:I

    .line 302
    iget v0, p1, Landroidx/media3/common/Format;->channelMask:I

    iput v0, p0, Landroidx/media3/common/Format$Builder;->channelMask:I

    .line 303
    iget v0, p1, Landroidx/media3/common/Format;->sampleRate:I

    iput v0, p0, Landroidx/media3/common/Format$Builder;->sampleRate:I

    .line 304
    iget v0, p1, Landroidx/media3/common/Format;->pcmEncoding:I

    iput v0, p0, Landroidx/media3/common/Format$Builder;->pcmEncoding:I

    .line 305
    iget v0, p1, Landroidx/media3/common/Format;->encoderDelay:I

    iput v0, p0, Landroidx/media3/common/Format$Builder;->encoderDelay:I

    .line 306
    iget v0, p1, Landroidx/media3/common/Format;->encoderPadding:I

    iput v0, p0, Landroidx/media3/common/Format$Builder;->encoderPadding:I

    .line 308
    iget v0, p1, Landroidx/media3/common/Format;->accessibilityChannel:I

    iput v0, p0, Landroidx/media3/common/Format$Builder;->accessibilityChannel:I

    .line 309
    iget v0, p1, Landroidx/media3/common/Format;->cueReplacementBehavior:I

    iput v0, p0, Landroidx/media3/common/Format$Builder;->cueReplacementBehavior:I

    .line 311
    iget v0, p1, Landroidx/media3/common/Format;->tileCountHorizontal:I

    iput v0, p0, Landroidx/media3/common/Format$Builder;->tileCountHorizontal:I

    .line 312
    iget v0, p1, Landroidx/media3/common/Format;->tileCountVertical:I

    iput v0, p0, Landroidx/media3/common/Format$Builder;->tileCountVertical:I

    .line 314
    iget v0, p1, Landroidx/media3/common/Format;->cryptoType:I

    iput v0, p0, Landroidx/media3/common/Format$Builder;->cryptoType:I

    .line 315
    return-void
.end method

.method public synthetic constructor <init>(Landroidx/media3/common/Format;Landroidx/media3/common/Format$1;)V
    .locals 0
    .param p1, "x0"    # Landroidx/media3/common/Format;
    .param p2, "x1"    # Landroidx/media3/common/Format$1;

    .line 151
    invoke-direct {p0, p1}, Landroidx/media3/common/Format$Builder;-><init>(Landroidx/media3/common/Format;)V

    return-void
.end method

.method public static synthetic access$100(Landroidx/media3/common/Format$Builder;)Ljava/util/List;
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget-object v0, p0, Landroidx/media3/common/Format$Builder;->labels:Ljava/util/List;

    return-object v0
.end method

.method public static synthetic access$1000(Landroidx/media3/common/Format$Builder;)I
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget v0, p0, Landroidx/media3/common/Format$Builder;->peakBitrate:I

    return v0
.end method

.method public static synthetic access$1100(Landroidx/media3/common/Format$Builder;)Ljava/lang/String;
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget-object v0, p0, Landroidx/media3/common/Format$Builder;->codecs:Ljava/lang/String;

    return-object v0
.end method

.method public static synthetic access$1200(Landroidx/media3/common/Format$Builder;)Landroidx/media3/common/Metadata;
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget-object v0, p0, Landroidx/media3/common/Format$Builder;->metadata:Landroidx/media3/common/Metadata;

    return-object v0
.end method

.method public static synthetic access$1300(Landroidx/media3/common/Format$Builder;)Ljava/lang/Object;
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget-object v0, p0, Landroidx/media3/common/Format$Builder;->customData:Ljava/lang/Object;

    return-object v0
.end method

.method public static synthetic access$1400(Landroidx/media3/common/Format$Builder;)Ljava/lang/String;
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget-object v0, p0, Landroidx/media3/common/Format$Builder;->primaryTrackGroupId:Ljava/lang/String;

    return-object v0
.end method

.method public static synthetic access$1500(Landroidx/media3/common/Format$Builder;)Ljava/lang/String;
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget-object v0, p0, Landroidx/media3/common/Format$Builder;->containerMimeType:Ljava/lang/String;

    return-object v0
.end method

.method public static synthetic access$1600(Landroidx/media3/common/Format$Builder;)Ljava/lang/String;
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget-object v0, p0, Landroidx/media3/common/Format$Builder;->sampleMimeType:Ljava/lang/String;

    return-object v0
.end method

.method public static synthetic access$1700(Landroidx/media3/common/Format$Builder;)I
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget v0, p0, Landroidx/media3/common/Format$Builder;->maxInputSize:I

    return v0
.end method

.method public static synthetic access$1800(Landroidx/media3/common/Format$Builder;)I
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget v0, p0, Landroidx/media3/common/Format$Builder;->maxNumReorderSamples:I

    return v0
.end method

.method public static synthetic access$1900(Landroidx/media3/common/Format$Builder;)Ljava/util/List;
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget-object v0, p0, Landroidx/media3/common/Format$Builder;->initializationData:Ljava/util/List;

    return-object v0
.end method

.method public static synthetic access$200(Landroidx/media3/common/Format$Builder;)Ljava/lang/String;
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget-object v0, p0, Landroidx/media3/common/Format$Builder;->label:Ljava/lang/String;

    return-object v0
.end method

.method public static synthetic access$2000(Landroidx/media3/common/Format$Builder;)Landroidx/media3/common/DrmInitData;
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget-object v0, p0, Landroidx/media3/common/Format$Builder;->drmInitData:Landroidx/media3/common/DrmInitData;

    return-object v0
.end method

.method public static synthetic access$2100(Landroidx/media3/common/Format$Builder;)J
    .locals 2
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget-wide v0, p0, Landroidx/media3/common/Format$Builder;->subsampleOffsetUs:J

    return-wide v0
.end method

.method public static synthetic access$2200(Landroidx/media3/common/Format$Builder;)Z
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget-boolean v0, p0, Landroidx/media3/common/Format$Builder;->hasPrerollSamples:Z

    return v0
.end method

.method public static synthetic access$2300(Landroidx/media3/common/Format$Builder;)I
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget v0, p0, Landroidx/media3/common/Format$Builder;->width:I

    return v0
.end method

.method public static synthetic access$2400(Landroidx/media3/common/Format$Builder;)I
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget v0, p0, Landroidx/media3/common/Format$Builder;->height:I

    return v0
.end method

.method public static synthetic access$2500(Landroidx/media3/common/Format$Builder;)I
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget v0, p0, Landroidx/media3/common/Format$Builder;->pixelFormat:I

    return v0
.end method

.method public static synthetic access$2600(Landroidx/media3/common/Format$Builder;)I
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget v0, p0, Landroidx/media3/common/Format$Builder;->decodedWidth:I

    return v0
.end method

.method public static synthetic access$2700(Landroidx/media3/common/Format$Builder;)I
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget v0, p0, Landroidx/media3/common/Format$Builder;->decodedHeight:I

    return v0
.end method

.method public static synthetic access$2800(Landroidx/media3/common/Format$Builder;)F
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget v0, p0, Landroidx/media3/common/Format$Builder;->frameRate:F

    return v0
.end method

.method public static synthetic access$2900(Landroidx/media3/common/Format$Builder;)I
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget v0, p0, Landroidx/media3/common/Format$Builder;->rotationDegrees:I

    return v0
.end method

.method public static synthetic access$300(Landroidx/media3/common/Format$Builder;)Ljava/lang/String;
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget-object v0, p0, Landroidx/media3/common/Format$Builder;->id:Ljava/lang/String;

    return-object v0
.end method

.method public static synthetic access$3000(Landroidx/media3/common/Format$Builder;)Z
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget-boolean v0, p0, Landroidx/media3/common/Format$Builder;->mirrorHorizontal:Z

    return v0
.end method

.method public static synthetic access$3100(Landroidx/media3/common/Format$Builder;)F
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget v0, p0, Landroidx/media3/common/Format$Builder;->pixelWidthHeightRatio:F

    return v0
.end method

.method public static synthetic access$3200(Landroidx/media3/common/Format$Builder;)[B
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget-object v0, p0, Landroidx/media3/common/Format$Builder;->projectionData:[B

    return-object v0
.end method

.method public static synthetic access$3300(Landroidx/media3/common/Format$Builder;)I
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget v0, p0, Landroidx/media3/common/Format$Builder;->stereoMode:I

    return v0
.end method

.method public static synthetic access$3400(Landroidx/media3/common/Format$Builder;)Landroidx/media3/common/ColorInfo;
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget-object v0, p0, Landroidx/media3/common/Format$Builder;->colorInfo:Landroidx/media3/common/ColorInfo;

    return-object v0
.end method

.method public static synthetic access$3500(Landroidx/media3/common/Format$Builder;)I
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget v0, p0, Landroidx/media3/common/Format$Builder;->maxSubLayers:I

    return v0
.end method

.method public static synthetic access$3600(Landroidx/media3/common/Format$Builder;)I
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget v0, p0, Landroidx/media3/common/Format$Builder;->channelCount:I

    return v0
.end method

.method public static synthetic access$3700(Landroidx/media3/common/Format$Builder;)I
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget v0, p0, Landroidx/media3/common/Format$Builder;->channelMask:I

    return v0
.end method

.method public static synthetic access$3800(Landroidx/media3/common/Format$Builder;)I
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget v0, p0, Landroidx/media3/common/Format$Builder;->sampleRate:I

    return v0
.end method

.method public static synthetic access$3900(Landroidx/media3/common/Format$Builder;)I
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget v0, p0, Landroidx/media3/common/Format$Builder;->pcmEncoding:I

    return v0
.end method

.method public static synthetic access$400(Landroidx/media3/common/Format$Builder;)Ljava/lang/String;
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget-object v0, p0, Landroidx/media3/common/Format$Builder;->language:Ljava/lang/String;

    return-object v0
.end method

.method public static synthetic access$4000(Landroidx/media3/common/Format$Builder;)I
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget v0, p0, Landroidx/media3/common/Format$Builder;->encoderDelay:I

    return v0
.end method

.method public static synthetic access$4100(Landroidx/media3/common/Format$Builder;)I
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget v0, p0, Landroidx/media3/common/Format$Builder;->encoderPadding:I

    return v0
.end method

.method public static synthetic access$4200(Landroidx/media3/common/Format$Builder;)I
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget v0, p0, Landroidx/media3/common/Format$Builder;->accessibilityChannel:I

    return v0
.end method

.method public static synthetic access$4300(Landroidx/media3/common/Format$Builder;)I
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget v0, p0, Landroidx/media3/common/Format$Builder;->cueReplacementBehavior:I

    return v0
.end method

.method public static synthetic access$4400(Landroidx/media3/common/Format$Builder;)I
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget v0, p0, Landroidx/media3/common/Format$Builder;->tileCountHorizontal:I

    return v0
.end method

.method public static synthetic access$4500(Landroidx/media3/common/Format$Builder;)I
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget v0, p0, Landroidx/media3/common/Format$Builder;->tileCountVertical:I

    return v0
.end method

.method public static synthetic access$4600(Landroidx/media3/common/Format$Builder;)I
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget v0, p0, Landroidx/media3/common/Format$Builder;->cryptoType:I

    return v0
.end method

.method public static synthetic access$500(Landroidx/media3/common/Format$Builder;)I
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget v0, p0, Landroidx/media3/common/Format$Builder;->selectionFlags:I

    return v0
.end method

.method public static synthetic access$600(Landroidx/media3/common/Format$Builder;)I
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget v0, p0, Landroidx/media3/common/Format$Builder;->auxiliaryTrackType:I

    return v0
.end method

.method public static synthetic access$700(Landroidx/media3/common/Format$Builder;)I
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget v0, p0, Landroidx/media3/common/Format$Builder;->roleFlags:I

    return v0
.end method

.method public static synthetic access$800(Landroidx/media3/common/Format$Builder;)F
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget v0, p0, Landroidx/media3/common/Format$Builder;->selectionPriority:F

    return v0
.end method

.method public static synthetic access$900(Landroidx/media3/common/Format$Builder;)I
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/Format$Builder;

    .line 151
    iget v0, p0, Landroidx/media3/common/Format$Builder;->averageBitrate:I

    return v0
.end method


# virtual methods
.method public build()Landroidx/media3/common/Format;
    .locals 2

    .line 934
    new-instance v0, Landroidx/media3/common/Format;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Landroidx/media3/common/Format;-><init>(Landroidx/media3/common/Format$Builder;Landroidx/media3/common/Format$1;)V

    return-object v0
.end method

.method public setAccessibilityChannel(I)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "accessibilityChannel"    # I

    .line 874
    iput p1, p0, Landroidx/media3/common/Format$Builder;->accessibilityChannel:I

    .line 875
    return-object p0
.end method

.method public setAuxiliaryTrackType(I)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "auxiliaryTrackType"    # I

    .line 435
    iput p1, p0, Landroidx/media3/common/Format$Builder;->auxiliaryTrackType:I

    .line 436
    return-object p0
.end method

.method public setAverageBitrate(I)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "averageBitrate"    # I

    .line 447
    iput p1, p0, Landroidx/media3/common/Format$Builder;->averageBitrate:I

    .line 448
    return-object p0
.end method

.method public setChannelCount(I)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "channelCount"    # I

    .line 796
    iput p1, p0, Landroidx/media3/common/Format$Builder;->channelCount:I

    .line 797
    return-object p0
.end method

.method public setChannelMask(I)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "channelMask"    # I

    .line 812
    iput p1, p0, Landroidx/media3/common/Format$Builder;->channelMask:I

    .line 813
    return-object p0
.end method

.method public setCodecs(Ljava/lang/String;)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "codecs"    # Ljava/lang/String;

    .line 471
    iput-object p1, p0, Landroidx/media3/common/Format$Builder;->codecs:Ljava/lang/String;

    .line 472
    return-object p0
.end method

.method public setColorInfo(Landroidx/media3/common/ColorInfo;)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "colorInfo"    # Landroidx/media3/common/ColorInfo;

    .line 766
    iput-object p1, p0, Landroidx/media3/common/Format$Builder;->colorInfo:Landroidx/media3/common/ColorInfo;

    .line 767
    return-object p0
.end method

.method public setContainerMimeType(Ljava/lang/String;)Landroidx/media3/common/Format$Builder;
    .locals 1
    .param p1, "containerMimeType"    # Ljava/lang/String;

    .line 531
    invoke-static {p1}, Landroidx/media3/common/MimeTypes;->normalizeMimeType(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Landroidx/media3/common/Format$Builder;->containerMimeType:Ljava/lang/String;

    .line 532
    return-object p0
.end method

.method public setCryptoType(I)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "cryptoType"    # I

    .line 927
    iput p1, p0, Landroidx/media3/common/Format$Builder;->cryptoType:I

    .line 928
    return-object p0
.end method

.method public setCueReplacementBehavior(I)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "cueReplacementBehavior"    # I

    .line 887
    iput p1, p0, Landroidx/media3/common/Format$Builder;->cueReplacementBehavior:I

    .line 888
    return-object p0
.end method

.method public setCustomData(Ljava/lang/Object;)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "customData"    # Ljava/lang/Object;

    .line 499
    iput-object p1, p0, Landroidx/media3/common/Format$Builder;->customData:Ljava/lang/Object;

    .line 500
    return-object p0
.end method

.method public setDecodedHeight(I)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "decodedHeight"    # I

    .line 681
    iput p1, p0, Landroidx/media3/common/Format$Builder;->decodedHeight:I

    .line 682
    return-object p0
.end method

.method public setDecodedWidth(I)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "decodedWidth"    # I

    .line 669
    iput p1, p0, Landroidx/media3/common/Format$Builder;->decodedWidth:I

    .line 670
    return-object p0
.end method

.method public setDrmInitData(Landroidx/media3/common/DrmInitData;)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "drmInitData"    # Landroidx/media3/common/DrmInitData;

    .line 593
    iput-object p1, p0, Landroidx/media3/common/Format$Builder;->drmInitData:Landroidx/media3/common/DrmInitData;

    .line 594
    return-object p0
.end method

.method public setEncoderDelay(I)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "encoderDelay"    # I

    .line 848
    iput p1, p0, Landroidx/media3/common/Format$Builder;->encoderDelay:I

    .line 849
    return-object p0
.end method

.method public setEncoderPadding(I)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "encoderPadding"    # I

    .line 860
    iput p1, p0, Landroidx/media3/common/Format$Builder;->encoderPadding:I

    .line 861
    return-object p0
.end method

.method public setFrameRate(F)Landroidx/media3/common/Format$Builder;
    .locals 1
    .param p1, "frameRate"    # F

    .line 693
    const/high16 v0, -0x40800000    # -1.0f

    cmpl-float v0, p1, v0

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    cmpl-float v0, p1, v0

    if-lez v0, :cond_1

    :cond_0
    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    goto :goto_1

    :goto_0
    const/4 v0, 0x1

    :goto_1
    invoke-static {v0}, Lcom/google/common/base/Preconditions;->checkArgument(Z)V

    .line 694
    iput p1, p0, Landroidx/media3/common/Format$Builder;->frameRate:F

    .line 695
    return-object p0
.end method

.method public setHasPrerollSamples(Z)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "hasPrerollSamples"    # Z

    .line 617
    iput-boolean p1, p0, Landroidx/media3/common/Format$Builder;->hasPrerollSamples:Z

    .line 618
    return-object p0
.end method

.method public setHeight(I)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "height"    # I

    .line 643
    iput p1, p0, Landroidx/media3/common/Format$Builder;->height:I

    .line 644
    return-object p0
.end method

.method public setId(I)Landroidx/media3/common/Format$Builder;
    .locals 1
    .param p1, "id"    # I

    .line 338
    invoke-static {p1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Landroidx/media3/common/Format$Builder;->id:Ljava/lang/String;

    .line 339
    return-object p0
.end method

.method public setId(Ljava/lang/String;)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "id"    # Ljava/lang/String;

    .line 325
    iput-object p1, p0, Landroidx/media3/common/Format$Builder;->id:Ljava/lang/String;

    .line 326
    return-object p0
.end method

.method public setInitializationData(Ljava/util/List;)Landroidx/media3/common/Format$Builder;
    .locals 0

    .line 581
    .local p1, "initializationData":Ljava/util/List;, "Ljava/util/List<[B>;"
    iput-object p1, p0, Landroidx/media3/common/Format$Builder;->initializationData:Ljava/util/List;

    .line 582
    return-object p0
.end method

.method public setLabel(Ljava/lang/String;)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "label"    # Ljava/lang/String;

    .line 353
    iput-object p1, p0, Landroidx/media3/common/Format$Builder;->label:Ljava/lang/String;

    .line 354
    return-object p0
.end method

.method public setLabels(Ljava/util/List;)Landroidx/media3/common/Format$Builder;
    .locals 1

    .line 368
    .local p1, "labels":Ljava/util/List;, "Ljava/util/List<Landroidx/media3/common/Label;>;"
    invoke-static {p1}, Lcom/google/common/collect/ImmutableList;->copyOf(Ljava/util/Collection;)Lcom/google/common/collect/ImmutableList;

    move-result-object v0

    iput-object v0, p0, Landroidx/media3/common/Format$Builder;->labels:Ljava/util/List;

    .line 369
    return-object p0
.end method

.method public setLanguage(Ljava/lang/String;)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "language"    # Ljava/lang/String;

    .line 380
    iput-object p1, p0, Landroidx/media3/common/Format$Builder;->language:Ljava/lang/String;

    .line 381
    return-object p0
.end method

.method public setMaxInputSize(I)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "maxInputSize"    # I

    .line 557
    iput p1, p0, Landroidx/media3/common/Format$Builder;->maxInputSize:I

    .line 558
    return-object p0
.end method

.method public setMaxNumReorderSamples(I)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "maxNumReorderSamples"    # I

    .line 569
    iput p1, p0, Landroidx/media3/common/Format$Builder;->maxNumReorderSamples:I

    .line 570
    return-object p0
.end method

.method public setMaxSubLayers(I)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "maxSubLayers"    # I

    .line 778
    iput p1, p0, Landroidx/media3/common/Format$Builder;->maxSubLayers:I

    .line 779
    return-object p0
.end method

.method public setMetadata(Landroidx/media3/common/Metadata;)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "metadata"    # Landroidx/media3/common/Metadata;

    .line 483
    iput-object p1, p0, Landroidx/media3/common/Format$Builder;->metadata:Landroidx/media3/common/Metadata;

    .line 484
    return-object p0
.end method

.method public setMirrorHorizontal(Z)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "mirrorHorizontal"    # Z

    .line 718
    iput-boolean p1, p0, Landroidx/media3/common/Format$Builder;->mirrorHorizontal:Z

    .line 719
    return-object p0
.end method

.method public setPcmEncoding(I)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "pcmEncoding"    # I

    .line 836
    iput p1, p0, Landroidx/media3/common/Format$Builder;->pcmEncoding:I

    .line 837
    return-object p0
.end method

.method public setPeakBitrate(I)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "peakBitrate"    # I

    .line 459
    iput p1, p0, Landroidx/media3/common/Format$Builder;->peakBitrate:I

    .line 460
    return-object p0
.end method

.method public setPixelWidthHeightRatio(F)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "pixelWidthHeightRatio"    # F

    .line 730
    iput p1, p0, Landroidx/media3/common/Format$Builder;->pixelWidthHeightRatio:F

    .line 731
    return-object p0
.end method

.method public setPrimaryTrackGroupId(Ljava/lang/String;)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "primaryTrackGroupId"    # Ljava/lang/String;

    .line 517
    iput-object p1, p0, Landroidx/media3/common/Format$Builder;->primaryTrackGroupId:Ljava/lang/String;

    .line 518
    return-object p0
.end method

.method public setProjectionData([B)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "projectionData"    # [B

    .line 742
    iput-object p1, p0, Landroidx/media3/common/Format$Builder;->projectionData:[B

    .line 743
    return-object p0
.end method

.method public setRoleFlags(I)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "roleFlags"    # I

    .line 407
    iput p1, p0, Landroidx/media3/common/Format$Builder;->roleFlags:I

    .line 408
    return-object p0
.end method

.method public setRotationDegrees(I)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "rotationDegrees"    # I

    .line 706
    iput p1, p0, Landroidx/media3/common/Format$Builder;->rotationDegrees:I

    .line 707
    return-object p0
.end method

.method public setSampleMimeType(Ljava/lang/String;)Landroidx/media3/common/Format$Builder;
    .locals 1
    .param p1, "sampleMimeType"    # Ljava/lang/String;

    .line 545
    invoke-static {p1}, Landroidx/media3/common/MimeTypes;->normalizeMimeType(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Landroidx/media3/common/Format$Builder;->sampleMimeType:Ljava/lang/String;

    .line 546
    return-object p0
.end method

.method public setSampleRate(I)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "sampleRate"    # I

    .line 824
    iput p1, p0, Landroidx/media3/common/Format$Builder;->sampleRate:I

    .line 825
    return-object p0
.end method

.method public setSelectionFlags(I)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "selectionFlags"    # I

    .line 392
    iput p1, p0, Landroidx/media3/common/Format$Builder;->selectionFlags:I

    .line 393
    return-object p0
.end method

.method public setSelectionPriority(F)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "selectionPriority"    # F

    .line 419
    iput p1, p0, Landroidx/media3/common/Format$Builder;->selectionPriority:F

    .line 420
    return-object p0
.end method

.method public setStereoMode(I)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "stereoMode"    # I

    .line 754
    iput p1, p0, Landroidx/media3/common/Format$Builder;->stereoMode:I

    .line 755
    return-object p0
.end method

.method public setSubsampleOffsetUs(J)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "subsampleOffsetUs"    # J

    .line 605
    iput-wide p1, p0, Landroidx/media3/common/Format$Builder;->subsampleOffsetUs:J

    .line 606
    return-object p0
.end method

.method public setTileCountHorizontal(I)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "tileCountHorizontal"    # I

    .line 901
    iput p1, p0, Landroidx/media3/common/Format$Builder;->tileCountHorizontal:I

    .line 902
    return-object p0
.end method

.method public setTileCountVertical(I)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "tileCountVertical"    # I

    .line 913
    iput p1, p0, Landroidx/media3/common/Format$Builder;->tileCountVertical:I

    .line 914
    return-object p0
.end method

.method public setWidth(I)Landroidx/media3/common/Format$Builder;
    .locals 0
    .param p1, "width"    # I

    .line 631
    iput p1, p0, Landroidx/media3/common/Format$Builder;->width:I

    .line 632
    return-object p0
.end method
