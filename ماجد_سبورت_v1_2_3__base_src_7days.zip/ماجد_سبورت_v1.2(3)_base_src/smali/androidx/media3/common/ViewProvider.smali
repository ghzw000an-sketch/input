.class public interface abstract Landroidx/media3/common/ViewProvider;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract getView(Landroid/view/ViewGroup;)Lcom/google/common/util/concurrent/ListenableFuture;
.end method
