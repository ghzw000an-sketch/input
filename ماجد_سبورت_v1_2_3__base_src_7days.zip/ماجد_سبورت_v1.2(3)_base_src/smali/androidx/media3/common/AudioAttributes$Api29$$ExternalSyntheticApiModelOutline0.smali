.class public abstract synthetic Landroidx/media3/common/AudioAttributes$Api29$$ExternalSyntheticApiModelOutline0;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static bridge synthetic m(Landroid/media/AudioAttributes$Builder;Z)Landroid/media/AudioAttributes$Builder;
    .locals 0

    .line 0
    invoke-virtual {p0, p1}, Landroid/media/AudioAttributes$Builder;->setHapticChannelsMuted(Z)Landroid/media/AudioAttributes$Builder;

    move-result-object p0

    return-object p0
.end method
