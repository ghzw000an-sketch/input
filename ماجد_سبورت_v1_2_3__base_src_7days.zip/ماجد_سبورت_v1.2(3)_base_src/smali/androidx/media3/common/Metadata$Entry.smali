.class public interface abstract Landroidx/media3/common/Metadata$Entry;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/media3/common/Metadata;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "Entry"
.end annotation


# virtual methods
.method public getWrappedMetadataBytes()[B
    .locals 1

    .line 50
    const/4 v0, 0x0

    return-object v0
.end method

.method public getWrappedMetadataFormat()Landroidx/media3/common/Format;
    .locals 1

    .line 41
    const/4 v0, 0x0

    return-object v0
.end method

.method public populateMediaMetadata(Landroidx/media3/common/MediaMetadata$Builder;)V
    .locals 0
    .param p1, "builder"    # Landroidx/media3/common/MediaMetadata$Builder;

    .line 59
    return-void
.end method
