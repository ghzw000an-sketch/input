.class public abstract Landroidx/media3/common/AudioAttributes$Api29;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/media3/common/AudioAttributes;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Api29"
.end annotation


# direct methods
.method public static synthetic access$300(Landroid/media/AudioAttributes$Builder;Z)V
    .locals 0
    .param p0, "x0"    # Landroid/media/AudioAttributes$Builder;
    .param p1, "x1"    # Z

    .line 421
    invoke-static {p0, p1}, Landroidx/media3/common/AudioAttributes$Api29;->setHapticChannelsMuted(Landroid/media/AudioAttributes$Builder;Z)V

    return-void
.end method

.method public static setAllowedCapturePolicy(Landroid/media/AudioAttributes$Builder;I)V
    .locals 0
    .param p0, "builder"    # Landroid/media/AudioAttributes$Builder;
    .param p1, "allowedCapturePolicy"    # I

    .line 426
    invoke-static {p0, p1}, Landroidx/media3/common/AudioAttributes$Api29$$ExternalSyntheticApiModelOutline1;->m(Landroid/media/AudioAttributes$Builder;I)Landroid/media/AudioAttributes$Builder;

    .line 427
    return-void
.end method

.method public static setHapticChannelsMuted(Landroid/media/AudioAttributes$Builder;Z)V
    .locals 0
    .param p0, "builder"    # Landroid/media/AudioAttributes$Builder;
    .param p1, "hapticChannelsMuted"    # Z

    .line 431
    invoke-static {p0, p1}, Landroidx/media3/common/AudioAttributes$Api29$$ExternalSyntheticApiModelOutline0;->m(Landroid/media/AudioAttributes$Builder;Z)Landroid/media/AudioAttributes$Builder;

    .line 432
    return-void
.end method
