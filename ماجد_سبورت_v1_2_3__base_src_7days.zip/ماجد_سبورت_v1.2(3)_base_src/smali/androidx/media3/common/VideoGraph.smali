.class public interface abstract Landroidx/media3/common/VideoGraph;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/media3/common/VideoGraph$Listener;,
        Landroidx/media3/common/VideoGraph$Factory;
    }
.end annotation


# virtual methods
.method public abstract flush()V
.end method

.method public abstract getInputSurface(I)Landroid/view/Surface;
.end method

.method public abstract getPendingInputFrameCount(I)I
.end method

.method public abstract redraw()V
.end method

.method public abstract registerInput(I)V
.end method

.method public abstract registerInputStream(IILandroidx/media3/common/Format;Ljava/util/List;J)V
.end method

.method public abstract renderOutputFrame(J)V
.end method

.method public abstract setCompositionEffects(Ljava/util/List;)V
.end method
