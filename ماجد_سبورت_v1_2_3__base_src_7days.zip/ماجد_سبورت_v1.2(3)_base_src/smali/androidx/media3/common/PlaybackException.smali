.class public abstract Landroidx/media3/common/PlaybackException;
.super Ljava/lang/Exception;
.source ""


# static fields
.field public static final FIELD_BUNDLE_EXTRAS:Ljava/lang/String;

.field public static final FIELD_INT_ERROR_CODE:Ljava/lang/String;

.field public static final FIELD_LONG_TIMESTAMP_MS:Ljava/lang/String;

.field public static final FIELD_STRING_CAUSE_CLASS_NAME:Ljava/lang/String;

.field public static final FIELD_STRING_CAUSE_MESSAGE:Ljava/lang/String;

.field public static final FIELD_STRING_MESSAGE:Ljava/lang/String;


# instance fields
.field public final errorCode:I

.field public final extras:Landroid/os/Bundle;

.field public final timestampMs:J


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 587
    const/4 v0, 0x0

    invoke-static {v0}, Landroidx/media3/common/util/Util;->intToStringMaxRadix(I)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Landroidx/media3/common/PlaybackException;->FIELD_INT_ERROR_CODE:Ljava/lang/String;

    .line 588
    const/4 v0, 0x1

    invoke-static {v0}, Landroidx/media3/common/util/Util;->intToStringMaxRadix(I)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Landroidx/media3/common/PlaybackException;->FIELD_LONG_TIMESTAMP_MS:Ljava/lang/String;

    .line 589
    const/4 v0, 0x2

    invoke-static {v0}, Landroidx/media3/common/util/Util;->intToStringMaxRadix(I)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Landroidx/media3/common/PlaybackException;->FIELD_STRING_MESSAGE:Ljava/lang/String;

    .line 590
    const/4 v0, 0x3

    invoke-static {v0}, Landroidx/media3/common/util/Util;->intToStringMaxRadix(I)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Landroidx/media3/common/PlaybackException;->FIELD_STRING_CAUSE_CLASS_NAME:Ljava/lang/String;

    .line 591
    const/4 v0, 0x4

    invoke-static {v0}, Landroidx/media3/common/util/Util;->intToStringMaxRadix(I)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Landroidx/media3/common/PlaybackException;->FIELD_STRING_CAUSE_MESSAGE:Ljava/lang/String;

    .line 592
    const/4 v0, 0x5

    invoke-static {v0}, Landroidx/media3/common/util/Util;->intToStringMaxRadix(I)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Landroidx/media3/common/PlaybackException;->FIELD_BUNDLE_EXTRAS:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/Throwable;ILandroid/os/Bundle;J)V
    .locals 0
    .param p1, "message"    # Ljava/lang/String;
    .param p2, "cause"    # Ljava/lang/Throwable;
    .param p3, "errorCode"    # I
    .param p4, "extras"    # Landroid/os/Bundle;
    .param p5, "timestampMs"    # J

    .line 534
    invoke-direct {p0, p1, p2}, Ljava/lang/Exception;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 535
    iput p3, p0, Landroidx/media3/common/PlaybackException;->errorCode:I

    .line 536
    iput-object p4, p0, Landroidx/media3/common/PlaybackException;->extras:Landroid/os/Bundle;

    .line 537
    iput-wide p5, p0, Landroidx/media3/common/PlaybackException;->timestampMs:J

    .line 538
    return-void
.end method

.method public static getErrorCodeName(I)Ljava/lang/String;
    .locals 1
    .param p0, "errorCode"    # I

    .line 348
    sparse-switch p0, :sswitch_data_0

    .line 456
    const v0, 0xf4240

    if-lt p0, v0, :cond_0

    .line 457
    const-string v0, "custom error code"

    return-object v0

    .line 459
    :cond_0
    const-string v0, "invalid error code"

    return-object v0

    .line 454
    :sswitch_0
    const-string v0, "ERROR_CODE_VIDEO_FRAME_PROCESSING_FAILED"

    return-object v0

    .line 452
    :sswitch_1
    const-string v0, "ERROR_CODE_VIDEO_FRAME_PROCESSOR_INIT_FAILED"

    return-object v0

    .line 450
    :sswitch_2
    const-string v0, "ERROR_CODE_DRM_LICENSE_EXPIRED"

    return-object v0

    .line 448
    :sswitch_3
    const-string v0, "ERROR_CODE_DRM_DEVICE_REVOKED"

    return-object v0

    .line 446
    :sswitch_4
    const-string v0, "ERROR_CODE_DRM_SYSTEM_ERROR"

    return-object v0

    .line 444
    :sswitch_5
    const-string v0, "ERROR_CODE_DRM_DISALLOWED_OPERATION"

    return-object v0

    .line 442
    :sswitch_6
    const-string v0, "ERROR_CODE_DRM_LICENSE_ACQUISITION_FAILED"

    return-object v0

    .line 440
    :sswitch_7
    const-string v0, "ERROR_CODE_DRM_CONTENT_ERROR"

    return-object v0

    .line 438
    :sswitch_8
    const-string v0, "ERROR_CODE_DRM_PROVISIONING_FAILED"

    return-object v0

    .line 436
    :sswitch_9
    const-string v0, "ERROR_CODE_DRM_SCHEME_UNSUPPORTED"

    return-object v0

    .line 434
    :sswitch_a
    const-string v0, "ERROR_CODE_DRM_UNSPECIFIED"

    return-object v0

    .line 432
    :sswitch_b
    const-string v0, "ERROR_CODE_AUDIO_TRACK_OFFLOAD_INIT_FAILED"

    return-object v0

    .line 430
    :sswitch_c
    const-string v0, "ERROR_CODE_AUDIO_TRACK_OFFLOAD_WRITE_FAILED"

    return-object v0

    .line 428
    :sswitch_d
    const-string v0, "ERROR_CODE_AUDIO_TRACK_WRITE_FAILED"

    return-object v0

    .line 426
    :sswitch_e
    const-string v0, "ERROR_CODE_AUDIO_TRACK_INIT_FAILED"

    return-object v0

    .line 424
    :sswitch_f
    const-string v0, "ERROR_CODE_DECODING_RESOURCES_RECLAIMED"

    return-object v0

    .line 422
    :sswitch_10
    const-string v0, "ERROR_CODE_DECODING_FORMAT_UNSUPPORTED"

    return-object v0

    .line 420
    :sswitch_11
    const-string v0, "ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES"

    return-object v0

    .line 418
    :sswitch_12
    const-string v0, "ERROR_CODE_DECODING_FAILED"

    return-object v0

    .line 416
    :sswitch_13
    const-string v0, "ERROR_CODE_DECODER_QUERY_FAILED"

    return-object v0

    .line 414
    :sswitch_14
    const-string v0, "ERROR_CODE_DECODER_INIT_FAILED"

    return-object v0

    .line 412
    :sswitch_15
    const-string v0, "ERROR_CODE_PARSING_MANIFEST_UNSUPPORTED"

    return-object v0

    .line 410
    :sswitch_16
    const-string v0, "ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED"

    return-object v0

    .line 408
    :sswitch_17
    const-string v0, "ERROR_CODE_PARSING_MANIFEST_MALFORMED"

    return-object v0

    .line 406
    :sswitch_18
    const-string v0, "ERROR_CODE_PARSING_CONTAINER_MALFORMED"

    return-object v0

    .line 404
    :sswitch_19
    const-string v0, "ERROR_CODE_IO_READ_POSITION_OUT_OF_RANGE"

    return-object v0

    .line 402
    :sswitch_1a
    const-string v0, "ERROR_CODE_IO_CLEARTEXT_NOT_PERMITTED"

    return-object v0

    .line 400
    :sswitch_1b
    const-string v0, "ERROR_CODE_IO_NO_PERMISSION"

    return-object v0

    .line 398
    :sswitch_1c
    const-string v0, "ERROR_CODE_IO_FILE_NOT_FOUND"

    return-object v0

    .line 396
    :sswitch_1d
    const-string v0, "ERROR_CODE_IO_BAD_HTTP_STATUS"

    return-object v0

    .line 394
    :sswitch_1e
    const-string v0, "ERROR_CODE_IO_INVALID_HTTP_CONTENT_TYPE"

    return-object v0

    .line 392
    :sswitch_1f
    const-string v0, "ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT"

    return-object v0

    .line 390
    :sswitch_20
    const-string v0, "ERROR_CODE_IO_NETWORK_CONNECTION_FAILED"

    return-object v0

    .line 388
    :sswitch_21
    const-string v0, "ERROR_CODE_IO_UNSPECIFIED"

    return-object v0

    .line 386
    :sswitch_22
    const-string v0, "ERROR_CODE_FAILED_RUNTIME_CHECK"

    return-object v0

    .line 384
    :sswitch_23
    const-string v0, "ERROR_CODE_TIMEOUT"

    return-object v0

    .line 382
    :sswitch_24
    const-string v0, "ERROR_CODE_BEHIND_LIVE_WINDOW"

    return-object v0

    .line 380
    :sswitch_25
    const-string v0, "ERROR_CODE_REMOTE_ERROR"

    return-object v0

    .line 378
    :sswitch_26
    const-string v0, "ERROR_CODE_UNSPECIFIED"

    return-object v0

    .line 350
    :sswitch_27
    const-string v0, "ERROR_CODE_INVALID_STATE"

    return-object v0

    .line 352
    :sswitch_28
    const-string v0, "ERROR_CODE_BAD_VALUE"

    return-object v0

    .line 354
    :sswitch_29
    const-string v0, "ERROR_CODE_PERMISSION_DENIED"

    return-object v0

    .line 356
    :sswitch_2a
    const-string v0, "ERROR_CODE_NOT_SUPPORTED"

    return-object v0

    .line 358
    :sswitch_2b
    const-string v0, "ERROR_CODE_DISCONNECTED"

    return-object v0

    .line 360
    :sswitch_2c
    const-string v0, "ERROR_CODE_AUTHENTICATION_EXPIRED"

    return-object v0

    .line 362
    :sswitch_2d
    const-string v0, "ERROR_CODE_PREMIUM_ACCOUNT_REQUIRED"

    return-object v0

    .line 364
    :sswitch_2e
    const-string v0, "ERROR_CODE_CONCURRENT_STREAM_LIMIT"

    return-object v0

    .line 366
    :sswitch_2f
    const-string v0, "ERROR_CODE_PARENTAL_CONTROL_RESTRICTED"

    return-object v0

    .line 368
    :sswitch_30
    const-string v0, "ERROR_CODE_NOT_AVAILABLE_IN_REGION"

    return-object v0

    .line 370
    :sswitch_31
    const-string v0, "ERROR_CODE_SKIP_LIMIT_REACHED"

    return-object v0

    .line 372
    :sswitch_32
    const-string v0, "ERROR_CODE_SETUP_REQUIRED"

    return-object v0

    .line 374
    :sswitch_33
    const-string v0, "ERROR_CODE_END_OF_PLAYLIST"

    return-object v0

    .line 376
    :sswitch_34
    const-string v0, "ERROR_CODE_CONTENT_ALREADY_PLAYING"

    return-object v0

    nop

    :sswitch_data_0
    .sparse-switch
        -0x6e -> :sswitch_34
        -0x6d -> :sswitch_33
        -0x6c -> :sswitch_32
        -0x6b -> :sswitch_31
        -0x6a -> :sswitch_30
        -0x69 -> :sswitch_2f
        -0x68 -> :sswitch_2e
        -0x67 -> :sswitch_2d
        -0x66 -> :sswitch_2c
        -0x64 -> :sswitch_2b
        -0x6 -> :sswitch_2a
        -0x4 -> :sswitch_29
        -0x3 -> :sswitch_28
        -0x2 -> :sswitch_27
        0x3e8 -> :sswitch_26
        0x3e9 -> :sswitch_25
        0x3ea -> :sswitch_24
        0x3eb -> :sswitch_23
        0x3ec -> :sswitch_22
        0x7d0 -> :sswitch_21
        0x7d1 -> :sswitch_20
        0x7d2 -> :sswitch_1f
        0x7d3 -> :sswitch_1e
        0x7d4 -> :sswitch_1d
        0x7d5 -> :sswitch_1c
        0x7d6 -> :sswitch_1b
        0x7d7 -> :sswitch_1a
        0x7d8 -> :sswitch_19
        0xbb9 -> :sswitch_18
        0xbba -> :sswitch_17
        0xbbb -> :sswitch_16
        0xbbc -> :sswitch_15
        0xfa1 -> :sswitch_14
        0xfa2 -> :sswitch_13
        0xfa3 -> :sswitch_12
        0xfa4 -> :sswitch_11
        0xfa5 -> :sswitch_10
        0xfa6 -> :sswitch_f
        0x1389 -> :sswitch_e
        0x138a -> :sswitch_d
        0x138b -> :sswitch_c
        0x138c -> :sswitch_b
        0x1770 -> :sswitch_a
        0x1771 -> :sswitch_9
        0x1772 -> :sswitch_8
        0x1773 -> :sswitch_7
        0x1774 -> :sswitch_6
        0x1775 -> :sswitch_5
        0x1776 -> :sswitch_4
        0x1777 -> :sswitch_3
        0x1778 -> :sswitch_2
        0x1b58 -> :sswitch_1
        0x1b59 -> :sswitch_0
    .end sparse-switch
.end method


# virtual methods
.method public final getErrorCodeName()Ljava/lang/String;
    .locals 1

    .line 469
    iget v0, p0, Landroidx/media3/common/PlaybackException;->errorCode:I

    invoke-static {v0}, Landroidx/media3/common/PlaybackException;->getErrorCodeName(I)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
