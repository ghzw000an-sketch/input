.class public final Landroidx/media3/common/DeviceInfo$Builder;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/media3/common/DeviceInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation


# instance fields
.field public maxVolume:I

.field public minVolume:I

.field public final playbackType:I

.field public routingControllerId:Ljava/lang/String;


# direct methods
.method public constructor <init>(I)V
    .locals 0
    .param p1, "playbackType"    # I

    .line 71
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 72
    iput p1, p0, Landroidx/media3/common/DeviceInfo$Builder;->playbackType:I

    .line 73
    return-void
.end method

.method public static synthetic access$100(Landroidx/media3/common/DeviceInfo$Builder;)I
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/DeviceInfo$Builder;

    .line 58
    iget v0, p0, Landroidx/media3/common/DeviceInfo$Builder;->playbackType:I

    return v0
.end method

.method public static synthetic access$200(Landroidx/media3/common/DeviceInfo$Builder;)I
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/DeviceInfo$Builder;

    .line 58
    iget v0, p0, Landroidx/media3/common/DeviceInfo$Builder;->minVolume:I

    return v0
.end method

.method public static synthetic access$300(Landroidx/media3/common/DeviceInfo$Builder;)I
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/DeviceInfo$Builder;

    .line 58
    iget v0, p0, Landroidx/media3/common/DeviceInfo$Builder;->maxVolume:I

    return v0
.end method

.method public static synthetic access$400(Landroidx/media3/common/DeviceInfo$Builder;)Ljava/lang/String;
    .locals 1
    .param p0, "x0"    # Landroidx/media3/common/DeviceInfo$Builder;

    .line 58
    iget-object v0, p0, Landroidx/media3/common/DeviceInfo$Builder;->routingControllerId:Ljava/lang/String;

    return-object v0
.end method


# virtual methods
.method public build()Landroidx/media3/common/DeviceInfo;
    .locals 2

    .line 125
    iget v0, p0, Landroidx/media3/common/DeviceInfo$Builder;->minVolume:I

    iget v1, p0, Landroidx/media3/common/DeviceInfo$Builder;->maxVolume:I

    if-gt v0, v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    invoke-static {v0}, Lcom/google/common/base/Preconditions;->checkArgument(Z)V

    .line 126
    new-instance v0, Landroidx/media3/common/DeviceInfo;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Landroidx/media3/common/DeviceInfo;-><init>(Landroidx/media3/common/DeviceInfo$Builder;Landroidx/media3/common/DeviceInfo$1;)V

    return-object v0
.end method

.method public setMaxVolume(I)Landroidx/media3/common/DeviceInfo$Builder;
    .locals 0
    .param p1, "maxVolume"    # I

    .line 97
    iput p1, p0, Landroidx/media3/common/DeviceInfo$Builder;->maxVolume:I

    .line 98
    return-object p0
.end method

.method public setMinVolume(I)Landroidx/media3/common/DeviceInfo$Builder;
    .locals 0
    .param p1, "minVolume"    # I

    .line 85
    iput p1, p0, Landroidx/media3/common/DeviceInfo$Builder;->minVolume:I

    .line 86
    return-object p0
.end method
