.class public final Landroidx/media3/common/AudioAttributes;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/media3/common/AudioAttributes$Builder;,
        Landroidx/media3/common/AudioAttributes$Api29;,
        Landroidx/media3/common/AudioAttributes$Api32;
    }
.end annotation


# static fields
.field public static final DEFAULT:Landroidx/media3/common/AudioAttributes;

.field public static final FIELD_ALLOWED_CAPTURE_POLICY:Ljava/lang/String;

.field public static final FIELD_CONTENT_TYPE:Ljava/lang/String;

.field public static final FIELD_FLAGS:Ljava/lang/String;

.field public static final FIELD_HAPTIC_CHANNELS_MUTED:Ljava/lang/String;

.field public static final FIELD_IS_CONTENT_SPATIALIZED:Ljava/lang/String;

.field public static final FIELD_SPATIALIZATION_BEHAVIOR:Ljava/lang/String;

.field public static final FIELD_USAGE:Ljava/lang/String;


# instance fields
.field public final allowedCapturePolicy:I

.field public final contentType:I

.field public final flags:I

.field public final hapticChannelsMuted:Z

.field public final isContentSpatialized:Z

.field public platformAudioAttributes:Landroid/media/AudioAttributes;

.field public final spatializationBehavior:I

.field public final usage:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 59
    new-instance v0, Landroidx/media3/common/AudioAttributes$Builder;

    invoke-direct {v0}, Landroidx/media3/common/AudioAttributes$Builder;-><init>()V

    invoke-virtual {v0}, Landroidx/media3/common/AudioAttributes$Builder;->build()Landroidx/media3/common/AudioAttributes;

    move-result-object v0

    sput-object v0, Landroidx/media3/common/AudioAttributes;->DEFAULT:Landroidx/media3/common/AudioAttributes;

    .line 310
    const/4 v0, 0x0

    invoke-static {v0}, Landroidx/media3/common/util/Util;->intToStringMaxRadix(I)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Landroidx/media3/common/AudioAttributes;->FIELD_CONTENT_TYPE:Ljava/lang/String;

    .line 311
    const/4 v0, 0x1

    invoke-static {v0}, Landroidx/media3/common/util/Util;->intToStringMaxRadix(I)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Landroidx/media3/common/AudioAttributes;->FIELD_FLAGS:Ljava/lang/String;

    .line 312
    const/4 v0, 0x2

    invoke-static {v0}, Landroidx/media3/common/util/Util;->intToStringMaxRadix(I)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Landroidx/media3/common/AudioAttributes;->FIELD_USAGE:Ljava/lang/String;

    .line 313
    const/4 v0, 0x3

    invoke-static {v0}, Landroidx/media3/common/util/Util;->intToStringMaxRadix(I)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Landroidx/media3/common/AudioAttributes;->FIELD_ALLOWED_CAPTURE_POLICY:Ljava/lang/String;

    .line 314
    const/4 v0, 0x4

    invoke-static {v0}, Landroidx/media3/common/util/Util;->intToStringMaxRadix(I)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Landroidx/media3/common/AudioAttributes;->FIELD_SPATIALIZATION_BEHAVIOR:Ljava/lang/String;

    .line 315
    const/4 v0, 0x5

    invoke-static {v0}, Landroidx/media3/common/util/Util;->intToStringMaxRadix(I)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Landroidx/media3/common/AudioAttributes;->FIELD_IS_CONTENT_SPATIALIZED:Ljava/lang/String;

    .line 316
    const/4 v0, 0x6

    invoke-static {v0}, Landroidx/media3/common/util/Util;->intToStringMaxRadix(I)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Landroidx/media3/common/AudioAttributes;->FIELD_HAPTIC_CHANNELS_MUTED:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(IIIIIZZ)V
    .locals 0
    .param p1, "contentType"    # I
    .param p2, "flags"    # I
    .param p3, "usage"    # I
    .param p4, "allowedCapturePolicy"    # I
    .param p5, "spatializationBehavior"    # I
    .param p6, "isContentSpatialized"    # Z
    .param p7, "hapticChannelsMuted"    # Z

    .line 219
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 220
    iput p1, p0, Landroidx/media3/common/AudioAttributes;->contentType:I

    .line 221
    iput p2, p0, Landroidx/media3/common/AudioAttributes;->flags:I

    .line 222
    iput p3, p0, Landroidx/media3/common/AudioAttributes;->usage:I

    .line 223
    iput p4, p0, Landroidx/media3/common/AudioAttributes;->allowedCapturePolicy:I

    .line 224
    iput p5, p0, Landroidx/media3/common/AudioAttributes;->spatializationBehavior:I

    .line 225
    iput-boolean p6, p0, Landroidx/media3/common/AudioAttributes;->isContentSpatialized:Z

    .line 226
    iput-boolean p7, p0, Landroidx/media3/common/AudioAttributes;->hapticChannelsMuted:Z

    .line 227
    return-void
.end method

.method public synthetic constructor <init>(IIIIIZZLandroidx/media3/common/AudioAttributes$1;)V
    .locals 0
    .param p1, "x0"    # I
    .param p2, "x1"    # I
    .param p3, "x2"    # I
    .param p4, "x3"    # I
    .param p5, "x4"    # I
    .param p6, "x5"    # Z
    .param p7, "x6"    # Z
    .param p8, "x7"    # Landroidx/media3/common/AudioAttributes$1;

    .line 40
    invoke-direct/range {p0 .. p7}, Landroidx/media3/common/AudioAttributes;-><init>(IIIIIZZ)V

    return-void
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 5
    .param p1, "obj"    # Ljava/lang/Object;

    .line 281
    const/4 v0, 0x1

    if-ne p0, p1, :cond_0

    .line 282
    return v0

    .line 284
    :cond_0
    const/4 v1, 0x0

    if-eqz p1, :cond_1

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    if-eq v2, v3, :cond_2

    :cond_1
    goto :goto_1

    .line 287
    :cond_2
    move-object v2, p1

    check-cast v2, Landroidx/media3/common/AudioAttributes;

    .line 288
    .local v2, "other":Landroidx/media3/common/AudioAttributes;
    iget v3, p0, Landroidx/media3/common/AudioAttributes;->contentType:I

    iget v4, v2, Landroidx/media3/common/AudioAttributes;->contentType:I

    if-ne v3, v4, :cond_3

    iget v3, p0, Landroidx/media3/common/AudioAttributes;->flags:I

    iget v4, v2, Landroidx/media3/common/AudioAttributes;->flags:I

    if-ne v3, v4, :cond_3

    iget v3, p0, Landroidx/media3/common/AudioAttributes;->usage:I

    iget v4, v2, Landroidx/media3/common/AudioAttributes;->usage:I

    if-ne v3, v4, :cond_3

    iget v3, p0, Landroidx/media3/common/AudioAttributes;->allowedCapturePolicy:I

    iget v4, v2, Landroidx/media3/common/AudioAttributes;->allowedCapturePolicy:I

    if-ne v3, v4, :cond_3

    iget v3, p0, Landroidx/media3/common/AudioAttributes;->spatializationBehavior:I

    iget v4, v2, Landroidx/media3/common/AudioAttributes;->spatializationBehavior:I

    if-ne v3, v4, :cond_3

    iget-boolean v3, p0, Landroidx/media3/common/AudioAttributes;->isContentSpatialized:Z

    iget-boolean v4, v2, Landroidx/media3/common/AudioAttributes;->isContentSpatialized:Z

    if-ne v3, v4, :cond_3

    iget-boolean v3, p0, Landroidx/media3/common/AudioAttributes;->hapticChannelsMuted:Z

    iget-boolean v4, v2, Landroidx/media3/common/AudioAttributes;->hapticChannelsMuted:Z

    if-ne v3, v4, :cond_3

    goto :goto_0

    :cond_3
    move v0, v1

    :goto_0
    return v0

    .line 285
    .end local v2    # "other":Landroidx/media3/common/AudioAttributes;
    :goto_1
    return v1
.end method

.method public getPlatformAudioAttributes()Landroid/media/AudioAttributes;
    .locals 3

    .line 245
    iget-object v0, p0, Landroidx/media3/common/AudioAttributes;->platformAudioAttributes:Landroid/media/AudioAttributes;

    if-nez v0, :cond_2

    .line 247
    new-instance v0, Landroid/media/AudioAttributes$Builder;

    invoke-direct {v0}, Landroid/media/AudioAttributes$Builder;-><init>()V

    iget v1, p0, Landroidx/media3/common/AudioAttributes;->contentType:I

    .line 249
    invoke-virtual {v0, v1}, Landroid/media/AudioAttributes$Builder;->setContentType(I)Landroid/media/AudioAttributes$Builder;

    move-result-object v0

    iget v1, p0, Landroidx/media3/common/AudioAttributes;->flags:I

    .line 250
    invoke-virtual {v0, v1}, Landroid/media/AudioAttributes$Builder;->setFlags(I)Landroid/media/AudioAttributes$Builder;

    move-result-object v0

    iget v1, p0, Landroidx/media3/common/AudioAttributes;->usage:I

    .line 251
    invoke-virtual {v0, v1}, Landroid/media/AudioAttributes$Builder;->setUsage(I)Landroid/media/AudioAttributes$Builder;

    move-result-object v0

    .line 252
    .local v0, "builder":Landroid/media/AudioAttributes$Builder;
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1d

    if-lt v1, v2, :cond_0

    .line 253
    iget v1, p0, Landroidx/media3/common/AudioAttributes;->allowedCapturePolicy:I

    invoke-static {v0, v1}, Landroidx/media3/common/AudioAttributes$Api29;->setAllowedCapturePolicy(Landroid/media/AudioAttributes$Builder;I)V

    .line 254
    iget-boolean v1, p0, Landroidx/media3/common/AudioAttributes;->hapticChannelsMuted:Z

    invoke-static {v0, v1}, Landroidx/media3/common/AudioAttributes$Api29;->access$300(Landroid/media/AudioAttributes$Builder;Z)V

    .line 256
    :cond_0
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x20

    if-lt v1, v2, :cond_1

    .line 257
    iget v1, p0, Landroidx/media3/common/AudioAttributes;->spatializationBehavior:I

    invoke-static {v0, v1}, Landroidx/media3/common/AudioAttributes$Api32;->setSpatializationBehavior(Landroid/media/AudioAttributes$Builder;I)V

    .line 258
    iget-boolean v1, p0, Landroidx/media3/common/AudioAttributes;->isContentSpatialized:Z

    invoke-static {v0, v1}, Landroidx/media3/common/AudioAttributes$Api32;->setIsContentSpatialized(Landroid/media/AudioAttributes$Builder;Z)V

    .line 260
    :cond_1
    invoke-virtual {v0}, Landroid/media/AudioAttributes$Builder;->build()Landroid/media/AudioAttributes;

    move-result-object v1

    iput-object v1, p0, Landroidx/media3/common/AudioAttributes;->platformAudioAttributes:Landroid/media/AudioAttributes;

    .line 262
    .end local v0    # "builder":Landroid/media/AudioAttributes$Builder;
    :cond_2
    iget-object v0, p0, Landroidx/media3/common/AudioAttributes;->platformAudioAttributes:Landroid/media/AudioAttributes;

    return-object v0
.end method

.method public final getStreamTypeInternal()I
    .locals 3

    .line 374
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1a

    const/4 v2, 0x3

    if-lt v0, v1, :cond_1

    .line 377
    :try_start_0
    invoke-virtual {p0}, Landroidx/media3/common/AudioAttributes;->getPlatformAudioAttributes()Landroid/media/AudioAttributes;

    move-result-object v0

    invoke-static {v0}, Landroidx/media3/common/AudioAttributes$$ExternalSyntheticApiModelOutline0;->m(Landroid/media/AudioAttributes;)I

    move-result v0
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    .line 381
    .local v0, "platformStreamType":I
    nop

    .line 382
    const/high16 v1, -0x80000000

    if-ne v0, v1, :cond_0

    .line 383
    goto :goto_0

    .line 384
    :cond_0
    move v2, v0

    .line 382
    :goto_0
    return v2

    .line 378
    .end local v0    # "platformStreamType":I
    :catch_0
    move-exception v0

    .line 380
    .local v0, "e":Ljava/lang/RuntimeException;
    return v2

    .line 387
    .end local v0    # "e":Ljava/lang/RuntimeException;
    :cond_1
    iget v0, p0, Landroidx/media3/common/AudioAttributes;->flags:I

    const/4 v1, 0x1

    and-int/2addr v0, v1

    if-ne v0, v1, :cond_2

    .line 388
    return v1

    .line 391
    :cond_2
    iget v0, p0, Landroidx/media3/common/AudioAttributes;->usage:I

    packed-switch v0, :pswitch_data_0

    .line 416
    :pswitch_0
    return v2

    .line 393
    :pswitch_1
    return v1

    .line 409
    :pswitch_2
    const/16 v0, 0xa

    return v0

    .line 401
    :pswitch_3
    const/4 v0, 0x2

    return v0

    .line 407
    :pswitch_4
    const/4 v0, 0x5

    return v0

    .line 399
    :pswitch_5
    const/4 v0, 0x4

    return v0

    .line 397
    :pswitch_6
    const/16 v0, 0x8

    return v0

    .line 395
    :pswitch_7
    const/4 v0, 0x0

    return v0

    nop

    :pswitch_data_0
    .packed-switch 0x2
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_4
        :pswitch_4
        :pswitch_4
        :pswitch_4
        :pswitch_2
        :pswitch_0
        :pswitch_1
    .end packed-switch
.end method

.method public getVolumeControlStream()I
    .locals 1

    .line 267
    invoke-virtual {p0}, Landroidx/media3/common/AudioAttributes;->getStreamTypeInternal()I

    move-result v0

    return v0
.end method

.method public hashCode()I
    .locals 3

    .line 299
    const/16 v0, 0x11

    .line 300
    .local v0, "result":I
    mul-int/lit8 v1, v0, 0x1f

    iget v2, p0, Landroidx/media3/common/AudioAttributes;->contentType:I

    add-int/2addr v1, v2

    .line 301
    .end local v0    # "result":I
    .local v1, "result":I
    mul-int/lit8 v0, v1, 0x1f

    iget v2, p0, Landroidx/media3/common/AudioAttributes;->flags:I

    add-int/2addr v0, v2

    .line 302
    .end local v1    # "result":I
    .restart local v0    # "result":I
    mul-int/lit8 v1, v0, 0x1f

    iget v2, p0, Landroidx/media3/common/AudioAttributes;->usage:I

    add-int/2addr v1, v2

    .line 303
    .end local v0    # "result":I
    .restart local v1    # "result":I
    mul-int/lit8 v0, v1, 0x1f

    iget v2, p0, Landroidx/media3/common/AudioAttributes;->allowedCapturePolicy:I

    add-int/2addr v0, v2

    .line 304
    .end local v1    # "result":I
    .restart local v0    # "result":I
    mul-int/lit8 v1, v0, 0x1f

    iget v2, p0, Landroidx/media3/common/AudioAttributes;->spatializationBehavior:I

    add-int/2addr v1, v2

    .line 305
    .end local v0    # "result":I
    .restart local v1    # "result":I
    mul-int/lit8 v0, v1, 0x1f

    iget-boolean v2, p0, Landroidx/media3/common/AudioAttributes;->isContentSpatialized:Z

    add-int/2addr v0, v2

    .line 306
    .end local v1    # "result":I
    .restart local v0    # "result":I
    mul-int/lit8 v1, v0, 0x1f

    iget-boolean v2, p0, Landroidx/media3/common/AudioAttributes;->hapticChannelsMuted:Z

    add-int/2addr v1, v2

    .line 307
    .end local v0    # "result":I
    .restart local v1    # "result":I
    return v1
.end method
