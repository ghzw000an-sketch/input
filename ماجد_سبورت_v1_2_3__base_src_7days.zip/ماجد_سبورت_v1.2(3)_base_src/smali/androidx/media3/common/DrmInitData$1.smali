.class public Landroidx/media3/common/DrmInitData$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/os/Parcelable$Creator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/media3/common/DrmInitData;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 235
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public createFromParcel(Landroid/os/Parcel;)Landroidx/media3/common/DrmInitData;
    .locals 1
    .param p1, "in"    # Landroid/os/Parcel;

    .line 239
    new-instance v0, Landroidx/media3/common/DrmInitData;

    invoke-direct {v0, p1}, Landroidx/media3/common/DrmInitData;-><init>(Landroid/os/Parcel;)V

    return-object v0
.end method

.method public bridge synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 0

    .line 235
    invoke-virtual {p0, p1}, Landroidx/media3/common/DrmInitData$1;->createFromParcel(Landroid/os/Parcel;)Landroidx/media3/common/DrmInitData;

    move-result-object p1

    return-object p1
.end method

.method public newArray(I)[Landroidx/media3/common/DrmInitData;
    .locals 1
    .param p1, "size"    # I

    .line 244
    new-array v0, p1, [Landroidx/media3/common/DrmInitData;

    return-object v0
.end method

.method public bridge synthetic newArray(I)[Ljava/lang/Object;
    .locals 0

    .line 235
    invoke-virtual {p0, p1}, Landroidx/media3/common/DrmInitData$1;->newArray(I)[Landroidx/media3/common/DrmInitData;

    move-result-object p1

    return-object p1
.end method
