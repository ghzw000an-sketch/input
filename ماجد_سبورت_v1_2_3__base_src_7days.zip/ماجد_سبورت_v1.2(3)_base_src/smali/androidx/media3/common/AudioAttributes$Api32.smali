.class public abstract Landroidx/media3/common/AudioAttributes$Api32;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/media3/common/AudioAttributes;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Api32"
.end annotation


# direct methods
.method public static setIsContentSpatialized(Landroid/media/AudioAttributes$Builder;Z)V
    .locals 0
    .param p0, "builder"    # Landroid/media/AudioAttributes$Builder;
    .param p1, "isContentSpatialized"    # Z

    .line 446
    invoke-static {p0, p1}, Landroidx/media3/common/AudioAttributes$Api32$$ExternalSyntheticApiModelOutline0;->m(Landroid/media/AudioAttributes$Builder;Z)Landroid/media/AudioAttributes$Builder;

    .line 447
    return-void
.end method

.method public static setSpatializationBehavior(Landroid/media/AudioAttributes$Builder;I)V
    .locals 0
    .param p0, "builder"    # Landroid/media/AudioAttributes$Builder;
    .param p1, "spatializationBehavior"    # I

    .line 441
    invoke-static {p0, p1}, Landroidx/media3/common/AudioAttributes$Api32$$ExternalSyntheticApiModelOutline1;->m(Landroid/media/AudioAttributes$Builder;I)Landroid/media/AudioAttributes$Builder;

    .line 442
    return-void
.end method
