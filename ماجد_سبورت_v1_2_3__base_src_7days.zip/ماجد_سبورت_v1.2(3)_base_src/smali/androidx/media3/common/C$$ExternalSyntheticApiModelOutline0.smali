.class public abstract synthetic Landroidx/media3/common/C$$ExternalSyntheticApiModelOutline0;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static bridge synthetic m()I
    .locals 1

    .line 0
    invoke-static {}, Landroid/os/IBinder;->getSuggestedMaxIpcSizeBytes()I

    move-result v0

    return v0
.end method
