.class public abstract Landroidx/media3/common/MimeTypes;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/media3/common/MimeTypes$CustomMimeType;,
        Landroidx/media3/common/MimeTypes$Mp4aObjectType;
    }
.end annotation


# static fields
.field public static final MP4A_RFC_6381_CODEC_PATTERN:Ljava/util/regex/Pattern;

.field public static final customMimeTypes:Ljava/util/ArrayList;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 206
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, Landroidx/media3/common/MimeTypes;->customMimeTypes:Ljava/util/ArrayList;

    .line 208
    nop

    .line 209
    const-string v0, "^mp4a\\.([a-zA-Z0-9]{2})(?:\\.([0-9]{1,2}))?$"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    sput-object v0, Landroidx/media3/common/MimeTypes;->MP4A_RFC_6381_CODEC_PATTERN:Ljava/util/regex/Pattern;

    .line 208
    return-void
.end method

.method public static allSamplesAreSyncSamples(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 5
    .param p0, "mimeType"    # Ljava/lang/String;
    .param p1, "codec"    # Ljava/lang/String;

    .line 300
    const/4 v0, 0x0

    if-nez p0, :cond_0

    .line 301
    return v0

    .line 303
    :cond_0
    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0x10

    const/4 v3, 0x1

    sparse-switch v1, :sswitch_data_0

    :cond_1
    goto/16 :goto_0

    :sswitch_0
    const-string v1, "audio/g711-mlaw"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    const/4 v1, 0x6

    goto/16 :goto_1

    :sswitch_1
    const-string v1, "audio/g711-alaw"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    const/4 v1, 0x5

    goto/16 :goto_1

    :sswitch_2
    const-string v1, "application/x-scte35"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    const/16 v1, 0xe

    goto/16 :goto_1

    :sswitch_3
    const-string v1, "audio/mpeg"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    move v1, v3

    goto/16 :goto_1

    :sswitch_4
    const-string v1, "audio/flac"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    const/4 v1, 0x7

    goto/16 :goto_1

    :sswitch_5
    const-string v1, "audio/eac3"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    const/16 v1, 0x9

    goto/16 :goto_1

    :sswitch_6
    const-string v1, "video/apv"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    move v1, v0

    goto/16 :goto_1

    :sswitch_7
    const-string v1, "application/x-emsg"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    const/16 v1, 0xd

    goto/16 :goto_1

    :sswitch_8
    const-string v1, "application/x-itut-t35"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    const/16 v1, 0x12

    goto/16 :goto_1

    :sswitch_9
    const-string v1, "application/x-media3-cues"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    const/16 v1, 0xb

    goto/16 :goto_1

    :sswitch_a
    const-string v1, "audio/raw"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    const/4 v1, 0x4

    goto/16 :goto_1

    :sswitch_b
    const-string v1, "audio/ac3"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    const/16 v1, 0x8

    goto/16 :goto_1

    :sswitch_c
    const-string v1, "application/meta"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    const/16 v1, 0x11

    goto :goto_1

    :sswitch_d
    const-string v1, "audio/mp4a-latm"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    const/16 v1, 0x14

    goto :goto_1

    :sswitch_e
    const-string v1, "audio/mpeg-L2"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    const/4 v1, 0x3

    goto :goto_1

    :sswitch_f
    const-string v1, "audio/mpeg-L1"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    const/4 v1, 0x2

    goto :goto_1

    :sswitch_10
    const-string v1, "application/id3"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    const/16 v1, 0xc

    goto :goto_1

    :sswitch_11
    const-string v1, "application/x-camera-motion"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    const/16 v1, 0x13

    goto :goto_1

    :sswitch_12
    const-string v1, "application/x-icy"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    const/16 v1, 0xf

    goto :goto_1

    :sswitch_13
    const-string v1, "application/vnd.dvb.ait"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    move v1, v2

    goto :goto_1

    :sswitch_14
    const-string v1, "audio/eac3-joc"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    const/16 v1, 0xa

    goto :goto_1

    :goto_0
    const/4 v1, -0x1

    :goto_1
    packed-switch v1, :pswitch_data_0

    .line 339
    return v0

    .line 326
    :pswitch_0
    if-nez p1, :cond_2

    .line 327
    return v0

    .line 329
    :cond_2
    invoke-static {p1}, Landroidx/media3/common/MimeTypes;->getObjectTypeFromMp4aRFC6381CodecString(Ljava/lang/String;)Landroidx/media3/common/MimeTypes$Mp4aObjectType;

    move-result-object v1

    .line 330
    .local v1, "objectType":Landroidx/media3/common/MimeTypes$Mp4aObjectType;
    if-nez v1, :cond_3

    .line 331
    return v0

    .line 333
    :cond_3
    invoke-virtual {v1}, Landroidx/media3/common/MimeTypes$Mp4aObjectType;->getEncoding()I

    move-result v4

    .line 337
    .local v4, "encoding":I
    if-eqz v4, :cond_4

    if-eq v4, v2, :cond_4

    move v0, v3

    :cond_4
    return v0

    .line 324
    .end local v1    # "objectType":Landroidx/media3/common/MimeTypes$Mp4aObjectType;
    .end local v4    # "encoding":I
    :pswitch_1
    return v3

    :sswitch_data_0
    .sparse-switch
        -0x7e929daa -> :sswitch_14
        -0x50bb4913 -> :sswitch_13
        -0x505c61b5 -> :sswitch_12
        -0x4b671bf6 -> :sswitch_11
        -0x4a682ec7 -> :sswitch_10
        -0x19cc928c -> :sswitch_f
        -0x19cc928b -> :sswitch_e
        -0x3313c2e -> :sswitch_d
        -0x29bcc9c -> :sswitch_c
        0xb269698 -> :sswitch_b
        0xb26d66f -> :sswitch_a
        0x1c029e8a -> :sswitch_9
        0x3ed9fa67 -> :sswitch_8
        0x44ce7ed0 -> :sswitch_7
        0x4f623693 -> :sswitch_6
        0x59ae0c65 -> :sswitch_5
        0x59aeaa01 -> :sswitch_4
        0x59b1e81e -> :sswitch_3
        0x62816bb7 -> :sswitch_2
        0x71710385 -> :sswitch_1
        0x717677f9 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_1
        :pswitch_1
        :pswitch_1
        :pswitch_1
        :pswitch_1
        :pswitch_1
        :pswitch_1
        :pswitch_1
        :pswitch_1
        :pswitch_1
        :pswitch_1
        :pswitch_1
        :pswitch_1
        :pswitch_1
        :pswitch_1
        :pswitch_1
        :pswitch_1
        :pswitch_1
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static containsCodecsCorrespondingToMimeType(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 1
    .param p0, "codecs"    # Ljava/lang/String;
    .param p1, "mimeType"    # Ljava/lang/String;

    .line 377
    invoke-static {p0, p1}, Landroidx/media3/common/MimeTypes;->getCodecsCorrespondingToMimeType(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public static getAudioMediaMimeType(Ljava/lang/String;)Ljava/lang/String;
    .locals 7
    .param p0, "codecs"    # Ljava/lang/String;

    .line 420
    const/4 v0, 0x0

    if-nez p0, :cond_0

    .line 421
    return-object v0

    .line 423
    :cond_0
    invoke-static {p0}, Landroidx/media3/common/util/Util;->splitCodecs(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    .line 424
    .local v1, "codecList":[Ljava/lang/String;
    array-length v2, v1

    const/4 v3, 0x0

    :goto_0
    if-ge v3, v2, :cond_2

    aget-object v4, v1, v3

    .line 425
    .local v4, "codec":Ljava/lang/String;
    invoke-static {v4}, Landroidx/media3/common/MimeTypes;->getMediaMimeType(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 426
    .local v5, "mimeType":Ljava/lang/String;
    if-eqz v5, :cond_1

    invoke-static {v5}, Landroidx/media3/common/MimeTypes;->isAudio(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_1

    .line 427
    return-object v5

    .line 424
    .end local v4    # "codec":Ljava/lang/String;
    .end local v5    # "mimeType":Ljava/lang/String;
    :cond_1
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 430
    :cond_2
    return-object v0
.end method

.method public static getCodecsCorrespondingToMimeType(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 7
    .param p0, "codecs"    # Ljava/lang/String;
    .param p1, "mimeType"    # Ljava/lang/String;

    .line 395
    const/4 v0, 0x0

    if-eqz p0, :cond_0

    if-nez p1, :cond_1

    :cond_0
    goto :goto_1

    .line 398
    :cond_1
    invoke-static {p0}, Landroidx/media3/common/util/Util;->splitCodecs(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    .line 399
    .local v1, "codecList":[Ljava/lang/String;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 400
    .local v2, "builder":Ljava/lang/StringBuilder;
    array-length v3, v1

    const/4 v4, 0x0

    :goto_0
    if-ge v4, v3, :cond_4

    aget-object v5, v1, v4

    .line 401
    .local v5, "codec":Ljava/lang/String;
    invoke-static {v5}, Landroidx/media3/common/MimeTypes;->getMediaMimeType(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {p1, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_3

    .line 402
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->length()I

    move-result v6

    if-lez v6, :cond_2

    .line 403
    const-string v6, ","

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 405
    :cond_2
    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 400
    .end local v5    # "codec":Ljava/lang/String;
    :cond_3
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    .line 408
    :cond_4
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->length()I

    move-result v3

    if-lez v3, :cond_5

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :cond_5
    return-object v0

    .line 396
    .end local v1    # "codecList":[Ljava/lang/String;
    .end local v2    # "builder":Ljava/lang/StringBuilder;
    :goto_1
    return-object v0
.end method

.method public static getCustomMimeTypeForCodec(Ljava/lang/String;)Ljava/lang/String;
    .locals 4
    .param p0, "codec"    # Ljava/lang/String;

    .line 814
    sget-object v0, Landroidx/media3/common/MimeTypes;->customMimeTypes:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    .line 815
    .local v0, "customMimeTypeCount":I
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_0
    if-ge v1, v0, :cond_1

    .line 816
    sget-object v2, Landroidx/media3/common/MimeTypes;->customMimeTypes:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/media3/common/MimeTypes$CustomMimeType;

    .line 817
    .local v2, "customMimeType":Landroidx/media3/common/MimeTypes$CustomMimeType;
    iget-object v3, v2, Landroidx/media3/common/MimeTypes$CustomMimeType;->codecPrefix:Ljava/lang/String;

    invoke-virtual {p0, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_0

    .line 818
    iget-object v3, v2, Landroidx/media3/common/MimeTypes$CustomMimeType;->mimeType:Ljava/lang/String;

    return-object v3

    .line 817
    :cond_0
    nop

    .line 815
    .end local v2    # "customMimeType":Landroidx/media3/common/MimeTypes$CustomMimeType;
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    nop

    .line 821
    .end local v1    # "i":I
    const/4 v1, 0x0

    return-object v1
.end method

.method public static getEncoding(Ljava/lang/String;Ljava/lang/String;)I
    .locals 7
    .param p0, "mimeType"    # Ljava/lang/String;
    .param p1, "codec"    # Ljava/lang/String;

    .line 695
    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/16 v3, 0x9

    const/4 v4, 0x7

    const/16 v5, 0x8

    const/4 v6, 0x0

    sparse-switch v0, :sswitch_data_0

    :cond_0
    goto/16 :goto_0

    :sswitch_0
    const-string v0, "audio/true-hd"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0xa

    goto/16 :goto_1

    :sswitch_1
    const-string v0, "audio/vnd.dts.hd"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    move v0, v4

    goto/16 :goto_1

    :sswitch_2
    const-string v0, "audio/opus"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0xb

    goto/16 :goto_1

    :sswitch_3
    const-string v0, "audio/mpeg"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    move v0, v6

    goto/16 :goto_1

    :sswitch_4
    const-string v0, "audio/eac3"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x3

    goto :goto_1

    :sswitch_5
    const-string v0, "audio/vnd.dts.uhd;profile=p2"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    move v0, v3

    goto :goto_1

    :sswitch_6
    const-string v0, "audio/dsd"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0xc

    goto :goto_1

    :sswitch_7
    const-string v0, "audio/ac4"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    move v0, v2

    goto :goto_1

    :sswitch_8
    const-string v0, "audio/ac3"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x2

    goto :goto_1

    :sswitch_9
    const-string v0, "audio/mp4a-latm"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_1

    :sswitch_a
    const-string v0, "audio/vnd.dts"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    move v0, v1

    goto :goto_1

    :sswitch_b
    const-string v0, "audio/vnd.dts.hd;profile=lbr"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    move v0, v5

    goto :goto_1

    :sswitch_c
    const-string v0, "audio/eac3-joc"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x4

    goto :goto_1

    :goto_0
    const/4 v0, -0x1

    :goto_1
    packed-switch v0, :pswitch_data_0

    .line 730
    return v6

    .line 728
    :pswitch_0
    const/16 v0, 0x1f

    return v0

    .line 726
    :pswitch_1
    const/16 v0, 0x14

    return v0

    .line 724
    :pswitch_2
    const/16 v0, 0xe

    return v0

    .line 722
    :pswitch_3
    const/16 v0, 0x1e

    return v0

    .line 720
    :pswitch_4
    return v5

    .line 718
    :pswitch_5
    return v5

    .line 716
    :pswitch_6
    return v4

    .line 714
    :pswitch_7
    const/16 v0, 0x11

    return v0

    .line 712
    :pswitch_8
    const/16 v0, 0x12

    return v0

    .line 710
    :pswitch_9
    return v1

    .line 708
    :pswitch_a
    return v2

    .line 699
    :pswitch_b
    if-nez p1, :cond_1

    .line 700
    return v6

    .line 702
    :cond_1
    invoke-static {p1}, Landroidx/media3/common/MimeTypes;->getObjectTypeFromMp4aRFC6381CodecString(Ljava/lang/String;)Landroidx/media3/common/MimeTypes$Mp4aObjectType;

    move-result-object v0

    .line 703
    .local v0, "objectType":Landroidx/media3/common/MimeTypes$Mp4aObjectType;
    if-nez v0, :cond_2

    .line 704
    return v6

    .line 706
    :cond_2
    invoke-virtual {v0}, Landroidx/media3/common/MimeTypes$Mp4aObjectType;->getEncoding()I

    move-result v1

    return v1

    .line 697
    .end local v0    # "objectType":Landroidx/media3/common/MimeTypes$Mp4aObjectType;
    :pswitch_c
    return v3

    :sswitch_data_0
    .sparse-switch
        -0x7e929daa -> :sswitch_c
        -0x51617051 -> :sswitch_b
        -0x41455b98 -> :sswitch_a
        -0x3313c2e -> :sswitch_9
        0xb269698 -> :sswitch_8
        0xb269699 -> :sswitch_7
        0xb26a3fc -> :sswitch_6
        0x20d04866 -> :sswitch_5
        0x59ae0c65 -> :sswitch_4
        0x59b1e81e -> :sswitch_3
        0x59b2d2d8 -> :sswitch_2
        0x59c2dc42 -> :sswitch_1
        0x5cc95062 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static getMediaMimeType(Ljava/lang/String;)Ljava/lang/String;
    .locals 3
    .param p0, "codec"    # Ljava/lang/String;

    .line 465
    if-nez p0, :cond_0

    .line 466
    const/4 v0, 0x0

    return-object v0

    .line 468
    :cond_0
    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/google/common/base/Ascii;->toLowerCase(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    .line 469
    const-string v0, "avc1"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, "avc3"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_2

    :cond_1
    goto/16 :goto_b

    .line 471
    :cond_2
    const-string v0, "hev1"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_3

    const-string v0, "hvc1"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_4

    :cond_3
    goto/16 :goto_a

    .line 473
    :cond_4
    const-string v0, "vvc1"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_5

    const-string v0, "vvi1"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_6

    :cond_5
    goto/16 :goto_9

    .line 475
    :cond_6
    const-string v0, "dvav"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    nop

    if-nez v0, :cond_26

    .line 476
    const-string v0, "dva1"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    nop

    if-nez v0, :cond_26

    .line 477
    const-string v0, "dvhe"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    nop

    if-nez v0, :cond_26

    .line 478
    const-string v0, "dvh1"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    nop

    if-nez v0, :cond_26

    .line 479
    const-string v0, "dav1"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_7

    goto/16 :goto_8

    .line 481
    :cond_7
    const-string v0, "av01"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_8

    .line 482
    const-string v0, "video/av01"

    return-object v0

    .line 483
    :cond_8
    const-string v0, "vp9"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_9

    const-string v0, "vp09"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_a

    :cond_9
    goto/16 :goto_7

    .line 485
    :cond_a
    const-string v0, "vp8"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_b

    const-string v0, "vp08"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_c

    :cond_b
    goto/16 :goto_6

    .line 487
    :cond_c
    const-string v0, "mp4a"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_f

    .line 488
    const/4 v0, 0x0

    .line 489
    .local v0, "mimeType":Ljava/lang/String;
    const-string v1, "mp4a."

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_d

    .line 490
    invoke-static {p0}, Landroidx/media3/common/MimeTypes;->getObjectTypeFromMp4aRFC6381CodecString(Ljava/lang/String;)Landroidx/media3/common/MimeTypes$Mp4aObjectType;

    move-result-object v1

    .line 491
    .local v1, "objectType":Landroidx/media3/common/MimeTypes$Mp4aObjectType;
    if-eqz v1, :cond_d

    .line 492
    iget v2, v1, Landroidx/media3/common/MimeTypes$Mp4aObjectType;->objectTypeIndication:I

    invoke-static {v2}, Landroidx/media3/common/MimeTypes;->getMimeTypeFromMp4ObjectType(I)Ljava/lang/String;

    move-result-object v0

    .line 495
    .end local v1    # "objectType":Landroidx/media3/common/MimeTypes$Mp4aObjectType;
    :cond_d
    if-nez v0, :cond_e

    const-string v1, "audio/mp4a-latm"

    goto :goto_0

    :cond_e
    move-object v1, v0

    :goto_0
    return-object v1

    .line 496
    .end local v0    # "mimeType":Ljava/lang/String;
    :cond_f
    const-string v0, "mha1"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_10

    .line 497
    const-string v0, "audio/mha1"

    return-object v0

    .line 498
    :cond_10
    const-string v0, "mhm1"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_11

    .line 499
    const-string v0, "audio/mhm1"

    return-object v0

    .line 500
    :cond_11
    const-string v0, "ac-3"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_12

    const-string v0, "dac3"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_13

    :cond_12
    goto/16 :goto_5

    .line 502
    :cond_13
    const-string v0, "ec-3"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_14

    const-string v0, "dec3"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_15

    :cond_14
    goto/16 :goto_4

    .line 504
    :cond_15
    const-string v0, "ec+3"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_16

    .line 505
    const-string v0, "audio/eac3-joc"

    return-object v0

    .line 506
    :cond_16
    const-string v0, "ac-4"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_17

    const-string v0, "dac4"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_18

    :cond_17
    goto/16 :goto_3

    .line 508
    :cond_18
    const-string v0, "dtsc"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_19

    .line 509
    const-string v0, "audio/vnd.dts"

    return-object v0

    .line 510
    :cond_19
    const-string v0, "dtse"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1a

    .line 511
    const-string v0, "audio/vnd.dts.hd;profile=lbr"

    return-object v0

    .line 512
    :cond_1a
    const-string v0, "dtsh"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_1b

    const-string v0, "dtsl"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1c

    :cond_1b
    goto :goto_2

    .line 514
    :cond_1c
    const-string v0, "dtsx"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1d

    .line 515
    const-string v0, "audio/vnd.dts.uhd;profile=p2"

    return-object v0

    .line 516
    :cond_1d
    const-string v0, "opus"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1e

    .line 517
    const-string v0, "audio/opus"

    return-object v0

    .line 518
    :cond_1e
    const-string v0, "vorbis"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1f

    .line 519
    const-string v0, "audio/vorbis"

    return-object v0

    .line 520
    :cond_1f
    const-string v0, "flac"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_20

    .line 521
    const-string v0, "audio/flac"

    return-object v0

    .line 522
    :cond_20
    const-string v0, "stpp"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_21

    .line 523
    const-string v0, "application/ttml+xml"

    return-object v0

    .line 524
    :cond_21
    const-string v0, "wvtt"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_22

    .line 525
    const-string v0, "text/vtt"

    return-object v0

    .line 526
    :cond_22
    const-string v0, "cea708"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_23

    .line 527
    const-string v0, "application/cea-708"

    return-object v0

    .line 528
    :cond_23
    const-string v0, "eia608"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_24

    const-string v0, "cea608"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_25

    :cond_24
    goto :goto_1

    .line 531
    :cond_25
    invoke-static {p0}, Landroidx/media3/common/MimeTypes;->getCustomMimeTypeForCodec(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 529
    :goto_1
    const-string v0, "application/cea-608"

    return-object v0

    .line 513
    :goto_2
    const-string v0, "audio/vnd.dts.hd"

    return-object v0

    .line 507
    :goto_3
    const-string v0, "audio/ac4"

    return-object v0

    .line 503
    :goto_4
    const-string v0, "audio/eac3"

    return-object v0

    .line 501
    :goto_5
    const-string v0, "audio/ac3"

    return-object v0

    .line 486
    :goto_6
    const-string v0, "video/x-vnd.on2.vp8"

    return-object v0

    .line 484
    :goto_7
    const-string v0, "video/x-vnd.on2.vp9"

    return-object v0

    .line 480
    :cond_26
    :goto_8
    const-string v0, "video/dolby-vision"

    return-object v0

    .line 474
    :goto_9
    const-string v0, "video/vvc"

    return-object v0

    .line 472
    :goto_a
    const-string v0, "video/hevc"

    return-object v0

    .line 470
    :goto_b
    const-string v0, "video/avc"

    return-object v0
.end method

.method public static getMimeTypeFromMp4ObjectType(I)Ljava/lang/String;
    .locals 1
    .param p0, "objectType"    # I

    .line 568
    sparse-switch p0, :sswitch_data_0

    .line 615
    const/4 v0, 0x0

    return-object v0

    .line 613
    :sswitch_0
    const-string v0, "audio/vorbis"

    return-object v0

    .line 592
    :sswitch_1
    const-string v0, "video/x-vnd.on2.vp9"

    return-object v0

    .line 611
    :sswitch_2
    const-string v0, "audio/ac4"

    return-object v0

    .line 609
    :sswitch_3
    const-string v0, "audio/opus"

    return-object v0

    .line 607
    :sswitch_4
    const-string v0, "audio/vnd.dts.hd"

    return-object v0

    .line 604
    :sswitch_5
    const-string v0, "audio/vnd.dts"

    return-object v0

    .line 601
    :sswitch_6
    const-string v0, "audio/eac3"

    return-object v0

    .line 599
    :sswitch_7
    const-string v0, "audio/ac3"

    return-object v0

    .line 590
    :sswitch_8
    const-string v0, "video/wvc1"

    return-object v0

    .line 588
    :sswitch_9
    const-string v0, "image/jpeg"

    return-object v0

    .line 583
    :sswitch_a
    const-string v0, "video/mpeg"

    return-object v0

    .line 586
    :sswitch_b
    const-string v0, "audio/mpeg"

    return-object v0

    .line 581
    :sswitch_c
    const-string v0, "video/mpeg2"

    return-object v0

    .line 597
    :sswitch_d
    const-string v0, "audio/mp4a-latm"

    return-object v0

    .line 574
    :sswitch_e
    const-string v0, "video/hevc"

    return-object v0

    .line 572
    :sswitch_f
    const-string v0, "video/avc"

    return-object v0

    .line 570
    :sswitch_10
    const-string v0, "video/mp4v-es"

    return-object v0

    :sswitch_data_0
    .sparse-switch
        0x20 -> :sswitch_10
        0x21 -> :sswitch_f
        0x23 -> :sswitch_e
        0x40 -> :sswitch_d
        0x60 -> :sswitch_c
        0x61 -> :sswitch_c
        0x62 -> :sswitch_c
        0x63 -> :sswitch_c
        0x64 -> :sswitch_c
        0x65 -> :sswitch_c
        0x66 -> :sswitch_d
        0x67 -> :sswitch_d
        0x68 -> :sswitch_d
        0x69 -> :sswitch_b
        0x6a -> :sswitch_a
        0x6b -> :sswitch_b
        0x6c -> :sswitch_9
        0xa3 -> :sswitch_8
        0xa5 -> :sswitch_7
        0xa6 -> :sswitch_6
        0xa9 -> :sswitch_5
        0xaa -> :sswitch_4
        0xab -> :sswitch_4
        0xac -> :sswitch_5
        0xad -> :sswitch_3
        0xae -> :sswitch_2
        0xb1 -> :sswitch_1
        0xdd -> :sswitch_0
    .end sparse-switch
.end method

.method public static getObjectTypeFromMp4aRFC6381CodecString(Ljava/lang/String;)Landroidx/media3/common/MimeTypes$Mp4aObjectType;
    .locals 6
    .param p0, "codec"    # Ljava/lang/String;

    .line 859
    sget-object v0, Landroidx/media3/common/MimeTypes;->MP4A_RFC_6381_CODEC_PATTERN:Ljava/util/regex/Pattern;

    invoke-virtual {v0, p0}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v0

    .line 860
    .local v0, "matcher":Ljava/util/regex/Matcher;
    invoke-virtual {v0}, Ljava/util/regex/Matcher;->matches()Z

    move-result v1

    const/4 v2, 0x0

    if-nez v1, :cond_0

    .line 861
    return-object v2

    .line 863
    :cond_0
    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .line 864
    .local v1, "objectTypeIndicationHex":Ljava/lang/String;
    const/4 v3, 0x2

    invoke-virtual {v0, v3}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v3

    .line 866
    .local v3, "audioObjectTypeIndicationDec":Ljava/lang/String;
    const/4 v4, 0x0

    .line 868
    .local v4, "audioObjectTypeIndication":I
    const/16 v5, 0x10

    :try_start_0
    invoke-static {v1, v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v5

    .line 869
    .local v5, "objectTypeIndication":I
    if-eqz v3, :cond_1

    .line 870
    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    move v4, v2

    goto :goto_0

    .line 872
    .end local v5    # "objectTypeIndication":I
    :catch_0
    move-exception v5

    goto :goto_1

    .line 874
    .restart local v5    # "objectTypeIndication":I
    :cond_1
    :goto_0
    nop

    .line 875
    new-instance v2, Landroidx/media3/common/MimeTypes$Mp4aObjectType;

    invoke-direct {v2, v5, v4}, Landroidx/media3/common/MimeTypes$Mp4aObjectType;-><init>(II)V

    return-object v2

    .line 872
    .end local v5    # "objectTypeIndication":I
    :goto_1
    nop

    .line 873
    .local v5, "e":Ljava/lang/NumberFormatException;
    return-object v2
.end method

.method public static getTopLevelType(Ljava/lang/String;)Ljava/lang/String;
    .locals 3
    .param p0, "mimeType"    # Ljava/lang/String;

    .line 802
    const/4 v0, 0x0

    if-nez p0, :cond_0

    .line 803
    return-object v0

    .line 805
    :cond_0
    const/16 v1, 0x2f

    invoke-virtual {p0, v1}, Ljava/lang/String;->indexOf(I)I

    move-result v1

    .line 806
    .local v1, "indexOfSlash":I
    const/4 v2, -0x1

    if-ne v1, v2, :cond_1

    .line 807
    return-object v0

    .line 809
    :cond_1
    const/4 v0, 0x0

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static getTrackType(Ljava/lang/String;)I
    .locals 1
    .param p0, "mimeType"    # Ljava/lang/String;

    .line 659
    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 660
    const/4 v0, -0x1

    return v0

    .line 661
    :cond_0
    invoke-static {p0}, Landroidx/media3/common/MimeTypes;->isAudio(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 662
    const/4 v0, 0x1

    return v0

    .line 663
    :cond_1
    invoke-static {p0}, Landroidx/media3/common/MimeTypes;->isVideo(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 664
    const/4 v0, 0x2

    return v0

    .line 665
    :cond_2
    invoke-static {p0}, Landroidx/media3/common/MimeTypes;->isText(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_3

    .line 666
    const/4 v0, 0x3

    return v0

    .line 667
    :cond_3
    invoke-static {p0}, Landroidx/media3/common/MimeTypes;->isImage(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_4

    .line 668
    const/4 v0, 0x4

    return v0

    .line 669
    :cond_4
    const-string v0, "application/id3"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    nop

    if-nez v0, :cond_7

    .line 670
    const-string v0, "application/x-emsg"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    nop

    if-nez v0, :cond_7

    .line 671
    const-string v0, "application/x-scte35"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    nop

    if-nez v0, :cond_7

    .line 672
    const-string v0, "application/x-icy"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    nop

    if-nez v0, :cond_7

    .line 673
    const-string v0, "application/vnd.dvb.ait"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    nop

    if-nez v0, :cond_7

    .line 674
    const-string v0, "application/meta"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    nop

    if-nez v0, :cond_7

    .line 675
    const-string v0, "application/x-itut-t35"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5

    goto :goto_0

    .line 677
    :cond_5
    const-string v0, "application/x-camera-motion"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_6

    .line 678
    const/4 v0, 0x6

    return v0

    .line 680
    :cond_6
    invoke-static {p0}, Landroidx/media3/common/MimeTypes;->getTrackTypeForCustomMimeType(Ljava/lang/String;)I

    move-result v0

    return v0

    .line 676
    :cond_7
    :goto_0
    const/4 v0, 0x5

    return v0
.end method

.method public static getTrackTypeForCustomMimeType(Ljava/lang/String;)I
    .locals 4
    .param p0, "mimeType"    # Ljava/lang/String;

    .line 825
    sget-object v0, Landroidx/media3/common/MimeTypes;->customMimeTypes:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    .line 826
    .local v0, "customMimeTypeCount":I
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_0
    if-ge v1, v0, :cond_1

    .line 827
    sget-object v2, Landroidx/media3/common/MimeTypes;->customMimeTypes:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/media3/common/MimeTypes$CustomMimeType;

    .line 828
    .local v2, "customMimeType":Landroidx/media3/common/MimeTypes$CustomMimeType;
    iget-object v3, v2, Landroidx/media3/common/MimeTypes$CustomMimeType;->mimeType:Ljava/lang/String;

    invoke-virtual {p0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_0

    .line 829
    iget v3, v2, Landroidx/media3/common/MimeTypes$CustomMimeType;->trackType:I

    return v3

    .line 828
    :cond_0
    nop

    .line 826
    .end local v2    # "customMimeType":Landroidx/media3/common/MimeTypes$CustomMimeType;
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    nop

    .line 832
    .end local v1    # "i":I
    const/4 v1, -0x1

    return v1
.end method

.method public static getTrackTypeOfCodec(Ljava/lang/String;)I
    .locals 1
    .param p0, "codec"    # Ljava/lang/String;

    .line 743
    invoke-static {p0}, Landroidx/media3/common/MimeTypes;->getMediaMimeType(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroidx/media3/common/MimeTypes;->getTrackType(Ljava/lang/String;)I

    move-result v0

    return v0
.end method

.method public static getVideoMediaMimeType(Ljava/lang/String;)Ljava/lang/String;
    .locals 7
    .param p0, "codecs"    # Ljava/lang/String;

    .line 352
    const/4 v0, 0x0

    if-nez p0, :cond_0

    .line 353
    return-object v0

    .line 355
    :cond_0
    invoke-static {p0}, Landroidx/media3/common/util/Util;->splitCodecs(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    .line 356
    .local v1, "codecList":[Ljava/lang/String;
    array-length v2, v1

    const/4 v3, 0x0

    :goto_0
    if-ge v3, v2, :cond_2

    aget-object v4, v1, v3

    .line 357
    .local v4, "codec":Ljava/lang/String;
    invoke-static {v4}, Landroidx/media3/common/MimeTypes;->getMediaMimeType(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 358
    .local v5, "mimeType":Ljava/lang/String;
    if-eqz v5, :cond_1

    invoke-static {v5}, Landroidx/media3/common/MimeTypes;->isVideo(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_1

    .line 359
    return-object v5

    .line 356
    .end local v4    # "codec":Ljava/lang/String;
    .end local v5    # "mimeType":Ljava/lang/String;
    :cond_1
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 362
    :cond_2
    return-object v0
.end method

.method public static isAudio(Ljava/lang/String;)Z
    .locals 2
    .param p0, "mimeType"    # Ljava/lang/String;

    .line 249
    const-string v0, "audio"

    invoke-static {p0}, Landroidx/media3/common/MimeTypes;->getTopLevelType(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method public static isDolbyVisionCodec(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 6
    .param p0, "codecs"    # Ljava/lang/String;
    .param p1, "supplementalCodecs"    # Ljava/lang/String;

    .line 631
    const/4 v0, 0x0

    if-nez p0, :cond_0

    .line 632
    return v0

    .line 634
    :cond_0
    const-string v1, "dvhe"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-nez v2, :cond_1

    const-string v2, "dvh1"

    invoke-virtual {p0, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v4

    if-nez v4, :cond_1

    const-string v4, "dav1"

    invoke-virtual {p0, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_2

    :cond_1
    goto :goto_0

    .line 638
    :cond_2
    if-nez p1, :cond_3

    .line 639
    return v0

    .line 642
    :cond_3
    invoke-virtual {p1, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_4

    const-string v1, "hev1"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_8

    .line 643
    :cond_4
    invoke-virtual {p1, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_5

    const-string v1, "hvc1"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_8

    .line 644
    :cond_5
    const-string v1, "dvav"

    invoke-virtual {p1, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_6

    const-string v1, "avc3"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_8

    .line 645
    :cond_6
    const-string v1, "dva1"

    invoke-virtual {p1, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_7

    const-string v1, "avc1"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_8

    .line 646
    :cond_7
    invoke-virtual {p1, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_9

    const-string v1, "av01"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_9

    :cond_8
    move v0, v3

    .line 642
    :cond_9
    return v0

    .line 636
    :goto_0
    return v3
.end method

.method public static isImage(Ljava/lang/String;)Z
    .locals 2
    .param p0, "mimeType"    # Ljava/lang/String;

    .line 284
    const-string v0, "image"

    invoke-static {p0}, Landroidx/media3/common/MimeTypes;->getTopLevelType(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    nop

    if-nez v0, :cond_1

    .line 285
    const-string v0, "application/x-image-uri"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v0, 0x1

    .line 284
    :goto_1
    return v0
.end method

.method public static isMatroska(Ljava/lang/String;)Z
    .locals 2
    .param p0, "mimeType"    # Ljava/lang/String;

    .line 784
    const/4 v0, 0x0

    if-nez p0, :cond_0

    .line 785
    return v0

    .line 787
    :cond_0
    const-string v1, "video/webm"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    nop

    if-nez v1, :cond_1

    .line 788
    const-string v1, "audio/webm"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    nop

    if-nez v1, :cond_1

    .line 789
    const-string v1, "application/webm"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    nop

    if-nez v1, :cond_1

    .line 790
    const-string v1, "video/x-matroska"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    nop

    if-nez v1, :cond_1

    .line 791
    const-string v1, "audio/x-matroska"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    nop

    if-nez v1, :cond_1

    .line 792
    const-string v1, "application/x-matroska"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_2

    :cond_1
    const/4 v0, 0x1

    .line 787
    :cond_2
    return v0
.end method

.method public static isText(Ljava/lang/String;)Z
    .locals 2
    .param p0, "mimeType"    # Ljava/lang/String;

    .line 266
    const-string v0, "text"

    invoke-static {p0}, Landroidx/media3/common/MimeTypes;->getTopLevelType(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    nop

    if-nez v0, :cond_1

    .line 267
    const-string v0, "application/x-media3-cues"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    nop

    if-nez v0, :cond_1

    .line 268
    const-string v0, "application/cea-608"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    nop

    if-nez v0, :cond_1

    .line 269
    const-string v0, "application/cea-708"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    nop

    if-nez v0, :cond_1

    .line 270
    const-string v0, "application/x-mp4-cea-608"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    nop

    if-nez v0, :cond_1

    .line 271
    const-string v0, "application/x-subrip"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    nop

    if-nez v0, :cond_1

    .line 272
    const-string v0, "application/ttml+xml"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    nop

    if-nez v0, :cond_1

    .line 273
    const-string v0, "application/x-quicktime-tx3g"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    nop

    if-nez v0, :cond_1

    .line 274
    const-string v0, "application/x-mp4-vtt"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    nop

    if-nez v0, :cond_1

    .line 275
    const-string v0, "application/x-rawcc"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    nop

    if-nez v0, :cond_1

    .line 276
    const-string v0, "application/vobsub"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    nop

    if-nez v0, :cond_1

    .line 277
    const-string v0, "application/pgs"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    nop

    if-nez v0, :cond_1

    .line 278
    const-string v0, "application/dvbsubs"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v0, 0x1

    .line 266
    :goto_1
    return v0
.end method

.method public static isVideo(Ljava/lang/String;)Z
    .locals 2
    .param p0, "mimeType"    # Ljava/lang/String;

    .line 255
    const-string v0, "video"

    invoke-static {p0}, Landroidx/media3/common/MimeTypes;->getTopLevelType(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method public static normalizeMimeType(Ljava/lang/String;)Ljava/lang/String;
    .locals 1
    .param p0, "mimeType"    # Ljava/lang/String;

    .line 754
    if-nez p0, :cond_0

    .line 755
    const/4 v0, 0x0

    return-object v0

    .line 757
    :cond_0
    invoke-static {p0}, Lcom/google/common/base/Ascii;->toLowerCase(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    .line 758
    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_0

    :cond_1
    goto :goto_0

    :sswitch_0
    const-string v0, "audio/mp3"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    const/4 v0, 0x2

    goto :goto_1

    :sswitch_1
    const-string v0, "audio/mpeg-l2"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    const/4 v0, 0x6

    goto :goto_1

    :sswitch_2
    const-string v0, "audio/mpeg-l1"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    const/4 v0, 0x5

    goto :goto_1

    :sswitch_3
    const-string v0, "audio/x-wav"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    const/4 v0, 0x3

    goto :goto_1

    :sswitch_4
    const-string v0, "application/x-mpegurl"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    const/4 v0, 0x4

    goto :goto_1

    :sswitch_5
    const-string v0, "audio/x-flac"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    const/4 v0, 0x1

    goto :goto_1

    :sswitch_6
    const-string v0, "video/x-mvhevc"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    const/4 v0, 0x0

    goto :goto_1

    :goto_0
    const/4 v0, -0x1

    :goto_1
    packed-switch v0, :pswitch_data_0

    .line 777
    return-object p0

    .line 775
    :pswitch_0
    const-string v0, "audio/mpeg-L2"

    return-object v0

    .line 773
    :pswitch_1
    const-string v0, "audio/mpeg-L1"

    return-object v0

    .line 771
    :pswitch_2
    const-string v0, "application/x-mpegURL"

    return-object v0

    .line 768
    :pswitch_3
    const-string v0, "audio/wav"

    return-object v0

    .line 766
    :pswitch_4
    const-string v0, "audio/mpeg"

    return-object v0

    .line 764
    :pswitch_5
    const-string v0, "audio/flac"

    return-object v0

    .line 761
    :pswitch_6
    const-string v0, "video/mv-hevc"

    return-object v0

    :sswitch_data_0
    .sparse-switch
        -0x6d4a8464 -> :sswitch_6
        -0x3c11ec0a -> :sswitch_5
        -0x3a5bd08a -> :sswitch_4
        -0x22f81362 -> :sswitch_3
        -0x19cc8eac -> :sswitch_2
        -0x19cc8eab -> :sswitch_1
        0xb26c537 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
