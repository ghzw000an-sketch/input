.class public final Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/media3/common/util/CodecSpecificDataUtil;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "MediaCodecProfileAndLevel"
.end annotation


# static fields
.field public static final UNSUPPORTABLE:Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;


# instance fields
.field public final isSupportableByMediaCodec:Z

.field public final level:I

.field public final profile:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 67
    new-instance v0, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    const/4 v1, 0x0

    invoke-direct {v0, v1, v1, v1}, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;-><init>(IIZ)V

    sput-object v0, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;->UNSUPPORTABLE:Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    return-void
.end method

.method public constructor <init>(II)V
    .locals 1
    .param p1, "profile"    # I
    .param p2, "level"    # I

    .line 77
    const/4 v0, 0x1

    invoke-direct {p0, p1, p2, v0}, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;-><init>(IIZ)V

    .line 78
    return-void
.end method

.method public constructor <init>(IIZ)V
    .locals 0
    .param p1, "profile"    # I
    .param p2, "level"    # I
    .param p3, "isSupportableByMediaCodec"    # Z

    .line 80
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 81
    iput-boolean p3, p0, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;->isSupportableByMediaCodec:Z

    .line 82
    iput p1, p0, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;->profile:I

    .line 83
    iput p2, p0, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;->level:I

    .line 84
    return-void
.end method


# virtual methods
.method public getLevel()I
    .locals 1

    .line 106
    iget-boolean v0, p0, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;->isSupportableByMediaCodec:Z

    invoke-static {v0}, Lcom/google/common/base/Preconditions;->checkState(Z)V

    .line 107
    iget v0, p0, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;->level:I

    return v0
.end method

.method public getProfile()I
    .locals 1

    .line 94
    iget-boolean v0, p0, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;->isSupportableByMediaCodec:Z

    invoke-static {v0}, Lcom/google/common/base/Preconditions;->checkState(Z)V

    .line 95
    iget v0, p0, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;->profile:I

    return v0
.end method

.method public isSupportableByMediaCodec()Z
    .locals 1

    .line 118
    iget-boolean v0, p0, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;->isSupportableByMediaCodec:Z

    return v0
.end method
