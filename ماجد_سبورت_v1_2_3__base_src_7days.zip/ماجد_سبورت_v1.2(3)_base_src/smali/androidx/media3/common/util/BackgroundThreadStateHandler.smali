.class public final Landroidx/media3/common/util/BackgroundThreadStateHandler;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/media3/common/util/BackgroundThreadStateHandler$StateChangeListener;
    }
.end annotation


# instance fields
.field public final backgroundHandler:Landroidx/media3/common/util/HandlerWrapper;

.field public backgroundState:Ljava/lang/Object;

.field public final foregroundHandler:Landroidx/media3/common/util/HandlerWrapper;

.field public foregroundState:Ljava/lang/Object;

.field public final onStateChanged:Landroidx/media3/common/util/BackgroundThreadStateHandler$StateChangeListener;

.field public pendingOperations:I


# direct methods
.method public static synthetic $r8$lambda$f0hFC73tfQBWeDExFIZmwNfoA-E(Landroidx/media3/common/util/BackgroundThreadStateHandler;Lcom/google/common/base/Function;)V
    .locals 0

    .line 0
    invoke-virtual {p0, p1}, Landroidx/media3/common/util/BackgroundThreadStateHandler;->lambda$updateStateAsync$1(Lcom/google/common/base/Function;)V

    return-void
.end method

.method public static synthetic $r8$lambda$hhYjRnaRRUwjgYpDYJM_auE3ai0(Landroidx/media3/common/util/BackgroundThreadStateHandler;Ljava/lang/Object;)V
    .locals 0

    .line 0
    invoke-virtual {p0, p1}, Landroidx/media3/common/util/BackgroundThreadStateHandler;->lambda$setStateInBackground$2(Ljava/lang/Object;)V

    return-void
.end method

.method public static synthetic $r8$lambda$lNGZQG-zRQnsJ9W6th9-dnrHlBQ(Landroidx/media3/common/util/BackgroundThreadStateHandler;Ljava/lang/Object;)V
    .locals 0

    .line 0
    invoke-virtual {p0, p1}, Landroidx/media3/common/util/BackgroundThreadStateHandler;->lambda$updateStateAsync$0(Ljava/lang/Object;)V

    return-void
.end method

.method public constructor <init>(Ljava/lang/Object;Landroid/os/Looper;Landroid/os/Looper;Landroidx/media3/common/util/Clock;Landroidx/media3/common/util/BackgroundThreadStateHandler$StateChangeListener;)V
    .locals 2
    .param p2, "backgroundLooper"    # Landroid/os/Looper;
    .param p3, "foregroundLooper"    # Landroid/os/Looper;
    .param p4, "clock"    # Landroidx/media3/common/util/Clock;

    .line 80
    .local p0, "this":Landroidx/media3/common/util/BackgroundThreadStateHandler;, "Landroidx/media3/common/util/BackgroundThreadStateHandler<TT;>;"
    .local p1, "initialState":Ljava/lang/Object;, "TT;"
    .local p5, "onStateChanged":Landroidx/media3/common/util/BackgroundThreadStateHandler$StateChangeListener;, "Landroidx/media3/common/util/BackgroundThreadStateHandler$StateChangeListener<TT;>;"
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 81
    const/4 v0, 0x0

    invoke-interface {p4, p2, v0}, Landroidx/media3/common/util/Clock;->createHandler(Landroid/os/Looper;Landroid/os/Handler$Callback;)Landroidx/media3/common/util/HandlerWrapper;

    move-result-object v1

    iput-object v1, p0, Landroidx/media3/common/util/BackgroundThreadStateHandler;->backgroundHandler:Landroidx/media3/common/util/HandlerWrapper;

    .line 82
    invoke-interface {p4, p3, v0}, Landroidx/media3/common/util/Clock;->createHandler(Landroid/os/Looper;Landroid/os/Handler$Callback;)Landroidx/media3/common/util/HandlerWrapper;

    move-result-object v0

    iput-object v0, p0, Landroidx/media3/common/util/BackgroundThreadStateHandler;->foregroundHandler:Landroidx/media3/common/util/HandlerWrapper;

    .line 83
    iput-object p1, p0, Landroidx/media3/common/util/BackgroundThreadStateHandler;->foregroundState:Ljava/lang/Object;

    .line 84
    iput-object p1, p0, Landroidx/media3/common/util/BackgroundThreadStateHandler;->backgroundState:Ljava/lang/Object;

    .line 85
    iput-object p5, p0, Landroidx/media3/common/util/BackgroundThreadStateHandler;->onStateChanged:Landroidx/media3/common/util/BackgroundThreadStateHandler$StateChangeListener;

    .line 86
    return-void
.end method


# virtual methods
.method public get()Ljava/lang/Object;
    .locals 2

    .line 95
    .local p0, "this":Landroidx/media3/common/util/BackgroundThreadStateHandler;, "Landroidx/media3/common/util/BackgroundThreadStateHandler<TT;>;"
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    .line 96
    .local v0, "myLooper":Landroid/os/Looper;
    iget-object v1, p0, Landroidx/media3/common/util/BackgroundThreadStateHandler;->foregroundHandler:Landroidx/media3/common/util/HandlerWrapper;

    invoke-interface {v1}, Landroidx/media3/common/util/HandlerWrapper;->getLooper()Landroid/os/Looper;

    move-result-object v1

    if-ne v0, v1, :cond_0

    .line 97
    iget-object v1, p0, Landroidx/media3/common/util/BackgroundThreadStateHandler;->foregroundState:Ljava/lang/Object;

    return-object v1

    .line 99
    :cond_0
    iget-object v1, p0, Landroidx/media3/common/util/BackgroundThreadStateHandler;->backgroundHandler:Landroidx/media3/common/util/HandlerWrapper;

    invoke-interface {v1}, Landroidx/media3/common/util/HandlerWrapper;->getLooper()Landroid/os/Looper;

    move-result-object v1

    if-ne v0, v1, :cond_1

    const/4 v1, 0x1

    goto :goto_0

    :cond_1
    const/4 v1, 0x0

    :goto_0
    invoke-static {v1}, Lcom/google/common/base/Preconditions;->checkState(Z)V

    .line 100
    iget-object v1, p0, Landroidx/media3/common/util/BackgroundThreadStateHandler;->backgroundState:Ljava/lang/Object;

    return-object v1
.end method

.method public final synthetic lambda$setStateInBackground$2(Ljava/lang/Object;)V
    .locals 1
    .param p1, "newState"    # Ljava/lang/Object;

    .line 144
    .local p0, "this":Landroidx/media3/common/util/BackgroundThreadStateHandler;, "Landroidx/media3/common/util/BackgroundThreadStateHandler<TT;>;"
    iget v0, p0, Landroidx/media3/common/util/BackgroundThreadStateHandler;->pendingOperations:I

    if-nez v0, :cond_0

    .line 145
    invoke-virtual {p0, p1}, Landroidx/media3/common/util/BackgroundThreadStateHandler;->updateStateInForeground(Ljava/lang/Object;)V

    .line 147
    :cond_0
    return-void
.end method

.method public final synthetic lambda$updateStateAsync$0(Ljava/lang/Object;)V
    .locals 1
    .param p1, "newState"    # Ljava/lang/Object;

    .line 124
    .local p0, "this":Landroidx/media3/common/util/BackgroundThreadStateHandler;, "Landroidx/media3/common/util/BackgroundThreadStateHandler<TT;>;"
    iget v0, p0, Landroidx/media3/common/util/BackgroundThreadStateHandler;->pendingOperations:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Landroidx/media3/common/util/BackgroundThreadStateHandler;->pendingOperations:I

    if-nez v0, :cond_0

    .line 125
    invoke-virtual {p0, p1}, Landroidx/media3/common/util/BackgroundThreadStateHandler;->updateStateInForeground(Ljava/lang/Object;)V

    .line 127
    :cond_0
    return-void
.end method

.method public final synthetic lambda$updateStateAsync$1(Lcom/google/common/base/Function;)V
    .locals 2
    .param p1, "backgroundStateUpdate"    # Lcom/google/common/base/Function;

    .line 120
    .local p0, "this":Landroidx/media3/common/util/BackgroundThreadStateHandler;, "Landroidx/media3/common/util/BackgroundThreadStateHandler<TT;>;"
    iget-object v0, p0, Landroidx/media3/common/util/BackgroundThreadStateHandler;->backgroundState:Ljava/lang/Object;

    invoke-interface {p1, v0}, Lcom/google/common/base/Function;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    iput-object v0, p0, Landroidx/media3/common/util/BackgroundThreadStateHandler;->backgroundState:Ljava/lang/Object;

    .line 121
    iget-object v0, p0, Landroidx/media3/common/util/BackgroundThreadStateHandler;->backgroundState:Ljava/lang/Object;

    .line 122
    .local v0, "newState":Ljava/lang/Object;, "TT;"
    new-instance v1, Landroidx/media3/common/util/BackgroundThreadStateHandler$$ExternalSyntheticLambda2;

    invoke-direct {v1, p0, v0}, Landroidx/media3/common/util/BackgroundThreadStateHandler$$ExternalSyntheticLambda2;-><init>(Landroidx/media3/common/util/BackgroundThreadStateHandler;Ljava/lang/Object;)V

    invoke-virtual {p0, v1}, Landroidx/media3/common/util/BackgroundThreadStateHandler;->runInForeground(Ljava/lang/Runnable;)V

    .line 128
    return-void
.end method

.method public runInBackground(Ljava/lang/Runnable;)V
    .locals 1
    .param p1, "runnable"    # Ljava/lang/Runnable;

    .line 162
    .local p0, "this":Landroidx/media3/common/util/BackgroundThreadStateHandler;, "Landroidx/media3/common/util/BackgroundThreadStateHandler<TT;>;"
    iget-object v0, p0, Landroidx/media3/common/util/BackgroundThreadStateHandler;->backgroundHandler:Landroidx/media3/common/util/HandlerWrapper;

    invoke-interface {v0}, Landroidx/media3/common/util/HandlerWrapper;->getLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Thread;->isAlive()Z

    move-result v0

    if-nez v0, :cond_0

    .line 164
    return-void

    .line 166
    :cond_0
    iget-object v0, p0, Landroidx/media3/common/util/BackgroundThreadStateHandler;->backgroundHandler:Landroidx/media3/common/util/HandlerWrapper;

    invoke-interface {v0, p1}, Landroidx/media3/common/util/HandlerWrapper;->post(Ljava/lang/Runnable;)Z

    .line 167
    return-void
.end method

.method public final runInForeground(Ljava/lang/Runnable;)V
    .locals 1
    .param p1, "runnable"    # Ljava/lang/Runnable;

    .line 170
    .local p0, "this":Landroidx/media3/common/util/BackgroundThreadStateHandler;, "Landroidx/media3/common/util/BackgroundThreadStateHandler<TT;>;"
    iget-object v0, p0, Landroidx/media3/common/util/BackgroundThreadStateHandler;->foregroundHandler:Landroidx/media3/common/util/HandlerWrapper;

    invoke-interface {v0}, Landroidx/media3/common/util/HandlerWrapper;->getLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Thread;->isAlive()Z

    move-result v0

    if-nez v0, :cond_0

    .line 172
    return-void

    .line 174
    :cond_0
    iget-object v0, p0, Landroidx/media3/common/util/BackgroundThreadStateHandler;->foregroundHandler:Landroidx/media3/common/util/HandlerWrapper;

    invoke-interface {v0, p1}, Landroidx/media3/common/util/HandlerWrapper;->post(Ljava/lang/Runnable;)Z

    .line 175
    return-void
.end method

.method public setStateInBackground(Ljava/lang/Object;)V
    .locals 1

    .line 141
    .local p0, "this":Landroidx/media3/common/util/BackgroundThreadStateHandler;, "Landroidx/media3/common/util/BackgroundThreadStateHandler<TT;>;"
    .local p1, "newState":Ljava/lang/Object;, "TT;"
    iput-object p1, p0, Landroidx/media3/common/util/BackgroundThreadStateHandler;->backgroundState:Ljava/lang/Object;

    .line 142
    new-instance v0, Landroidx/media3/common/util/BackgroundThreadStateHandler$$ExternalSyntheticLambda0;

    invoke-direct {v0, p0, p1}, Landroidx/media3/common/util/BackgroundThreadStateHandler$$ExternalSyntheticLambda0;-><init>(Landroidx/media3/common/util/BackgroundThreadStateHandler;Ljava/lang/Object;)V

    invoke-virtual {p0, v0}, Landroidx/media3/common/util/BackgroundThreadStateHandler;->runInForeground(Ljava/lang/Runnable;)V

    .line 148
    return-void
.end method

.method public updateStateAsync(Lcom/google/common/base/Function;Lcom/google/common/base/Function;)V
    .locals 3

    .line 116
    .local p0, "this":Landroidx/media3/common/util/BackgroundThreadStateHandler;, "Landroidx/media3/common/util/BackgroundThreadStateHandler<TT;>;"
    .local p1, "placeholderState":Lcom/google/common/base/Function;, "Lcom/google/common/base/Function<TT;TT;>;"
    .local p2, "backgroundStateUpdate":Lcom/google/common/base/Function;, "Lcom/google/common/base/Function<TT;TT;>;"
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    iget-object v1, p0, Landroidx/media3/common/util/BackgroundThreadStateHandler;->foregroundHandler:Landroidx/media3/common/util/HandlerWrapper;

    invoke-interface {v1}, Landroidx/media3/common/util/HandlerWrapper;->getLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v2, 0x1

    if-ne v0, v1, :cond_0

    move v0, v2

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    invoke-static {v0}, Lcom/google/common/base/Preconditions;->checkState(Z)V

    .line 117
    iget v0, p0, Landroidx/media3/common/util/BackgroundThreadStateHandler;->pendingOperations:I

    add-int/2addr v0, v2

    iput v0, p0, Landroidx/media3/common/util/BackgroundThreadStateHandler;->pendingOperations:I

    .line 118
    new-instance v0, Landroidx/media3/common/util/BackgroundThreadStateHandler$$ExternalSyntheticLambda1;

    invoke-direct {v0, p0, p2}, Landroidx/media3/common/util/BackgroundThreadStateHandler$$ExternalSyntheticLambda1;-><init>(Landroidx/media3/common/util/BackgroundThreadStateHandler;Lcom/google/common/base/Function;)V

    invoke-virtual {p0, v0}, Landroidx/media3/common/util/BackgroundThreadStateHandler;->runInBackground(Ljava/lang/Runnable;)V

    .line 129
    iget-object v0, p0, Landroidx/media3/common/util/BackgroundThreadStateHandler;->foregroundState:Ljava/lang/Object;

    invoke-interface {p1, v0}, Lcom/google/common/base/Function;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroidx/media3/common/util/BackgroundThreadStateHandler;->updateStateInForeground(Ljava/lang/Object;)V

    .line 130
    return-void
.end method

.method public final updateStateInForeground(Ljava/lang/Object;)V
    .locals 2

    .line 178
    .local p0, "this":Landroidx/media3/common/util/BackgroundThreadStateHandler;, "Landroidx/media3/common/util/BackgroundThreadStateHandler<TT;>;"
    .local p1, "newState":Ljava/lang/Object;, "TT;"
    iget-object v0, p0, Landroidx/media3/common/util/BackgroundThreadStateHandler;->foregroundState:Ljava/lang/Object;

    .line 179
    .local v0, "oldState":Ljava/lang/Object;, "TT;"
    iput-object p1, p0, Landroidx/media3/common/util/BackgroundThreadStateHandler;->foregroundState:Ljava/lang/Object;

    .line 180
    invoke-virtual {v0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    .line 181
    iget-object v1, p0, Landroidx/media3/common/util/BackgroundThreadStateHandler;->onStateChanged:Landroidx/media3/common/util/BackgroundThreadStateHandler$StateChangeListener;

    invoke-interface {v1, v0, p1}, Landroidx/media3/common/util/BackgroundThreadStateHandler$StateChangeListener;->onStateChanged(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 183
    :cond_0
    return-void
.end method
