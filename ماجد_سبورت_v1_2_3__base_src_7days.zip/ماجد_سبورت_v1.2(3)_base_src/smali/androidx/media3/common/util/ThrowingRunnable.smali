.class public interface abstract Landroidx/media3/common/util/ThrowingRunnable;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract run()V
.end method
