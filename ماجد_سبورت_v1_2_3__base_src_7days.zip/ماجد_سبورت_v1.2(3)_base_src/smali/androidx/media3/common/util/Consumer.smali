.class public interface abstract Landroidx/media3/common/util/Consumer;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract accept(Ljava/lang/Object;)V
.end method
