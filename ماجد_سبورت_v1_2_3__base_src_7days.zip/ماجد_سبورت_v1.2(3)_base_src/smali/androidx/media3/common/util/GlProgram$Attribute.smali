.class public final Landroidx/media3/common/util/GlProgram$Attribute;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/media3/common/util/GlProgram;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Attribute"
.end annotation


# instance fields
.field public final location:I

.field public final name:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .param p1, "name"    # Ljava/lang/String;
    .param p2, "location"    # I

    .line 336
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 337
    iput-object p1, p0, Landroidx/media3/common/util/GlProgram$Attribute;->name:Ljava/lang/String;

    .line 338
    iput p2, p0, Landroidx/media3/common/util/GlProgram$Attribute;->location:I

    .line 339
    return-void
.end method

.method public static create(II)Landroidx/media3/common/util/GlProgram$Attribute;
    .locals 13
    .param p0, "programId"    # I
    .param p1, "index"    # I

    .line 301
    const/4 v1, 0x1

    new-array v11, v1, [I

    .line 302
    .local v11, "attributeNameMaxLength":[I
    const v2, 0x8b8a

    const/4 v12, 0x0

    invoke-static {p0, v2, v11, v12}, Landroid/opengl/GLES20;->glGetProgramiv(II[II)V

    .line 307
    aget v2, v11, v12

    new-array v9, v2, [B

    .line 309
    .local v9, "nameBytes":[B
    aget v2, v11, v12

    new-array v3, v1, [I

    new-array v5, v1, [I

    new-array v7, v1, [I

    const/4 v8, 0x0

    const/4 v10, 0x0

    const/4 v4, 0x0

    const/4 v6, 0x0

    move v0, p0

    move v1, p1

    invoke-static/range {v0 .. v10}, Landroid/opengl/GLES20;->glGetActiveAttrib(III[II[II[II[BI)V

    .line 321
    new-instance v1, Ljava/lang/String;

    invoke-static {v9}, Landroidx/media3/common/util/GlProgram;->access$000([B)I

    move-result v2

    invoke-direct {v1, v9, v12, v2}, Ljava/lang/String;-><init>([BII)V

    .line 322
    .local v1, "name":Ljava/lang/String;
    invoke-static {p0, v1}, Landroidx/media3/common/util/GlProgram;->access$100(ILjava/lang/String;)I

    move-result v2

    .line 324
    .local v2, "location":I
    new-instance v3, Landroidx/media3/common/util/GlProgram$Attribute;

    invoke-direct {v3, v1, v2}, Landroidx/media3/common/util/GlProgram$Attribute;-><init>(Ljava/lang/String;I)V

    return-object v3
.end method
