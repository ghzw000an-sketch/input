.class public final synthetic Landroidx/media3/common/util/StuckPlayerDetector$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/os/Handler$Callback;


# instance fields
.field public final synthetic f$0:Landroidx/media3/common/util/StuckPlayerDetector;


# direct methods
.method public synthetic constructor <init>(Landroidx/media3/common/util/StuckPlayerDetector;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/media3/common/util/StuckPlayerDetector$$ExternalSyntheticLambda0;->f$0:Landroidx/media3/common/util/StuckPlayerDetector;

    return-void
.end method


# virtual methods
.method public final handleMessage(Landroid/os/Message;)Z
    .locals 1

    .line 0
    iget-object v0, p0, Landroidx/media3/common/util/StuckPlayerDetector$$ExternalSyntheticLambda0;->f$0:Landroidx/media3/common/util/StuckPlayerDetector;

    invoke-static {v0, p1}, Landroidx/media3/common/util/StuckPlayerDetector;->$r8$lambda$O20OfWQe0IImnmxCKXMyVoyaxfk(Landroidx/media3/common/util/StuckPlayerDetector;Landroid/os/Message;)Z

    move-result p1

    return p1
.end method
