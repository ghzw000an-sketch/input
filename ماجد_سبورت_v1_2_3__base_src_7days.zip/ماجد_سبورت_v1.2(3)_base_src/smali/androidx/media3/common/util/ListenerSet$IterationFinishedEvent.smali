.class public interface abstract Landroidx/media3/common/util/ListenerSet$IterationFinishedEvent;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/media3/common/util/ListenerSet;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "IterationFinishedEvent"
.end annotation


# virtual methods
.method public abstract invoke(Ljava/lang/Object;Landroidx/media3/common/FlagSet;)V
.end method
