.class public abstract Landroidx/media3/common/util/WavUtil;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static getPcmEncodingForType(II)I
    .locals 1
    .param p0, "type"    # I
    .param p1, "bitsPerSample"    # I

    .line 101
    sparse-switch p0, :sswitch_data_0

    .line 108
    const/4 v0, 0x0

    return v0

    .line 106
    :sswitch_0
    invoke-static {p1}, Landroidx/media3/common/util/Util;->getFloatPcmEncoding(I)I

    move-result v0

    return v0

    .line 104
    :sswitch_1
    invoke-static {p1}, Landroidx/media3/common/util/Util;->getPcmEncoding(I)I

    move-result v0

    return v0

    nop

    :sswitch_data_0
    .sparse-switch
        0x1 -> :sswitch_1
        0x3 -> :sswitch_0
        0xfffe -> :sswitch_1
    .end sparse-switch
.end method

.method public static isChannelMaskValid(II)Z
    .locals 1
    .param p0, "channelMask"    # I
    .param p1, "channelCount"    # I

    .line 120
    shr-int/lit8 v0, p0, 0x12

    nop

    if-nez v0, :cond_1

    if-eqz p0, :cond_0

    .line 121
    invoke-static {p0}, Ljava/lang/Integer;->bitCount(I)I

    move-result v0

    if-ne v0, p1, :cond_1

    :cond_0
    const/4 v0, 0x1

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    .line 120
    :goto_0
    return v0
.end method

.method public static mapToAudioFormatChannelMask(I)I
    .locals 1
    .param p0, "wavChannelMask"    # I

    .line 133
    if-nez p0, :cond_0

    .line 134
    const/4 v0, -0x1

    return v0

    .line 138
    :cond_0
    shl-int/lit8 v0, p0, 0x2

    return v0
.end method
