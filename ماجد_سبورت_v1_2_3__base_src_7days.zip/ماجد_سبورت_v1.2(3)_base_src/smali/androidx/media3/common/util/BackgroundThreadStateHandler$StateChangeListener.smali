.class public interface abstract Landroidx/media3/common/util/BackgroundThreadStateHandler$StateChangeListener;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/media3/common/util/BackgroundThreadStateHandler;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "StateChangeListener"
.end annotation


# virtual methods
.method public abstract onStateChanged(Ljava/lang/Object;Ljava/lang/Object;)V
.end method
