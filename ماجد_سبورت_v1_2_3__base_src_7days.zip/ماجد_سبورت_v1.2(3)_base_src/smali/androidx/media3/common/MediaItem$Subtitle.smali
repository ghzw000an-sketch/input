.class public abstract Landroidx/media3/common/MediaItem$Subtitle;
.super Landroidx/media3/common/MediaItem$SubtitleConfiguration;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/media3/common/MediaItem;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Subtitle"
.end annotation
