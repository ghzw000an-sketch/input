.class public abstract Landroidx/collection/SparseArrayCompatKt;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSparseArrayCompat.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SparseArrayCompat.kt\nandroidx/collection/SparseArrayCompatKt\n*L\n1#1,535:1\n244#1,6:536\n244#1,6:542\n353#1,40:548\n353#1,40:588\n459#1,9:628\n*S KotlinDebug\n*F\n+ 1 SparseArrayCompat.kt\nandroidx/collection/SparseArrayCompatKt\n*L\n255#1:536,6\n260#1:542,6\n397#1:548,40\n405#1:588,40\n477#1:628,9\n*E\n"
.end annotation


# static fields
.field public static final DELETED:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 26
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Landroidx/collection/SparseArrayCompatKt;->DELETED:Ljava/lang/Object;

    return-void
.end method

.method public static final synthetic access$gc(Landroidx/collection/SparseArrayCompat;)V
    .locals 0
    .param p0, "$receiver"    # Landroidx/collection/SparseArrayCompat;

    .line 1
    invoke-static {p0}, Landroidx/collection/SparseArrayCompatKt;->gc(Landroidx/collection/SparseArrayCompat;)V

    return-void
.end method

.method public static final synthetic access$getDELETED$p()Ljava/lang/Object;
    .locals 1

    .line 1
    sget-object v0, Landroidx/collection/SparseArrayCompatKt;->DELETED:Ljava/lang/Object;

    return-object v0
.end method

.method public static final commonGet(Landroidx/collection/SparseArrayCompat;I)Ljava/lang/Object;
    .locals 6
    .param p0, "$this$commonGet"    # Landroidx/collection/SparseArrayCompat;
    .param p1, "key"    # I

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 255
    const/4 v0, 0x0

    .local v0, "defaultValue$iv":Ljava/lang/Object;
    move-object v1, p0

    .local v1, "$this$internalGet$iv":Landroidx/collection/SparseArrayCompat;
    const/4 v2, 0x0

    .line 244
    .local v2, "$i$f$internalGet":I
    iget-object v3, v1, Landroidx/collection/SparseArrayCompat;->keys:[I

    iget v4, v1, Landroidx/collection/SparseArrayCompat;->size:I

    invoke-static {v3, v4, p1}, Landroidx/collection/internal/ContainerHelpersKt;->binarySearch([III)I

    move-result v3

    .line 245
    .local v3, "i$iv":I
    if-ltz v3, :cond_0

    iget-object v4, v1, Landroidx/collection/SparseArrayCompat;->values:[Ljava/lang/Object;

    aget-object v4, v4, v3

    sget-object v5, Landroidx/collection/SparseArrayCompatKt;->DELETED:Ljava/lang/Object;

    if-ne v4, v5, :cond_1

    :cond_0
    goto :goto_0

    .line 249
    :cond_1
    iget-object v4, v1, Landroidx/collection/SparseArrayCompat;->values:[Ljava/lang/Object;

    aget-object v4, v4, v3

    goto :goto_1

    .line 246
    :goto_0
    move-object v4, v0

    .line 245
    :goto_1
    nop

    .line 255
    .end local v0    # "defaultValue$iv":Ljava/lang/Object;
    .end local v1    # "$this$internalGet$iv":Landroidx/collection/SparseArrayCompat;
    .end local v2    # "$i$f$internalGet":I
    .end local v3    # "i$iv":I
    return-object v4
.end method

.method public static final gc(Landroidx/collection/SparseArrayCompat;)V
    .locals 7
    .param p0, "$this$gc"    # Landroidx/collection/SparseArrayCompat;

    .line 332
    iget v0, p0, Landroidx/collection/SparseArrayCompat;->size:I

    .line 333
    .local v0, "n":I
    const/4 v1, 0x0

    .line 334
    .local v1, "o":I
    iget-object v2, p0, Landroidx/collection/SparseArrayCompat;->keys:[I

    .line 335
    .local v2, "keys":[I
    iget-object v3, p0, Landroidx/collection/SparseArrayCompat;->values:[Ljava/lang/Object;

    .line 336
    .local v3, "values":[Ljava/lang/Object;
    const/4 v4, 0x0

    .local v4, "i":I
    :goto_0
    if-ge v4, v0, :cond_2

    .line 337
    aget-object v5, v3, v4

    .line 338
    .local v5, "value":Ljava/lang/Object;
    sget-object v6, Landroidx/collection/SparseArrayCompatKt;->DELETED:Ljava/lang/Object;

    if-eq v5, v6, :cond_1

    .line 339
    if-eq v4, v1, :cond_0

    .line 340
    aget v6, v2, v4

    aput v6, v2, v1

    .line 341
    aput-object v5, v3, v1

    .line 342
    const/4 v6, 0x0

    aput-object v6, v3, v4

    .line 344
    :cond_0
    add-int/lit8 v1, v1, 0x1

    .line 336
    .end local v5    # "value":Ljava/lang/Object;
    :cond_1
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_2
    nop

    .line 347
    .end local v4    # "i":I
    const/4 v4, 0x0

    iput-boolean v4, p0, Landroidx/collection/SparseArrayCompat;->garbage:Z

    .line 348
    iput v1, p0, Landroidx/collection/SparseArrayCompat;->size:I

    .line 349
    return-void
.end method
