.class public Landroidx/collection/SparseArrayCompat;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Cloneable;


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSparseArrayCompat.jvm.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SparseArrayCompat.jvm.kt\nandroidx/collection/SparseArrayCompat\n+ 2 SparseArrayCompat.kt\nandroidx/collection/SparseArrayCompatKt\n*L\n1#1,273:1\n275#2,9:274\n288#2,5:283\n296#2,5:288\n304#2,8:293\n320#2,9:301\n353#2,40:310\n396#2,2:350\n353#2,47:352\n403#2,3:399\n353#2,40:402\n407#2:442\n412#2,4:443\n419#2:447\n423#2,4:448\n431#2,8:452\n443#2,5:460\n451#2,4:465\n459#2,9:469\n472#2:478\n477#2:479\n459#2,9:480\n482#2,8:489\n493#2,17:497\n513#2,21:514\n*S KotlinDebug\n*F\n+ 1 SparseArrayCompat.jvm.kt\nandroidx/collection/SparseArrayCompat\n*L\n130#1:274,9\n135#1:283,5\n144#1:288,5\n152#1:293,8\n163#1:301,9\n169#1:310,40\n176#1:350,2\n176#1:352,47\n186#1:399,3\n186#1:402,40\n186#1:442\n191#1:443,4\n205#1:447\n212#1:448,4\n218#1:452,8\n224#1:460,5\n234#1:465,4\n246#1:469,9\n249#1:478\n252#1:479\n252#1:480,9\n257#1:489,8\n263#1:497,17\n271#1:514,21\n*E\n"
.end annotation


# instance fields
.field public synthetic garbage:Z

.field public synthetic keys:[I

.field public synthetic size:I

.field public synthetic values:[Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 3

    .line 0
    const/4 v0, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {p0, v2, v0, v1}, Landroidx/collection/SparseArrayCompat;-><init>(IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-void
.end method

.method public constructor <init>(I)V
    .locals 2
    .param p1, "initialCapacity"    # I

    .line 60
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 80
    nop

    .line 81
    if-nez p1, :cond_0

    .line 82
    sget-object v0, Landroidx/collection/internal/ContainerHelpersKt;->EMPTY_INTS:[I

    iput-object v0, p0, Landroidx/collection/SparseArrayCompat;->keys:[I

    .line 83
    sget-object v0, Landroidx/collection/internal/ContainerHelpersKt;->EMPTY_OBJECTS:[Ljava/lang/Object;

    iput-object v0, p0, Landroidx/collection/SparseArrayCompat;->values:[Ljava/lang/Object;

    goto :goto_0

    .line 85
    :cond_0
    invoke-static {p1}, Landroidx/collection/internal/ContainerHelpersKt;->idealIntArraySize(I)I

    move-result v0

    .line 86
    .local v0, "capacity":I
    new-array v1, v0, [I

    iput-object v1, p0, Landroidx/collection/SparseArrayCompat;->keys:[I

    .line 87
    new-array v1, v0, [Ljava/lang/Object;

    iput-object v1, p0, Landroidx/collection/SparseArrayCompat;->values:[Ljava/lang/Object;

    .line 89
    .end local v0    # "capacity":I
    :goto_0
    nop

    .line 61
    return-void
.end method

.method public synthetic constructor <init>(IILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    .line 61
    and-int/lit8 p2, p2, 0x1

    if-eqz p2, :cond_0

    .line 66
    const/16 p1, 0xa

    .line 61
    :cond_0
    invoke-direct {p0, p1}, Landroidx/collection/SparseArrayCompat;-><init>(I)V

    .line 272
    return-void
.end method


# virtual methods
.method public append(ILjava/lang/Object;)V
    .locals 6
    .param p1, "key"    # I
    .param p2, "value"    # Ljava/lang/Object;

    .line 263
    move-object v0, p0

    .local v0, "$this$commonAppend$iv":Landroidx/collection/SparseArrayCompat;
    const/4 v1, 0x0

    .line 493
    .local v1, "$i$f$commonAppend":I
    iget v2, v0, Landroidx/collection/SparseArrayCompat;->size:I

    if-eqz v2, :cond_0

    iget-object v2, v0, Landroidx/collection/SparseArrayCompat;->keys:[I

    iget v3, v0, Landroidx/collection/SparseArrayCompat;->size:I

    add-int/lit8 v3, v3, -0x1

    aget v2, v2, v3

    if-gt p1, v2, :cond_0

    .line 494
    invoke-virtual {v0, p1, p2}, Landroidx/collection/SparseArrayCompat;->put(ILjava/lang/Object;)V

    .line 495
    goto :goto_0

    .line 497
    :cond_0
    iget-boolean v2, v0, Landroidx/collection/SparseArrayCompat;->garbage:Z

    if-eqz v2, :cond_1

    iget v2, v0, Landroidx/collection/SparseArrayCompat;->size:I

    iget-object v3, v0, Landroidx/collection/SparseArrayCompat;->keys:[I

    array-length v3, v3

    if-lt v2, v3, :cond_1

    .line 498
    invoke-static {v0}, Landroidx/collection/SparseArrayCompatKt;->access$gc(Landroidx/collection/SparseArrayCompat;)V

    .line 500
    :cond_1
    iget v2, v0, Landroidx/collection/SparseArrayCompat;->size:I

    .line 501
    .local v2, "pos$iv":I
    iget-object v3, v0, Landroidx/collection/SparseArrayCompat;->keys:[I

    array-length v3, v3

    if-lt v2, v3, :cond_2

    .line 502
    add-int/lit8 v3, v2, 0x1

    invoke-static {v3}, Landroidx/collection/internal/ContainerHelpersKt;->idealIntArraySize(I)I

    move-result v3

    .line 503
    .local v3, "n$iv":I
    iget-object v4, v0, Landroidx/collection/SparseArrayCompat;->keys:[I

    invoke-static {v4, v3}, Ljava/util/Arrays;->copyOf([II)[I

    move-result-object v4

    const-string v5, "copyOf(this, newSize)"

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object v4, v0, Landroidx/collection/SparseArrayCompat;->keys:[I

    .line 504
    iget-object v4, v0, Landroidx/collection/SparseArrayCompat;->values:[Ljava/lang/Object;

    invoke-static {v4, v3}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v4

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object v4, v0, Landroidx/collection/SparseArrayCompat;->values:[Ljava/lang/Object;

    .line 506
    .end local v3    # "n$iv":I
    :cond_2
    iget-object v3, v0, Landroidx/collection/SparseArrayCompat;->keys:[I

    aput p1, v3, v2

    .line 507
    iget-object v3, v0, Landroidx/collection/SparseArrayCompat;->values:[Ljava/lang/Object;

    aput-object p2, v3, v2

    .line 508
    add-int/lit8 v3, v2, 0x1

    iput v3, v0, Landroidx/collection/SparseArrayCompat;->size:I

    .line 509
    nop

    .line 263
    .end local v0    # "$this$commonAppend$iv":Landroidx/collection/SparseArrayCompat;
    .end local v1    # "$i$f$commonAppend":I
    .end local v2    # "pos$iv":I
    :goto_0
    return-void
.end method

.method public clear()V
    .locals 6

    .line 257
    move-object v0, p0

    .local v0, "$this$commonClear$iv":Landroidx/collection/SparseArrayCompat;
    const/4 v1, 0x0

    .line 482
    .local v1, "$i$f$commonClear":I
    iget v2, v0, Landroidx/collection/SparseArrayCompat;->size:I

    .line 483
    .local v2, "n$iv":I
    iget-object v3, v0, Landroidx/collection/SparseArrayCompat;->values:[Ljava/lang/Object;

    .line 484
    .local v3, "values$iv":[Ljava/lang/Object;
    const/4 v4, 0x0

    .local v4, "i$iv":I
    :goto_0
    if-ge v4, v2, :cond_0

    .line 485
    const/4 v5, 0x0

    aput-object v5, v3, v4

    .line 484
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_0
    nop

    .line 487
    .end local v4    # "i$iv":I
    const/4 v4, 0x0

    iput v4, v0, Landroidx/collection/SparseArrayCompat;->size:I

    .line 488
    iput-boolean v4, v0, Landroidx/collection/SparseArrayCompat;->garbage:Z

    .line 489
    nop

    .line 257
    .end local v0    # "$this$commonClear$iv":Landroidx/collection/SparseArrayCompat;
    .end local v1    # "$i$f$commonClear":I
    .end local v2    # "n$iv":I
    .end local v3    # "values$iv":[Ljava/lang/Object;
    return-void
.end method

.method public clone()Landroidx/collection/SparseArrayCompat;
    .locals 2

    .line 93
    invoke-super {p0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    const-string v1, "null cannot be cast to non-null type androidx.collection.SparseArrayCompat<E of androidx.collection.SparseArrayCompat>"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Landroidx/collection/SparseArrayCompat;

    .line 94
    .local v0, "clone":Landroidx/collection/SparseArrayCompat;
    iget-object v1, p0, Landroidx/collection/SparseArrayCompat;->keys:[I

    invoke-virtual {v1}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [I

    iput-object v1, v0, Landroidx/collection/SparseArrayCompat;->keys:[I

    .line 95
    iget-object v1, p0, Landroidx/collection/SparseArrayCompat;->values:[Ljava/lang/Object;

    invoke-virtual {v1}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [Ljava/lang/Object;

    iput-object v1, v0, Landroidx/collection/SparseArrayCompat;->values:[Ljava/lang/Object;

    .line 96
    return-object v0
.end method

.method public bridge synthetic clone()Ljava/lang/Object;
    .locals 1

    .line 60
    invoke-virtual {p0}, Landroidx/collection/SparseArrayCompat;->clone()Landroidx/collection/SparseArrayCompat;

    move-result-object v0

    return-object v0
.end method

.method public get(I)Ljava/lang/Object;
    .locals 1
    .param p1, "key"    # I

    .line 102
    invoke-static {p0, p1}, Landroidx/collection/SparseArrayCompatKt;->commonGet(Landroidx/collection/SparseArrayCompat;I)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public indexOfValue(Ljava/lang/Object;)I
    .locals 5
    .param p1, "value"    # Ljava/lang/Object;

    .line 246
    move-object v0, p0

    .local v0, "$this$commonIndexOfValue$iv":Landroidx/collection/SparseArrayCompat;
    const/4 v1, 0x0

    .line 459
    .local v1, "$i$f$commonIndexOfValue":I
    iget-boolean v2, v0, Landroidx/collection/SparseArrayCompat;->garbage:Z

    if-eqz v2, :cond_0

    .line 460
    invoke-static {v0}, Landroidx/collection/SparseArrayCompatKt;->access$gc(Landroidx/collection/SparseArrayCompat;)V

    .line 462
    :cond_0
    const/4 v2, 0x0

    .local v2, "i$iv":I
    iget v3, v0, Landroidx/collection/SparseArrayCompat;->size:I

    :goto_0
    if-ge v2, v3, :cond_2

    .line 463
    iget-object v4, v0, Landroidx/collection/SparseArrayCompat;->values:[Ljava/lang/Object;

    aget-object v4, v4, v2

    if-ne v4, p1, :cond_1

    .line 464
    goto :goto_1

    .line 462
    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_2
    nop

    .line 467
    .end local v2    # "i$iv":I
    const/4 v2, -0x1

    .line 246
    .end local v0    # "$this$commonIndexOfValue$iv":Landroidx/collection/SparseArrayCompat;
    .end local v1    # "$i$f$commonIndexOfValue":I
    :goto_1
    return v2
.end method

.method public keyAt(I)I
    .locals 3
    .param p1, "index"    # I

    .line 212
    move-object v0, p0

    .local v0, "$this$commonKeyAt$iv":Landroidx/collection/SparseArrayCompat;
    const/4 v1, 0x0

    .line 423
    .local v1, "$i$f$commonKeyAt":I
    iget-boolean v2, v0, Landroidx/collection/SparseArrayCompat;->garbage:Z

    if-eqz v2, :cond_0

    .line 424
    invoke-static {v0}, Landroidx/collection/SparseArrayCompatKt;->access$gc(Landroidx/collection/SparseArrayCompat;)V

    .line 426
    :cond_0
    iget-object v2, v0, Landroidx/collection/SparseArrayCompat;->keys:[I

    aget v0, v2, p1

    .line 212
    .end local v0    # "$this$commonKeyAt$iv":Landroidx/collection/SparseArrayCompat;
    .end local v1    # "$i$f$commonKeyAt":I
    return v0
.end method

.method public put(ILjava/lang/Object;)V
    .locals 7
    .param p1, "key"    # I
    .param p2, "value"    # Ljava/lang/Object;

    .line 169
    move-object v0, p0

    .local v0, "$this$commonPut$iv":Landroidx/collection/SparseArrayCompat;
    const/4 v1, 0x0

    .line 353
    .local v1, "$i$f$commonPut":I
    iget-object v2, v0, Landroidx/collection/SparseArrayCompat;->keys:[I

    iget v3, v0, Landroidx/collection/SparseArrayCompat;->size:I

    invoke-static {v2, v3, p1}, Landroidx/collection/internal/ContainerHelpersKt;->binarySearch([III)I

    move-result v2

    .line 354
    .local v2, "i$iv":I
    if-ltz v2, :cond_0

    .line 355
    iget-object v3, v0, Landroidx/collection/SparseArrayCompat;->values:[Ljava/lang/Object;

    aput-object p2, v3, v2

    goto/16 :goto_0

    .line 357
    :cond_0
    not-int v2, v2

    .line 358
    iget v3, v0, Landroidx/collection/SparseArrayCompat;->size:I

    if-ge v2, v3, :cond_1

    iget-object v3, v0, Landroidx/collection/SparseArrayCompat;->values:[Ljava/lang/Object;

    aget-object v3, v3, v2

    invoke-static {}, Landroidx/collection/SparseArrayCompatKt;->access$getDELETED$p()Ljava/lang/Object;

    move-result-object v4

    if-ne v3, v4, :cond_1

    .line 359
    iget-object v3, v0, Landroidx/collection/SparseArrayCompat;->keys:[I

    aput p1, v3, v2

    .line 360
    iget-object v3, v0, Landroidx/collection/SparseArrayCompat;->values:[Ljava/lang/Object;

    aput-object p2, v3, v2

    .line 361
    goto :goto_1

    .line 363
    :cond_1
    iget-boolean v3, v0, Landroidx/collection/SparseArrayCompat;->garbage:Z

    if-eqz v3, :cond_2

    iget v3, v0, Landroidx/collection/SparseArrayCompat;->size:I

    iget-object v4, v0, Landroidx/collection/SparseArrayCompat;->keys:[I

    array-length v4, v4

    if-lt v3, v4, :cond_2

    .line 364
    invoke-static {v0}, Landroidx/collection/SparseArrayCompatKt;->access$gc(Landroidx/collection/SparseArrayCompat;)V

    .line 367
    iget-object v3, v0, Landroidx/collection/SparseArrayCompat;->keys:[I

    iget v4, v0, Landroidx/collection/SparseArrayCompat;->size:I

    invoke-static {v3, v4, p1}, Landroidx/collection/internal/ContainerHelpersKt;->binarySearch([III)I

    move-result v3

    not-int v2, v3

    .line 369
    :cond_2
    iget v3, v0, Landroidx/collection/SparseArrayCompat;->size:I

    iget-object v4, v0, Landroidx/collection/SparseArrayCompat;->keys:[I

    array-length v4, v4

    if-lt v3, v4, :cond_3

    .line 370
    iget v3, v0, Landroidx/collection/SparseArrayCompat;->size:I

    add-int/lit8 v3, v3, 0x1

    invoke-static {v3}, Landroidx/collection/internal/ContainerHelpersKt;->idealIntArraySize(I)I

    move-result v3

    .line 371
    .local v3, "n$iv":I
    iget-object v4, v0, Landroidx/collection/SparseArrayCompat;->keys:[I

    invoke-static {v4, v3}, Ljava/util/Arrays;->copyOf([II)[I

    move-result-object v4

    const-string v5, "copyOf(this, newSize)"

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object v4, v0, Landroidx/collection/SparseArrayCompat;->keys:[I

    .line 372
    iget-object v4, v0, Landroidx/collection/SparseArrayCompat;->values:[Ljava/lang/Object;

    invoke-static {v4, v3}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v4

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object v4, v0, Landroidx/collection/SparseArrayCompat;->values:[Ljava/lang/Object;

    .line 374
    .end local v3    # "n$iv":I
    :cond_3
    iget v3, v0, Landroidx/collection/SparseArrayCompat;->size:I

    sub-int/2addr v3, v2

    if-eqz v3, :cond_4

    .line 375
    iget-object v3, v0, Landroidx/collection/SparseArrayCompat;->keys:[I

    .line 376
    iget-object v4, v0, Landroidx/collection/SparseArrayCompat;->keys:[I

    .line 377
    add-int/lit8 v5, v2, 0x1

    .line 378
    nop

    .line 379
    iget v6, v0, Landroidx/collection/SparseArrayCompat;->size:I

    .line 375
    invoke-static {v3, v4, v5, v2, v6}, Lkotlin/collections/ArraysKt___ArraysJvmKt;->copyInto([I[IIII)[I

    .line 381
    iget-object v3, v0, Landroidx/collection/SparseArrayCompat;->values:[Ljava/lang/Object;

    .line 382
    iget-object v4, v0, Landroidx/collection/SparseArrayCompat;->values:[Ljava/lang/Object;

    .line 383
    add-int/lit8 v5, v2, 0x1

    .line 384
    nop

    .line 385
    iget v6, v0, Landroidx/collection/SparseArrayCompat;->size:I

    .line 381
    invoke-static {v3, v4, v5, v2, v6}, Lkotlin/collections/ArraysKt___ArraysJvmKt;->copyInto([Ljava/lang/Object;[Ljava/lang/Object;III)[Ljava/lang/Object;

    .line 388
    :cond_4
    iget-object v3, v0, Landroidx/collection/SparseArrayCompat;->keys:[I

    aput p1, v3, v2

    .line 389
    iget-object v3, v0, Landroidx/collection/SparseArrayCompat;->values:[Ljava/lang/Object;

    aput-object p2, v3, v2

    .line 390
    iget v3, v0, Landroidx/collection/SparseArrayCompat;->size:I

    add-int/lit8 v3, v3, 0x1

    iput v3, v0, Landroidx/collection/SparseArrayCompat;->size:I

    .line 392
    :goto_0
    nop

    .line 169
    .end local v0    # "$this$commonPut$iv":Landroidx/collection/SparseArrayCompat;
    .end local v1    # "$i$f$commonPut":I
    .end local v2    # "i$iv":I
    :goto_1
    return-void
.end method

.method public size()I
    .locals 3

    .line 191
    move-object v0, p0

    .local v0, "$this$commonSize$iv":Landroidx/collection/SparseArrayCompat;
    const/4 v1, 0x0

    .line 412
    .local v1, "$i$f$commonSize":I
    iget-boolean v2, v0, Landroidx/collection/SparseArrayCompat;->garbage:Z

    if-eqz v2, :cond_0

    .line 413
    invoke-static {v0}, Landroidx/collection/SparseArrayCompatKt;->access$gc(Landroidx/collection/SparseArrayCompat;)V

    .line 415
    :cond_0
    iget v0, v0, Landroidx/collection/SparseArrayCompat;->size:I

    .line 191
    .end local v0    # "$this$commonSize$iv":Landroidx/collection/SparseArrayCompat;
    .end local v1    # "$i$f$commonSize":I
    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 8

    .line 271
    move-object v0, p0

    .local v0, "$this$commonToString$iv":Landroidx/collection/SparseArrayCompat;
    const/4 v1, 0x0

    .line 513
    .local v1, "$i$f$commonToString":I
    invoke-virtual {v0}, Landroidx/collection/SparseArrayCompat;->size()I

    move-result v2

    if-gtz v2, :cond_0

    .line 514
    const-string v2, "{}"

    goto :goto_2

    .line 516
    :cond_0
    new-instance v2, Ljava/lang/StringBuilder;

    iget v3, v0, Landroidx/collection/SparseArrayCompat;->size:I

    mul-int/lit8 v3, v3, 0x1c

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(I)V

    .line 517
    .local v2, "buffer$iv":Ljava/lang/StringBuilder;
    const/16 v3, 0x7b

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 518
    const/4 v3, 0x0

    .local v3, "i$iv":I
    iget v4, v0, Landroidx/collection/SparseArrayCompat;->size:I

    :goto_0
    if-ge v3, v4, :cond_3

    .line 519
    if-lez v3, :cond_1

    .line 520
    const-string v5, ", "

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 522
    :cond_1
    invoke-virtual {v0, v3}, Landroidx/collection/SparseArrayCompat;->keyAt(I)I

    move-result v5

    .line 523
    .local v5, "key$iv":I
    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 524
    const/16 v6, 0x3d

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 525
    invoke-virtual {v0, v3}, Landroidx/collection/SparseArrayCompat;->valueAt(I)Ljava/lang/Object;

    move-result-object v6

    .line 526
    .local v6, "value$iv":Ljava/lang/Object;
    if-eq v6, v0, :cond_2

    .line 527
    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    goto :goto_1

    .line 529
    :cond_2
    const-string v7, "(this Map)"

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 518
    .end local v5    # "key$iv":I
    .end local v6    # "value$iv":Ljava/lang/Object;
    :goto_1
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_3
    nop

    .line 532
    .end local v3    # "i$iv":I
    const/16 v3, 0x7d

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 533
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const-string v4, "buffer.toString()"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v2, v3

    .line 271
    .end local v0    # "$this$commonToString$iv":Landroidx/collection/SparseArrayCompat;
    .end local v1    # "$i$f$commonToString":I
    .end local v2    # "buffer$iv":Ljava/lang/StringBuilder;
    :goto_2
    return-object v2
.end method

.method public valueAt(I)Ljava/lang/Object;
    .locals 3
    .param p1, "index"    # I

    .line 218
    move-object v0, p0

    .local v0, "$this$commonValueAt$iv":Landroidx/collection/SparseArrayCompat;
    const/4 v1, 0x0

    .line 431
    .local v1, "$i$f$commonValueAt":I
    iget-boolean v2, v0, Landroidx/collection/SparseArrayCompat;->garbage:Z

    if-eqz v2, :cond_0

    .line 432
    invoke-static {v0}, Landroidx/collection/SparseArrayCompatKt;->access$gc(Landroidx/collection/SparseArrayCompat;)V

    .line 438
    :cond_0
    iget-object v2, v0, Landroidx/collection/SparseArrayCompat;->values:[Ljava/lang/Object;

    aget-object v0, v2, p1

    .line 218
    .end local v0    # "$this$commonValueAt$iv":Landroidx/collection/SparseArrayCompat;
    .end local v1    # "$i$f$commonValueAt":I
    return-object v0
.end method
