.class public final Landroidx/collection/ArrayMap$ValueIterator;
.super Landroidx/collection/IndexBasedArrayIterator;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/collection/ArrayMap;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x11
    name = "ValueIterator"
.end annotation


# instance fields
.field public final synthetic this$0:Landroidx/collection/ArrayMap;


# direct methods
.method public constructor <init>(Landroidx/collection/ArrayMap;)V
    .locals 1
    .param p1, "this$0"    # Landroidx/collection/ArrayMap;

    .line 517
    .local p0, "this":Landroidx/collection/ArrayMap$ValueIterator;, "Landroidx/collection/ArrayMap<TK;TV;>.ValueIterator;"
    iput-object p1, p0, Landroidx/collection/ArrayMap$ValueIterator;->this$0:Landroidx/collection/ArrayMap;

    .line 518
    invoke-virtual {p1}, Landroidx/collection/SimpleArrayMap;->size()I

    move-result v0

    invoke-direct {p0, v0}, Landroidx/collection/IndexBasedArrayIterator;-><init>(I)V

    .line 519
    return-void
.end method


# virtual methods
.method public elementAt(I)Ljava/lang/Object;
    .locals 1
    .param p1, "index"    # I

    .line 523
    .local p0, "this":Landroidx/collection/ArrayMap$ValueIterator;, "Landroidx/collection/ArrayMap<TK;TV;>.ValueIterator;"
    iget-object v0, p0, Landroidx/collection/ArrayMap$ValueIterator;->this$0:Landroidx/collection/ArrayMap;

    invoke-virtual {v0, p1}, Landroidx/collection/SimpleArrayMap;->valueAt(I)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public removeAt(I)V
    .locals 1
    .param p1, "index"    # I

    .line 528
    .local p0, "this":Landroidx/collection/ArrayMap$ValueIterator;, "Landroidx/collection/ArrayMap<TK;TV;>.ValueIterator;"
    iget-object v0, p0, Landroidx/collection/ArrayMap$ValueIterator;->this$0:Landroidx/collection/ArrayMap;

    invoke-virtual {v0, p1}, Landroidx/collection/SimpleArrayMap;->removeAt(I)Ljava/lang/Object;

    .line 529
    return-void
.end method
