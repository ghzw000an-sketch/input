.class public interface abstract Landroidx/startup/Initializer;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract create(Landroid/content/Context;)Ljava/lang/Object;
.end method

.method public abstract dependencies()Ljava/util/List;
.end method
