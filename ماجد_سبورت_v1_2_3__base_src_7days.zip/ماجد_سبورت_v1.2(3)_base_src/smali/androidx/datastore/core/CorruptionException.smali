.class public abstract Landroidx/datastore/core/CorruptionException;
.super Ljava/io/IOException;
.source ""
