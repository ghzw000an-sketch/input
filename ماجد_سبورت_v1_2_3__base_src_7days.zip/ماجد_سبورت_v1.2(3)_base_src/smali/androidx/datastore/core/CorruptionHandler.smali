.class public interface abstract Landroidx/datastore/core/CorruptionHandler;
.super Ljava/lang/Object;
.source ""
