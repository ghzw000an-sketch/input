.class public final Landroidx/datastore/core/Data;
.super Landroidx/datastore/core/State;
.source ""


# instance fields
.field public final hashCode:I

.field public final value:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Ljava/lang/Object;I)V
    .locals 1
    .param p1, "value"    # Ljava/lang/Object;
    .param p2, "hashCode"    # I

    .line 55
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Landroidx/datastore/core/State;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    iput-object p1, p0, Landroidx/datastore/core/Data;->value:Ljava/lang/Object;

    iput p2, p0, Landroidx/datastore/core/Data;->hashCode:I

    return-void
.end method


# virtual methods
.method public final checkHashCode()V
    .locals 3

    .line 57
    iget-object v0, p0, Landroidx/datastore/core/Data;->value:Ljava/lang/Object;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    goto :goto_0

    :cond_0
    move v0, v1

    :goto_0
    iget v2, p0, Landroidx/datastore/core/Data;->hashCode:I

    if-ne v0, v2, :cond_1

    const/4 v1, 0x1

    :cond_1
    if-eqz v1, :cond_2

    .line 60
    return-void

    .line 57
    :cond_2
    const/4 v0, 0x0

    .line 58
    .local v0, "$i$a$-check-Data$checkHashCode$1":I
    nop

    .line 57
    .end local v0    # "$i$a$-check-Data$checkHashCode$1":I
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Data in DataStore was mutated but DataStore is only compatible with Immutable types."

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final getValue()Ljava/lang/Object;
    .locals 1

    .line 55
    iget-object v0, p0, Landroidx/datastore/core/Data;->value:Ljava/lang/Object;

    return-object v0
.end method
