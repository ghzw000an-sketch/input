.class public abstract Landroidx/datastore/core/handlers/ReplaceFileCorruptionHandler;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroidx/datastore/core/CorruptionHandler;
