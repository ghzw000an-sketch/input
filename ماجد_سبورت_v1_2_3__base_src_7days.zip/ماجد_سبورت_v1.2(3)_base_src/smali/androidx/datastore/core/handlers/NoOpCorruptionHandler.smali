.class public final Landroidx/datastore/core/handlers/NoOpCorruptionHandler;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroidx/datastore/core/CorruptionHandler;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 24
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
