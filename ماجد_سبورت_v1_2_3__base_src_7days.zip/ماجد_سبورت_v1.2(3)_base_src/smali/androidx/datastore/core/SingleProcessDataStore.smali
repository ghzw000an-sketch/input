.class public final Landroidx/datastore/core/SingleProcessDataStore;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroidx/datastore/core/DataStore;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/datastore/core/SingleProcessDataStore$Message;,
        Landroidx/datastore/core/SingleProcessDataStore$UncloseableOutputStream;,
        Landroidx/datastore/core/SingleProcessDataStore$Companion;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSingleProcessDataStore.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SingleProcessDataStore.kt\nandroidx/datastore/core/SingleProcessDataStore\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 Mutex.kt\nkotlinx/coroutines/sync/MutexKt\n*L\n1#1,497:1\n1849#2,2:498\n109#3,11:500\n*S KotlinDebug\n*F\n+ 1 SingleProcessDataStore.kt\nandroidx/datastore/core/SingleProcessDataStore\n*L\n348#1:498,2\n350#1:500,11\n*E\n"
.end annotation


# static fields
.field public static final Companion:Landroidx/datastore/core/SingleProcessDataStore$Companion;

.field public static final activeFiles:Ljava/util/Set;

.field public static final activeFilesLock:Ljava/lang/Object;


# instance fields
.field public final SCRATCH_SUFFIX:Ljava/lang/String;

.field public final actor:Landroidx/datastore/core/SimpleActor;

.field public final corruptionHandler:Landroidx/datastore/core/CorruptionHandler;

.field public final data:Lkotlinx/coroutines/flow/Flow;

.field public final downstreamFlow:Lkotlinx/coroutines/flow/MutableStateFlow;

.field public final file$delegate:Lkotlin/Lazy;

.field public initTasks:Ljava/util/List;

.field public final produceFile:Lkotlin/jvm/functions/Function0;

.field public final scope:Lkotlinx/coroutines/CoroutineScope;

.field public final serializer:Landroidx/datastore/core/Serializer;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 163
    new-instance v0, Landroidx/datastore/core/SingleProcessDataStore$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Landroidx/datastore/core/SingleProcessDataStore$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Landroidx/datastore/core/SingleProcessDataStore;->Companion:Landroidx/datastore/core/SingleProcessDataStore$Companion;

    .line 492
    new-instance v0, Ljava/util/LinkedHashSet;

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    sput-object v0, Landroidx/datastore/core/SingleProcessDataStore;->activeFiles:Ljava/util/Set;

    .line 494
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Landroidx/datastore/core/SingleProcessDataStore;->activeFilesLock:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lkotlin/jvm/functions/Function0;Landroidx/datastore/core/Serializer;Ljava/util/List;Landroidx/datastore/core/CorruptionHandler;Lkotlinx/coroutines/CoroutineScope;)V
    .locals 6
    .param p1, "produceFile"    # Lkotlin/jvm/functions/Function0;
    .param p2, "serializer"    # Landroidx/datastore/core/Serializer;
    .param p3, "initTasksList"    # Ljava/util/List;
    .param p4, "corruptionHandler"    # Landroidx/datastore/core/CorruptionHandler;
    .param p5, "scope"    # Lkotlinx/coroutines/CoroutineScope;

    const-string v0, "produceFile"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "serializer"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "initTasksList"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "corruptionHandler"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "scope"

    invoke-static {p5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 76
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 77
    iput-object p1, p0, Landroidx/datastore/core/SingleProcessDataStore;->produceFile:Lkotlin/jvm/functions/Function0;

    .line 78
    iput-object p2, p0, Landroidx/datastore/core/SingleProcessDataStore;->serializer:Landroidx/datastore/core/Serializer;

    .line 87
    iput-object p4, p0, Landroidx/datastore/core/SingleProcessDataStore;->corruptionHandler:Landroidx/datastore/core/CorruptionHandler;

    .line 88
    iput-object p5, p0, Landroidx/datastore/core/SingleProcessDataStore;->scope:Lkotlinx/coroutines/CoroutineScope;

    .line 91
    new-instance v0, Landroidx/datastore/core/SingleProcessDataStore$data$1;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Landroidx/datastore/core/SingleProcessDataStore$data$1;-><init>(Landroidx/datastore/core/SingleProcessDataStore;Lkotlin/coroutines/Continuation;)V

    invoke-static {v0}, Lkotlinx/coroutines/flow/FlowKt;->flow(Lkotlin/jvm/functions/Function2;)Lkotlinx/coroutines/flow/Flow;

    move-result-object v0

    iput-object v0, p0, Landroidx/datastore/core/SingleProcessDataStore;->data:Lkotlinx/coroutines/flow/Flow;

    .line 161
    const-string v0, ".tmp"

    iput-object v0, p0, Landroidx/datastore/core/SingleProcessDataStore;->SCRATCH_SUFFIX:Ljava/lang/String;

    .line 163
    new-instance v0, Landroidx/datastore/core/SingleProcessDataStore$file$2;

    invoke-direct {v0, p0}, Landroidx/datastore/core/SingleProcessDataStore$file$2;-><init>(Landroidx/datastore/core/SingleProcessDataStore;)V

    invoke-static {v0}, Lkotlin/LazyKt__LazyJVMKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v0

    iput-object v0, p0, Landroidx/datastore/core/SingleProcessDataStore;->file$delegate:Lkotlin/Lazy;

    .line 182
    sget-object v0, Landroidx/datastore/core/UnInitialized;->INSTANCE:Landroidx/datastore/core/UnInitialized;

    invoke-static {v0}, Lkotlinx/coroutines/flow/StateFlowKt;->MutableStateFlow(Ljava/lang/Object;)Lkotlinx/coroutines/flow/MutableStateFlow;

    move-result-object v0

    iput-object v0, p0, Landroidx/datastore/core/SingleProcessDataStore;->downstreamFlow:Lkotlinx/coroutines/flow/MutableStateFlow;

    .line 185
    invoke-static {p3}, Lkotlin/collections/CollectionsKt___CollectionsKt;->toList(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, Landroidx/datastore/core/SingleProcessDataStore;->initTasks:Ljava/util/List;

    .line 211
    new-instance v0, Landroidx/datastore/core/SimpleActor;

    .line 212
    iget-object v2, p0, Landroidx/datastore/core/SingleProcessDataStore;->scope:Lkotlinx/coroutines/CoroutineScope;

    .line 213
    new-instance v3, Landroidx/datastore/core/SingleProcessDataStore$actor$1;

    invoke-direct {v3, p0}, Landroidx/datastore/core/SingleProcessDataStore$actor$1;-><init>(Landroidx/datastore/core/SingleProcessDataStore;)V

    .line 224
    sget-object v4, Landroidx/datastore/core/SingleProcessDataStore$actor$2;->INSTANCE:Landroidx/datastore/core/SingleProcessDataStore$actor$2;

    .line 236
    new-instance v5, Landroidx/datastore/core/SingleProcessDataStore$actor$3;

    invoke-direct {v5, p0, v1}, Landroidx/datastore/core/SingleProcessDataStore$actor$3;-><init>(Landroidx/datastore/core/SingleProcessDataStore;Lkotlin/coroutines/Continuation;)V

    .line 211
    invoke-direct {v0, v2, v3, v4, v5}, Landroidx/datastore/core/SimpleActor;-><init>(Lkotlinx/coroutines/CoroutineScope;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;)V

    iput-object v0, p0, Landroidx/datastore/core/SingleProcessDataStore;->actor:Landroidx/datastore/core/SimpleActor;

    .line 76
    return-void
.end method

.method public static final synthetic access$getActiveFiles$cp()Ljava/util/Set;
    .locals 1

    .line 76
    sget-object v0, Landroidx/datastore/core/SingleProcessDataStore;->activeFiles:Ljava/util/Set;

    return-object v0
.end method

.method public static final synthetic access$getActiveFilesLock$cp()Ljava/lang/Object;
    .locals 1

    .line 76
    sget-object v0, Landroidx/datastore/core/SingleProcessDataStore;->activeFilesLock:Ljava/lang/Object;

    return-object v0
.end method

.method public static final synthetic access$getActor$p(Landroidx/datastore/core/SingleProcessDataStore;)Landroidx/datastore/core/SimpleActor;
    .locals 1
    .param p0, "$this"    # Landroidx/datastore/core/SingleProcessDataStore;

    .line 76
    iget-object v0, p0, Landroidx/datastore/core/SingleProcessDataStore;->actor:Landroidx/datastore/core/SimpleActor;

    return-object v0
.end method

.method public static final synthetic access$getDownstreamFlow$p(Landroidx/datastore/core/SingleProcessDataStore;)Lkotlinx/coroutines/flow/MutableStateFlow;
    .locals 1
    .param p0, "$this"    # Landroidx/datastore/core/SingleProcessDataStore;

    .line 76
    iget-object v0, p0, Landroidx/datastore/core/SingleProcessDataStore;->downstreamFlow:Lkotlinx/coroutines/flow/MutableStateFlow;

    return-object v0
.end method

.method public static final synthetic access$getFile(Landroidx/datastore/core/SingleProcessDataStore;)Ljava/io/File;
    .locals 1
    .param p0, "$this"    # Landroidx/datastore/core/SingleProcessDataStore;

    .line 76
    invoke-virtual {p0}, Landroidx/datastore/core/SingleProcessDataStore;->getFile()Ljava/io/File;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$getProduceFile$p(Landroidx/datastore/core/SingleProcessDataStore;)Lkotlin/jvm/functions/Function0;
    .locals 1
    .param p0, "$this"    # Landroidx/datastore/core/SingleProcessDataStore;

    .line 76
    iget-object v0, p0, Landroidx/datastore/core/SingleProcessDataStore;->produceFile:Lkotlin/jvm/functions/Function0;

    return-object v0
.end method

.method public static final synthetic access$handleRead(Landroidx/datastore/core/SingleProcessDataStore;Landroidx/datastore/core/SingleProcessDataStore$Message$Read;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 1
    .param p0, "$this"    # Landroidx/datastore/core/SingleProcessDataStore;
    .param p1, "read"    # Landroidx/datastore/core/SingleProcessDataStore$Message$Read;
    .param p2, "$completion"    # Lkotlin/coroutines/Continuation;

    .line 76
    invoke-virtual {p0, p1, p2}, Landroidx/datastore/core/SingleProcessDataStore;->handleRead(Landroidx/datastore/core/SingleProcessDataStore$Message$Read;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$handleUpdate(Landroidx/datastore/core/SingleProcessDataStore;Landroidx/datastore/core/SingleProcessDataStore$Message$Update;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 1
    .param p0, "$this"    # Landroidx/datastore/core/SingleProcessDataStore;
    .param p1, "update"    # Landroidx/datastore/core/SingleProcessDataStore$Message$Update;
    .param p2, "$completion"    # Lkotlin/coroutines/Continuation;

    .line 76
    invoke-virtual {p0, p1, p2}, Landroidx/datastore/core/SingleProcessDataStore;->handleUpdate(Landroidx/datastore/core/SingleProcessDataStore$Message$Update;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$readAndInit(Landroidx/datastore/core/SingleProcessDataStore;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 1
    .param p0, "$this"    # Landroidx/datastore/core/SingleProcessDataStore;
    .param p1, "$completion"    # Lkotlin/coroutines/Continuation;

    .line 76
    invoke-virtual {p0, p1}, Landroidx/datastore/core/SingleProcessDataStore;->readAndInit(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$readAndInitOrPropagateAndThrowFailure(Landroidx/datastore/core/SingleProcessDataStore;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 1
    .param p0, "$this"    # Landroidx/datastore/core/SingleProcessDataStore;
    .param p1, "$completion"    # Lkotlin/coroutines/Continuation;

    .line 76
    invoke-virtual {p0, p1}, Landroidx/datastore/core/SingleProcessDataStore;->readAndInitOrPropagateAndThrowFailure(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$readAndInitOrPropagateFailure(Landroidx/datastore/core/SingleProcessDataStore;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 1
    .param p0, "$this"    # Landroidx/datastore/core/SingleProcessDataStore;
    .param p1, "$completion"    # Lkotlin/coroutines/Continuation;

    .line 76
    invoke-virtual {p0, p1}, Landroidx/datastore/core/SingleProcessDataStore;->readAndInitOrPropagateFailure(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$readData(Landroidx/datastore/core/SingleProcessDataStore;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 1
    .param p0, "$this"    # Landroidx/datastore/core/SingleProcessDataStore;
    .param p1, "$completion"    # Lkotlin/coroutines/Continuation;

    .line 76
    invoke-virtual {p0, p1}, Landroidx/datastore/core/SingleProcessDataStore;->readData(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$readDataOrHandleCorruption(Landroidx/datastore/core/SingleProcessDataStore;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 1
    .param p0, "$this"    # Landroidx/datastore/core/SingleProcessDataStore;
    .param p1, "$completion"    # Lkotlin/coroutines/Continuation;

    .line 76
    invoke-virtual {p0, p1}, Landroidx/datastore/core/SingleProcessDataStore;->readDataOrHandleCorruption(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$transformAndWrite(Landroidx/datastore/core/SingleProcessDataStore;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/CoroutineContext;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 1
    .param p0, "$this"    # Landroidx/datastore/core/SingleProcessDataStore;
    .param p1, "transform"    # Lkotlin/jvm/functions/Function2;
    .param p2, "callerContext"    # Lkotlin/coroutines/CoroutineContext;
    .param p3, "$completion"    # Lkotlin/coroutines/Continuation;

    .line 76
    invoke-virtual {p0, p1, p2, p3}, Landroidx/datastore/core/SingleProcessDataStore;->transformAndWrite(Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/CoroutineContext;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method


# virtual methods
.method public final createParentDirectories(Ljava/io/File;)V
    .locals 5
    .param p1, "$this$createParentDirectories"    # Ljava/io/File;

    .line 449
    invoke-virtual {p1}, Ljava/io/File;->getCanonicalFile()Ljava/io/File;

    move-result-object v0

    invoke-virtual {v0}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object v0

    .line 451
    .local v0, "parent":Ljava/io/File;
    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    move-object v1, v0

    .local v1, "it":Ljava/io/File;
    const/4 v2, 0x0

    .line 452
    .local v2, "$i$a$-let-SingleProcessDataStore$createParentDirectories$1":I
    invoke-virtual {v1}, Ljava/io/File;->mkdirs()Z

    .line 453
    invoke-virtual {v1}, Ljava/io/File;->isDirectory()Z

    move-result v3

    if-eqz v3, :cond_1

    .line 456
    nop

    .line 451
    .end local v1    # "it":Ljava/io/File;
    .end local v2    # "$i$a$-let-SingleProcessDataStore$createParentDirectories$1":I
    nop

    .line 457
    :goto_0
    return-void

    .line 454
    .restart local v1    # "it":Ljava/io/File;
    .restart local v2    # "$i$a$-let-SingleProcessDataStore$createParentDirectories$1":I
    :cond_1
    new-instance v3, Ljava/io/IOException;

    const-string v4, "Unable to create parent directories of "

    invoke-static {v4, p1}, Lkotlin/jvm/internal/Intrinsics;->stringPlus(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v3
.end method

.method public getData()Lkotlinx/coroutines/flow/Flow;
    .locals 1

    .line 91
    iget-object v0, p0, Landroidx/datastore/core/SingleProcessDataStore;->data:Lkotlinx/coroutines/flow/Flow;

    return-object v0
.end method

.method public final getFile()Ljava/io/File;
    .locals 1

    .line 163
    iget-object v0, p0, Landroidx/datastore/core/SingleProcessDataStore;->file$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/io/File;

    return-object v0
.end method

.method public final handleRead(Landroidx/datastore/core/SingleProcessDataStore$Message$Read;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 3
    .param p1, "read"    # Landroidx/datastore/core/SingleProcessDataStore$Message$Read;
    .param p2, "$completion"    # Lkotlin/coroutines/Continuation;

    .line 248
    iget-object v0, p0, Landroidx/datastore/core/SingleProcessDataStore;->downstreamFlow:Lkotlinx/coroutines/flow/MutableStateFlow;

    invoke-interface {v0}, Lkotlinx/coroutines/flow/MutableStateFlow;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/datastore/core/State;

    .line 249
    .local v0, "currentState":Landroidx/datastore/core/State;
    instance-of v1, v0, Landroidx/datastore/core/Data;

    if-eqz v1, :cond_0

    goto :goto_1

    .line 252
    :cond_0
    instance-of v1, v0, Landroidx/datastore/core/ReadException;

    if-eqz v1, :cond_2

    .line 253
    invoke-virtual {p1}, Landroidx/datastore/core/SingleProcessDataStore$Message$Read;->getLastState()Landroidx/datastore/core/State;

    move-result-object v1

    if-ne v0, v1, :cond_5

    .line 254
    invoke-virtual {p0, p2}, Landroidx/datastore/core/SingleProcessDataStore;->readAndInitOrPropagateFailure(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt__IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v2

    if-ne v1, v2, :cond_1

    return-object v1

    :cond_1
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 265
    :goto_0
    return-object v1

    .line 260
    :cond_2
    sget-object v1, Landroidx/datastore/core/UnInitialized;->INSTANCE:Landroidx/datastore/core/UnInitialized;

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_4

    .line 261
    invoke-virtual {p0, p2}, Landroidx/datastore/core/SingleProcessDataStore;->readAndInitOrPropagateFailure(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt__IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v2

    if-ne v1, v2, :cond_3

    return-object v1

    :cond_3
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    goto :goto_0

    .line 263
    :cond_4
    instance-of v1, v0, Landroidx/datastore/core/Final;

    nop

    if-nez v1, :cond_6

    .line 265
    .end local v0    # "currentState":Landroidx/datastore/core/State;
    :cond_5
    :goto_1
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0

    .line 263
    .restart local v0    # "currentState":Landroidx/datastore/core/State;
    :cond_6
    new-instance v1, Ljava/lang/IllegalStateException;

    const-string v2, "Can\'t read in final state."

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method public final handleUpdate(Landroidx/datastore/core/SingleProcessDataStore$Message$Update;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 10

    instance-of v0, p2, Landroidx/datastore/core/SingleProcessDataStore$handleUpdate$1;

    if-eqz v0, :cond_0

    move-object v0, p2

    check-cast v0, Landroidx/datastore/core/SingleProcessDataStore$handleUpdate$1;

    iget v1, v0, Landroidx/datastore/core/SingleProcessDataStore$handleUpdate$1;->label:I

    const/high16 v2, -0x80000000

    and-int/2addr v1, v2

    if-eqz v1, :cond_0

    iget p2, v0, Landroidx/datastore/core/SingleProcessDataStore$handleUpdate$1;->label:I

    sub-int/2addr p2, v2

    iput p2, v0, Landroidx/datastore/core/SingleProcessDataStore$handleUpdate$1;->label:I

    .local v0, "$continuation":Lkotlin/coroutines/Continuation;
    :goto_0
    goto :goto_1

    .end local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    :cond_0
    new-instance v0, Landroidx/datastore/core/SingleProcessDataStore$handleUpdate$1;

    invoke-direct {v0, p0, p2}, Landroidx/datastore/core/SingleProcessDataStore$handleUpdate$1;-><init>(Landroidx/datastore/core/SingleProcessDataStore;Lkotlin/coroutines/Continuation;)V

    goto :goto_0

    .restart local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    :goto_1
    iget-object p2, v0, Landroidx/datastore/core/SingleProcessDataStore$handleUpdate$1;->result:Ljava/lang/Object;

    .local p2, "$result":Ljava/lang/Object;
    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt__IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v1

    .line 267
    iget v2, v0, Landroidx/datastore/core/SingleProcessDataStore$handleUpdate$1;->label:I

    const/4 v3, 0x0

    const/4 v4, 0x0

    nop

    packed-switch v2, :pswitch_data_0

    .line 298
    .end local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    .end local p2    # "$result":Ljava/lang/Object;
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 267
    .restart local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    .local v4, "$i$a$-runCatching-SingleProcessDataStore$handleUpdate$2":I
    .restart local p2    # "$result":Ljava/lang/Object;
    :pswitch_0
    const/4 p1, 0x0

    .end local v4    # "$i$a$-runCatching-SingleProcessDataStore$handleUpdate$2":I
    .local p1, "$i$a$-runCatching-SingleProcessDataStore$handleUpdate$2":I
    iget-object v1, v0, Landroidx/datastore/core/SingleProcessDataStore$handleUpdate$1;->L$0:Ljava/lang/Object;

    check-cast v1, Lkotlinx/coroutines/CompletableDeferred;

    :try_start_0
    invoke-static {p2}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move-object v4, p2

    goto/16 :goto_6

    .line 271
    .end local p1    # "$i$a$-runCatching-SingleProcessDataStore$handleUpdate$2":I
    :catchall_0
    move-exception p1

    goto/16 :goto_9

    .line 267
    :pswitch_1
    move-object v2, v3

    .local v2, "$this$handleUpdate_u24lambda_u2d0":Landroidx/datastore/core/SingleProcessDataStore;
    .restart local v4    # "$i$a$-runCatching-SingleProcessDataStore$handleUpdate$2":I
    .local p1, "update":Landroidx/datastore/core/SingleProcessDataStore$Message$Update;
    const/4 v4, 0x0

    iget-object v5, v0, Landroidx/datastore/core/SingleProcessDataStore$handleUpdate$1;->L$2:Ljava/lang/Object;

    check-cast v5, Lkotlinx/coroutines/CompletableDeferred;

    iget-object v6, v0, Landroidx/datastore/core/SingleProcessDataStore$handleUpdate$1;->L$1:Ljava/lang/Object;

    move-object v2, v6

    check-cast v2, Landroidx/datastore/core/SingleProcessDataStore;

    iget-object v6, v0, Landroidx/datastore/core/SingleProcessDataStore$handleUpdate$1;->L$0:Ljava/lang/Object;

    move-object p1, v6

    check-cast p1, Landroidx/datastore/core/SingleProcessDataStore$Message$Update;

    :try_start_1
    invoke-static {p2}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    goto/16 :goto_5

    .line 271
    .end local v2    # "$this$handleUpdate_u24lambda_u2d0":Landroidx/datastore/core/SingleProcessDataStore;
    .end local v4    # "$i$a$-runCatching-SingleProcessDataStore$handleUpdate$2":I
    .end local p1    # "update":Landroidx/datastore/core/SingleProcessDataStore$Message$Update;
    :catchall_1
    move-exception p1

    move-object v1, v5

    goto/16 :goto_9

    .line 267
    :pswitch_2
    move-object v1, v3

    .local v1, "$this$handleUpdate_u24lambda_u2d0":Landroidx/datastore/core/SingleProcessDataStore;
    .local v3, "currentState":Landroidx/datastore/core/State;
    .restart local v4    # "$i$a$-runCatching-SingleProcessDataStore$handleUpdate$2":I
    .restart local p1    # "update":Landroidx/datastore/core/SingleProcessDataStore$Message$Update;
    const/4 v2, 0x0

    .end local v4    # "$i$a$-runCatching-SingleProcessDataStore$handleUpdate$2":I
    .local v2, "$i$a$-runCatching-SingleProcessDataStore$handleUpdate$2":I
    iget-object v4, v0, Landroidx/datastore/core/SingleProcessDataStore$handleUpdate$1;->L$0:Ljava/lang/Object;

    check-cast v4, Lkotlinx/coroutines/CompletableDeferred;

    :try_start_2
    invoke-static {p2}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    move-object v5, v4

    move-object v4, p2

    goto :goto_2

    .line 271
    .end local v1    # "$this$handleUpdate_u24lambda_u2d0":Landroidx/datastore/core/SingleProcessDataStore;
    .end local v2    # "$i$a$-runCatching-SingleProcessDataStore$handleUpdate$2":I
    .end local v3    # "currentState":Landroidx/datastore/core/State;
    .end local p1    # "update":Landroidx/datastore/core/SingleProcessDataStore$Message$Update;
    :catchall_2
    move-exception p1

    move-object v1, v4

    goto/16 :goto_9

    .line 267
    :pswitch_3
    invoke-static {p2}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    move-object v2, p0

    .line 270
    .local v2, "this":Landroidx/datastore/core/SingleProcessDataStore;
    .restart local p1    # "update":Landroidx/datastore/core/SingleProcessDataStore$Message$Update;
    invoke-virtual {p1}, Landroidx/datastore/core/SingleProcessDataStore$Message$Update;->getAck()Lkotlinx/coroutines/CompletableDeferred;

    move-result-object v4

    .line 271
    :try_start_3
    sget-object v5, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v5, v2

    .local v5, "$this$handleUpdate_u24lambda_u2d0":Landroidx/datastore/core/SingleProcessDataStore;
    const/4 v6, 0x0

    .line 273
    .local v6, "$i$a$-runCatching-SingleProcessDataStore$handleUpdate$2":I
    iget-object v7, v5, Landroidx/datastore/core/SingleProcessDataStore;->downstreamFlow:Lkotlinx/coroutines/flow/MutableStateFlow;

    invoke-interface {v7}, Lkotlinx/coroutines/flow/MutableStateFlow;->getValue()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroidx/datastore/core/State;

    .line 274
    .local v7, "currentState":Landroidx/datastore/core/State;
    instance-of v8, v7, Landroidx/datastore/core/Data;

    const/4 v9, 0x1

    if-eqz v8, :cond_2

    .line 276
    invoke-virtual {p1}, Landroidx/datastore/core/SingleProcessDataStore$Message$Update;->getTransform()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-virtual {p1}, Landroidx/datastore/core/SingleProcessDataStore$Message$Update;->getCallerContext()Lkotlin/coroutines/CoroutineContext;

    move-result-object v8

    iput-object v4, v0, Landroidx/datastore/core/SingleProcessDataStore$handleUpdate$1;->L$0:Ljava/lang/Object;

    iput v9, v0, Landroidx/datastore/core/SingleProcessDataStore$handleUpdate$1;->label:I

    invoke-virtual {v5, v3, v8, v0}, Landroidx/datastore/core/SingleProcessDataStore;->transformAndWrite(Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/CoroutineContext;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v3

    .end local v2    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    if-ne v3, v1, :cond_1

    .line 267
    return-object v1

    .line 276
    :cond_1
    move-object v1, v5

    move v2, v6

    move-object v5, v4

    move-object v4, v3

    move-object v3, v7

    .end local v5    # "$this$handleUpdate_u24lambda_u2d0":Landroidx/datastore/core/SingleProcessDataStore;
    .end local v6    # "$i$a$-runCatching-SingleProcessDataStore$handleUpdate$2":I
    .end local v7    # "currentState":Landroidx/datastore/core/State;
    .restart local v1    # "$this$handleUpdate_u24lambda_u2d0":Landroidx/datastore/core/SingleProcessDataStore;
    .local v2, "$i$a$-runCatching-SingleProcessDataStore$handleUpdate$2":I
    .restart local v3    # "currentState":Landroidx/datastore/core/State;
    :goto_2
    move-object v1, v5

    goto :goto_7

    .line 274
    .end local v1    # "$this$handleUpdate_u24lambda_u2d0":Landroidx/datastore/core/SingleProcessDataStore;
    .end local v3    # "currentState":Landroidx/datastore/core/State;
    .local v2, "this":Landroidx/datastore/core/SingleProcessDataStore;
    .restart local v5    # "$this$handleUpdate_u24lambda_u2d0":Landroidx/datastore/core/SingleProcessDataStore;
    .restart local v6    # "$i$a$-runCatching-SingleProcessDataStore$handleUpdate$2":I
    .restart local v7    # "currentState":Landroidx/datastore/core/State;
    :cond_2
    nop

    .line 278
    .end local v2    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    instance-of v2, v7, Landroidx/datastore/core/ReadException;

    if-eqz v2, :cond_3

    :goto_3
    goto :goto_4

    :cond_3
    instance-of v9, v7, Landroidx/datastore/core/UnInitialized;

    goto :goto_3

    :goto_4
    if-eqz v9, :cond_7

    .line 279
    invoke-virtual {p1}, Landroidx/datastore/core/SingleProcessDataStore$Message$Update;->getLastState()Landroidx/datastore/core/State;

    move-result-object v2

    if-ne v7, v2, :cond_6

    .line 281
    iput-object p1, v0, Landroidx/datastore/core/SingleProcessDataStore$handleUpdate$1;->L$0:Ljava/lang/Object;

    iput-object v5, v0, Landroidx/datastore/core/SingleProcessDataStore$handleUpdate$1;->L$1:Ljava/lang/Object;

    iput-object v4, v0, Landroidx/datastore/core/SingleProcessDataStore$handleUpdate$1;->L$2:Ljava/lang/Object;

    const/4 v2, 0x2

    iput v2, v0, Landroidx/datastore/core/SingleProcessDataStore$handleUpdate$1;->label:I

    invoke-virtual {v5, v0}, Landroidx/datastore/core/SingleProcessDataStore;->readAndInitOrPropagateAndThrowFailure(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .end local v7    # "currentState":Landroidx/datastore/core/State;
    if-ne v2, v1, :cond_4

    .line 267
    return-object v1

    .line 281
    :cond_4
    move-object v2, v5

    move-object v5, v4

    move v4, v6

    .line 284
    .end local v5    # "$this$handleUpdate_u24lambda_u2d0":Landroidx/datastore/core/SingleProcessDataStore;
    .end local v6    # "$i$a$-runCatching-SingleProcessDataStore$handleUpdate$2":I
    .local v2, "$this$handleUpdate_u24lambda_u2d0":Landroidx/datastore/core/SingleProcessDataStore;
    .restart local v4    # "$i$a$-runCatching-SingleProcessDataStore$handleUpdate$2":I
    :goto_5
    :try_start_4
    invoke-virtual {p1}, Landroidx/datastore/core/SingleProcessDataStore$Message$Update;->getTransform()Lkotlin/jvm/functions/Function2;

    move-result-object v6

    invoke-virtual {p1}, Landroidx/datastore/core/SingleProcessDataStore$Message$Update;->getCallerContext()Lkotlin/coroutines/CoroutineContext;

    move-result-object v7

    iput-object v5, v0, Landroidx/datastore/core/SingleProcessDataStore$handleUpdate$1;->L$0:Ljava/lang/Object;

    iput-object v3, v0, Landroidx/datastore/core/SingleProcessDataStore$handleUpdate$1;->L$1:Ljava/lang/Object;

    iput-object v3, v0, Landroidx/datastore/core/SingleProcessDataStore$handleUpdate$1;->L$2:Ljava/lang/Object;

    const/4 v3, 0x3

    iput v3, v0, Landroidx/datastore/core/SingleProcessDataStore$handleUpdate$1;->label:I

    invoke-virtual {v2, v6, v7, v0}, Landroidx/datastore/core/SingleProcessDataStore;->transformAndWrite(Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/CoroutineContext;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v3
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .end local v2    # "$this$handleUpdate_u24lambda_u2d0":Landroidx/datastore/core/SingleProcessDataStore;
    .end local p1    # "update":Landroidx/datastore/core/SingleProcessDataStore$Message$Update;
    if-ne v3, v1, :cond_5

    .line 267
    return-object v1

    .line 284
    :cond_5
    move p1, v4

    move-object v1, v5

    move-object v4, v3

    .end local v4    # "$i$a$-runCatching-SingleProcessDataStore$handleUpdate$2":I
    .local p1, "$i$a$-runCatching-SingleProcessDataStore$handleUpdate$2":I
    :goto_6
    move v2, p1

    .line 273
    .end local p1    # "$i$a$-runCatching-SingleProcessDataStore$handleUpdate$2":I
    .local v2, "$i$a$-runCatching-SingleProcessDataStore$handleUpdate$2":I
    :goto_7
    nop

    .line 271
    .end local v2    # "$i$a$-runCatching-SingleProcessDataStore$handleUpdate$2":I
    :try_start_5
    invoke-static {v4}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    goto :goto_a

    .line 279
    .restart local v5    # "$this$handleUpdate_u24lambda_u2d0":Landroidx/datastore/core/SingleProcessDataStore;
    .restart local v6    # "$i$a$-runCatching-SingleProcessDataStore$handleUpdate$2":I
    .restart local v7    # "currentState":Landroidx/datastore/core/State;
    .local p1, "update":Landroidx/datastore/core/SingleProcessDataStore$Message$Update;
    :cond_6
    nop

    .line 290
    .end local v5    # "$this$handleUpdate_u24lambda_u2d0":Landroidx/datastore/core/SingleProcessDataStore;
    .end local v7    # "currentState":Landroidx/datastore/core/State;
    .end local p1    # "update":Landroidx/datastore/core/SingleProcessDataStore$Message$Update;
    :try_start_6
    move-object p1, v7

    check-cast p1, Landroidx/datastore/core/ReadException;

    invoke-virtual {p1}, Landroidx/datastore/core/ReadException;->getReadException()Ljava/lang/Throwable;

    move-result-object p1

    .end local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    .end local p2    # "$result":Ljava/lang/Object;
    throw p1

    .line 278
    .restart local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    .restart local v5    # "$this$handleUpdate_u24lambda_u2d0":Landroidx/datastore/core/SingleProcessDataStore;
    .restart local v7    # "currentState":Landroidx/datastore/core/State;
    .restart local p1    # "update":Landroidx/datastore/core/SingleProcessDataStore$Message$Update;
    .restart local p2    # "$result":Ljava/lang/Object;
    :cond_7
    nop

    .line 294
    .end local v5    # "$this$handleUpdate_u24lambda_u2d0":Landroidx/datastore/core/SingleProcessDataStore;
    .end local v7    # "currentState":Landroidx/datastore/core/State;
    .end local p1    # "update":Landroidx/datastore/core/SingleProcessDataStore$Message$Update;
    instance-of p1, v7, Landroidx/datastore/core/Final;

    nop

    if-eqz p1, :cond_8

    move-object p1, v7

    check-cast p1, Landroidx/datastore/core/Final;

    invoke-virtual {p1}, Landroidx/datastore/core/Final;->getFinalException()Ljava/lang/Throwable;

    move-result-object p1

    .end local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    .end local p2    # "$result":Ljava/lang/Object;
    :goto_8
    throw p1

    .restart local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    .restart local p2    # "$result":Ljava/lang/Object;
    :cond_8
    new-instance p1, Lkotlin/NoWhenBranchMatchedException;

    invoke-direct {p1}, Lkotlin/NoWhenBranchMatchedException;-><init>()V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    goto :goto_8

    .line 271
    .end local v6    # "$i$a$-runCatching-SingleProcessDataStore$handleUpdate$2":I
    :goto_9
    sget-object v2, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {p1}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object p1

    invoke-static {p1}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    .line 270
    :goto_a
    invoke-static {v1, p1}, Lkotlinx/coroutines/CompletableDeferredKt;->completeWith(Lkotlinx/coroutines/CompletableDeferred;Ljava/lang/Object;)Z

    .line 298
    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p1

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final readAndInit(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 18

    move-object/from16 v0, p1

    instance-of v1, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;

    if-eqz v1, :cond_0

    move-object v1, v0

    check-cast v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;

    iget v2, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->label:I

    const/high16 v3, -0x80000000

    and-int/2addr v2, v3

    if-eqz v2, :cond_0

    iget v0, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->label:I

    sub-int/2addr v0, v3

    iput v0, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->label:I

    move-object/from16 v2, p0

    .local v1, "$continuation":Lkotlin/coroutines/Continuation;
    :goto_0
    goto :goto_1

    .end local v1    # "$continuation":Lkotlin/coroutines/Continuation;
    :cond_0
    new-instance v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;

    move-object/from16 v2, p0

    invoke-direct {v1, v2, v0}, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;-><init>(Landroidx/datastore/core/SingleProcessDataStore;Lkotlin/coroutines/Continuation;)V

    goto :goto_0

    .restart local v1    # "$continuation":Lkotlin/coroutines/Continuation;
    :goto_1
    iget-object v0, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->result:Ljava/lang/Object;

    .local v0, "$result":Ljava/lang/Object;
    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt__IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v3

    .line 317
    iget v4, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->label:I

    const/4 v5, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    nop

    packed-switch v4, :pswitch_data_0

    .line 355
    .end local v0    # "$result":Ljava/lang/Object;
    .end local v1    # "$continuation":Lkotlin/coroutines/Continuation;
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 317
    .restart local v0    # "$result":Ljava/lang/Object;
    .restart local v1    # "$continuation":Lkotlin/coroutines/Continuation;
    :pswitch_0
    move-object v3, v6

    .local v3, "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    move v4, v7

    .local v4, "$i$f$withLock":I
    .local v6, "owner$iv":Ljava/lang/Object;
    const/4 v4, 0x0

    const/4 v6, 0x0

    iget-object v8, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->L$3:Ljava/lang/Object;

    move-object v3, v8

    check-cast v3, Lkotlinx/coroutines/sync/Mutex;

    iget-object v8, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->L$2:Ljava/lang/Object;

    check-cast v8, Lkotlin/jvm/internal/Ref$BooleanRef;

    iget-object v9, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->L$1:Ljava/lang/Object;

    check-cast v9, Lkotlin/jvm/internal/Ref$ObjectRef;

    iget-object v10, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->L$0:Ljava/lang/Object;

    check-cast v10, Landroidx/datastore/core/SingleProcessDataStore;

    invoke-static {v0}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    move-object v5, v3

    move-object v3, v1

    move-object v1, v0

    goto/16 :goto_8

    .end local v3    # "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    .end local v4    # "$i$f$withLock":I
    .end local v6    # "owner$iv":Ljava/lang/Object;
    :pswitch_1
    move-object v4, v6

    .local v4, "updateLock":Lkotlinx/coroutines/sync/Mutex;
    move-object v8, v6

    .local v8, "initializationComplete":Lkotlin/jvm/internal/Ref$BooleanRef;
    move v9, v7

    .local v9, "$i$a$-forEach-SingleProcessDataStore$readAndInit$2":I
    move v10, v7

    .local v10, "$i$f$forEach":I
    move-object v11, v6

    .local v11, "initData":Lkotlin/jvm/internal/Ref$ObjectRef;
    const/4 v10, 0x0

    const/4 v9, 0x0

    iget-object v12, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->L$5:Ljava/lang/Object;

    check-cast v12, Ljava/util/Iterator;

    iget-object v13, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->L$4:Ljava/lang/Object;

    check-cast v13, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1;

    iget-object v14, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->L$3:Ljava/lang/Object;

    move-object v8, v14

    check-cast v8, Lkotlin/jvm/internal/Ref$BooleanRef;

    iget-object v14, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->L$2:Ljava/lang/Object;

    move-object v11, v14

    check-cast v11, Lkotlin/jvm/internal/Ref$ObjectRef;

    iget-object v14, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->L$1:Ljava/lang/Object;

    move-object v4, v14

    check-cast v4, Lkotlinx/coroutines/sync/Mutex;

    iget-object v14, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->L$0:Ljava/lang/Object;

    check-cast v14, Landroidx/datastore/core/SingleProcessDataStore;

    invoke-static {v0}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    move-object v5, v6

    goto/16 :goto_6

    .end local v4    # "updateLock":Lkotlinx/coroutines/sync/Mutex;
    .end local v8    # "initializationComplete":Lkotlin/jvm/internal/Ref$BooleanRef;
    .end local v9    # "$i$a$-forEach-SingleProcessDataStore$readAndInit$2":I
    .end local v10    # "$i$f$forEach":I
    .end local v11    # "initData":Lkotlin/jvm/internal/Ref$ObjectRef;
    :pswitch_2
    move-object v4, v6

    .restart local v4    # "updateLock":Lkotlinx/coroutines/sync/Mutex;
    move-object v8, v6

    .local v8, "initData":Lkotlin/jvm/internal/Ref$ObjectRef;
    iget-object v9, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->L$3:Ljava/lang/Object;

    check-cast v9, Lkotlin/jvm/internal/Ref$ObjectRef;

    iget-object v10, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->L$2:Ljava/lang/Object;

    move-object v8, v10

    check-cast v8, Lkotlin/jvm/internal/Ref$ObjectRef;

    iget-object v10, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->L$1:Ljava/lang/Object;

    move-object v4, v10

    check-cast v4, Lkotlinx/coroutines/sync/Mutex;

    iget-object v10, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->L$0:Ljava/lang/Object;

    check-cast v10, Landroidx/datastore/core/SingleProcessDataStore;

    invoke-static {v0}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    move-object v11, v10

    move-object v10, v9

    move-object v9, v8

    move-object v8, v0

    goto :goto_4

    .end local v4    # "updateLock":Lkotlinx/coroutines/sync/Mutex;
    .end local v8    # "initData":Lkotlin/jvm/internal/Ref$ObjectRef;
    :pswitch_3
    invoke-static {v0}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    move-object/from16 v10, p0

    .line 319
    .local v10, "this":Landroidx/datastore/core/SingleProcessDataStore;
    iget-object v4, v10, Landroidx/datastore/core/SingleProcessDataStore;->downstreamFlow:Lkotlinx/coroutines/flow/MutableStateFlow;

    invoke-interface {v4}, Lkotlinx/coroutines/flow/MutableStateFlow;->getValue()Ljava/lang/Object;

    move-result-object v4

    sget-object v8, Landroidx/datastore/core/UnInitialized;->INSTANCE:Landroidx/datastore/core/UnInitialized;

    invoke-static {v4, v8}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_1

    iget-object v4, v10, Landroidx/datastore/core/SingleProcessDataStore;->downstreamFlow:Lkotlinx/coroutines/flow/MutableStateFlow;

    invoke-interface {v4}, Lkotlinx/coroutines/flow/MutableStateFlow;->getValue()Ljava/lang/Object;

    move-result-object v4

    instance-of v4, v4, Landroidx/datastore/core/ReadException;

    if-eqz v4, :cond_2

    :cond_1
    goto :goto_2

    :cond_2
    move v4, v7

    goto :goto_3

    :goto_2
    move v4, v5

    :goto_3
    if-eqz v4, :cond_9

    .line 321
    invoke-static {v7, v5, v6}, Lkotlinx/coroutines/sync/MutexKt;->Mutex$default(ZILjava/lang/Object;)Lkotlinx/coroutines/sync/Mutex;

    move-result-object v4

    .line 322
    .restart local v4    # "updateLock":Lkotlinx/coroutines/sync/Mutex;
    new-instance v8, Lkotlin/jvm/internal/Ref$ObjectRef;

    invoke-direct {v8}, Lkotlin/jvm/internal/Ref$ObjectRef;-><init>()V

    move-object v9, v8

    .local v9, "initData":Lkotlin/jvm/internal/Ref$ObjectRef;
    iput-object v10, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->L$0:Ljava/lang/Object;

    iput-object v4, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->L$1:Ljava/lang/Object;

    iput-object v9, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->L$2:Ljava/lang/Object;

    iput-object v9, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->L$3:Ljava/lang/Object;

    iput v5, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->label:I

    invoke-virtual {v10, v1}, Landroidx/datastore/core/SingleProcessDataStore;->readDataOrHandleCorruption(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v8

    .end local v10    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    if-ne v8, v3, :cond_3

    .line 317
    return-object v3

    .line 322
    :cond_3
    move-object v11, v10

    move-object v10, v9

    .line 317
    :goto_4
    iput-object v8, v10, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    .line 324
    new-instance v8, Lkotlin/jvm/internal/Ref$BooleanRef;

    invoke-direct {v8}, Lkotlin/jvm/internal/Ref$BooleanRef;-><init>()V

    .line 327
    .local v8, "initializationComplete":Lkotlin/jvm/internal/Ref$BooleanRef;
    new-instance v10, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1;

    invoke-direct {v10, v4, v8, v9, v11}, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1;-><init>(Lkotlinx/coroutines/sync/Mutex;Lkotlin/jvm/internal/Ref$BooleanRef;Lkotlin/jvm/internal/Ref$ObjectRef;Landroidx/datastore/core/SingleProcessDataStore;)V

    .line 348
    .local v10, "api":Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1;
    iget-object v12, v11, Landroidx/datastore/core/SingleProcessDataStore;->initTasks:Ljava/util/List;

    if-nez v12, :cond_4

    move-object v10, v11

    goto :goto_7

    .local v12, "$this$forEach$iv":Ljava/lang/Iterable;
    :cond_4
    const/4 v13, 0x0

    .line 498
    .local v13, "$i$f$forEach":I
    invoke-interface {v12}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v14

    move-object/from16 v17, v11

    move-object v11, v9

    move-object v9, v12

    move-object v12, v14

    move-object/from16 v14, v17

    move/from16 v17, v13

    move-object v13, v10

    move/from16 v10, v17

    .end local v12    # "$this$forEach$iv":Ljava/lang/Iterable;
    .local v9, "$this$forEach$iv":Ljava/lang/Iterable;
    .local v10, "$i$f$forEach":I
    .restart local v11    # "initData":Lkotlin/jvm/internal/Ref$ObjectRef;
    .local v13, "api":Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1;
    :goto_5
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v15

    nop

    if-eqz v15, :cond_6

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v15

    .local v15, "element$iv":Ljava/lang/Object;
    move-object v7, v15

    check-cast v7, Lkotlin/jvm/functions/Function2;

    .local v7, "it":Lkotlin/jvm/functions/Function2;
    const/16 v16, 0x0

    .line 348
    .local v16, "$i$a$-forEach-SingleProcessDataStore$readAndInit$2":I
    iput-object v14, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->L$0:Ljava/lang/Object;

    iput-object v4, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->L$1:Ljava/lang/Object;

    iput-object v11, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->L$2:Ljava/lang/Object;

    iput-object v8, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->L$3:Ljava/lang/Object;

    iput-object v13, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->L$4:Ljava/lang/Object;

    iput-object v12, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->L$5:Ljava/lang/Object;

    const/4 v5, 0x2

    iput v5, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->label:I

    invoke-interface {v7, v13, v1}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    .end local v7    # "it":Lkotlin/jvm/functions/Function2;
    .end local v9    # "$this$forEach$iv":Ljava/lang/Iterable;
    .end local v13    # "api":Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1;
    .end local v15    # "element$iv":Ljava/lang/Object;
    if-ne v5, v3, :cond_5

    .line 317
    return-object v3

    .line 348
    :cond_5
    move-object v5, v9

    move/from16 v9, v16

    .end local v16    # "$i$a$-forEach-SingleProcessDataStore$readAndInit$2":I
    .local v9, "$i$a$-forEach-SingleProcessDataStore$readAndInit$2":I
    :goto_6
    move-object v9, v5

    .local v9, "$this$forEach$iv":Ljava/lang/Iterable;
    const/4 v5, 0x1

    const/4 v7, 0x0

    .restart local v13    # "api":Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1;
    goto :goto_5

    .line 499
    .end local v9    # "$this$forEach$iv":Ljava/lang/Iterable;
    .end local v13    # "api":Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1;
    :cond_6
    move-object v9, v11

    move-object v10, v14

    .line 349
    .end local v10    # "$i$f$forEach":I
    .end local v11    # "initData":Lkotlin/jvm/internal/Ref$ObjectRef;
    .local v9, "initData":Lkotlin/jvm/internal/Ref$ObjectRef;
    :goto_7
    iput-object v6, v10, Landroidx/datastore/core/SingleProcessDataStore;->initTasks:Ljava/util/List;

    .line 350
    move-object v5, v4

    .line 500
    .local v5, "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    const/4 v7, 0x0

    .local v7, "owner$iv":Ljava/lang/Object;
    const/4 v11, 0x0

    .line 501
    .local v11, "$i$f$withLock":I
    nop

    .line 505
    iput-object v10, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->L$0:Ljava/lang/Object;

    iput-object v9, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->L$1:Ljava/lang/Object;

    iput-object v8, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->L$2:Ljava/lang/Object;

    iput-object v5, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->L$3:Ljava/lang/Object;

    iput-object v6, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->L$4:Ljava/lang/Object;

    iput-object v6, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->L$5:Ljava/lang/Object;

    const/4 v6, 0x3

    iput v6, v1, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$1;->label:I

    invoke-interface {v5, v7, v1}, Lkotlinx/coroutines/sync/Mutex;->lock(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v4

    .end local v4    # "updateLock":Lkotlinx/coroutines/sync/Mutex;
    .end local v8    # "initializationComplete":Lkotlin/jvm/internal/Ref$BooleanRef;
    .end local v9    # "initData":Lkotlin/jvm/internal/Ref$ObjectRef;
    if-ne v4, v3, :cond_7

    .line 317
    return-object v3

    .line 505
    :cond_7
    move-object v6, v7

    move v4, v11

    move-object v3, v1

    move-object v1, v0

    .line 506
    .end local v0    # "$result":Ljava/lang/Object;
    .end local v7    # "owner$iv":Ljava/lang/Object;
    .end local v11    # "$i$f$withLock":I
    .local v1, "$result":Ljava/lang/Object;
    .local v3, "$continuation":Lkotlin/coroutines/Continuation;
    .local v4, "$i$f$withLock":I
    .restart local v6    # "owner$iv":Ljava/lang/Object;
    :goto_8
    nop

    .line 116
    const/4 v0, 0x0

    .line 351
    .local v0, "$i$a$-withLock$default-SingleProcessDataStore$readAndInit$3":I
    const/4 v7, 0x1

    :try_start_0
    iput-boolean v7, v8, Lkotlin/jvm/internal/Ref$BooleanRef;->element:Z

    .line 352
    nop

    .end local v0    # "$i$a$-withLock$default-SingleProcessDataStore$readAndInit$3":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 509
    invoke-interface {v5, v6}, Lkotlinx/coroutines/sync/Mutex;->unlock(Ljava/lang/Object;)V

    .line 116
    nop

    .line 354
    .end local v4    # "$i$f$withLock":I
    .end local v5    # "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    .end local v6    # "owner$iv":Ljava/lang/Object;
    iget-object v0, v10, Landroidx/datastore/core/SingleProcessDataStore;->downstreamFlow:Lkotlinx/coroutines/flow/MutableStateFlow;

    new-instance v4, Landroidx/datastore/core/Data;

    iget-object v5, v9, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    iget-object v6, v9, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    if-eqz v6, :cond_8

    invoke-virtual {v6}, Ljava/lang/Object;->hashCode()I

    move-result v7

    goto :goto_9

    :cond_8
    const/4 v7, 0x0

    :goto_9
    invoke-direct {v4, v5, v7}, Landroidx/datastore/core/Data;-><init>(Ljava/lang/Object;I)V

    invoke-interface {v0, v4}, Lkotlinx/coroutines/flow/MutableStateFlow;->setValue(Ljava/lang/Object;)V

    .line 355
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0

    .line 510
    .restart local v4    # "$i$f$withLock":I
    .restart local v5    # "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    .restart local v6    # "owner$iv":Ljava/lang/Object;
    :catchall_0
    move-exception v0

    .line 509
    invoke-interface {v5, v6}, Lkotlinx/coroutines/sync/Mutex;->unlock(Ljava/lang/Object;)V

    throw v0

    .line 319
    .end local v3    # "$continuation":Lkotlin/coroutines/Continuation;
    .end local v4    # "$i$f$withLock":I
    .end local v5    # "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    .end local v6    # "owner$iv":Ljava/lang/Object;
    .local v0, "$result":Ljava/lang/Object;
    .local v1, "$continuation":Lkotlin/coroutines/Continuation;
    .local v10, "this":Landroidx/datastore/core/SingleProcessDataStore;
    :cond_9
    new-instance v3, Ljava/lang/IllegalStateException;

    const-string v4, "Check failed."

    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v3

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final readAndInitOrPropagateAndThrowFailure(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 6

    instance-of v0, p1, Landroidx/datastore/core/SingleProcessDataStore$readAndInitOrPropagateAndThrowFailure$1;

    if-eqz v0, :cond_0

    move-object v0, p1

    check-cast v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInitOrPropagateAndThrowFailure$1;

    iget v1, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInitOrPropagateAndThrowFailure$1;->label:I

    const/high16 v2, -0x80000000

    and-int/2addr v1, v2

    if-eqz v1, :cond_0

    iget p1, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInitOrPropagateAndThrowFailure$1;->label:I

    sub-int/2addr p1, v2

    iput p1, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInitOrPropagateAndThrowFailure$1;->label:I

    .local v0, "$continuation":Lkotlin/coroutines/Continuation;
    :goto_0
    goto :goto_1

    .end local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    :cond_0
    new-instance v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInitOrPropagateAndThrowFailure$1;

    invoke-direct {v0, p0, p1}, Landroidx/datastore/core/SingleProcessDataStore$readAndInitOrPropagateAndThrowFailure$1;-><init>(Landroidx/datastore/core/SingleProcessDataStore;Lkotlin/coroutines/Continuation;)V

    goto :goto_0

    .restart local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    :goto_1
    iget-object p1, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInitOrPropagateAndThrowFailure$1;->result:Ljava/lang/Object;

    .local p1, "$result":Ljava/lang/Object;
    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt__IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v1

    .line 300
    iget v2, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInitOrPropagateAndThrowFailure$1;->label:I

    nop

    packed-switch v2, :pswitch_data_0

    .line 307
    .end local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    .end local p1    # "$result":Ljava/lang/Object;
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 300
    .restart local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    .restart local p1    # "$result":Ljava/lang/Object;
    :pswitch_0
    move-object v1, p0

    .local v1, "this":Landroidx/datastore/core/SingleProcessDataStore;
    iget-object v2, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInitOrPropagateAndThrowFailure$1;->L$0:Ljava/lang/Object;

    move-object v1, v2

    check-cast v1, Landroidx/datastore/core/SingleProcessDataStore;

    :try_start_0
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_2

    .line 303
    :catchall_0
    move-exception v2

    goto :goto_3

    .line 300
    .end local v1    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    :pswitch_1
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    move-object v2, p0

    .line 301
    .local v2, "this":Landroidx/datastore/core/SingleProcessDataStore;
    nop

    .line 302
    :try_start_1
    iput-object v2, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInitOrPropagateAndThrowFailure$1;->L$0:Ljava/lang/Object;

    const/4 v3, 0x1

    iput v3, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInitOrPropagateAndThrowFailure$1;->label:I

    invoke-virtual {v2, v0}, Landroidx/datastore/core/SingleProcessDataStore;->readAndInit(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v3
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    if-ne v3, v1, :cond_1

    .line 300
    return-object v1

    .line 302
    :cond_1
    move-object v1, v2

    .end local v2    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    .restart local v1    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    :goto_2
    nop

    .line 307
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v2

    .line 303
    .end local v1    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    .restart local v2    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    :catchall_1
    move-exception v1

    move-object v5, v2

    move-object v2, v1

    move-object v1, v5

    .end local v2    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    .restart local v1    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    :goto_3
    nop

    .line 304
    .local v2, "throwable":Ljava/lang/Throwable;
    iget-object v3, v1, Landroidx/datastore/core/SingleProcessDataStore;->downstreamFlow:Lkotlinx/coroutines/flow/MutableStateFlow;

    new-instance v4, Landroidx/datastore/core/ReadException;

    invoke-direct {v4, v2}, Landroidx/datastore/core/ReadException;-><init>(Ljava/lang/Throwable;)V

    invoke-interface {v3, v4}, Lkotlinx/coroutines/flow/MutableStateFlow;->setValue(Ljava/lang/Object;)V

    .line 305
    throw v2

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final readAndInitOrPropagateFailure(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 6

    instance-of v0, p1, Landroidx/datastore/core/SingleProcessDataStore$readAndInitOrPropagateFailure$1;

    if-eqz v0, :cond_0

    move-object v0, p1

    check-cast v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInitOrPropagateFailure$1;

    iget v1, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInitOrPropagateFailure$1;->label:I

    const/high16 v2, -0x80000000

    and-int/2addr v1, v2

    if-eqz v1, :cond_0

    iget p1, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInitOrPropagateFailure$1;->label:I

    sub-int/2addr p1, v2

    iput p1, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInitOrPropagateFailure$1;->label:I

    .local v0, "$continuation":Lkotlin/coroutines/Continuation;
    :goto_0
    goto :goto_1

    .end local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    :cond_0
    new-instance v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInitOrPropagateFailure$1;

    invoke-direct {v0, p0, p1}, Landroidx/datastore/core/SingleProcessDataStore$readAndInitOrPropagateFailure$1;-><init>(Landroidx/datastore/core/SingleProcessDataStore;Lkotlin/coroutines/Continuation;)V

    goto :goto_0

    .restart local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    :goto_1
    iget-object p1, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInitOrPropagateFailure$1;->result:Ljava/lang/Object;

    .local p1, "$result":Ljava/lang/Object;
    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt__IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v1

    .line 309
    iget v2, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInitOrPropagateFailure$1;->label:I

    nop

    packed-switch v2, :pswitch_data_0

    .line 315
    .end local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    .end local p1    # "$result":Ljava/lang/Object;
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 309
    .restart local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    .restart local p1    # "$result":Ljava/lang/Object;
    :pswitch_0
    move-object v1, p0

    .local v1, "this":Landroidx/datastore/core/SingleProcessDataStore;
    iget-object v2, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInitOrPropagateFailure$1;->L$0:Ljava/lang/Object;

    move-object v1, v2

    check-cast v1, Landroidx/datastore/core/SingleProcessDataStore;

    :try_start_0
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_2

    .line 312
    :catchall_0
    move-exception v2

    goto :goto_3

    .line 309
    .end local v1    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    :pswitch_1
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    move-object v2, p0

    .line 310
    .local v2, "this":Landroidx/datastore/core/SingleProcessDataStore;
    nop

    .line 311
    :try_start_1
    iput-object v2, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInitOrPropagateFailure$1;->L$0:Ljava/lang/Object;

    const/4 v3, 0x1

    iput v3, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInitOrPropagateFailure$1;->label:I

    invoke-virtual {v2, v0}, Landroidx/datastore/core/SingleProcessDataStore;->readAndInit(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v3
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    if-ne v3, v1, :cond_1

    .line 309
    return-object v1

    .line 311
    :cond_1
    move-object v1, v2

    .end local v2    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    .restart local v1    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    :goto_2
    goto :goto_4

    .line 312
    .end local v1    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    .restart local v2    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    :catchall_1
    move-exception v1

    move-object v5, v2

    move-object v2, v1

    move-object v1, v5

    .end local v2    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    .restart local v1    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    :goto_3
    nop

    .line 313
    .local v2, "throwable":Ljava/lang/Throwable;
    iget-object v3, v1, Landroidx/datastore/core/SingleProcessDataStore;->downstreamFlow:Lkotlinx/coroutines/flow/MutableStateFlow;

    new-instance v4, Landroidx/datastore/core/ReadException;

    invoke-direct {v4, v2}, Landroidx/datastore/core/ReadException;-><init>(Ljava/lang/Throwable;)V

    invoke-interface {v3, v4}, Lkotlinx/coroutines/flow/MutableStateFlow;->setValue(Ljava/lang/Object;)V

    .line 315
    .end local v2    # "throwable":Ljava/lang/Throwable;
    :goto_4
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v2

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final readData(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 10

    instance-of v0, p1, Landroidx/datastore/core/SingleProcessDataStore$readData$1;

    if-eqz v0, :cond_0

    move-object v0, p1

    check-cast v0, Landroidx/datastore/core/SingleProcessDataStore$readData$1;

    iget v1, v0, Landroidx/datastore/core/SingleProcessDataStore$readData$1;->label:I

    const/high16 v2, -0x80000000

    and-int/2addr v1, v2

    if-eqz v1, :cond_0

    iget p1, v0, Landroidx/datastore/core/SingleProcessDataStore$readData$1;->label:I

    sub-int/2addr p1, v2

    iput p1, v0, Landroidx/datastore/core/SingleProcessDataStore$readData$1;->label:I

    .local v0, "$continuation":Lkotlin/coroutines/Continuation;
    :goto_0
    goto :goto_1

    .end local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    :cond_0
    new-instance v0, Landroidx/datastore/core/SingleProcessDataStore$readData$1;

    invoke-direct {v0, p0, p1}, Landroidx/datastore/core/SingleProcessDataStore$readData$1;-><init>(Landroidx/datastore/core/SingleProcessDataStore;Lkotlin/coroutines/Continuation;)V

    goto :goto_0

    .restart local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    :goto_1
    iget-object p1, v0, Landroidx/datastore/core/SingleProcessDataStore$readData$1;->result:Ljava/lang/Object;

    .local p1, "$result":Ljava/lang/Object;
    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt__IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v1

    .line 378
    iget v2, v0, Landroidx/datastore/core/SingleProcessDataStore$readData$1;->label:I

    nop

    packed-switch v2, :pswitch_data_0

    .line 387
    .end local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    .end local p1    # "$result":Ljava/lang/Object;
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 378
    .restart local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    .restart local p1    # "$result":Ljava/lang/Object;
    :pswitch_0
    move-object v1, p0

    .local v1, "this":Landroidx/datastore/core/SingleProcessDataStore;
    const/4 v2, 0x0

    .local v2, "$i$a$-use-SingleProcessDataStore$readData$2":I
    const/4 v2, 0x0

    iget-object v3, v0, Landroidx/datastore/core/SingleProcessDataStore$readData$1;->L$2:Ljava/lang/Object;

    check-cast v3, Ljava/lang/Throwable;

    iget-object v4, v0, Landroidx/datastore/core/SingleProcessDataStore$readData$1;->L$1:Ljava/lang/Object;

    check-cast v4, Ljava/io/Closeable;

    iget-object v5, v0, Landroidx/datastore/core/SingleProcessDataStore$readData$1;->L$0:Ljava/lang/Object;

    move-object v1, v5

    check-cast v1, Landroidx/datastore/core/SingleProcessDataStore;

    :try_start_0
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move-object v6, p1

    goto :goto_2

    .line 381
    .end local v2    # "$i$a$-use-SingleProcessDataStore$readData$2":I
    :catchall_0
    move-exception v2

    goto :goto_3

    .line 378
    .end local v1    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    :pswitch_1
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    move-object v2, p0

    .line 379
    .local v2, "this":Landroidx/datastore/core/SingleProcessDataStore;
    nop

    .line 380
    :try_start_1
    new-instance v4, Ljava/io/FileInputStream;

    invoke-virtual {v2}, Landroidx/datastore/core/SingleProcessDataStore;->getFile()Ljava/io/File;

    move-result-object v3

    invoke-direct {v4, v3}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V
    :try_end_1
    .catch Ljava/io/FileNotFoundException; {:try_start_1 .. :try_end_1} :catch_1

    move-object v3, v4

    .local v3, "stream":Ljava/io/FileInputStream;
    const/4 v5, 0x0

    .line 381
    .local v5, "$i$a$-use-SingleProcessDataStore$readData$2":I
    :try_start_2
    iget-object v6, v2, Landroidx/datastore/core/SingleProcessDataStore;->serializer:Landroidx/datastore/core/Serializer;

    iput-object v2, v0, Landroidx/datastore/core/SingleProcessDataStore$readData$1;->L$0:Ljava/lang/Object;

    iput-object v4, v0, Landroidx/datastore/core/SingleProcessDataStore$readData$1;->L$1:Ljava/lang/Object;

    const/4 v7, 0x0

    iput-object v7, v0, Landroidx/datastore/core/SingleProcessDataStore$readData$1;->L$2:Ljava/lang/Object;

    const/4 v8, 0x1

    iput v8, v0, Landroidx/datastore/core/SingleProcessDataStore$readData$1;->label:I

    invoke-interface {v6, v3, v0}, Landroidx/datastore/core/Serializer;->readFrom(Ljava/io/InputStream;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v6
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .end local v3    # "stream":Ljava/io/FileInputStream;
    if-ne v6, v1, :cond_1

    .line 378
    return-object v1

    .line 381
    :cond_1
    move-object v1, v2

    move-object v3, v7

    .end local v2    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    .end local v5    # "$i$a$-use-SingleProcessDataStore$readData$2":I
    .restart local v1    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    :goto_2
    :try_start_3
    invoke-static {v4, v3}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    :try_end_3
    .catch Ljava/io/FileNotFoundException; {:try_start_3 .. :try_end_3} :catch_0

    return-object v6

    .line 383
    :catch_0
    move-exception v2

    goto :goto_4

    .line 381
    .end local v1    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    .restart local v2    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    :catchall_1
    move-exception v1

    move-object v9, v2

    move-object v2, v1

    move-object v1, v9

    .end local v2    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    .restart local v1    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    :goto_3
    nop

    .end local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    .end local v1    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    .end local p1    # "$result":Ljava/lang/Object;
    :try_start_4
    throw v2
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .restart local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    .restart local v1    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    .restart local p1    # "$result":Ljava/lang/Object;
    :catchall_2
    move-exception v3

    :try_start_5
    invoke-static {v4, v2}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    .end local v1    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    .end local p1    # "$result":Ljava/lang/Object;
    throw v3
    :try_end_5
    .catch Ljava/io/FileNotFoundException; {:try_start_5 .. :try_end_5} :catch_0

    .line 383
    .restart local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    .restart local v2    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    .restart local p1    # "$result":Ljava/lang/Object;
    :catch_1
    move-exception v1

    move-object v9, v2

    move-object v2, v1

    move-object v1, v9

    .end local v2    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    .restart local v1    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    :goto_4
    nop

    .line 384
    .local v2, "ex":Ljava/io/FileNotFoundException;
    invoke-virtual {v1}, Landroidx/datastore/core/SingleProcessDataStore;->getFile()Ljava/io/File;

    move-result-object v3

    invoke-virtual {v3}, Ljava/io/File;->exists()Z

    move-result v3

    if-nez v3, :cond_2

    .line 387
    iget-object v3, v1, Landroidx/datastore/core/SingleProcessDataStore;->serializer:Landroidx/datastore/core/Serializer;

    invoke-interface {v3}, Landroidx/datastore/core/Serializer;->getDefaultValue()Ljava/lang/Object;

    move-result-object v3

    return-object v3

    .line 385
    :cond_2
    throw v2

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final readDataOrHandleCorruption(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 6

    instance-of v0, p1, Landroidx/datastore/core/SingleProcessDataStore$readDataOrHandleCorruption$1;

    if-eqz v0, :cond_0

    move-object v0, p1

    check-cast v0, Landroidx/datastore/core/SingleProcessDataStore$readDataOrHandleCorruption$1;

    iget v1, v0, Landroidx/datastore/core/SingleProcessDataStore$readDataOrHandleCorruption$1;->label:I

    const/high16 v2, -0x80000000

    and-int/2addr v1, v2

    if-eqz v1, :cond_0

    iget p1, v0, Landroidx/datastore/core/SingleProcessDataStore$readDataOrHandleCorruption$1;->label:I

    sub-int/2addr p1, v2

    iput p1, v0, Landroidx/datastore/core/SingleProcessDataStore$readDataOrHandleCorruption$1;->label:I

    .local v0, "$continuation":Lkotlin/coroutines/Continuation;
    :goto_0
    goto :goto_1

    .end local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    :cond_0
    new-instance v0, Landroidx/datastore/core/SingleProcessDataStore$readDataOrHandleCorruption$1;

    invoke-direct {v0, p0, p1}, Landroidx/datastore/core/SingleProcessDataStore$readDataOrHandleCorruption$1;-><init>(Landroidx/datastore/core/SingleProcessDataStore;Lkotlin/coroutines/Continuation;)V

    goto :goto_0

    .restart local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    :goto_1
    iget-object p1, v0, Landroidx/datastore/core/SingleProcessDataStore$readDataOrHandleCorruption$1;->result:Ljava/lang/Object;

    .local p1, "$result":Ljava/lang/Object;
    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt__IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v1

    .line 357
    iget v2, v0, Landroidx/datastore/core/SingleProcessDataStore$readDataOrHandleCorruption$1;->label:I

    const/4 v3, 0x0

    nop

    packed-switch v2, :pswitch_data_0

    .line 374
    .end local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    .end local p1    # "$result":Ljava/lang/Object;
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 357
    .restart local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    .restart local p1    # "$result":Ljava/lang/Object;
    :pswitch_0
    move-object v1, v3

    .local v1, "ex":Landroidx/datastore/core/CorruptionException;
    .local v3, "newData":Ljava/lang/Object;
    iget-object v2, v0, Landroidx/datastore/core/SingleProcessDataStore$readDataOrHandleCorruption$1;->L$1:Ljava/lang/Object;

    .end local v3    # "newData":Ljava/lang/Object;
    .local v2, "newData":Ljava/lang/Object;
    iget-object v3, v0, Landroidx/datastore/core/SingleProcessDataStore$readDataOrHandleCorruption$1;->L$0:Ljava/lang/Object;

    move-object v1, v3

    check-cast v1, Landroidx/datastore/core/CorruptionException;

    :try_start_0
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    .line 366
    :catch_0
    move-exception v3

    goto :goto_3

    .line 357
    .end local v1    # "ex":Landroidx/datastore/core/CorruptionException;
    .end local v2    # "newData":Ljava/lang/Object;
    .local v3, "ex":Landroidx/datastore/core/CorruptionException;
    :pswitch_1
    iget-object v2, v0, Landroidx/datastore/core/SingleProcessDataStore$readDataOrHandleCorruption$1;->L$1:Ljava/lang/Object;

    check-cast v2, Landroidx/datastore/core/CorruptionException;

    .end local v3    # "ex":Landroidx/datastore/core/CorruptionException;
    .local v2, "ex":Landroidx/datastore/core/CorruptionException;
    iget-object v3, v0, Landroidx/datastore/core/SingleProcessDataStore$readDataOrHandleCorruption$1;->L$0:Ljava/lang/Object;

    check-cast v3, Landroidx/datastore/core/SingleProcessDataStore;

    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    move-object v4, p1

    .line 364
    .local v4, "newData":Ljava/lang/Object;
    nop

    .line 365
    :try_start_1
    iput-object v2, v0, Landroidx/datastore/core/SingleProcessDataStore$readDataOrHandleCorruption$1;->L$0:Ljava/lang/Object;

    iput-object v4, v0, Landroidx/datastore/core/SingleProcessDataStore$readDataOrHandleCorruption$1;->L$1:Ljava/lang/Object;

    const/4 v5, 0x3

    iput v5, v0, Landroidx/datastore/core/SingleProcessDataStore$readDataOrHandleCorruption$1;->label:I

    invoke-virtual {v3, v4, v0}, Landroidx/datastore/core/SingleProcessDataStore;->writeData$datastore_core(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v3
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1

    if-ne v3, v1, :cond_1

    .line 357
    return-object v1

    .line 365
    :cond_1
    move-object v1, v2

    move-object v2, v4

    .end local v4    # "newData":Ljava/lang/Object;
    .restart local v1    # "ex":Landroidx/datastore/core/CorruptionException;
    .local v2, "newData":Ljava/lang/Object;
    :goto_2
    nop

    .line 374
    return-object v2

    .line 366
    .end local v1    # "ex":Landroidx/datastore/core/CorruptionException;
    .local v2, "ex":Landroidx/datastore/core/CorruptionException;
    .restart local v4    # "newData":Ljava/lang/Object;
    :catch_1
    move-exception v3

    move-object v1, v2

    move-object v2, v4

    .end local v4    # "newData":Ljava/lang/Object;
    .restart local v1    # "ex":Landroidx/datastore/core/CorruptionException;
    .local v2, "newData":Ljava/lang/Object;
    :goto_3
    nop

    .line 369
    .local v3, "writeEx":Ljava/io/IOException;
    invoke-static {v1, v3}, Lkotlin/ExceptionsKt__ExceptionsKt;->addSuppressed(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    .line 370
    throw v1

    .line 357
    .end local v1    # "ex":Landroidx/datastore/core/CorruptionException;
    .end local v2    # "newData":Ljava/lang/Object;
    .end local v3    # "writeEx":Ljava/io/IOException;
    :pswitch_2
    move-object v1, p0

    .local v1, "this":Landroidx/datastore/core/SingleProcessDataStore;
    iget-object v2, v0, Landroidx/datastore/core/SingleProcessDataStore$readDataOrHandleCorruption$1;->L$0:Ljava/lang/Object;

    move-object v1, v2

    check-cast v1, Landroidx/datastore/core/SingleProcessDataStore;

    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    move-object v3, p1

    goto :goto_4

    .end local v1    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    :pswitch_3
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    move-object v2, p0

    .line 358
    .local v2, "this":Landroidx/datastore/core/SingleProcessDataStore;
    nop

    .line 359
    iput-object v2, v0, Landroidx/datastore/core/SingleProcessDataStore$readDataOrHandleCorruption$1;->L$0:Ljava/lang/Object;

    const/4 v3, 0x1

    iput v3, v0, Landroidx/datastore/core/SingleProcessDataStore$readDataOrHandleCorruption$1;->label:I

    invoke-virtual {v2, v0}, Landroidx/datastore/core/SingleProcessDataStore;->readData(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v3

    if-ne v3, v1, :cond_2

    .line 357
    return-object v1

    .line 359
    :cond_2
    move-object v1, v2

    .line 360
    .end local v2    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    .restart local v1    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    :goto_4
    return-object v3

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final transformAndWrite(Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/CoroutineContext;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 8

    instance-of v0, p3, Landroidx/datastore/core/SingleProcessDataStore$transformAndWrite$1;

    if-eqz v0, :cond_0

    move-object v0, p3

    check-cast v0, Landroidx/datastore/core/SingleProcessDataStore$transformAndWrite$1;

    iget v1, v0, Landroidx/datastore/core/SingleProcessDataStore$transformAndWrite$1;->label:I

    const/high16 v2, -0x80000000

    and-int/2addr v1, v2

    if-eqz v1, :cond_0

    iget p3, v0, Landroidx/datastore/core/SingleProcessDataStore$transformAndWrite$1;->label:I

    sub-int/2addr p3, v2

    iput p3, v0, Landroidx/datastore/core/SingleProcessDataStore$transformAndWrite$1;->label:I

    .local v0, "$continuation":Lkotlin/coroutines/Continuation;
    :goto_0
    goto :goto_1

    .end local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    :cond_0
    new-instance v0, Landroidx/datastore/core/SingleProcessDataStore$transformAndWrite$1;

    invoke-direct {v0, p0, p3}, Landroidx/datastore/core/SingleProcessDataStore$transformAndWrite$1;-><init>(Landroidx/datastore/core/SingleProcessDataStore;Lkotlin/coroutines/Continuation;)V

    goto :goto_0

    .restart local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    :goto_1
    iget-object p3, v0, Landroidx/datastore/core/SingleProcessDataStore$transformAndWrite$1;->result:Ljava/lang/Object;

    .local p3, "$result":Ljava/lang/Object;
    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt__IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v1

    .line 392
    iget v2, v0, Landroidx/datastore/core/SingleProcessDataStore$transformAndWrite$1;->label:I

    const/4 v3, 0x0

    nop

    packed-switch v2, :pswitch_data_0

    .line 407
    .end local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    .end local p3    # "$result":Ljava/lang/Object;
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 392
    .restart local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    .restart local p3    # "$result":Ljava/lang/Object;
    :pswitch_0
    iget-object p1, v0, Landroidx/datastore/core/SingleProcessDataStore$transformAndWrite$1;->L$1:Ljava/lang/Object;

    iget-object p2, v0, Landroidx/datastore/core/SingleProcessDataStore$transformAndWrite$1;->L$0:Ljava/lang/Object;

    check-cast p2, Landroidx/datastore/core/SingleProcessDataStore;

    invoke-static {p3}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    goto :goto_3

    :pswitch_1
    move-object p1, p0

    .local p1, "this":Landroidx/datastore/core/SingleProcessDataStore;
    move-object p2, v3

    .local p2, "curDataAndHash":Landroidx/datastore/core/Data;
    move-object v2, v3

    .local v2, "curData":Ljava/lang/Object;
    iget-object v2, v0, Landroidx/datastore/core/SingleProcessDataStore$transformAndWrite$1;->L$2:Ljava/lang/Object;

    iget-object v4, v0, Landroidx/datastore/core/SingleProcessDataStore$transformAndWrite$1;->L$1:Ljava/lang/Object;

    move-object p2, v4

    check-cast p2, Landroidx/datastore/core/Data;

    iget-object v4, v0, Landroidx/datastore/core/SingleProcessDataStore$transformAndWrite$1;->L$0:Ljava/lang/Object;

    move-object p1, v4

    check-cast p1, Landroidx/datastore/core/SingleProcessDataStore;

    invoke-static {p3}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    move-object v5, v2

    move-object v2, p1

    move-object p1, p3

    goto :goto_2

    .end local v2    # "curData":Ljava/lang/Object;
    .end local p1    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    .end local p2    # "curDataAndHash":Landroidx/datastore/core/Data;
    :pswitch_2
    invoke-static {p3}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    move-object v2, p0

    .line 398
    .local v2, "this":Landroidx/datastore/core/SingleProcessDataStore;
    .local p1, "transform":Lkotlin/jvm/functions/Function2;
    .local p2, "callerContext":Lkotlin/coroutines/CoroutineContext;
    iget-object v4, v2, Landroidx/datastore/core/SingleProcessDataStore;->downstreamFlow:Lkotlinx/coroutines/flow/MutableStateFlow;

    invoke-interface {v4}, Lkotlinx/coroutines/flow/MutableStateFlow;->getValue()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroidx/datastore/core/Data;

    .line 399
    .local v4, "curDataAndHash":Landroidx/datastore/core/Data;
    invoke-virtual {v4}, Landroidx/datastore/core/Data;->checkHashCode()V

    .line 401
    invoke-virtual {v4}, Landroidx/datastore/core/Data;->getValue()Ljava/lang/Object;

    move-result-object v5

    .line 402
    .local v5, "curData":Ljava/lang/Object;
    new-instance v6, Landroidx/datastore/core/SingleProcessDataStore$transformAndWrite$newData$1;

    invoke-direct {v6, p1, v5, v3}, Landroidx/datastore/core/SingleProcessDataStore$transformAndWrite$newData$1;-><init>(Lkotlin/jvm/functions/Function2;Ljava/lang/Object;Lkotlin/coroutines/Continuation;)V

    iput-object v2, v0, Landroidx/datastore/core/SingleProcessDataStore$transformAndWrite$1;->L$0:Ljava/lang/Object;

    iput-object v4, v0, Landroidx/datastore/core/SingleProcessDataStore$transformAndWrite$1;->L$1:Ljava/lang/Object;

    iput-object v5, v0, Landroidx/datastore/core/SingleProcessDataStore$transformAndWrite$1;->L$2:Ljava/lang/Object;

    const/4 v7, 0x1

    iput v7, v0, Landroidx/datastore/core/SingleProcessDataStore$transformAndWrite$1;->label:I

    invoke-static {p2, v6, v0}, Lkotlinx/coroutines/BuildersKt;->withContext(Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object p1

    .end local p1    # "transform":Lkotlin/jvm/functions/Function2;
    .end local p2    # "callerContext":Lkotlin/coroutines/CoroutineContext;
    if-ne p1, v1, :cond_1

    .line 392
    return-object v1

    .line 402
    :cond_1
    move-object p2, v4

    .line 392
    .end local v4    # "curDataAndHash":Landroidx/datastore/core/Data;
    .local p2, "curDataAndHash":Landroidx/datastore/core/Data;
    :goto_2
    nop

    .line 405
    .local p1, "newData":Ljava/lang/Object;
    invoke-virtual {p2}, Landroidx/datastore/core/Data;->checkHashCode()V

    .line 407
    invoke-static {v5, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2

    .line 408
    goto :goto_5

    .line 410
    :cond_2
    iput-object v2, v0, Landroidx/datastore/core/SingleProcessDataStore$transformAndWrite$1;->L$0:Ljava/lang/Object;

    iput-object p1, v0, Landroidx/datastore/core/SingleProcessDataStore$transformAndWrite$1;->L$1:Ljava/lang/Object;

    iput-object v3, v0, Landroidx/datastore/core/SingleProcessDataStore$transformAndWrite$1;->L$2:Ljava/lang/Object;

    const/4 v3, 0x2

    iput v3, v0, Landroidx/datastore/core/SingleProcessDataStore$transformAndWrite$1;->label:I

    invoke-virtual {v2, p1, v0}, Landroidx/datastore/core/SingleProcessDataStore;->writeData$datastore_core(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object p2

    .end local v2    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    .end local v5    # "curData":Ljava/lang/Object;
    .end local p1    # "newData":Ljava/lang/Object;
    .end local p2    # "curDataAndHash":Landroidx/datastore/core/Data;
    if-ne p2, v1, :cond_3

    .line 392
    return-object v1

    .line 410
    :cond_3
    move-object p2, v2

    .line 411
    :goto_3
    iget-object p2, p2, Landroidx/datastore/core/SingleProcessDataStore;->downstreamFlow:Lkotlinx/coroutines/flow/MutableStateFlow;

    new-instance v1, Landroidx/datastore/core/Data;

    if-eqz p1, :cond_4

    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    move-result v2

    goto :goto_4

    :cond_4
    const/4 v2, 0x0

    :goto_4
    invoke-direct {v1, p1, v2}, Landroidx/datastore/core/Data;-><init>(Ljava/lang/Object;I)V

    invoke-interface {p2, v1}, Lkotlinx/coroutines/flow/MutableStateFlow;->setValue(Ljava/lang/Object;)V

    .line 412
    move-object v5, p1

    .line 407
    :goto_5
    return-object v5

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public updateData(Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 4
    .param p1, "transform"    # Lkotlin/jvm/functions/Function2;
    .param p2, "$completion"    # Lkotlin/coroutines/Continuation;

    .line 150
    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-static {v0, v1, v0}, Lkotlinx/coroutines/CompletableDeferredKt;->CompletableDeferred$default(Lkotlinx/coroutines/Job;ILjava/lang/Object;)Lkotlinx/coroutines/CompletableDeferred;

    move-result-object v0

    .line 151
    .local v0, "ack":Lkotlinx/coroutines/CompletableDeferred;
    iget-object v1, p0, Landroidx/datastore/core/SingleProcessDataStore;->downstreamFlow:Lkotlinx/coroutines/flow/MutableStateFlow;

    invoke-interface {v1}, Lkotlinx/coroutines/flow/MutableStateFlow;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/datastore/core/State;

    .line 154
    .local v1, "currentDownStreamFlowState":Landroidx/datastore/core/State;
    new-instance v2, Landroidx/datastore/core/SingleProcessDataStore$Message$Update;

    invoke-interface {p2}, Lkotlin/coroutines/Continuation;->getContext()Lkotlin/coroutines/CoroutineContext;

    move-result-object v3

    invoke-direct {v2, p1, v0, v1, v3}, Landroidx/datastore/core/SingleProcessDataStore$Message$Update;-><init>(Lkotlin/jvm/functions/Function2;Lkotlinx/coroutines/CompletableDeferred;Landroidx/datastore/core/State;Lkotlin/coroutines/CoroutineContext;)V

    .line 153
    nop

    .line 156
    .local v2, "updateMsg":Landroidx/datastore/core/SingleProcessDataStore$Message$Update;
    iget-object v3, p0, Landroidx/datastore/core/SingleProcessDataStore;->actor:Landroidx/datastore/core/SimpleActor;

    invoke-virtual {v3, v2}, Landroidx/datastore/core/SimpleActor;->offer(Ljava/lang/Object;)V

    .line 158
    invoke-interface {v0, p2}, Lkotlinx/coroutines/Deferred;->await(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v3

    return-object v3
.end method

.method public final writeData$datastore_core(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 11

    instance-of v0, p2, Landroidx/datastore/core/SingleProcessDataStore$writeData$1;

    if-eqz v0, :cond_0

    move-object v0, p2

    check-cast v0, Landroidx/datastore/core/SingleProcessDataStore$writeData$1;

    iget v1, v0, Landroidx/datastore/core/SingleProcessDataStore$writeData$1;->label:I

    const/high16 v2, -0x80000000

    and-int/2addr v1, v2

    if-eqz v1, :cond_0

    iget p2, v0, Landroidx/datastore/core/SingleProcessDataStore$writeData$1;->label:I

    sub-int/2addr p2, v2

    iput p2, v0, Landroidx/datastore/core/SingleProcessDataStore$writeData$1;->label:I

    .local v0, "$continuation":Lkotlin/coroutines/Continuation;
    :goto_0
    goto :goto_1

    .end local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    :cond_0
    new-instance v0, Landroidx/datastore/core/SingleProcessDataStore$writeData$1;

    invoke-direct {v0, p0, p2}, Landroidx/datastore/core/SingleProcessDataStore$writeData$1;-><init>(Landroidx/datastore/core/SingleProcessDataStore;Lkotlin/coroutines/Continuation;)V

    goto :goto_0

    .restart local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    :goto_1
    iget-object p2, v0, Landroidx/datastore/core/SingleProcessDataStore$writeData$1;->result:Ljava/lang/Object;

    .local p2, "$result":Ljava/lang/Object;
    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt__IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v1

    .line 420
    iget v2, v0, Landroidx/datastore/core/SingleProcessDataStore$writeData$1;->label:I

    const/4 v3, 0x0

    nop

    packed-switch v2, :pswitch_data_0

    .line 446
    .end local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    .end local p2    # "$result":Ljava/lang/Object;
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 420
    .restart local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    .restart local p2    # "$result":Ljava/lang/Object;
    :pswitch_0
    move-object p1, p0

    .local p1, "this":Landroidx/datastore/core/SingleProcessDataStore;
    const/4 v1, 0x0

    .local v1, "$i$a$-use-SingleProcessDataStore$writeData$2":I
    move-object v2, v3

    .local v2, "scratchFile":Ljava/io/File;
    .local v3, "stream":Ljava/io/FileOutputStream;
    const/4 v1, 0x0

    iget-object v4, v0, Landroidx/datastore/core/SingleProcessDataStore$writeData$1;->L$4:Ljava/lang/Object;

    move-object v3, v4

    check-cast v3, Ljava/io/FileOutputStream;

    iget-object v4, v0, Landroidx/datastore/core/SingleProcessDataStore$writeData$1;->L$3:Ljava/lang/Object;

    check-cast v4, Ljava/lang/Throwable;

    iget-object v5, v0, Landroidx/datastore/core/SingleProcessDataStore$writeData$1;->L$2:Ljava/lang/Object;

    check-cast v5, Ljava/io/Closeable;

    iget-object v6, v0, Landroidx/datastore/core/SingleProcessDataStore$writeData$1;->L$1:Ljava/lang/Object;

    move-object v2, v6

    check-cast v2, Ljava/io/File;

    iget-object v6, v0, Landroidx/datastore/core/SingleProcessDataStore$writeData$1;->L$0:Ljava/lang/Object;

    move-object p1, v6

    check-cast p1, Landroidx/datastore/core/SingleProcessDataStore;

    :try_start_0
    invoke-static {p2}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_2

    .line 425
    .end local v1    # "$i$a$-use-SingleProcessDataStore$writeData$2":I
    .end local v3    # "stream":Ljava/io/FileOutputStream;
    :catchall_0
    move-exception v1

    goto/16 :goto_3

    .line 420
    .end local v2    # "scratchFile":Ljava/io/File;
    .end local p1    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    :pswitch_1
    invoke-static {p2}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    move-object v2, p0

    .line 421
    .local v2, "this":Landroidx/datastore/core/SingleProcessDataStore;
    .local p1, "newData":Ljava/lang/Object;
    invoke-virtual {v2}, Landroidx/datastore/core/SingleProcessDataStore;->getFile()Ljava/io/File;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroidx/datastore/core/SingleProcessDataStore;->createParentDirectories(Ljava/io/File;)V

    .line 423
    new-instance v4, Ljava/io/File;

    invoke-virtual {v2}, Landroidx/datastore/core/SingleProcessDataStore;->getFile()Ljava/io/File;

    move-result-object v5

    invoke-virtual {v5}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v5

    iget-object v6, v2, Landroidx/datastore/core/SingleProcessDataStore;->SCRATCH_SUFFIX:Ljava/lang/String;

    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->stringPlus(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v5}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 424
    .local v4, "scratchFile":Ljava/io/File;
    nop

    .line 425
    :try_start_1
    new-instance v5, Ljava/io/FileOutputStream;

    invoke-direct {v5, v4}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1

    move-object v6, v5

    .local v6, "stream":Ljava/io/FileOutputStream;
    const/4 v7, 0x0

    .line 426
    .local v7, "$i$a$-use-SingleProcessDataStore$writeData$2":I
    :try_start_2
    iget-object v8, v2, Landroidx/datastore/core/SingleProcessDataStore;->serializer:Landroidx/datastore/core/Serializer;

    new-instance v9, Landroidx/datastore/core/SingleProcessDataStore$UncloseableOutputStream;

    invoke-direct {v9, v6}, Landroidx/datastore/core/SingleProcessDataStore$UncloseableOutputStream;-><init>(Ljava/io/FileOutputStream;)V

    iput-object v2, v0, Landroidx/datastore/core/SingleProcessDataStore$writeData$1;->L$0:Ljava/lang/Object;

    iput-object v4, v0, Landroidx/datastore/core/SingleProcessDataStore$writeData$1;->L$1:Ljava/lang/Object;

    iput-object v5, v0, Landroidx/datastore/core/SingleProcessDataStore$writeData$1;->L$2:Ljava/lang/Object;

    iput-object v3, v0, Landroidx/datastore/core/SingleProcessDataStore$writeData$1;->L$3:Ljava/lang/Object;

    iput-object v6, v0, Landroidx/datastore/core/SingleProcessDataStore$writeData$1;->L$4:Ljava/lang/Object;

    const/4 v10, 0x1

    iput v10, v0, Landroidx/datastore/core/SingleProcessDataStore$writeData$1;->label:I

    invoke-interface {v8, p1, v9, v0}, Landroidx/datastore/core/Serializer;->writeTo(Ljava/lang/Object;Ljava/io/OutputStream;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v8
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .end local p1    # "newData":Ljava/lang/Object;
    if-ne v8, v1, :cond_1

    .line 420
    return-object v1

    .line 426
    :cond_1
    move-object p1, v2

    move-object v2, v4

    move v1, v7

    move-object v4, v3

    move-object v3, v6

    .line 427
    .end local v4    # "scratchFile":Ljava/io/File;
    .end local v6    # "stream":Ljava/io/FileOutputStream;
    .end local v7    # "$i$a$-use-SingleProcessDataStore$writeData$2":I
    .restart local v1    # "$i$a$-use-SingleProcessDataStore$writeData$2":I
    .local v2, "scratchFile":Ljava/io/File;
    .restart local v3    # "stream":Ljava/io/FileOutputStream;
    .local p1, "this":Landroidx/datastore/core/SingleProcessDataStore;
    :goto_2
    :try_start_3
    invoke-virtual {v3}, Ljava/io/FileOutputStream;->getFD()Ljava/io/FileDescriptor;

    move-result-object v6

    invoke-virtual {v6}, Ljava/io/FileDescriptor;->sync()V

    .line 430
    nop

    .end local v1    # "$i$a$-use-SingleProcessDataStore$writeData$2":I
    .end local v3    # "stream":Ljava/io/FileOutputStream;
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 425
    :try_start_4
    invoke-static {v5, v4}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 432
    invoke-virtual {p1}, Landroidx/datastore/core/SingleProcessDataStore;->getFile()Ljava/io/File;

    move-result-object v1

    invoke-virtual {v2, v1}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    move-result v1
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_0

    if-eqz v1, :cond_2

    .line 446
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1

    .line 433
    :cond_2
    :try_start_5
    new-instance v1, Ljava/io/IOException;

    .line 434
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Unable to rename "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v4, ".This likely means that there are multiple instances of DataStore for this file. Ensure that you are only creating a single instance of datastore for this file."

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .line 433
    invoke-direct {v1, v3}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .end local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    .end local v2    # "scratchFile":Ljava/io/File;
    .end local p1    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    .end local p2    # "$result":Ljava/lang/Object;
    throw v1
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_0

    .line 440
    .restart local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    .restart local v2    # "scratchFile":Ljava/io/File;
    .restart local p1    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    .restart local p2    # "$result":Ljava/lang/Object;
    :catch_0
    move-exception v1

    move-object v4, v2

    move-object v2, p1

    goto :goto_4

    .line 425
    .end local p1    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    .local v2, "this":Landroidx/datastore/core/SingleProcessDataStore;
    .restart local v4    # "scratchFile":Ljava/io/File;
    :catchall_1
    move-exception v1

    move-object p1, v2

    move-object v2, v4

    .end local v4    # "scratchFile":Ljava/io/File;
    .local v2, "scratchFile":Ljava/io/File;
    .restart local p1    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    :goto_3
    nop

    .end local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    .end local v2    # "scratchFile":Ljava/io/File;
    .end local p1    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    .end local p2    # "$result":Ljava/lang/Object;
    :try_start_6
    throw v1
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    .restart local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    .restart local v2    # "scratchFile":Ljava/io/File;
    .restart local p1    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    .restart local p2    # "$result":Ljava/lang/Object;
    :catchall_2
    move-exception v3

    :try_start_7
    invoke-static {v5, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    .end local v2    # "scratchFile":Ljava/io/File;
    .end local p1    # "this":Landroidx/datastore/core/SingleProcessDataStore;
    .end local p2    # "$result":Ljava/lang/Object;
    throw v3
    :try_end_7
    .catch Ljava/io/IOException; {:try_start_7 .. :try_end_7} :catch_0

    .line 440
    .restart local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    .local v2, "this":Landroidx/datastore/core/SingleProcessDataStore;
    .restart local v4    # "scratchFile":Ljava/io/File;
    .restart local p2    # "$result":Ljava/lang/Object;
    :catch_1
    move-exception v1

    :goto_4
    nop

    .line 441
    .local v1, "ex":Ljava/io/IOException;
    invoke-virtual {v4}, Ljava/io/File;->exists()Z

    move-result p1

    if-eqz p1, :cond_3

    .line 442
    invoke-virtual {v4}, Ljava/io/File;->delete()Z

    .line 444
    :cond_3
    throw v1

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
