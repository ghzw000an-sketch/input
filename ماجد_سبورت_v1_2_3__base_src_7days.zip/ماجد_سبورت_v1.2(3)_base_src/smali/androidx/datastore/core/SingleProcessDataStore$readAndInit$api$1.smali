.class public final Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroidx/datastore/core/InitializerApi;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/datastore/core/SingleProcessDataStore;->readAndInit(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSingleProcessDataStore.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SingleProcessDataStore.kt\nandroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1\n+ 2 Mutex.kt\nkotlinx/coroutines/sync/MutexKt\n*L\n1#1,497:1\n109#2,11:498\n*S KotlinDebug\n*F\n+ 1 SingleProcessDataStore.kt\nandroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1\n*L\n329#1:498,11\n*E\n"
.end annotation


# instance fields
.field public final synthetic $initData:Lkotlin/jvm/internal/Ref$ObjectRef;

.field public final synthetic $initializationComplete:Lkotlin/jvm/internal/Ref$BooleanRef;

.field public final synthetic $updateLock:Lkotlinx/coroutines/sync/Mutex;

.field public final synthetic this$0:Landroidx/datastore/core/SingleProcessDataStore;


# direct methods
.method public constructor <init>(Lkotlinx/coroutines/sync/Mutex;Lkotlin/jvm/internal/Ref$BooleanRef;Lkotlin/jvm/internal/Ref$ObjectRef;Landroidx/datastore/core/SingleProcessDataStore;)V
    .locals 0
    .param p1, "$updateLock"    # Lkotlinx/coroutines/sync/Mutex;
    .param p2, "$initializationComplete"    # Lkotlin/jvm/internal/Ref$BooleanRef;
    .param p3, "$initData"    # Lkotlin/jvm/internal/Ref$ObjectRef;
    .param p4, "$receiver"    # Landroidx/datastore/core/SingleProcessDataStore;

    iput-object p1, p0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1;->$updateLock:Lkotlinx/coroutines/sync/Mutex;

    iput-object p2, p0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1;->$initializationComplete:Lkotlin/jvm/internal/Ref$BooleanRef;

    iput-object p3, p0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1;->$initData:Lkotlin/jvm/internal/Ref$ObjectRef;

    iput-object p4, p0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1;->this$0:Landroidx/datastore/core/SingleProcessDataStore;

    .line 327
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public updateData(Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 12

    instance-of v0, p2, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1;

    if-eqz v0, :cond_0

    move-object v0, p2

    check-cast v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1;

    iget v1, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1;->label:I

    const/high16 v2, -0x80000000

    and-int/2addr v1, v2

    if-eqz v1, :cond_0

    iget p2, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1;->label:I

    sub-int/2addr p2, v2

    iput p2, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1;->label:I

    .local v0, "$continuation":Lkotlin/coroutines/Continuation;
    :goto_0
    goto :goto_1

    .end local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    :cond_0
    new-instance v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1;

    invoke-direct {v0, p0, p2}, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1;-><init>(Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1;Lkotlin/coroutines/Continuation;)V

    goto :goto_0

    .restart local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    :goto_1
    iget-object p2, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1;->result:Ljava/lang/Object;

    .local p2, "$result":Ljava/lang/Object;
    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt__IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v1

    .line 328
    iget v2, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1;->label:I

    const/4 v3, 0x0

    const/4 v4, 0x0

    nop

    packed-switch v2, :pswitch_data_0

    .line 329
    .end local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    .end local p2    # "$result":Ljava/lang/Object;
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 328
    .restart local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    .restart local p2    # "$result":Ljava/lang/Object;
    :pswitch_0
    move-object p1, v3

    .local p1, "owner$iv":Ljava/lang/Object;
    move v1, v4

    .local v1, "$i$f$withLock":I
    move-object v2, v3

    .local v2, "newData":Ljava/lang/Object;
    .local v3, "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    .local v4, "$i$a$-withLock$default-SingleProcessDataStore$readAndInit$api$1$updateData$2":I
    const/4 v1, 0x0

    const/4 v4, 0x0

    iget-object v2, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1;->L$2:Ljava/lang/Object;

    iget-object v5, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1;->L$1:Ljava/lang/Object;

    check-cast v5, Lkotlin/jvm/internal/Ref$ObjectRef;

    const/4 p1, 0x0

    iget-object v6, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1;->L$0:Ljava/lang/Object;

    move-object v3, v6

    check-cast v3, Lkotlinx/coroutines/sync/Mutex;

    :try_start_0
    invoke-static {p2}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto/16 :goto_4

    .line 508
    .end local v2    # "newData":Ljava/lang/Object;
    .end local v4    # "$i$a$-withLock$default-SingleProcessDataStore$readAndInit$api$1$updateData$2":I
    :catchall_0
    move-exception v2

    goto/16 :goto_6

    .line 328
    .end local v1    # "$i$f$withLock":I
    .end local v3    # "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    .end local p1    # "owner$iv":Ljava/lang/Object;
    :pswitch_1
    move-object p1, v3

    .restart local p1    # "owner$iv":Ljava/lang/Object;
    move v2, v4

    .local v2, "$i$f$withLock":I
    .restart local v3    # "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    .restart local v4    # "$i$a$-withLock$default-SingleProcessDataStore$readAndInit$api$1$updateData$2":I
    const/4 v2, 0x0

    const/4 v4, 0x0

    iget-object v5, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1;->L$2:Ljava/lang/Object;

    check-cast v5, Landroidx/datastore/core/SingleProcessDataStore;

    iget-object v6, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1;->L$1:Ljava/lang/Object;

    check-cast v6, Lkotlin/jvm/internal/Ref$ObjectRef;

    const/4 p1, 0x0

    iget-object v7, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1;->L$0:Ljava/lang/Object;

    move-object v3, v7

    check-cast v3, Lkotlinx/coroutines/sync/Mutex;

    :try_start_1
    invoke-static {p2}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    move-object v7, v5

    move-object v5, v3

    move-object v3, p2

    goto/16 :goto_3

    .line 508
    .end local v4    # "$i$a$-withLock$default-SingleProcessDataStore$readAndInit$api$1$updateData$2":I
    :catchall_1
    move-exception v1

    move v11, v2

    move-object v2, v1

    move v1, v11

    goto/16 :goto_6

    .line 328
    .end local v2    # "$i$f$withLock":I
    .end local v3    # "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    .end local p1    # "owner$iv":Ljava/lang/Object;
    :pswitch_2
    move-object v2, v3

    .local v2, "owner$iv":Ljava/lang/Object;
    .local v4, "$i$f$withLock":I
    .local p1, "transform":Lkotlin/jvm/functions/Function2;
    move-object v5, v3

    .local v5, "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    const/4 v4, 0x0

    iget-object v6, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1;->L$4:Ljava/lang/Object;

    check-cast v6, Landroidx/datastore/core/SingleProcessDataStore;

    iget-object v7, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1;->L$3:Ljava/lang/Object;

    check-cast v7, Lkotlin/jvm/internal/Ref$ObjectRef;

    iget-object v8, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1;->L$2:Ljava/lang/Object;

    check-cast v8, Lkotlin/jvm/internal/Ref$BooleanRef;

    const/4 v2, 0x0

    iget-object v9, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1;->L$1:Ljava/lang/Object;

    move-object v5, v9

    check-cast v5, Lkotlinx/coroutines/sync/Mutex;

    iget-object v9, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1;->L$0:Ljava/lang/Object;

    move-object p1, v9

    check-cast p1, Lkotlin/jvm/functions/Function2;

    invoke-static {p2}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    goto :goto_2

    .end local v2    # "owner$iv":Ljava/lang/Object;
    .end local v4    # "$i$f$withLock":I
    .end local v5    # "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    .end local p1    # "transform":Lkotlin/jvm/functions/Function2;
    :pswitch_3
    invoke-static {p2}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    move-object v2, p0

    .line 329
    .local v2, "this":Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1;
    .restart local p1    # "transform":Lkotlin/jvm/functions/Function2;
    iget-object v4, v2, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1;->$updateLock:Lkotlinx/coroutines/sync/Mutex;

    .local v4, "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    iget-object v8, v2, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1;->$initializationComplete:Lkotlin/jvm/internal/Ref$BooleanRef;

    iget-object v7, v2, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1;->$initData:Lkotlin/jvm/internal/Ref$ObjectRef;

    iget-object v5, v2, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1;->this$0:Landroidx/datastore/core/SingleProcessDataStore;

    .line 498
    const/4 v6, 0x0

    .local v6, "owner$iv":Ljava/lang/Object;
    const/4 v9, 0x0

    .line 499
    .local v9, "$i$f$withLock":I
    nop

    .line 503
    iput-object p1, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1;->L$0:Ljava/lang/Object;

    iput-object v4, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1;->L$1:Ljava/lang/Object;

    iput-object v8, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1;->L$2:Ljava/lang/Object;

    iput-object v7, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1;->L$3:Ljava/lang/Object;

    iput-object v5, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1;->L$4:Ljava/lang/Object;

    const/4 v10, 0x1

    iput v10, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1;->label:I

    invoke-interface {v4, v6, v0}, Lkotlinx/coroutines/sync/Mutex;->lock(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v2

    .end local v2    # "this":Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1;
    if-ne v2, v1, :cond_1

    .line 328
    return-object v1

    .line 503
    :cond_1
    move-object v2, v6

    move-object v6, v5

    move-object v5, v4

    move v4, v9

    .line 504
    .end local v6    # "owner$iv":Ljava/lang/Object;
    .end local v9    # "$i$f$withLock":I
    .local v2, "owner$iv":Ljava/lang/Object;
    .local v4, "$i$f$withLock":I
    .restart local v5    # "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    :goto_2
    nop

    .line 116
    const/4 v9, 0x0

    .line 330
    .local v9, "$i$a$-withLock$default-SingleProcessDataStore$readAndInit$api$1$updateData$2":I
    :try_start_2
    iget-boolean v8, v8, Lkotlin/jvm/internal/Ref$BooleanRef;->element:Z

    if-nez v8, :cond_5

    .line 337
    iget-object v8, v7, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    iput-object v5, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1;->L$0:Ljava/lang/Object;

    iput-object v7, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1;->L$1:Ljava/lang/Object;

    iput-object v6, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1;->L$2:Ljava/lang/Object;

    iput-object v3, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1;->L$3:Ljava/lang/Object;

    iput-object v3, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1;->L$4:Ljava/lang/Object;

    const/4 v3, 0x2

    iput v3, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1;->label:I

    invoke-interface {p1, v8, v0}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_4

    .end local p1    # "transform":Lkotlin/jvm/functions/Function2;
    if-ne v3, v1, :cond_2

    .line 328
    return-object v1

    .line 337
    :cond_2
    move-object p1, v7

    move-object v7, v6

    move-object v6, p1

    move-object p1, v2

    move v2, v4

    move v4, v9

    .end local v9    # "$i$a$-withLock$default-SingleProcessDataStore$readAndInit$api$1$updateData$2":I
    .local v2, "$i$f$withLock":I
    .local v4, "$i$a$-withLock$default-SingleProcessDataStore$readAndInit$api$1$updateData$2":I
    .local p1, "owner$iv":Ljava/lang/Object;
    :goto_3
    nop

    .line 338
    .local v3, "newData":Ljava/lang/Object;
    :try_start_3
    iget-object v8, v6, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    invoke-static {v3, v8}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_4

    .line 339
    iput-object v5, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1;->L$0:Ljava/lang/Object;

    iput-object v6, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1;->L$1:Ljava/lang/Object;

    iput-object v3, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1;->L$2:Ljava/lang/Object;

    const/4 v8, 0x3

    iput v8, v0, Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1;->label:I

    invoke-virtual {v7, v3, v0}, Landroidx/datastore/core/SingleProcessDataStore;->writeData$datastore_core(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v7
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    if-ne v7, v1, :cond_3

    .line 328
    return-object v1

    .line 339
    :cond_3
    move v1, v2

    move-object v2, v3

    move-object v3, v5

    move-object v5, v6

    .line 340
    .end local v5    # "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    .restart local v1    # "$i$f$withLock":I
    .local v2, "newData":Ljava/lang/Object;
    .local v3, "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    :goto_4
    :try_start_4
    iput-object v2, v5, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    move-object v6, v5

    move-object v5, v3

    move-object v3, v2

    goto :goto_5

    .line 508
    .end local v1    # "$i$f$withLock":I
    .end local v3    # "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    .end local v4    # "$i$a$-withLock$default-SingleProcessDataStore$readAndInit$api$1$updateData$2":I
    .local v2, "$i$f$withLock":I
    .restart local v5    # "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    :catchall_2
    move-exception v1

    move v3, v2

    move-object v2, v1

    move v1, v3

    move-object v3, v5

    goto :goto_6

    .line 338
    .local v3, "newData":Ljava/lang/Object;
    .restart local v4    # "$i$a$-withLock$default-SingleProcessDataStore$readAndInit$api$1$updateData$2":I
    :cond_4
    move v1, v2

    .line 343
    .end local v2    # "$i$f$withLock":I
    .restart local v1    # "$i$f$withLock":I
    :goto_5
    :try_start_5
    iget-object v2, v6, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_3

    .line 507
    .end local v3    # "newData":Ljava/lang/Object;
    .end local v4    # "$i$a$-withLock$default-SingleProcessDataStore$readAndInit$api$1$updateData$2":I
    invoke-interface {v5, p1}, Lkotlinx/coroutines/sync/Mutex;->unlock(Ljava/lang/Object;)V

    .line 116
    nop

    .line 329
    .end local v1    # "$i$f$withLock":I
    .end local v5    # "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    .end local p1    # "owner$iv":Ljava/lang/Object;
    return-object v2

    .line 508
    .restart local v1    # "$i$f$withLock":I
    .restart local v5    # "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    .restart local p1    # "owner$iv":Ljava/lang/Object;
    :catchall_3
    move-exception v2

    move-object v3, v5

    goto :goto_6

    .end local v1    # "$i$f$withLock":I
    .end local p1    # "owner$iv":Ljava/lang/Object;
    .local v2, "owner$iv":Ljava/lang/Object;
    .local v4, "$i$f$withLock":I
    :catchall_4
    move-exception p1

    move-object v1, v2

    move-object v2, p1

    move-object p1, v1

    move v1, v4

    move-object v3, v5

    goto :goto_6

    .line 331
    .restart local v9    # "$i$a$-withLock$default-SingleProcessDataStore$readAndInit$api$1$updateData$2":I
    .local p1, "transform":Lkotlin/jvm/functions/Function2;
    :cond_5
    :try_start_6
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 332
    const-string v3, "InitializerApi.updateData should not be called after initialization is complete."

    .line 331
    invoke-direct {v1, v3}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .end local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    .end local v2    # "owner$iv":Ljava/lang/Object;
    .end local v4    # "$i$f$withLock":I
    .end local v5    # "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    .end local p2    # "$result":Ljava/lang/Object;
    throw v1
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_4

    .line 508
    .end local v9    # "$i$a$-withLock$default-SingleProcessDataStore$readAndInit$api$1$updateData$2":I
    .restart local v0    # "$continuation":Lkotlin/coroutines/Continuation;
    .restart local v1    # "$i$f$withLock":I
    .local v3, "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    .local p1, "owner$iv":Ljava/lang/Object;
    .restart local p2    # "$result":Ljava/lang/Object;
    :goto_6
    nop

    .line 507
    invoke-interface {v3, p1}, Lkotlinx/coroutines/sync/Mutex;->unlock(Ljava/lang/Object;)V

    throw v2

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
