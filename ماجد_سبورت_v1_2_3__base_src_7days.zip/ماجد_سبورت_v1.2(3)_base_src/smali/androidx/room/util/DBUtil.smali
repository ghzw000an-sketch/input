.class public abstract Landroidx/room/util/DBUtil;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDBUtil.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DBUtil.kt\nandroidx/room/util/DBUtil\n+ 2 CursorUtil.kt\nandroidx/room/util/CursorUtil\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,214:1\n145#2,7:215\n145#2,7:224\n1855#3,2:222\n*S KotlinDebug\n*F\n+ 1 DBUtil.kt\nandroidx/room/util/DBUtil\n*L\n100#1:215,7\n121#1:224,7\n107#1:222,2\n*E\n"
.end annotation


# direct methods
.method public static final dropFtsSyncTriggers(Landroidx/sqlite/db/SupportSQLiteDatabase;)V
    .locals 11
    .param p0, "db"    # Landroidx/sqlite/db/SupportSQLiteDatabase;

    const-string v0, "db"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 99
    invoke-static {}, Lkotlin/collections/CollectionsKt__CollectionsJVMKt;->createListBuilder()Ljava/util/List;

    move-result-object v0

    move-object v1, v0

    .local v1, "$this$dropFtsSyncTriggers_u24lambda_u241":Ljava/util/List;
    const/4 v2, 0x0

    .line 100
    .local v2, "$i$a$-buildList-DBUtil$dropFtsSyncTriggers$existingTriggers$1":I
    const-string v3, "SELECT name FROM sqlite_master WHERE type = \'trigger\'"

    invoke-interface {p0, v3}, Landroidx/sqlite/db/SupportSQLiteDatabase;->query(Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v3

    .local v3, "$this$useCursor$iv":Landroid/database/Cursor;
    const/4 v4, 0x0

    .line 145
    .local v4, "$i$f$useCursor":I
    nop

    .line 146
    move-object v5, v3

    .local v5, "cursor":Landroid/database/Cursor;
    const/4 v6, 0x0

    .line 101
    .local v6, "$i$a$-useCursor-DBUtil$dropFtsSyncTriggers$existingTriggers$1$1":I
    :goto_0
    :try_start_0
    invoke-interface {v5}, Landroid/database/Cursor;->moveToNext()Z

    move-result v7

    const/4 v8, 0x0

    if-eqz v7, :cond_0

    .line 102
    invoke-interface {v5, v8}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v7

    invoke-interface {v1, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 146
    .end local v5    # "cursor":Landroid/database/Cursor;
    .end local v6    # "$i$a$-useCursor-DBUtil$dropFtsSyncTriggers$existingTriggers$1$1":I
    :catchall_0
    move-exception v0

    goto :goto_2

    .line 104
    .restart local v5    # "cursor":Landroid/database/Cursor;
    .restart local v6    # "$i$a$-useCursor-DBUtil$dropFtsSyncTriggers$existingTriggers$1$1":I
    :cond_0
    nop

    .end local v5    # "cursor":Landroid/database/Cursor;
    .end local v6    # "$i$a$-useCursor-DBUtil$dropFtsSyncTriggers$existingTriggers$1$1":I
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 146
    const/4 v5, 0x0

    invoke-static {v3, v5}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 105
    .end local v3    # "$this$useCursor$iv":Landroid/database/Cursor;
    .end local v4    # "$i$f$useCursor":I
    nop

    .line 99
    .end local v1    # "$this$dropFtsSyncTriggers_u24lambda_u241":Ljava/util/List;
    .end local v2    # "$i$a$-buildList-DBUtil$dropFtsSyncTriggers$existingTriggers$1":I
    invoke-static {v0}, Lkotlin/collections/CollectionsKt__CollectionsJVMKt;->build(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    .line 107
    .local v0, "existingTriggers":Ljava/util/List;
    move-object v1, v0

    .local v1, "$this$forEach$iv":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 1855
    .local v2, "$i$f$forEach":I
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_1
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_2

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    .local v4, "element$iv":Ljava/lang/Object;
    move-object v6, v4

    check-cast v6, Ljava/lang/String;

    .local v6, "triggerName":Ljava/lang/String;
    const/4 v7, 0x0

    .line 108
    .local v7, "$i$a$-forEach-DBUtil$dropFtsSyncTriggers$1":I
    const-string v9, "triggerName"

    invoke-static {v6, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v9, "room_fts_content_sync_"

    const/4 v10, 0x2

    invoke-static {v6, v9, v8, v10, v5}, Lkotlin/text/StringsKt__StringsJVMKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_1

    .line 109
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "DROP TRIGGER IF EXISTS "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-interface {p0, v9}, Landroidx/sqlite/db/SupportSQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 111
    :cond_1
    nop

    .line 1855
    .end local v6    # "triggerName":Ljava/lang/String;
    .end local v7    # "$i$a$-forEach-DBUtil$dropFtsSyncTriggers$1":I
    nop

    .end local v4    # "element$iv":Ljava/lang/Object;
    goto :goto_1

    .line 1856
    :cond_2
    nop

    .line 112
    .end local v1    # "$this$forEach$iv":Ljava/lang/Iterable;
    .end local v2    # "$i$f$forEach":I
    return-void

    .line 146
    .end local v0    # "existingTriggers":Ljava/util/List;
    .local v1, "$this$dropFtsSyncTriggers_u24lambda_u241":Ljava/util/List;
    .local v2, "$i$a$-buildList-DBUtil$dropFtsSyncTriggers$existingTriggers$1":I
    .restart local v3    # "$this$useCursor$iv":Landroid/database/Cursor;
    .local v4, "$i$f$useCursor":I
    :goto_2
    nop

    .end local v1    # "$this$dropFtsSyncTriggers_u24lambda_u241":Ljava/util/List;
    .end local v2    # "$i$a$-buildList-DBUtil$dropFtsSyncTriggers$existingTriggers$1":I
    .end local v3    # "$this$useCursor$iv":Landroid/database/Cursor;
    .end local v4    # "$i$f$useCursor":I
    .end local p0    # "db":Landroidx/sqlite/db/SupportSQLiteDatabase;
    :try_start_1
    throw v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .restart local v1    # "$this$dropFtsSyncTriggers_u24lambda_u241":Ljava/util/List;
    .restart local v2    # "$i$a$-buildList-DBUtil$dropFtsSyncTriggers$existingTriggers$1":I
    .restart local v3    # "$this$useCursor$iv":Landroid/database/Cursor;
    .restart local v4    # "$i$f$useCursor":I
    .restart local p0    # "db":Landroidx/sqlite/db/SupportSQLiteDatabase;
    :catchall_1
    move-exception v5

    invoke-static {v3, v0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v5
.end method

.method public static final query(Landroidx/room/RoomDatabase;Landroidx/sqlite/db/SupportSQLiteQuery;ZLandroid/os/CancellationSignal;)Landroid/database/Cursor;
    .locals 4
    .param p0, "db"    # Landroidx/room/RoomDatabase;
    .param p1, "sqLiteQuery"    # Landroidx/sqlite/db/SupportSQLiteQuery;
    .param p2, "maybeCopy"    # Z
    .param p3, "signal"    # Landroid/os/CancellationSignal;

    const-string v0, "db"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "sqLiteQuery"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 75
    invoke-virtual {p0, p1, p3}, Landroidx/room/RoomDatabase;->query(Landroidx/sqlite/db/SupportSQLiteQuery;Landroid/os/CancellationSignal;)Landroid/database/Cursor;

    move-result-object v0

    .line 76
    .local v0, "cursor":Landroid/database/Cursor;
    if-eqz p2, :cond_1

    instance-of v1, v0, Landroid/database/AbstractWindowedCursor;

    if-eqz v1, :cond_1

    .line 77
    move-object v1, v0

    check-cast v1, Landroid/database/AbstractWindowedCursor;

    invoke-virtual {v1}, Landroid/database/AbstractCursor;->getCount()I

    move-result v1

    .line 78
    .local v1, "rowsInCursor":I
    move-object v2, v0

    check-cast v2, Landroid/database/AbstractWindowedCursor;

    invoke-virtual {v2}, Landroid/database/AbstractWindowedCursor;->hasWindow()Z

    move-result v2

    if-eqz v2, :cond_0

    .line 79
    move-object v2, v0

    check-cast v2, Landroid/database/AbstractWindowedCursor;

    invoke-virtual {v2}, Landroid/database/AbstractWindowedCursor;->getWindow()Landroid/database/CursorWindow;

    move-result-object v2

    invoke-virtual {v2}, Landroid/database/CursorWindow;->getNumRows()I

    move-result v2

    goto :goto_0

    .line 81
    :cond_0
    move v2, v1

    .line 78
    :goto_0
    nop

    .line 83
    .local v2, "rowsInWindow":I
    nop

    nop

    if-ge v2, v1, :cond_1

    .line 84
    invoke-static {v0}, Landroidx/room/util/CursorUtil;->copyAndClose(Landroid/database/Cursor;)Landroid/database/Cursor;

    move-result-object v3

    return-object v3

    .line 87
    .end local v1    # "rowsInCursor":I
    .end local v2    # "rowsInWindow":I
    :cond_1
    return-object v0
.end method

.method public static final readVersion(Ljava/io/File;)I
    .locals 10
    .param p0, "databaseFile"    # Ljava/io/File;

    const-string v0, "databaseFile"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 142
    new-instance v0, Ljava/io/FileInputStream;

    invoke-direct {v0, p0}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    invoke-virtual {v0}, Ljava/io/FileInputStream;->getChannel()Ljava/nio/channels/FileChannel;

    move-result-object v1

    move-object v2, v1

    .local v2, "input":Ljava/nio/channels/FileChannel;
    const/4 v0, 0x0

    .line 143
    .local v0, "$i$a$-use-DBUtil$readVersion$1":I
    const/4 v8, 0x4

    :try_start_0
    invoke-static {v8}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object v3

    move-object v9, v3

    .line 144
    .local v9, "buffer":Ljava/nio/ByteBuffer;
    const-wide/16 v5, 0x4

    const/4 v7, 0x1

    const-wide/16 v3, 0x3c

    invoke-virtual/range {v2 .. v7}, Ljava/nio/channels/FileChannel;->tryLock(JJZ)Ljava/nio/channels/FileLock;

    .line 145
    const-wide/16 v3, 0x3c

    invoke-virtual {v2, v3, v4}, Ljava/nio/channels/FileChannel;->position(J)Ljava/nio/channels/FileChannel;

    .line 146
    invoke-virtual {v2, v9}, Ljava/nio/channels/FileChannel;->read(Ljava/nio/ByteBuffer;)I

    move-result v3

    .line 147
    .local v3, "read":I
    if-ne v3, v8, :cond_0

    .line 150
    invoke-virtual {v9}, Ljava/nio/ByteBuffer;->rewind()Ljava/nio/Buffer;

    .line 151
    invoke-virtual {v9}, Ljava/nio/ByteBuffer;->getInt()I

    move-result v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .end local v0    # "$i$a$-use-DBUtil$readVersion$1":I
    .end local v2    # "input":Ljava/nio/channels/FileChannel;
    .end local v3    # "read":I
    .end local v9    # "buffer":Ljava/nio/ByteBuffer;
    const/4 v0, 0x0

    invoke-static {v1, v0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return v4

    :catchall_0
    move-exception v0

    move-object v2, v0

    goto :goto_0

    .line 148
    .restart local v0    # "$i$a$-use-DBUtil$readVersion$1":I
    .restart local v2    # "input":Ljava/nio/channels/FileChannel;
    .restart local v3    # "read":I
    .restart local v9    # "buffer":Ljava/nio/ByteBuffer;
    :cond_0
    :try_start_1
    new-instance v4, Ljava/io/IOException;

    const-string v5, "Bad database header, unable to read 4 bytes at offset 60"

    invoke-direct {v4, v5}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .end local p0    # "databaseFile":Ljava/io/File;
    throw v4
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 151
    .end local v0    # "$i$a$-use-DBUtil$readVersion$1":I
    .end local v2    # "input":Ljava/nio/channels/FileChannel;
    .end local v3    # "read":I
    .end local v9    # "buffer":Ljava/nio/ByteBuffer;
    .restart local p0    # "databaseFile":Ljava/io/File;
    :goto_0
    nop

    .end local p0    # "databaseFile":Ljava/io/File;
    :try_start_2
    throw v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .restart local p0    # "databaseFile":Ljava/io/File;
    :catchall_1
    move-exception v0

    invoke-static {v1, v2}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0
.end method
