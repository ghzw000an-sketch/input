.class public abstract Landroidx/room/util/TableInfoKt;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nTableInfo.kt\nKotlin\n*S Kotlin\n*F\n+ 1 TableInfo.kt\nandroidx/room/util/TableInfoKt\n+ 2 CursorUtil.kt\nandroidx/room/util/CursorUtil\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,646:1\n145#2,2:647\n148#2,2:654\n151#2:660\n145#2,7:661\n145#2,7:668\n145#2,7:675\n766#3:649\n857#3,2:650\n1855#3,2:652\n857#3,2:656\n1855#3,2:658\n*S KotlinDebug\n*F\n+ 1 TableInfo.kt\nandroidx/room/util/TableInfoKt\n*L\n477#1:647,2\n477#1:654,2\n477#1:660\n542#1:661,7\n580#1:668,7\n613#1:675,7\n497#1:649\n497#1:650,2\n499#1:652,2\n497#1:656,2\n499#1:658,2\n*E\n"
.end annotation


# direct methods
.method public static final readColumns(Landroidx/sqlite/db/SupportSQLiteDatabase;Ljava/lang/String;)Ljava/util/Map;
    .locals 26
    .param p0, "database"    # Landroidx/sqlite/db/SupportSQLiteDatabase;
    .param p1, "tableName"    # Ljava/lang/String;

    .line 542
    const-string v0, "type"

    const-string v1, "name"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "PRAGMA table_info(`"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v3, p1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "`)"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    move-object/from16 v4, p0

    invoke-interface {v4, v2}, Landroidx/sqlite/db/SupportSQLiteDatabase;->query(Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v2

    .local v2, "$this$useCursor$iv":Landroid/database/Cursor;
    const/4 v5, 0x0

    .line 145
    .local v5, "$i$f$useCursor":I
    nop

    .line 146
    move-object v6, v2

    .local v6, "cursor":Landroid/database/Cursor;
    const/4 v7, 0x0

    .line 543
    .local v7, "$i$a$-useCursor-TableInfoKt$readColumns$1":I
    :try_start_0
    invoke-interface {v6}, Landroid/database/Cursor;->getColumnCount()I

    move-result v8

    const/4 v9, 0x0

    if-gtz v8, :cond_0

    .line 544
    invoke-static {}, Lkotlin/collections/MapsKt__MapsKt;->emptyMap()Ljava/util/Map;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .end local v2    # "$this$useCursor$iv":Landroid/database/Cursor;
    .end local v5    # "$i$f$useCursor":I
    .end local v6    # "cursor":Landroid/database/Cursor;
    .end local v7    # "$i$a$-useCursor-TableInfoKt$readColumns$1":I
    invoke-static {v2, v9}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-object v0

    .line 553
    .restart local v2    # "$this$useCursor$iv":Landroid/database/Cursor;
    .restart local v5    # "$i$f$useCursor":I
    :catchall_0
    move-exception v0

    move-object v1, v0

    goto/16 :goto_3

    .line 547
    .restart local v6    # "cursor":Landroid/database/Cursor;
    .restart local v7    # "$i$a$-useCursor-TableInfoKt$readColumns$1":I
    :cond_0
    :try_start_1
    invoke-interface {v6, v1}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v8

    .line 548
    .local v8, "nameIndex":I
    invoke-interface {v6, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v10

    .line 549
    .local v10, "typeIndex":I
    const-string v11, "notnull"

    invoke-interface {v6, v11}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v11

    .line 550
    .local v11, "notNullIndex":I
    const-string v12, "pk"

    invoke-interface {v6, v12}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v12

    .line 551
    .local v12, "pkIndex":I
    const-string v13, "dflt_value"

    invoke-interface {v6, v13}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v13

    .line 553
    .local v13, "defaultValueIndex":I
    invoke-static {}, Lkotlin/collections/MapsKt__MapsJVMKt;->createMapBuilder()Ljava/util/Map;

    move-result-object v14

    move-object v15, v14

    .local v15, "$this$readColumns_u24lambda_u246_u24lambda_u245":Ljava/util/Map;
    const/16 v16, 0x0

    .line 554
    .local v16, "$i$a$-buildMap-TableInfoKt$readColumns$1$1":I
    :goto_0
    invoke-interface {v6}, Landroid/database/Cursor;->moveToNext()Z

    move-result v17

    if-eqz v17, :cond_2

    .line 555
    invoke-interface {v6, v8}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v17

    move-object/from16 v19, v17

    .line 556
    .local v19, "name":Ljava/lang/String;
    invoke-interface {v6, v10}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v20

    move-object/from16 v17, v20

    .line 557
    .local v17, "type":Ljava/lang/String;
    invoke-interface {v6, v11}, Landroid/database/Cursor;->getInt(I)I

    move-result v18

    if-eqz v18, :cond_1

    const/16 v18, 0x1

    :goto_1
    move/from16 v21, v18

    goto :goto_2

    :cond_1
    const/16 v18, 0x0

    goto :goto_1

    .line 558
    .local v21, "notNull":Z
    :goto_2
    invoke-interface {v6, v12}, Landroid/database/Cursor;->getInt(I)I

    move-result v22

    .line 559
    .local v22, "primaryKeyPosition":I
    invoke-interface {v6, v13}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v23

    .line 560
    .local v23, "defaultValue":Ljava/lang/String;
    nop

    .line 561
    move-object/from16 v9, v19

    .end local v19    # "name":Ljava/lang/String;
    .local v9, "name":Ljava/lang/String;
    invoke-static {v9, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 562
    new-instance v18, Landroidx/room/util/TableInfo$Column;

    .line 563
    nop

    .line 564
    move-object/from16 v25, v1

    move-object/from16 v1, v17

    .end local v17    # "type":Ljava/lang/String;
    .local v1, "type":Ljava/lang/String;
    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 565
    nop

    .line 566
    nop

    .line 567
    nop

    .line 568
    nop

    .line 562
    const/16 v24, 0x2

    move-object/from16 v20, v1

    move-object/from16 v19, v9

    .end local v1    # "type":Ljava/lang/String;
    .end local v9    # "name":Ljava/lang/String;
    .restart local v19    # "name":Ljava/lang/String;
    .local v20, "type":Ljava/lang/String;
    invoke-direct/range {v18 .. v24}, Landroidx/room/util/TableInfo$Column;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    move-object/from16 v17, v0

    move-object/from16 v0, v18

    .line 560
    .end local v19    # "name":Ljava/lang/String;
    .end local v20    # "type":Ljava/lang/String;
    .restart local v1    # "type":Ljava/lang/String;
    .restart local v9    # "name":Ljava/lang/String;
    invoke-interface {v15, v9, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-object/from16 v0, v17

    move-object/from16 v1, v25

    const/4 v9, 0x0

    goto :goto_0

    .line 572
    .end local v1    # "type":Ljava/lang/String;
    .end local v9    # "name":Ljava/lang/String;
    .end local v21    # "notNull":Z
    .end local v22    # "primaryKeyPosition":I
    .end local v23    # "defaultValue":Ljava/lang/String;
    :cond_2
    nop

    .line 553
    .end local v15    # "$this$readColumns_u24lambda_u246_u24lambda_u245":Ljava/util/Map;
    .end local v16    # "$i$a$-buildMap-TableInfoKt$readColumns$1$1":I
    invoke-static {v14}, Lkotlin/collections/MapsKt__MapsJVMKt;->build(Ljava/util/Map;)Ljava/util/Map;

    move-result-object v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v1, 0x0

    .end local v2    # "$this$useCursor$iv":Landroid/database/Cursor;
    .end local v5    # "$i$f$useCursor":I
    .end local v6    # "cursor":Landroid/database/Cursor;
    .end local v7    # "$i$a$-useCursor-TableInfoKt$readColumns$1":I
    .end local v8    # "nameIndex":I
    .end local v10    # "typeIndex":I
    .end local v11    # "notNullIndex":I
    .end local v12    # "pkIndex":I
    .end local v13    # "defaultValueIndex":I
    invoke-static {v2, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-object v0

    .restart local v2    # "$this$useCursor$iv":Landroid/database/Cursor;
    .restart local v5    # "$i$f$useCursor":I
    :goto_3
    nop

    .end local v2    # "$this$useCursor$iv":Landroid/database/Cursor;
    .end local v5    # "$i$f$useCursor":I
    .end local p0    # "database":Landroidx/sqlite/db/SupportSQLiteDatabase;
    .end local p1    # "tableName":Ljava/lang/String;
    :try_start_2
    throw v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .restart local v2    # "$this$useCursor$iv":Landroid/database/Cursor;
    .restart local v5    # "$i$f$useCursor":I
    .restart local p0    # "database":Landroidx/sqlite/db/SupportSQLiteDatabase;
    .restart local p1    # "tableName":Ljava/lang/String;
    :catchall_1
    move-exception v0

    invoke-static {v2, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0
.end method

.method public static final readForeignKeyFieldMappings(Landroid/database/Cursor;)Ljava/util/List;
    .locals 13
    .param p0, "cursor"    # Landroid/database/Cursor;

    .line 519
    const-string v0, "id"

    invoke-interface {p0, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v0

    .line 520
    .local v0, "idColumnIndex":I
    const-string v1, "seq"

    invoke-interface {p0, v1}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v1

    .line 521
    .local v1, "seqColumnIndex":I
    const-string v2, "from"

    invoke-interface {p0, v2}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v2

    .line 522
    .local v2, "fromColumnIndex":I
    const-string v3, "to"

    invoke-interface {p0, v3}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v3

    .line 524
    .local v3, "toColumnIndex":I
    invoke-static {}, Lkotlin/collections/CollectionsKt__CollectionsJVMKt;->createListBuilder()Ljava/util/List;

    move-result-object v4

    move-object v5, v4

    .local v5, "$this$readForeignKeyFieldMappings_u24lambda_u244":Ljava/util/List;
    const/4 v6, 0x0

    .line 525
    .local v6, "$i$a$-buildList-TableInfoKt$readForeignKeyFieldMappings$1":I
    :goto_0
    invoke-interface {p0}, Landroid/database/Cursor;->moveToNext()Z

    move-result v7

    if-eqz v7, :cond_0

    .line 526
    nop

    .line 527
    new-instance v7, Landroidx/room/util/TableInfo$ForeignKeyWithSequence;

    .line 528
    invoke-interface {p0, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v8

    .line 529
    invoke-interface {p0, v1}, Landroid/database/Cursor;->getInt(I)I

    move-result v9

    .line 530
    invoke-interface {p0, v2}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v10

    const-string v11, "cursor.getString(fromColumnIndex)"

    invoke-static {v10, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 531
    invoke-interface {p0, v3}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v11

    const-string v12, "cursor.getString(toColumnIndex)"

    invoke-static {v11, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 527
    invoke-direct {v7, v8, v9, v10, v11}, Landroidx/room/util/TableInfo$ForeignKeyWithSequence;-><init>(IILjava/lang/String;Ljava/lang/String;)V

    .line 526
    invoke-interface {v5, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 535
    :cond_0
    nop

    .line 524
    .end local v5    # "$this$readForeignKeyFieldMappings_u24lambda_u244":Ljava/util/List;
    .end local v6    # "$i$a$-buildList-TableInfoKt$readForeignKeyFieldMappings$1":I
    invoke-static {v4}, Lkotlin/collections/CollectionsKt__CollectionsJVMKt;->build(Ljava/util/List;)Ljava/util/List;

    move-result-object v4

    .line 535
    invoke-static {v4}, Lkotlin/collections/CollectionsKt___CollectionsKt;->sorted(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v4

    .line 524
    return-object v4
.end method

.method public static final readForeignKeys(Landroidx/sqlite/db/SupportSQLiteDatabase;Ljava/lang/String;)Ljava/util/Set;
    .locals 28
    .param p0, "database"    # Landroidx/sqlite/db/SupportSQLiteDatabase;
    .param p1, "tableName"    # Ljava/lang/String;

    .line 477
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "PRAGMA foreign_key_list(`"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v1, p1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "`)"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    move-object/from16 v2, p0

    invoke-interface {v2, v0}, Landroidx/sqlite/db/SupportSQLiteDatabase;->query(Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v3

    .local v3, "$this$useCursor$iv":Landroid/database/Cursor;
    const/4 v4, 0x0

    .line 145
    .local v4, "$i$f$useCursor":I
    nop

    .line 146
    move-object v0, v3

    .local v0, "cursor":Landroid/database/Cursor;
    const/4 v5, 0x0

    .line 478
    .local v5, "$i$a$-useCursor-TableInfoKt$readForeignKeys$1":I
    :try_start_0
    const-string v6, "id"

    invoke-interface {v0, v6}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v6

    .line 479
    .local v6, "idColumnIndex":I
    const-string v7, "seq"

    invoke-interface {v0, v7}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v7

    .line 480
    .local v7, "seqColumnIndex":I
    const-string v8, "table"

    invoke-interface {v0, v8}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v8

    .line 481
    .local v8, "tableColumnIndex":I
    const-string v9, "on_delete"

    invoke-interface {v0, v9}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v9

    .line 482
    .local v9, "onDeleteColumnIndex":I
    const-string v10, "on_update"

    invoke-interface {v0, v10}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v10

    .line 483
    .local v10, "onUpdateColumnIndex":I
    invoke-static {v0}, Landroidx/room/util/TableInfoKt;->readForeignKeyFieldMappings(Landroid/database/Cursor;)Ljava/util/List;

    move-result-object v11

    .line 486
    .local v11, "ordered":Ljava/util/List;
    const/4 v12, -0x1

    invoke-interface {v0, v12}, Landroid/database/Cursor;->moveToPosition(I)Z

    .line 487
    invoke-static {}, Lkotlin/collections/SetsKt__SetsJVMKt;->createSetBuilder()Ljava/util/Set;

    move-result-object v12

    move-object v13, v12

    .local v13, "$this$readForeignKeys_u24lambda_u243_u24lambda_u242":Ljava/util/Set;
    const/4 v14, 0x0

    .line 488
    .local v14, "$i$a$-buildSet-TableInfoKt$readForeignKeys$1$1":I
    :goto_0
    invoke-interface {v0}, Landroid/database/Cursor;->moveToNext()Z

    move-result v15

    if-eqz v15, :cond_5

    .line 489
    invoke-interface {v0, v7}, Landroid/database/Cursor;->getInt(I)I

    move-result v15

    .line 490
    .local v15, "seq":I
    if-eqz v15, :cond_0

    .line 491
    goto :goto_0

    .line 493
    :cond_0
    invoke-interface {v0, v6}, Landroid/database/Cursor;->getInt(I)I

    move-result v16

    move/from16 v17, v16

    .line 494
    .local v17, "id":I
    new-instance v16, Ljava/util/ArrayList;

    invoke-direct/range {v16 .. v16}, Ljava/util/ArrayList;-><init>()V

    move-object/from16 v22, v16

    .line 495
    .local v22, "myColumns":Ljava/util/List;
    new-instance v23, Ljava/util/ArrayList;

    invoke-direct/range {v23 .. v23}, Ljava/util/ArrayList;-><init>()V

    move-object/from16 v16, v23

    .line 497
    .local v16, "refColumns":Ljava/util/List;
    move-object/from16 v18, v11

    .local v18, "$this$filter$iv":Ljava/lang/Iterable;
    const/16 v19, 0x0

    .line 649
    .local v19, "$i$f$filter":I
    new-instance v20, Ljava/util/ArrayList;

    invoke-direct/range {v20 .. v20}, Ljava/util/ArrayList;-><init>()V

    move-object/from16 v21, v20

    .local v21, "destination$iv$iv":Ljava/util/Collection;
    move-object/from16 v20, v18

    .local v20, "$this$filterTo$iv$iv":Ljava/lang/Iterable;
    const/16 v23, 0x0

    .line 650
    .local v23, "$i$f$filterTo":I
    invoke-interface/range {v20 .. v20}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v24

    :goto_1
    invoke-interface/range {v24 .. v24}, Ljava/util/Iterator;->hasNext()Z

    move-result v25

    if-eqz v25, :cond_3

    invoke-interface/range {v24 .. v24}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v25

    move-object/from16 v26, v25

    .local v26, "element$iv$iv":Ljava/lang/Object;
    move-object/from16 v25, v26

    check-cast v25, Landroidx/room/util/TableInfo$ForeignKeyWithSequence;

    .local v25, "it":Landroidx/room/util/TableInfo$ForeignKeyWithSequence;
    const/16 v27, 0x0

    .line 498
    .local v27, "$i$a$-filter-TableInfoKt$readForeignKeys$1$1$1":I
    invoke-virtual/range {v25 .. v25}, Landroidx/room/util/TableInfo$ForeignKeyWithSequence;->getId()I

    move-result v1

    move/from16 v2, v17

    .end local v17    # "id":I
    .local v2, "id":I
    if-ne v1, v2, :cond_1

    const/4 v1, 0x1

    goto :goto_2

    :cond_1
    const/4 v1, 0x0

    .line 650
    .end local v25    # "it":Landroidx/room/util/TableInfo$ForeignKeyWithSequence;
    .end local v27    # "$i$a$-filter-TableInfoKt$readForeignKeys$1$1$1":I
    :goto_2
    if-eqz v1, :cond_2

    move/from16 v17, v2

    move-object/from16 v1, v21

    move-object/from16 v2, v26

    .end local v21    # "destination$iv$iv":Ljava/util/Collection;
    .end local v26    # "element$iv$iv":Ljava/lang/Object;
    .local v1, "destination$iv$iv":Ljava/util/Collection;
    .local v2, "element$iv$iv":Ljava/lang/Object;
    .restart local v17    # "id":I
    invoke-interface {v1, v2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move-object/from16 v2, p0

    move-object/from16 v21, v1

    :goto_3
    move-object/from16 v1, p1

    goto :goto_1

    .line 487
    .end local v0    # "cursor":Landroid/database/Cursor;
    .end local v1    # "destination$iv$iv":Ljava/util/Collection;
    .end local v2    # "element$iv$iv":Ljava/lang/Object;
    .end local v5    # "$i$a$-useCursor-TableInfoKt$readForeignKeys$1":I
    .end local v6    # "idColumnIndex":I
    .end local v7    # "seqColumnIndex":I
    .end local v8    # "tableColumnIndex":I
    .end local v9    # "onDeleteColumnIndex":I
    .end local v10    # "onUpdateColumnIndex":I
    .end local v11    # "ordered":Ljava/util/List;
    .end local v13    # "$this$readForeignKeys_u24lambda_u243_u24lambda_u242":Ljava/util/Set;
    .end local v14    # "$i$a$-buildSet-TableInfoKt$readForeignKeys$1$1":I
    .end local v15    # "seq":I
    .end local v16    # "refColumns":Ljava/util/List;
    .end local v17    # "id":I
    .end local v18    # "$this$filter$iv":Ljava/lang/Iterable;
    .end local v19    # "$i$f$filter":I
    .end local v20    # "$this$filterTo$iv$iv":Ljava/lang/Iterable;
    .end local v22    # "myColumns":Ljava/util/List;
    .end local v23    # "$i$f$filterTo":I
    :catchall_0
    move-exception v0

    move-object v1, v0

    goto/16 :goto_5

    .line 650
    .restart local v0    # "cursor":Landroid/database/Cursor;
    .local v2, "id":I
    .restart local v5    # "$i$a$-useCursor-TableInfoKt$readForeignKeys$1":I
    .restart local v6    # "idColumnIndex":I
    .restart local v7    # "seqColumnIndex":I
    .restart local v8    # "tableColumnIndex":I
    .restart local v9    # "onDeleteColumnIndex":I
    .restart local v10    # "onUpdateColumnIndex":I
    .restart local v11    # "ordered":Ljava/util/List;
    .restart local v13    # "$this$readForeignKeys_u24lambda_u243_u24lambda_u242":Ljava/util/Set;
    .restart local v14    # "$i$a$-buildSet-TableInfoKt$readForeignKeys$1$1":I
    .restart local v15    # "seq":I
    .restart local v16    # "refColumns":Ljava/util/List;
    .restart local v18    # "$this$filter$iv":Ljava/lang/Iterable;
    .restart local v19    # "$i$f$filter":I
    .restart local v20    # "$this$filterTo$iv$iv":Ljava/lang/Iterable;
    .restart local v21    # "destination$iv$iv":Ljava/util/Collection;
    .restart local v22    # "myColumns":Ljava/util/List;
    .restart local v23    # "$i$f$filterTo":I
    .restart local v26    # "element$iv$iv":Ljava/lang/Object;
    :cond_2
    move/from16 v17, v2

    move-object/from16 v1, v21

    move-object/from16 v2, v26

    .end local v21    # "destination$iv$iv":Ljava/util/Collection;
    .end local v26    # "element$iv$iv":Ljava/lang/Object;
    .restart local v1    # "destination$iv$iv":Ljava/util/Collection;
    .local v2, "element$iv$iv":Ljava/lang/Object;
    .restart local v17    # "id":I
    move-object/from16 v2, p0

    goto :goto_3

    .line 651
    .end local v1    # "destination$iv$iv":Ljava/util/Collection;
    .end local v2    # "element$iv$iv":Ljava/lang/Object;
    .restart local v21    # "destination$iv$iv":Ljava/util/Collection;
    :cond_3
    move-object/from16 v1, v21

    .line 649
    .end local v20    # "$this$filterTo$iv$iv":Ljava/lang/Iterable;
    .end local v21    # "destination$iv$iv":Ljava/util/Collection;
    .end local v23    # "$i$f$filterTo":I
    nop

    .line 499
    .end local v18    # "$this$filter$iv":Ljava/lang/Iterable;
    .end local v19    # "$i$f$filter":I
    nop

    .local v1, "$this$forEach$iv":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 1855
    .local v2, "$i$f$forEach":I
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v18

    :goto_4
    invoke-interface/range {v18 .. v18}, Ljava/util/Iterator;->hasNext()Z

    move-result v19

    if-eqz v19, :cond_4

    invoke-interface/range {v18 .. v18}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v19

    .local v19, "element$iv":Ljava/lang/Object;
    move-object/from16 v20, v19

    check-cast v20, Landroidx/room/util/TableInfo$ForeignKeyWithSequence;

    .local v20, "key":Landroidx/room/util/TableInfo$ForeignKeyWithSequence;
    const/16 v21, 0x0

    .line 500
    .local v21, "$i$a$-forEach-TableInfoKt$readForeignKeys$1$1$2":I
    move-object/from16 v23, v1

    .end local v1    # "$this$forEach$iv":Ljava/lang/Iterable;
    .local v23, "$this$forEach$iv":Ljava/lang/Iterable;
    invoke-virtual/range {v20 .. v20}, Landroidx/room/util/TableInfo$ForeignKeyWithSequence;->getFrom()Ljava/lang/String;

    move-result-object v1

    move/from16 v24, v2

    move-object/from16 v2, v22

    .end local v22    # "myColumns":Ljava/util/List;
    .local v2, "myColumns":Ljava/util/List;
    .local v24, "$i$f$forEach":I
    invoke-interface {v2, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 501
    invoke-virtual/range {v20 .. v20}, Landroidx/room/util/TableInfo$ForeignKeyWithSequence;->getTo()Ljava/lang/String;

    move-result-object v1

    move-object/from16 v22, v2

    move-object/from16 v2, v16

    .end local v16    # "refColumns":Ljava/util/List;
    .local v2, "refColumns":Ljava/util/List;
    .restart local v22    # "myColumns":Ljava/util/List;
    invoke-interface {v2, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 502
    nop

    .line 1855
    .end local v20    # "key":Landroidx/room/util/TableInfo$ForeignKeyWithSequence;
    .end local v21    # "$i$a$-forEach-TableInfoKt$readForeignKeys$1$1$2":I
    move-object/from16 v16, v2

    move-object/from16 v1, v23

    move/from16 v2, v24

    .end local v19    # "element$iv":Ljava/lang/Object;
    goto :goto_4

    .line 1856
    .end local v23    # "$this$forEach$iv":Ljava/lang/Iterable;
    .end local v24    # "$i$f$forEach":I
    .restart local v1    # "$this$forEach$iv":Ljava/lang/Iterable;
    .local v2, "$i$f$forEach":I
    .restart local v16    # "refColumns":Ljava/util/List;
    :cond_4
    move-object/from16 v23, v1

    move/from16 v24, v2

    move-object/from16 v2, v16

    .line 504
    .end local v1    # "$this$forEach$iv":Ljava/lang/Iterable;
    .end local v16    # "refColumns":Ljava/util/List;
    .local v2, "refColumns":Ljava/util/List;
    nop

    .line 505
    new-instance v18, Landroidx/room/util/TableInfo$ForeignKey;

    .line 506
    invoke-interface {v0, v8}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    move-object/from16 v23, v2

    .end local v2    # "refColumns":Ljava/util/List;
    .local v23, "refColumns":Ljava/util/List;
    const-string v2, "cursor.getString(tableColumnIndex)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 507
    invoke-interface {v0, v9}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v2

    move-object/from16 v19, v1

    const-string v1, "cursor.getString(onDeleteColumnIndex)"

    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 508
    invoke-interface {v0, v10}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    move-object/from16 v16, v0

    .end local v0    # "cursor":Landroid/database/Cursor;
    .local v16, "cursor":Landroid/database/Cursor;
    const-string v0, "cursor.getString(onUpdateColumnIndex)"

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 509
    nop

    .line 510
    nop

    .line 505
    move-object/from16 v21, v1

    move-object/from16 v20, v2

    invoke-direct/range {v18 .. v23}, Landroidx/room/util/TableInfo$ForeignKey;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/util/List;)V

    move-object/from16 v0, v18

    .line 504
    invoke-interface {v13, v0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    move-object/from16 v2, p0

    move-object/from16 v1, p1

    move-object/from16 v0, v16

    goto/16 :goto_0

    .line 514
    .end local v15    # "seq":I
    .end local v16    # "cursor":Landroid/database/Cursor;
    .end local v17    # "id":I
    .end local v22    # "myColumns":Ljava/util/List;
    .end local v23    # "refColumns":Ljava/util/List;
    .restart local v0    # "cursor":Landroid/database/Cursor;
    :cond_5
    move-object/from16 v16, v0

    .line 487
    .end local v0    # "cursor":Landroid/database/Cursor;
    .end local v13    # "$this$readForeignKeys_u24lambda_u243_u24lambda_u242":Ljava/util/Set;
    .end local v14    # "$i$a$-buildSet-TableInfoKt$readForeignKeys$1$1":I
    .restart local v16    # "cursor":Landroid/database/Cursor;
    invoke-static {v12}, Lkotlin/collections/SetsKt__SetsJVMKt;->build(Ljava/util/Set;)Ljava/util/Set;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .end local v3    # "$this$useCursor$iv":Landroid/database/Cursor;
    .end local v4    # "$i$f$useCursor":I
    .end local v5    # "$i$a$-useCursor-TableInfoKt$readForeignKeys$1":I
    .end local v6    # "idColumnIndex":I
    .end local v7    # "seqColumnIndex":I
    .end local v8    # "tableColumnIndex":I
    .end local v9    # "onDeleteColumnIndex":I
    .end local v10    # "onUpdateColumnIndex":I
    .end local v11    # "ordered":Ljava/util/List;
    .end local v16    # "cursor":Landroid/database/Cursor;
    const/4 v1, 0x0

    invoke-static {v3, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-object v0

    .restart local v3    # "$this$useCursor$iv":Landroid/database/Cursor;
    .restart local v4    # "$i$f$useCursor":I
    :goto_5
    nop

    .end local v3    # "$this$useCursor$iv":Landroid/database/Cursor;
    .end local v4    # "$i$f$useCursor":I
    .end local p0    # "database":Landroidx/sqlite/db/SupportSQLiteDatabase;
    .end local p1    # "tableName":Ljava/lang/String;
    :try_start_1
    throw v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .restart local v3    # "$this$useCursor$iv":Landroid/database/Cursor;
    .restart local v4    # "$i$f$useCursor":I
    .restart local p0    # "database":Landroidx/sqlite/db/SupportSQLiteDatabase;
    .restart local p1    # "tableName":Ljava/lang/String;
    :catchall_1
    move-exception v0

    invoke-static {v3, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0
.end method

.method public static final readIndex(Landroidx/sqlite/db/SupportSQLiteDatabase;Ljava/lang/String;Z)Landroidx/room/util/TableInfo$Index;
    .locals 19
    .param p0, "database"    # Landroidx/sqlite/db/SupportSQLiteDatabase;
    .param p1, "name"    # Ljava/lang/String;
    .param p2, "unique"    # Z

    .line 613
    move-object/from16 v1, p1

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "PRAGMA index_xinfo(`"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "`)"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    move-object/from16 v2, p0

    invoke-interface {v2, v0}, Landroidx/sqlite/db/SupportSQLiteDatabase;->query(Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v3

    .local v3, "$this$useCursor$iv":Landroid/database/Cursor;
    const/4 v4, 0x0

    .line 145
    .local v4, "$i$f$useCursor":I
    nop

    .line 146
    move-object v0, v3

    .local v0, "cursor":Landroid/database/Cursor;
    const/4 v5, 0x0

    .line 614
    .local v5, "$i$a$-useCursor-TableInfoKt$readIndex$1":I
    :try_start_0
    const-string v6, "seqno"

    invoke-interface {v0, v6}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v6

    .line 615
    .local v6, "seqnoColumnIndex":I
    const-string v7, "cid"

    invoke-interface {v0, v7}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v7

    .line 616
    .local v7, "cidColumnIndex":I
    const-string v8, "name"

    invoke-interface {v0, v8}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v8

    .line 617
    .local v8, "nameColumnIndex":I
    const-string v9, "desc"

    invoke-interface {v0, v9}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v9

    .line 618
    .local v9, "descColumnIndex":I
    nop

    .line 619
    const/4 v11, -0x1

    if-eq v6, v11, :cond_6

    .line 620
    if-eq v7, v11, :cond_5

    .line 621
    if-eq v8, v11, :cond_4

    .line 622
    if-ne v9, v11, :cond_0

    move/from16 v14, p2

    move-object/from16 v18, v0

    goto/16 :goto_3

    .line 627
    :cond_0
    new-instance v11, Ljava/util/TreeMap;

    invoke-direct {v11}, Ljava/util/TreeMap;-><init>()V

    .line 628
    .local v11, "columnsMap":Ljava/util/TreeMap;
    new-instance v12, Ljava/util/TreeMap;

    invoke-direct {v12}, Ljava/util/TreeMap;-><init>()V

    .line 629
    .local v12, "ordersMap":Ljava/util/TreeMap;
    :goto_0
    invoke-interface {v0}, Landroid/database/Cursor;->moveToNext()Z

    move-result v13

    if-eqz v13, :cond_3

    .line 630
    invoke-interface {v0, v7}, Landroid/database/Cursor;->getInt(I)I

    move-result v13

    .line 631
    .local v13, "cid":I
    if-gez v13, :cond_1

    .line 633
    goto :goto_0

    .line 635
    :cond_1
    invoke-interface {v0, v6}, Landroid/database/Cursor;->getInt(I)I

    move-result v14

    .line 636
    .local v14, "seq":I
    invoke-interface {v0, v8}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v15

    .line 637
    .local v15, "columnName":Ljava/lang/String;
    invoke-interface {v0, v9}, Landroid/database/Cursor;->getInt(I)I

    move-result v16

    nop

    if-lez v16, :cond_2

    const-string v16, "DESC"

    goto :goto_2

    .line 146
    .end local v0    # "cursor":Landroid/database/Cursor;
    .end local v5    # "$i$a$-useCursor-TableInfoKt$readIndex$1":I
    .end local v6    # "seqnoColumnIndex":I
    .end local v7    # "cidColumnIndex":I
    .end local v8    # "nameColumnIndex":I
    .end local v9    # "descColumnIndex":I
    .end local v11    # "columnsMap":Ljava/util/TreeMap;
    .end local v12    # "ordersMap":Ljava/util/TreeMap;
    .end local v13    # "cid":I
    .end local v14    # "seq":I
    .end local v15    # "columnName":Ljava/lang/String;
    :catchall_0
    move-exception v0

    move/from16 v14, p2

    :goto_1
    move-object v5, v0

    goto :goto_4

    .line 637
    .restart local v0    # "cursor":Landroid/database/Cursor;
    .restart local v5    # "$i$a$-useCursor-TableInfoKt$readIndex$1":I
    .restart local v6    # "seqnoColumnIndex":I
    .restart local v7    # "cidColumnIndex":I
    .restart local v8    # "nameColumnIndex":I
    .restart local v9    # "descColumnIndex":I
    .restart local v11    # "columnsMap":Ljava/util/TreeMap;
    .restart local v12    # "ordersMap":Ljava/util/TreeMap;
    .restart local v13    # "cid":I
    .restart local v14    # "seq":I
    .restart local v15    # "columnName":Ljava/lang/String;
    :cond_2
    const-string v16, "ASC"

    :goto_2
    move-object/from16 v17, v16

    .local v17, "order":Ljava/lang/String;
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    .line 638
    move-object/from16 v18, v0

    .end local v0    # "cursor":Landroid/database/Cursor;
    .local v18, "cursor":Landroid/database/Cursor;
    const-string v0, "columnName"

    invoke-static {v15, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {v11, v10, v15}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    .line 639
    move-object/from16 v10, v17

    .end local v17    # "order":Ljava/lang/String;
    .local v10, "order":Ljava/lang/String;
    invoke-interface {v12, v0, v10}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-object/from16 v0, v18

    goto :goto_0

    .line 641
    .end local v10    # "order":Ljava/lang/String;
    .end local v13    # "cid":I
    .end local v14    # "seq":I
    .end local v15    # "columnName":Ljava/lang/String;
    .end local v18    # "cursor":Landroid/database/Cursor;
    .restart local v0    # "cursor":Landroid/database/Cursor;
    :cond_3
    move-object/from16 v18, v0

    .end local v0    # "cursor":Landroid/database/Cursor;
    .restart local v18    # "cursor":Landroid/database/Cursor;
    invoke-virtual {v11}, Ljava/util/TreeMap;->values()Ljava/util/Collection;

    move-result-object v0

    const-string v10, "columnsMap.values"

    invoke-static {v0, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, Lkotlin/collections/CollectionsKt___CollectionsKt;->toList(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v0

    .line 642
    .local v0, "columns":Ljava/util/List;
    invoke-virtual {v12}, Ljava/util/TreeMap;->values()Ljava/util/Collection;

    move-result-object v10

    const-string v13, "ordersMap.values"

    invoke-static {v10, v13}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v10}, Lkotlin/collections/CollectionsKt___CollectionsKt;->toList(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v10

    .line 643
    .local v10, "orders":Ljava/util/List;
    new-instance v13, Landroidx/room/util/TableInfo$Index;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move/from16 v14, p2

    :try_start_1
    invoke-direct {v13, v1, v14, v0, v10}, Landroidx/room/util/TableInfo$Index;-><init>(Ljava/lang/String;ZLjava/util/List;Ljava/util/List;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 146
    .end local v0    # "columns":Ljava/util/List;
    .end local v5    # "$i$a$-useCursor-TableInfoKt$readIndex$1":I
    .end local v6    # "seqnoColumnIndex":I
    .end local v7    # "cidColumnIndex":I
    .end local v8    # "nameColumnIndex":I
    .end local v9    # "descColumnIndex":I
    .end local v10    # "orders":Ljava/util/List;
    .end local v11    # "columnsMap":Ljava/util/TreeMap;
    .end local v12    # "ordersMap":Ljava/util/TreeMap;
    .end local v18    # "cursor":Landroid/database/Cursor;
    const/4 v0, 0x0

    invoke-static {v3, v0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 613
    .end local v3    # "$this$useCursor$iv":Landroid/database/Cursor;
    .end local v4    # "$i$f$useCursor":I
    return-object v13

    .line 146
    .restart local v3    # "$this$useCursor$iv":Landroid/database/Cursor;
    .restart local v4    # "$i$f$useCursor":I
    :catchall_1
    move-exception v0

    goto :goto_1

    .line 621
    .local v0, "cursor":Landroid/database/Cursor;
    .restart local v5    # "$i$a$-useCursor-TableInfoKt$readIndex$1":I
    .restart local v6    # "seqnoColumnIndex":I
    .restart local v7    # "cidColumnIndex":I
    .restart local v8    # "nameColumnIndex":I
    .restart local v9    # "descColumnIndex":I
    :cond_4
    move/from16 v14, p2

    move-object/from16 v18, v0

    .end local v0    # "cursor":Landroid/database/Cursor;
    .restart local v18    # "cursor":Landroid/database/Cursor;
    goto :goto_3

    .line 620
    .end local v18    # "cursor":Landroid/database/Cursor;
    .restart local v0    # "cursor":Landroid/database/Cursor;
    :cond_5
    move/from16 v14, p2

    move-object/from16 v18, v0

    .end local v0    # "cursor":Landroid/database/Cursor;
    .restart local v18    # "cursor":Landroid/database/Cursor;
    goto :goto_3

    .line 619
    .end local v18    # "cursor":Landroid/database/Cursor;
    .restart local v0    # "cursor":Landroid/database/Cursor;
    :cond_6
    move/from16 v14, p2

    move-object/from16 v18, v0

    .line 625
    .end local v0    # "cursor":Landroid/database/Cursor;
    .restart local v18    # "cursor":Landroid/database/Cursor;
    :goto_3
    const/4 v0, 0x0

    .end local v3    # "$this$useCursor$iv":Landroid/database/Cursor;
    .end local v4    # "$i$f$useCursor":I
    .end local v5    # "$i$a$-useCursor-TableInfoKt$readIndex$1":I
    .end local v6    # "seqnoColumnIndex":I
    .end local v7    # "cidColumnIndex":I
    .end local v8    # "nameColumnIndex":I
    .end local v9    # "descColumnIndex":I
    .end local v18    # "cursor":Landroid/database/Cursor;
    invoke-static {v3, v0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-object v0

    .line 146
    .restart local v3    # "$this$useCursor$iv":Landroid/database/Cursor;
    .restart local v4    # "$i$f$useCursor":I
    :goto_4
    nop

    .end local v3    # "$this$useCursor$iv":Landroid/database/Cursor;
    .end local v4    # "$i$f$useCursor":I
    .end local p0    # "database":Landroidx/sqlite/db/SupportSQLiteDatabase;
    .end local p1    # "name":Ljava/lang/String;
    .end local p2    # "unique":Z
    :try_start_2
    throw v5
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    .restart local v3    # "$this$useCursor$iv":Landroid/database/Cursor;
    .restart local v4    # "$i$f$useCursor":I
    .restart local p0    # "database":Landroidx/sqlite/db/SupportSQLiteDatabase;
    .restart local p1    # "name":Ljava/lang/String;
    .restart local p2    # "unique":Z
    :catchall_2
    move-exception v0

    invoke-static {v3, v5}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0
.end method

.method public static final readIndices(Landroidx/sqlite/db/SupportSQLiteDatabase;Ljava/lang/String;)Ljava/util/Set;
    .locals 16
    .param p0, "database"    # Landroidx/sqlite/db/SupportSQLiteDatabase;
    .param p1, "tableName"    # Ljava/lang/String;

    .line 580
    move-object/from16 v1, p0

    const-string v0, "name"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "PRAGMA index_list(`"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v3, p1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "`)"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v1, v2}, Landroidx/sqlite/db/SupportSQLiteDatabase;->query(Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v2

    .local v2, "$this$useCursor$iv":Landroid/database/Cursor;
    const/4 v4, 0x0

    .line 145
    .local v4, "$i$f$useCursor":I
    nop

    .line 146
    move-object v5, v2

    .local v5, "cursor":Landroid/database/Cursor;
    const/4 v6, 0x0

    .line 581
    .local v6, "$i$a$-useCursor-TableInfoKt$readIndices$1":I
    :try_start_0
    invoke-interface {v5, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v7

    .line 582
    .local v7, "nameColumnIndex":I
    const-string v8, "origin"

    invoke-interface {v5, v8}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v8

    .line 583
    .local v8, "originColumnIndex":I
    const-string v9, "unique"

    invoke-interface {v5, v9}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v9

    .line 584
    .local v9, "uniqueIndex":I
    const/4 v10, -0x1

    if-eq v7, v10, :cond_0

    if-eq v8, v10, :cond_0

    if-ne v9, v10, :cond_1

    :cond_0
    goto :goto_2

    .line 588
    :cond_1
    invoke-static {}, Lkotlin/collections/SetsKt__SetsJVMKt;->createSetBuilder()Ljava/util/Set;

    move-result-object v10

    move-object v12, v10

    .local v12, "$this$readIndices_u24lambda_u248_u24lambda_u247":Ljava/util/Set;
    const/4 v13, 0x0

    .line 589
    .local v13, "$i$a$-buildSet-TableInfoKt$readIndices$1$1":I
    :goto_0
    invoke-interface {v5}, Landroid/database/Cursor;->moveToNext()Z

    move-result v14

    if-eqz v14, :cond_5

    .line 590
    invoke-interface {v5, v8}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v14

    .line 591
    .local v14, "origin":Ljava/lang/String;
    const-string v15, "c"

    invoke-static {v15, v14}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v15

    if-nez v15, :cond_2

    .line 593
    goto :goto_0

    .line 595
    :cond_2
    invoke-interface {v5, v7}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v15

    .line 596
    .local v15, "name":Ljava/lang/String;
    invoke-interface {v5, v9}, Landroid/database/Cursor;->getInt(I)I

    move-result v11

    const/4 v3, 0x1

    if-ne v11, v3, :cond_3

    goto :goto_1

    :cond_3
    const/4 v3, 0x0

    .line 598
    .local v3, "unique":Z
    :goto_1
    invoke-static {v15, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v1, v15, v3}, Landroidx/room/util/TableInfoKt;->readIndex(Landroidx/sqlite/db/SupportSQLiteDatabase;Ljava/lang/String;Z)Landroidx/room/util/TableInfo$Index;

    move-result-object v11
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez v11, :cond_4

    const/4 v0, 0x0

    .end local v2    # "$this$useCursor$iv":Landroid/database/Cursor;
    .end local v3    # "unique":Z
    .end local v4    # "$i$f$useCursor":I
    .end local v5    # "cursor":Landroid/database/Cursor;
    .end local v6    # "$i$a$-useCursor-TableInfoKt$readIndices$1":I
    .end local v7    # "nameColumnIndex":I
    .end local v8    # "originColumnIndex":I
    .end local v9    # "uniqueIndex":I
    .end local v12    # "$this$readIndices_u24lambda_u248_u24lambda_u247":Ljava/util/Set;
    .end local v13    # "$i$a$-buildSet-TableInfoKt$readIndices$1$1":I
    .end local v14    # "origin":Ljava/lang/String;
    .end local v15    # "name":Ljava/lang/String;
    invoke-static {v2, v0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-object v0

    .line 599
    .restart local v2    # "$this$useCursor$iv":Landroid/database/Cursor;
    .restart local v3    # "unique":Z
    .restart local v4    # "$i$f$useCursor":I
    .restart local v5    # "cursor":Landroid/database/Cursor;
    .restart local v6    # "$i$a$-useCursor-TableInfoKt$readIndices$1":I
    .restart local v7    # "nameColumnIndex":I
    .restart local v8    # "originColumnIndex":I
    .restart local v9    # "uniqueIndex":I
    .local v11, "index":Landroidx/room/util/TableInfo$Index;
    .restart local v12    # "$this$readIndices_u24lambda_u248_u24lambda_u247":Ljava/util/Set;
    .restart local v13    # "$i$a$-buildSet-TableInfoKt$readIndices$1$1":I
    .restart local v14    # "origin":Ljava/lang/String;
    .restart local v15    # "name":Ljava/lang/String;
    :cond_4
    :try_start_1
    invoke-interface {v12, v11}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    move-object/from16 v3, p1

    goto :goto_0

    .line 588
    .end local v3    # "unique":Z
    .end local v5    # "cursor":Landroid/database/Cursor;
    .end local v6    # "$i$a$-useCursor-TableInfoKt$readIndices$1":I
    .end local v7    # "nameColumnIndex":I
    .end local v8    # "originColumnIndex":I
    .end local v9    # "uniqueIndex":I
    .end local v11    # "index":Landroidx/room/util/TableInfo$Index;
    .end local v12    # "$this$readIndices_u24lambda_u248_u24lambda_u247":Ljava/util/Set;
    .end local v13    # "$i$a$-buildSet-TableInfoKt$readIndices$1$1":I
    .end local v14    # "origin":Ljava/lang/String;
    .end local v15    # "name":Ljava/lang/String;
    :catchall_0
    move-exception v0

    move-object v3, v0

    goto :goto_3

    .line 601
    .restart local v5    # "cursor":Landroid/database/Cursor;
    .restart local v6    # "$i$a$-useCursor-TableInfoKt$readIndices$1":I
    .restart local v7    # "nameColumnIndex":I
    .restart local v8    # "originColumnIndex":I
    .restart local v9    # "uniqueIndex":I
    .restart local v12    # "$this$readIndices_u24lambda_u248_u24lambda_u247":Ljava/util/Set;
    .restart local v13    # "$i$a$-buildSet-TableInfoKt$readIndices$1$1":I
    :cond_5
    nop

    .line 588
    .end local v12    # "$this$readIndices_u24lambda_u248_u24lambda_u247":Ljava/util/Set;
    .end local v13    # "$i$a$-buildSet-TableInfoKt$readIndices$1$1":I
    invoke-static {v10}, Lkotlin/collections/SetsKt__SetsJVMKt;->build(Ljava/util/Set;)Ljava/util/Set;

    move-result-object v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v3, 0x0

    .end local v2    # "$this$useCursor$iv":Landroid/database/Cursor;
    .end local v4    # "$i$f$useCursor":I
    .end local v5    # "cursor":Landroid/database/Cursor;
    .end local v6    # "$i$a$-useCursor-TableInfoKt$readIndices$1":I
    .end local v7    # "nameColumnIndex":I
    .end local v8    # "originColumnIndex":I
    .end local v9    # "uniqueIndex":I
    invoke-static {v2, v3}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-object v0

    .line 586
    .restart local v2    # "$this$useCursor$iv":Landroid/database/Cursor;
    .restart local v4    # "$i$f$useCursor":I
    .restart local v5    # "cursor":Landroid/database/Cursor;
    .restart local v6    # "$i$a$-useCursor-TableInfoKt$readIndices$1":I
    .restart local v7    # "nameColumnIndex":I
    .restart local v8    # "originColumnIndex":I
    .restart local v9    # "uniqueIndex":I
    :goto_2
    const/4 v0, 0x0

    .end local v2    # "$this$useCursor$iv":Landroid/database/Cursor;
    .end local v4    # "$i$f$useCursor":I
    .end local v5    # "cursor":Landroid/database/Cursor;
    .end local v6    # "$i$a$-useCursor-TableInfoKt$readIndices$1":I
    .end local v7    # "nameColumnIndex":I
    .end local v8    # "originColumnIndex":I
    .end local v9    # "uniqueIndex":I
    invoke-static {v2, v0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-object v0

    .line 588
    .restart local v2    # "$this$useCursor$iv":Landroid/database/Cursor;
    .restart local v4    # "$i$f$useCursor":I
    :goto_3
    nop

    .end local v2    # "$this$useCursor$iv":Landroid/database/Cursor;
    .end local v4    # "$i$f$useCursor":I
    .end local p0    # "database":Landroidx/sqlite/db/SupportSQLiteDatabase;
    .end local p1    # "tableName":Ljava/lang/String;
    :try_start_2
    throw v3
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .restart local v2    # "$this$useCursor$iv":Landroid/database/Cursor;
    .restart local v4    # "$i$f$useCursor":I
    .restart local p0    # "database":Landroidx/sqlite/db/SupportSQLiteDatabase;
    .restart local p1    # "tableName":Ljava/lang/String;
    :catchall_1
    move-exception v0

    invoke-static {v2, v3}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0
.end method

.method public static final readTableInfo(Landroidx/sqlite/db/SupportSQLiteDatabase;Ljava/lang/String;)Landroidx/room/util/TableInfo;
    .locals 4
    .param p0, "database"    # Landroidx/sqlite/db/SupportSQLiteDatabase;
    .param p1, "tableName"    # Ljava/lang/String;

    const-string v0, "database"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "tableName"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 466
    invoke-static {p0, p1}, Landroidx/room/util/TableInfoKt;->readColumns(Landroidx/sqlite/db/SupportSQLiteDatabase;Ljava/lang/String;)Ljava/util/Map;

    move-result-object v0

    .line 467
    .local v0, "columns":Ljava/util/Map;
    invoke-static {p0, p1}, Landroidx/room/util/TableInfoKt;->readForeignKeys(Landroidx/sqlite/db/SupportSQLiteDatabase;Ljava/lang/String;)Ljava/util/Set;

    move-result-object v1

    .line 468
    .local v1, "foreignKeys":Ljava/util/Set;
    invoke-static {p0, p1}, Landroidx/room/util/TableInfoKt;->readIndices(Landroidx/sqlite/db/SupportSQLiteDatabase;Ljava/lang/String;)Ljava/util/Set;

    move-result-object v2

    .line 469
    .local v2, "indices":Ljava/util/Set;
    new-instance v3, Landroidx/room/util/TableInfo;

    invoke-direct {v3, p1, v0, v1, v2}, Landroidx/room/util/TableInfo;-><init>(Ljava/lang/String;Ljava/util/Map;Ljava/util/Set;Ljava/util/Set;)V

    return-object v3
.end method
