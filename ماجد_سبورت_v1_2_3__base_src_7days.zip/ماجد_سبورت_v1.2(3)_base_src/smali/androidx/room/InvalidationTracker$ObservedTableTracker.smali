.class public final Landroidx/room/InvalidationTracker$ObservedTableTracker;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/room/InvalidationTracker;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "ObservedTableTracker"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/room/InvalidationTracker$ObservedTableTracker$Companion;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nInvalidationTracker.kt\nKotlin\n*S Kotlin\n*F\n+ 1 InvalidationTracker.kt\nandroidx/room/InvalidationTracker$ObservedTableTracker\n+ 2 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n*L\n1#1,840:1\n13600#2,2:841\n13600#2,2:843\n13684#2,3:845\n*S KotlinDebug\n*F\n+ 1 InvalidationTracker.kt\nandroidx/room/InvalidationTracker$ObservedTableTracker\n*L\n711#1:841,2\n729#1:843,2\n765#1:845,3\n*E\n"
.end annotation


# static fields
.field public static final Companion:Landroidx/room/InvalidationTracker$ObservedTableTracker$Companion;


# instance fields
.field public needsSync:Z

.field public final tableObservers:[J

.field public final triggerStateChanges:[I

.field public final triggerStates:[Z


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Landroidx/room/InvalidationTracker$ObservedTableTracker$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Landroidx/room/InvalidationTracker$ObservedTableTracker$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Landroidx/room/InvalidationTracker$ObservedTableTracker;->Companion:Landroidx/room/InvalidationTracker$ObservedTableTracker$Companion;

    return-void
.end method

.method public constructor <init>(I)V
    .locals 1
    .param p1, "tableCount"    # I

    .line 692
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 694
    new-array v0, p1, [J

    iput-object v0, p0, Landroidx/room/InvalidationTracker$ObservedTableTracker;->tableObservers:[J

    .line 698
    new-array v0, p1, [Z

    iput-object v0, p0, Landroidx/room/InvalidationTracker$ObservedTableTracker;->triggerStates:[Z

    .line 701
    new-array v0, p1, [I

    iput-object v0, p0, Landroidx/room/InvalidationTracker$ObservedTableTracker;->triggerStateChanges:[I

    .line 692
    return-void
.end method


# virtual methods
.method public final getTablesToSync()[I
    .locals 17

    .line 761
    move-object/from16 v1, p0

    monitor-enter p0

    const/4 v0, 0x0

    .line 762
    .local v0, "$i$a$-synchronized-InvalidationTracker$ObservedTableTracker$getTablesToSync$1":I
    :try_start_0
    iget-boolean v2, v1, Landroidx/room/InvalidationTracker$ObservedTableTracker;->needsSync:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez v2, :cond_0

    .line 763
    nop

    .end local v0    # "$i$a$-synchronized-InvalidationTracker$ObservedTableTracker$getTablesToSync$1":I
    monitor-exit p0

    const/4 v0, 0x0

    return-object v0

    .line 765
    .restart local v0    # "$i$a$-synchronized-InvalidationTracker$ObservedTableTracker$getTablesToSync$1":I
    :cond_0
    :try_start_1
    iget-object v2, v1, Landroidx/room/InvalidationTracker$ObservedTableTracker;->tableObservers:[J

    .local v2, "$this$forEachIndexed$iv":[J
    const/4 v3, 0x0

    .line 13684
    .local v3, "$i$f$forEachIndexed":I
    const/4 v4, 0x0

    .line 846
    .local v4, "index$iv":I
    array-length v5, v2

    const/4 v6, 0x0

    move v7, v6

    :goto_0
    if-ge v7, v5, :cond_4

    aget-wide v8, v2, v7

    .local v8, "item$iv":J
    add-int/lit8 v10, v4, 0x1

    .local v4, "i":I
    .local v10, "index$iv":I
    move-wide v11, v8

    .local v11, "observerCount":J
    const/4 v13, 0x0

    .line 766
    .local v13, "$i$a$-forEachIndexed-InvalidationTracker$ObservedTableTracker$getTablesToSync$1$1":I
    const-wide/16 v14, 0x0

    cmp-long v14, v11, v14

    if-lez v14, :cond_1

    const/4 v14, 0x1

    goto :goto_1

    :cond_1
    move v14, v6

    .line 767
    .local v14, "newState":Z
    :goto_1
    iget-object v15, v1, Landroidx/room/InvalidationTracker$ObservedTableTracker;->triggerStates:[Z

    aget-boolean v15, v15, v4

    if-eq v14, v15, :cond_3

    .line 768
    iget-object v15, v1, Landroidx/room/InvalidationTracker$ObservedTableTracker;->triggerStateChanges:[I

    if-eqz v14, :cond_2

    const/16 v16, 0x1

    goto :goto_2

    :cond_2
    const/16 v16, 0x2

    :goto_2
    aput v16, v15, v4

    goto :goto_3

    .line 775
    .end local v0    # "$i$a$-synchronized-InvalidationTracker$ObservedTableTracker$getTablesToSync$1":I
    .end local v2    # "$this$forEachIndexed$iv":[J
    .end local v3    # "$i$f$forEachIndexed":I
    .end local v4    # "i":I
    .end local v8    # "item$iv":J
    .end local v10    # "index$iv":I
    .end local v11    # "observerCount":J
    .end local v13    # "$i$a$-forEachIndexed-InvalidationTracker$ObservedTableTracker$getTablesToSync$1$1":I
    .end local v14    # "newState":Z
    :catchall_0
    move-exception v0

    goto :goto_4

    .line 770
    .restart local v0    # "$i$a$-synchronized-InvalidationTracker$ObservedTableTracker$getTablesToSync$1":I
    .restart local v2    # "$this$forEachIndexed$iv":[J
    .restart local v3    # "$i$f$forEachIndexed":I
    .restart local v4    # "i":I
    .restart local v8    # "item$iv":J
    .restart local v10    # "index$iv":I
    .restart local v11    # "observerCount":J
    .restart local v13    # "$i$a$-forEachIndexed-InvalidationTracker$ObservedTableTracker$getTablesToSync$1$1":I
    .restart local v14    # "newState":Z
    :cond_3
    iget-object v15, v1, Landroidx/room/InvalidationTracker$ObservedTableTracker;->triggerStateChanges:[I

    aput v6, v15, v4

    .line 772
    :goto_3
    iget-object v15, v1, Landroidx/room/InvalidationTracker$ObservedTableTracker;->triggerStates:[Z

    aput-boolean v14, v15, v4

    .line 773
    nop

    .line 846
    .end local v4    # "i":I
    .end local v11    # "observerCount":J
    .end local v13    # "$i$a$-forEachIndexed-InvalidationTracker$ObservedTableTracker$getTablesToSync$1$1":I
    .end local v14    # "newState":Z
    nop

    .end local v8    # "item$iv":J
    add-int/lit8 v7, v7, 0x1

    move v4, v10

    goto :goto_0

    .line 847
    .end local v10    # "index$iv":I
    .local v4, "index$iv":I
    :cond_4
    nop

    .line 774
    .end local v2    # "$this$forEachIndexed$iv":[J
    .end local v3    # "$i$f$forEachIndexed":I
    .end local v4    # "index$iv":I
    iput-boolean v6, v1, Landroidx/room/InvalidationTracker$ObservedTableTracker;->needsSync:Z

    .line 775
    iget-object v2, v1, Landroidx/room/InvalidationTracker$ObservedTableTracker;->triggerStateChanges:[I

    invoke-virtual {v2}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, [I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .end local v0    # "$i$a$-synchronized-InvalidationTracker$ObservedTableTracker$getTablesToSync$1":I
    monitor-exit p0

    return-object v2

    :goto_4
    monitor-exit p0

    throw v0
.end method

.method public final varargs onAdded([I)Z
    .locals 14
    .param p1, "tableIds"    # [I

    const-string v0, "tableIds"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 709
    const/4 v0, 0x0

    .line 710
    .local v0, "needTriggerSync":Z
    monitor-enter p0

    const/4 v1, 0x0

    .line 711
    .local v1, "$i$a$-synchronized-InvalidationTracker$ObservedTableTracker$onAdded$1":I
    move-object v2, p1

    .local v2, "$this$forEach$iv":[I
    const/4 v3, 0x0

    .line 841
    .local v3, "$i$f$forEach":I
    :try_start_0
    array-length v4, v2

    const/4 v5, 0x0

    :goto_0
    if-ge v5, v4, :cond_1

    aget v6, v2, v5

    .local v6, "element$iv":I
    move v7, v6

    .local v7, "tableId":I
    const/4 v8, 0x0

    .line 712
    .local v8, "$i$a$-forEach-InvalidationTracker$ObservedTableTracker$onAdded$1$1":I
    iget-object v9, p0, Landroidx/room/InvalidationTracker$ObservedTableTracker;->tableObservers:[J

    aget-wide v10, v9, v7

    .line 713
    .local v10, "prevObserverCount":J
    iget-object v9, p0, Landroidx/room/InvalidationTracker$ObservedTableTracker;->tableObservers:[J

    const-wide/16 v12, 0x1

    add-long/2addr v12, v10

    aput-wide v12, v9, v7

    .line 714
    const-wide/16 v12, 0x0

    cmp-long v9, v10, v12

    if-nez v9, :cond_0

    .line 715
    const/4 v9, 0x1

    iput-boolean v9, p0, Landroidx/room/InvalidationTracker$ObservedTableTracker;->needsSync:Z

    .line 716
    const/4 v0, 0x1

    goto :goto_1

    .line 710
    .end local v1    # "$i$a$-synchronized-InvalidationTracker$ObservedTableTracker$onAdded$1":I
    .end local v2    # "$this$forEach$iv":[I
    .end local v3    # "$i$f$forEach":I
    .end local v6    # "element$iv":I
    .end local v7    # "tableId":I
    .end local v8    # "$i$a$-forEach-InvalidationTracker$ObservedTableTracker$onAdded$1$1":I
    .end local v10    # "prevObserverCount":J
    :catchall_0
    move-exception v1

    goto :goto_2

    .line 718
    .restart local v1    # "$i$a$-synchronized-InvalidationTracker$ObservedTableTracker$onAdded$1":I
    .restart local v2    # "$this$forEach$iv":[I
    .restart local v3    # "$i$f$forEach":I
    .restart local v6    # "element$iv":I
    .restart local v7    # "tableId":I
    .restart local v8    # "$i$a$-forEach-InvalidationTracker$ObservedTableTracker$onAdded$1$1":I
    .restart local v10    # "prevObserverCount":J
    :cond_0
    :goto_1
    nop

    .line 841
    .end local v7    # "tableId":I
    .end local v8    # "$i$a$-forEach-InvalidationTracker$ObservedTableTracker$onAdded$1$1":I
    .end local v10    # "prevObserverCount":J
    nop

    .end local v6    # "element$iv":I
    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    .line 842
    :cond_1
    nop

    .line 719
    .end local v2    # "$this$forEach$iv":[I
    .end local v3    # "$i$f$forEach":I
    nop

    .end local v1    # "$i$a$-synchronized-InvalidationTracker$ObservedTableTracker$onAdded$1":I
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 710
    monitor-exit p0

    .line 720
    return v0

    .line 710
    :goto_2
    monitor-exit p0

    throw v1
.end method

.method public final varargs onRemoved([I)Z
    .locals 18
    .param p1, "tableIds"    # [I

    move-object/from16 v1, p0

    const-string v0, "tableIds"

    move-object/from16 v2, p1

    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 727
    const/4 v3, 0x0

    .line 728
    .local v3, "needTriggerSync":Z
    monitor-enter p0

    const/4 v0, 0x0

    .line 729
    .local v0, "$i$a$-synchronized-InvalidationTracker$ObservedTableTracker$onRemoved$1":I
    move-object/from16 v4, p1

    .local v4, "$this$forEach$iv":[I
    const/4 v5, 0x0

    .line 843
    .local v5, "$i$f$forEach":I
    :try_start_0
    array-length v6, v4

    const/4 v7, 0x0

    :goto_0
    if-ge v7, v6, :cond_1

    aget v8, v4, v7

    .local v8, "element$iv":I
    move v9, v8

    .local v9, "tableId":I
    const/4 v10, 0x0

    .line 730
    .local v10, "$i$a$-forEach-InvalidationTracker$ObservedTableTracker$onRemoved$1$1":I
    iget-object v11, v1, Landroidx/room/InvalidationTracker$ObservedTableTracker;->tableObservers:[J

    aget-wide v12, v11, v9

    .line 731
    .local v12, "prevObserverCount":J
    iget-object v11, v1, Landroidx/room/InvalidationTracker$ObservedTableTracker;->tableObservers:[J

    const-wide/16 v14, 0x1

    sub-long v16, v12, v14

    aput-wide v16, v11, v9

    .line 732
    cmp-long v11, v12, v14

    if-nez v11, :cond_0

    .line 733
    const/4 v11, 0x1

    iput-boolean v11, v1, Landroidx/room/InvalidationTracker$ObservedTableTracker;->needsSync:Z

    .line 734
    const/4 v3, 0x1

    goto :goto_1

    .line 728
    .end local v0    # "$i$a$-synchronized-InvalidationTracker$ObservedTableTracker$onRemoved$1":I
    .end local v4    # "$this$forEach$iv":[I
    .end local v5    # "$i$f$forEach":I
    .end local v8    # "element$iv":I
    .end local v9    # "tableId":I
    .end local v10    # "$i$a$-forEach-InvalidationTracker$ObservedTableTracker$onRemoved$1$1":I
    .end local v12    # "prevObserverCount":J
    :catchall_0
    move-exception v0

    goto :goto_2

    .line 736
    .restart local v0    # "$i$a$-synchronized-InvalidationTracker$ObservedTableTracker$onRemoved$1":I
    .restart local v4    # "$this$forEach$iv":[I
    .restart local v5    # "$i$f$forEach":I
    .restart local v8    # "element$iv":I
    .restart local v9    # "tableId":I
    .restart local v10    # "$i$a$-forEach-InvalidationTracker$ObservedTableTracker$onRemoved$1$1":I
    .restart local v12    # "prevObserverCount":J
    :cond_0
    :goto_1
    nop

    .line 843
    .end local v9    # "tableId":I
    .end local v10    # "$i$a$-forEach-InvalidationTracker$ObservedTableTracker$onRemoved$1$1":I
    .end local v12    # "prevObserverCount":J
    nop

    .end local v8    # "element$iv":I
    add-int/lit8 v7, v7, 0x1

    goto :goto_0

    .line 844
    :cond_1
    nop

    .line 737
    .end local v4    # "$this$forEach$iv":[I
    .end local v5    # "$i$f$forEach":I
    nop

    .end local v0    # "$i$a$-synchronized-InvalidationTracker$ObservedTableTracker$onRemoved$1":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 728
    monitor-exit p0

    .line 738
    return v3

    .line 728
    :goto_2
    monitor-exit p0

    throw v0
.end method

.method public final resetTriggerState()V
    .locals 3

    .line 746
    monitor-enter p0

    const/4 v0, 0x0

    .line 747
    .local v0, "$i$a$-synchronized-InvalidationTracker$ObservedTableTracker$resetTriggerState$1":I
    :try_start_0
    iget-object v1, p0, Landroidx/room/InvalidationTracker$ObservedTableTracker;->triggerStates:[Z

    const/4 v2, 0x0

    invoke-static {v1, v2}, Ljava/util/Arrays;->fill([ZZ)V

    .line 748
    const/4 v1, 0x1

    iput-boolean v1, p0, Landroidx/room/InvalidationTracker$ObservedTableTracker;->needsSync:Z

    .line 749
    nop

    .end local v0    # "$i$a$-synchronized-InvalidationTracker$ObservedTableTracker$resetTriggerState$1":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 746
    monitor-exit p0

    .line 750
    return-void

    .line 746
    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method
