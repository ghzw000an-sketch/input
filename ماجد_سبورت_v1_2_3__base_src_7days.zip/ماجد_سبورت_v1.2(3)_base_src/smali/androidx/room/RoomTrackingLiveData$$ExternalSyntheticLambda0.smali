.class public final synthetic Landroidx/room/RoomTrackingLiveData$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Landroidx/room/RoomTrackingLiveData;


# direct methods
.method public synthetic constructor <init>(Landroidx/room/RoomTrackingLiveData;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/room/RoomTrackingLiveData$$ExternalSyntheticLambda0;->f$0:Landroidx/room/RoomTrackingLiveData;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    .line 0
    iget-object v0, p0, Landroidx/room/RoomTrackingLiveData$$ExternalSyntheticLambda0;->f$0:Landroidx/room/RoomTrackingLiveData;

    invoke-static {v0}, Landroidx/room/RoomTrackingLiveData;->$r8$lambda$LoxQhNUdjL-YTm7h4N6PsLKEypI(Landroidx/room/RoomTrackingLiveData;)V

    return-void
.end method
