.class public final Landroidx/room/RoomSQLiteQuery$Companion;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/room/RoomSQLiteQuery;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Companion"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 160
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Landroidx/room/RoomSQLiteQuery$Companion;-><init>()V

    return-void
.end method


# virtual methods
.method public final acquire(Ljava/lang/String;I)Landroidx/room/RoomSQLiteQuery;
    .locals 5
    .param p1, "query"    # Ljava/lang/String;
    .param p2, "argumentCount"    # I

    const-string v0, "query"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 202
    sget-object v0, Landroidx/room/RoomSQLiteQuery;->queryPool:Ljava/util/TreeMap;

    monitor-enter v0

    const/4 v1, 0x0

    .line 203
    .local v1, "$i$a$-synchronized-RoomSQLiteQuery$Companion$acquire$1":I
    :try_start_0
    sget-object v2, Landroidx/room/RoomSQLiteQuery;->queryPool:Ljava/util/TreeMap;

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/TreeMap;->ceilingEntry(Ljava/lang/Object;)Ljava/util/Map$Entry;

    move-result-object v2

    .line 204
    .local v2, "entry":Ljava/util/Map$Entry;
    if-eqz v2, :cond_0

    .line 205
    sget-object v3, Landroidx/room/RoomSQLiteQuery;->queryPool:Ljava/util/TreeMap;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/TreeMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 206
    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/room/RoomSQLiteQuery;

    .line 207
    .local v3, "sqliteQuery":Landroidx/room/RoomSQLiteQuery;
    invoke-virtual {v3, p1, p2}, Landroidx/room/RoomSQLiteQuery;->init(Ljava/lang/String;I)V

    .line 208
    const-string v4, "sqliteQuery"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .end local v1    # "$i$a$-synchronized-RoomSQLiteQuery$Companion$acquire$1":I
    .end local v2    # "entry":Ljava/util/Map$Entry;
    .end local v3    # "sqliteQuery":Landroidx/room/RoomSQLiteQuery;
    monitor-exit v0

    return-object v3

    .line 202
    :catchall_0
    move-exception v1

    goto :goto_0

    .line 210
    .restart local v1    # "$i$a$-synchronized-RoomSQLiteQuery$Companion$acquire$1":I
    .restart local v2    # "entry":Ljava/util/Map$Entry;
    :cond_0
    nop

    .end local v1    # "$i$a$-synchronized-RoomSQLiteQuery$Companion$acquire$1":I
    .end local v2    # "entry":Ljava/util/Map$Entry;
    :try_start_1
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 202
    monitor-exit v0

    .line 211
    new-instance v0, Landroidx/room/RoomSQLiteQuery;

    const/4 v1, 0x0

    invoke-direct {v0, p2, v1}, Landroidx/room/RoomSQLiteQuery;-><init>(ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 212
    .local v0, "sqLiteQuery":Landroidx/room/RoomSQLiteQuery;
    invoke-virtual {v0, p1, p2}, Landroidx/room/RoomSQLiteQuery;->init(Ljava/lang/String;I)V

    .line 213
    return-object v0

    .line 202
    .end local v0    # "sqLiteQuery":Landroidx/room/RoomSQLiteQuery;
    :goto_0
    monitor-exit v0

    throw v1
.end method

.method public final prunePoolLocked$room_runtime_release()V
    .locals 3

    .line 217
    sget-object v0, Landroidx/room/RoomSQLiteQuery;->queryPool:Ljava/util/TreeMap;

    invoke-virtual {v0}, Ljava/util/TreeMap;->size()I

    move-result v0

    const/16 v1, 0xf

    if-le v0, v1, :cond_0

    .line 218
    sget-object v0, Landroidx/room/RoomSQLiteQuery;->queryPool:Ljava/util/TreeMap;

    invoke-virtual {v0}, Ljava/util/TreeMap;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0xa

    .line 219
    .local v0, "toBeRemoved":I
    sget-object v1, Landroidx/room/RoomSQLiteQuery;->queryPool:Ljava/util/TreeMap;

    invoke-virtual {v1}, Ljava/util/TreeMap;->descendingKeySet()Ljava/util/NavigableSet;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/NavigableSet;->iterator()Ljava/util/Iterator;

    move-result-object v1

    const-string v2, "queryPool.descendingKeySet().iterator()"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 220
    .local v1, "iterator":Ljava/util/Iterator;
    :goto_0
    add-int/lit8 v2, v0, -0x1

    .end local v0    # "toBeRemoved":I
    .local v2, "toBeRemoved":I
    if-lez v0, :cond_0

    .line 221
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 222
    invoke-interface {v1}, Ljava/util/Iterator;->remove()V

    move v0, v2

    goto :goto_0

    .line 225
    .end local v1    # "iterator":Ljava/util/Iterator;
    .end local v2    # "toBeRemoved":I
    :cond_0
    return-void
.end method
