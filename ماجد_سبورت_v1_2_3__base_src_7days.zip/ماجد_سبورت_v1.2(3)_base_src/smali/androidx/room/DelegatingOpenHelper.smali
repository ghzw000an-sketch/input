.class public interface abstract Landroidx/room/DelegatingOpenHelper;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract getDelegate()Landroidx/sqlite/db/SupportSQLiteOpenHelper;
.end method
