.class public final Landroidx/room/AutoCloser;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/room/AutoCloser$Companion;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nAutoCloser.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AutoCloser.kt\nandroidx/room/AutoCloser\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,228:1\n1#2:229\n*E\n"
.end annotation


# static fields
.field public static final Companion:Landroidx/room/AutoCloser$Companion;


# instance fields
.field public autoCloseTimeoutInMs:J

.field public final autoCloser:Ljava/lang/Runnable;

.field public delegateDatabase:Landroidx/sqlite/db/SupportSQLiteDatabase;

.field public delegateOpenHelper:Landroidx/sqlite/db/SupportSQLiteOpenHelper;

.field public final executeAutoCloser:Ljava/lang/Runnable;

.field public final executor:Ljava/util/concurrent/Executor;

.field public final handler:Landroid/os/Handler;

.field public lastDecrementRefCountTimeStamp:J

.field public final lock:Ljava/lang/Object;

.field public manuallyClosed:Z

.field public onAutoCloseCallback:Ljava/lang/Runnable;

.field public refCount:I


# direct methods
.method public static synthetic $r8$lambda$2bqU2AY0pACLcZVHaA6vI_33RZM(Landroidx/room/AutoCloser;)V
    .locals 0

    .line 0
    invoke-static {p0}, Landroidx/room/AutoCloser;->executeAutoCloser$lambda$0(Landroidx/room/AutoCloser;)V

    return-void
.end method

.method public static synthetic $r8$lambda$G2ZrHH8pFF9fWfG-_cMVTmkERIo(Landroidx/room/AutoCloser;)V
    .locals 0

    .line 0
    invoke-static {p0}, Landroidx/room/AutoCloser;->autoCloser$lambda$3(Landroidx/room/AutoCloser;)V

    return-void
.end method

.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Landroidx/room/AutoCloser$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Landroidx/room/AutoCloser$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Landroidx/room/AutoCloser;->Companion:Landroidx/room/AutoCloser$Companion;

    return-void
.end method

.method public constructor <init>(JLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/Executor;)V
    .locals 2
    .param p1, "autoCloseTimeoutAmount"    # J
    .param p3, "autoCloseTimeUnit"    # Ljava/util/concurrent/TimeUnit;
    .param p4, "autoCloseExecutor"    # Ljava/util/concurrent/Executor;

    const-string v0, "autoCloseTimeUnit"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "autoCloseExecutor"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 40
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 46
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Landroidx/room/AutoCloser;->handler:Landroid/os/Handler;

    .line 50
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Landroidx/room/AutoCloser;->lock:Ljava/lang/Object;

    .line 52
    invoke-virtual {p3, p1, p2}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    move-result-wide v0

    iput-wide v0, p0, Landroidx/room/AutoCloser;->autoCloseTimeoutInMs:J

    .line 54
    iput-object p4, p0, Landroidx/room/AutoCloser;->executor:Ljava/util/concurrent/Executor;

    .line 60
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    iput-wide v0, p0, Landroidx/room/AutoCloser;->lastDecrementRefCountTimeStamp:J

    .line 68
    new-instance v0, Landroidx/room/AutoCloser$$ExternalSyntheticLambda0;

    invoke-direct {v0, p0}, Landroidx/room/AutoCloser$$ExternalSyntheticLambda0;-><init>(Landroidx/room/AutoCloser;)V

    iput-object v0, p0, Landroidx/room/AutoCloser;->executeAutoCloser:Ljava/lang/Runnable;

    .line 70
    new-instance v0, Landroidx/room/AutoCloser$$ExternalSyntheticLambda1;

    invoke-direct {v0, p0}, Landroidx/room/AutoCloser$$ExternalSyntheticLambda1;-><init>(Landroidx/room/AutoCloser;)V

    iput-object v0, p0, Landroidx/room/AutoCloser;->autoCloser:Ljava/lang/Runnable;

    .line 40
    return-void
.end method

.method public static final autoCloser$lambda$3(Landroidx/room/AutoCloser;)V
    .locals 6
    .param p0, "this$0"    # Landroidx/room/AutoCloser;

    const-string v0, "this$0"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 71
    iget-object v0, p0, Landroidx/room/AutoCloser;->lock:Ljava/lang/Object;

    monitor-enter v0

    const/4 v1, 0x0

    .line 72
    .local v1, "$i$a$-synchronized-AutoCloser$autoCloser$1$1":I
    :try_start_0
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v2

    iget-wide v4, p0, Landroidx/room/AutoCloser;->lastDecrementRefCountTimeStamp:J

    sub-long/2addr v2, v4

    .line 73
    iget-wide v4, p0, Landroidx/room/AutoCloser;->autoCloseTimeoutInMs:J
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    cmp-long v2, v2, v4

    if-gez v2, :cond_0

    .line 78
    nop

    .end local v1    # "$i$a$-synchronized-AutoCloser$autoCloser$1$1":I
    monitor-exit v0

    return-void

    .line 80
    .restart local v1    # "$i$a$-synchronized-AutoCloser$autoCloser$1$1":I
    :cond_0
    :try_start_1
    iget v2, p0, Landroidx/room/AutoCloser;->refCount:I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    if-eqz v2, :cond_1

    .line 84
    nop

    .end local v1    # "$i$a$-synchronized-AutoCloser$autoCloser$1$1":I
    monitor-exit v0

    return-void

    .line 86
    .restart local v1    # "$i$a$-synchronized-AutoCloser$autoCloser$1$1":I
    :cond_1
    :try_start_2
    iget-object v2, p0, Landroidx/room/AutoCloser;->onAutoCloseCallback:Ljava/lang/Runnable;

    const/4 v3, 0x0

    if-eqz v2, :cond_2

    invoke-interface {v2}, Ljava/lang/Runnable;->run()V

    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    goto :goto_0

    .line 71
    .end local v1    # "$i$a$-synchronized-AutoCloser$autoCloser$1$1":I
    :catchall_0
    move-exception v1

    goto :goto_1

    .line 86
    .restart local v1    # "$i$a$-synchronized-AutoCloser$autoCloser$1$1":I
    :cond_2
    move-object v2, v3

    :goto_0
    if-eqz v2, :cond_5

    .line 92
    iget-object v2, p0, Landroidx/room/AutoCloser;->delegateDatabase:Landroidx/sqlite/db/SupportSQLiteDatabase;

    if-eqz v2, :cond_4

    .local v2, "it":Landroidx/sqlite/db/SupportSQLiteDatabase;
    const/4 v4, 0x0

    .line 93
    .local v4, "$i$a$-let-AutoCloser$autoCloser$1$1$1":I
    invoke-interface {v2}, Landroidx/sqlite/db/SupportSQLiteDatabase;->isOpen()Z

    move-result v5

    if-eqz v5, :cond_3

    .line 94
    invoke-interface {v2}, Ljava/io/Closeable;->close()V

    .line 96
    :cond_3
    nop

    .line 92
    .end local v2    # "it":Landroidx/sqlite/db/SupportSQLiteDatabase;
    .end local v4    # "$i$a$-let-AutoCloser$autoCloser$1$1$1":I
    :cond_4
    nop

    .line 97
    iput-object v3, p0, Landroidx/room/AutoCloser;->delegateDatabase:Landroidx/sqlite/db/SupportSQLiteDatabase;

    .line 98
    nop

    .end local v1    # "$i$a$-synchronized-AutoCloser$autoCloser$1$1":I
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 71
    monitor-exit v0

    .line 99
    return-void

    .line 86
    .restart local v1    # "$i$a$-synchronized-AutoCloser$autoCloser$1$1":I
    :cond_5
    :try_start_3
    new-instance v2, Ljava/lang/IllegalStateException;

    .line 87
    const-string v3, "onAutoCloseCallback is null but it should have been set before use. Please file a bug against Room at: https://issuetracker.google.com/issues/new?component=413107&template=1096568"

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .end local p0    # "this$0":Landroidx/room/AutoCloser;
    throw v2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 71
    .end local v1    # "$i$a$-synchronized-AutoCloser$autoCloser$1$1":I
    .restart local p0    # "this$0":Landroidx/room/AutoCloser;
    :goto_1
    monitor-exit v0

    throw v1
.end method

.method public static final executeAutoCloser$lambda$0(Landroidx/room/AutoCloser;)V
    .locals 2
    .param p0, "this$0"    # Landroidx/room/AutoCloser;

    const-string v0, "this$0"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 68
    iget-object v0, p0, Landroidx/room/AutoCloser;->executor:Ljava/util/concurrent/Executor;

    iget-object v1, p0, Landroidx/room/AutoCloser;->autoCloser:Ljava/lang/Runnable;

    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method


# virtual methods
.method public final closeDatabaseIfOpen()V
    .locals 3

    .line 185
    iget-object v0, p0, Landroidx/room/AutoCloser;->lock:Ljava/lang/Object;

    monitor-enter v0

    const/4 v1, 0x0

    .line 186
    .local v1, "$i$a$-synchronized-AutoCloser$closeDatabaseIfOpen$1":I
    const/4 v2, 0x1

    :try_start_0
    iput-boolean v2, p0, Landroidx/room/AutoCloser;->manuallyClosed:Z

    .line 187
    iget-object v2, p0, Landroidx/room/AutoCloser;->delegateDatabase:Landroidx/sqlite/db/SupportSQLiteDatabase;

    if-eqz v2, :cond_0

    invoke-interface {v2}, Ljava/io/Closeable;->close()V

    goto :goto_0

    .line 185
    .end local v1    # "$i$a$-synchronized-AutoCloser$closeDatabaseIfOpen$1":I
    :catchall_0
    move-exception v1

    goto :goto_1

    .line 188
    .restart local v1    # "$i$a$-synchronized-AutoCloser$closeDatabaseIfOpen$1":I
    :cond_0
    :goto_0
    const/4 v2, 0x0

    iput-object v2, p0, Landroidx/room/AutoCloser;->delegateDatabase:Landroidx/sqlite/db/SupportSQLiteDatabase;

    .line 189
    nop

    .end local v1    # "$i$a$-synchronized-AutoCloser$closeDatabaseIfOpen$1":I
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 185
    monitor-exit v0

    .line 190
    return-void

    .line 185
    :goto_1
    monitor-exit v0

    throw v1
.end method

.method public final decrementCountAndScheduleClose()V
    .locals 6

    .line 160
    iget-object v0, p0, Landroidx/room/AutoCloser;->lock:Ljava/lang/Object;

    monitor-enter v0

    const/4 v1, 0x0

    .line 161
    .local v1, "$i$a$-synchronized-AutoCloser$decrementCountAndScheduleClose$1":I
    :try_start_0
    iget v2, p0, Landroidx/room/AutoCloser;->refCount:I

    if-lez v2, :cond_0

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    :goto_0
    if-eqz v2, :cond_3

    .line 165
    iget v2, p0, Landroidx/room/AutoCloser;->refCount:I

    add-int/lit8 v2, v2, -0x1

    iput v2, p0, Landroidx/room/AutoCloser;->refCount:I

    .line 168
    iget v2, p0, Landroidx/room/AutoCloser;->refCount:I

    if-nez v2, :cond_2

    .line 169
    iget-object v2, p0, Landroidx/room/AutoCloser;->delegateDatabase:Landroidx/sqlite/db/SupportSQLiteDatabase;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez v2, :cond_1

    .line 171
    nop

    .end local v1    # "$i$a$-synchronized-AutoCloser$decrementCountAndScheduleClose$1":I
    monitor-exit v0

    return-void

    .line 173
    .restart local v1    # "$i$a$-synchronized-AutoCloser$decrementCountAndScheduleClose$1":I
    :cond_1
    :try_start_1
    iget-object v2, p0, Landroidx/room/AutoCloser;->handler:Landroid/os/Handler;

    iget-object v3, p0, Landroidx/room/AutoCloser;->executeAutoCloser:Ljava/lang/Runnable;

    iget-wide v4, p0, Landroidx/room/AutoCloser;->autoCloseTimeoutInMs:J

    invoke-virtual {v2, v3, v4, v5}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_1

    .line 160
    .end local v1    # "$i$a$-synchronized-AutoCloser$decrementCountAndScheduleClose$1":I
    :catchall_0
    move-exception v1

    goto :goto_2

    .line 175
    .restart local v1    # "$i$a$-synchronized-AutoCloser$decrementCountAndScheduleClose$1":I
    :cond_2
    :goto_1
    nop

    .end local v1    # "$i$a$-synchronized-AutoCloser$decrementCountAndScheduleClose$1":I
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 160
    monitor-exit v0

    .line 176
    return-void

    .line 161
    .restart local v1    # "$i$a$-synchronized-AutoCloser$decrementCountAndScheduleClose$1":I
    :cond_3
    const/4 v2, 0x0

    .line 162
    .local v2, "$i$a$-check-AutoCloser$decrementCountAndScheduleClose$1$1":I
    :try_start_2
    const-string v3, "ref count is 0 or lower but we\'re supposed to decrement"

    .line 161
    .end local v2    # "$i$a$-check-AutoCloser$decrementCountAndScheduleClose$1$1":I
    new-instance v2, Ljava/lang/IllegalStateException;

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 160
    .end local v1    # "$i$a$-synchronized-AutoCloser$decrementCountAndScheduleClose$1":I
    :goto_2
    monitor-exit v0

    throw v1
.end method

.method public final executeRefCountingFunction(Lkotlin/jvm/functions/Function1;)Ljava/lang/Object;
    .locals 1
    .param p1, "block"    # Lkotlin/jvm/functions/Function1;

    const-string v0, "block"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 119
    nop

    .line 120
    :try_start_0
    invoke-virtual {p0}, Landroidx/room/AutoCloser;->incrementCountAndEnsureDbIsOpen()Landroidx/sqlite/db/SupportSQLiteDatabase;

    move-result-object v0

    invoke-interface {p1, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 122
    invoke-virtual {p0}, Landroidx/room/AutoCloser;->decrementCountAndScheduleClose()V

    .line 123
    return-object v0

    .line 122
    :catchall_0
    move-exception v0

    invoke-virtual {p0}, Landroidx/room/AutoCloser;->decrementCountAndScheduleClose()V

    throw v0
.end method

.method public final getDelegateDatabase$room_runtime_release()Landroidx/sqlite/db/SupportSQLiteDatabase;
    .locals 1

    .line 64
    iget-object v0, p0, Landroidx/room/AutoCloser;->delegateDatabase:Landroidx/sqlite/db/SupportSQLiteDatabase;

    return-object v0
.end method

.method public final getDelegateOpenHelper()Landroidx/sqlite/db/SupportSQLiteOpenHelper;
    .locals 1

    .line 45
    iget-object v0, p0, Landroidx/room/AutoCloser;->delegateOpenHelper:Landroidx/sqlite/db/SupportSQLiteOpenHelper;

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    const-string v0, "delegateOpenHelper"

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    const/4 v0, 0x0

    return-object v0
.end method

.method public final incrementCountAndEnsureDbIsOpen()Landroidx/sqlite/db/SupportSQLiteDatabase;
    .locals 5

    .line 139
    iget-object v0, p0, Landroidx/room/AutoCloser;->lock:Ljava/lang/Object;

    monitor-enter v0

    const/4 v1, 0x0

    .line 142
    .local v1, "$i$a$-synchronized-AutoCloser$incrementCountAndEnsureDbIsOpen$1":I
    :try_start_0
    iget-object v2, p0, Landroidx/room/AutoCloser;->handler:Landroid/os/Handler;

    iget-object v3, p0, Landroidx/room/AutoCloser;->executeAutoCloser:Ljava/lang/Runnable;

    invoke-virtual {v2, v3}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 143
    iget v2, p0, Landroidx/room/AutoCloser;->refCount:I

    add-int/lit8 v2, v2, 0x1

    iput v2, p0, Landroidx/room/AutoCloser;->refCount:I

    .line 144
    iget-boolean v2, p0, Landroidx/room/AutoCloser;->manuallyClosed:Z

    if-nez v2, :cond_2

    .line 145
    iget-object v2, p0, Landroidx/room/AutoCloser;->delegateDatabase:Landroidx/sqlite/db/SupportSQLiteDatabase;

    if-eqz v2, :cond_1

    .local v2, "it":Landroidx/sqlite/db/SupportSQLiteDatabase;
    const/4 v3, 0x0

    .line 146
    .local v3, "$i$a$-let-AutoCloser$incrementCountAndEnsureDbIsOpen$1$2":I
    invoke-interface {v2}, Landroidx/sqlite/db/SupportSQLiteDatabase;->isOpen()Z

    move-result v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v4, :cond_0

    .line 147
    nop

    .end local v1    # "$i$a$-synchronized-AutoCloser$incrementCountAndEnsureDbIsOpen$1":I
    .end local v2    # "it":Landroidx/sqlite/db/SupportSQLiteDatabase;
    .end local v3    # "$i$a$-let-AutoCloser$incrementCountAndEnsureDbIsOpen$1$2":I
    monitor-exit v0

    return-object v2

    .line 149
    .restart local v1    # "$i$a$-synchronized-AutoCloser$incrementCountAndEnsureDbIsOpen$1":I
    .restart local v2    # "it":Landroidx/sqlite/db/SupportSQLiteDatabase;
    .restart local v3    # "$i$a$-let-AutoCloser$incrementCountAndEnsureDbIsOpen$1$2":I
    :cond_0
    nop

    .line 145
    .end local v2    # "it":Landroidx/sqlite/db/SupportSQLiteDatabase;
    .end local v3    # "$i$a$-let-AutoCloser$incrementCountAndEnsureDbIsOpen$1$2":I
    :cond_1
    goto :goto_0

    .line 150
    .end local v1    # "$i$a$-synchronized-AutoCloser$incrementCountAndEnsureDbIsOpen$1":I
    :catchall_0
    move-exception v1

    goto :goto_1

    .restart local v1    # "$i$a$-synchronized-AutoCloser$incrementCountAndEnsureDbIsOpen$1":I
    :goto_0
    :try_start_1
    invoke-virtual {p0}, Landroidx/room/AutoCloser;->getDelegateOpenHelper()Landroidx/sqlite/db/SupportSQLiteOpenHelper;

    move-result-object v2

    invoke-interface {v2}, Landroidx/sqlite/db/SupportSQLiteOpenHelper;->getWritableDatabase()Landroidx/sqlite/db/SupportSQLiteDatabase;

    move-result-object v2

    move-object v3, v2

    .line 229
    .local v3, "it":Landroidx/sqlite/db/SupportSQLiteDatabase;
    const/4 v4, 0x0

    .line 150
    .local v4, "$i$a$-also-AutoCloser$incrementCountAndEnsureDbIsOpen$1$3":I
    iput-object v3, p0, Landroidx/room/AutoCloser;->delegateDatabase:Landroidx/sqlite/db/SupportSQLiteDatabase;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .end local v1    # "$i$a$-synchronized-AutoCloser$incrementCountAndEnsureDbIsOpen$1":I
    .end local v3    # "it":Landroidx/sqlite/db/SupportSQLiteDatabase;
    .end local v4    # "$i$a$-also-AutoCloser$incrementCountAndEnsureDbIsOpen$1$3":I
    monitor-exit v0

    return-object v2

    .line 229
    .restart local v1    # "$i$a$-synchronized-AutoCloser$incrementCountAndEnsureDbIsOpen$1":I
    :cond_2
    const/4 v2, 0x0

    .line 144
    .local v2, "$i$a$-check-AutoCloser$incrementCountAndEnsureDbIsOpen$1$1":I
    :try_start_2
    const-string v3, "Attempting to open already closed database."

    .end local v2    # "$i$a$-check-AutoCloser$incrementCountAndEnsureDbIsOpen$1$1":I
    new-instance v2, Ljava/lang/IllegalStateException;

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 150
    .end local v1    # "$i$a$-synchronized-AutoCloser$incrementCountAndEnsureDbIsOpen$1":I
    :goto_1
    monitor-exit v0

    throw v1
.end method

.method public final init(Landroidx/sqlite/db/SupportSQLiteOpenHelper;)V
    .locals 1
    .param p1, "delegateOpenHelper"    # Landroidx/sqlite/db/SupportSQLiteOpenHelper;

    const-string v0, "delegateOpenHelper"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 109
    invoke-virtual {p0, p1}, Landroidx/room/AutoCloser;->setDelegateOpenHelper(Landroidx/sqlite/db/SupportSQLiteOpenHelper;)V

    .line 110
    return-void
.end method

.method public final setAutoCloseCallback(Ljava/lang/Runnable;)V
    .locals 1
    .param p1, "onAutoClose"    # Ljava/lang/Runnable;

    const-string v0, "onAutoClose"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 220
    iput-object p1, p0, Landroidx/room/AutoCloser;->onAutoCloseCallback:Ljava/lang/Runnable;

    .line 221
    return-void
.end method

.method public final setDelegateOpenHelper(Landroidx/sqlite/db/SupportSQLiteOpenHelper;)V
    .locals 1
    .param p1, "<set-?>"    # Landroidx/sqlite/db/SupportSQLiteOpenHelper;

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 45
    iput-object p1, p0, Landroidx/room/AutoCloser;->delegateOpenHelper:Landroidx/sqlite/db/SupportSQLiteOpenHelper;

    return-void
.end method
