.class public Landroidx/room/RoomDatabase$Builder;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/room/RoomDatabase;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nRoomDatabase.kt\nKotlin\n*S Kotlin\n*F\n+ 1 RoomDatabase.kt\nandroidx/room/RoomDatabase$Builder\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,1548:1\n1#2:1549\n*E\n"
.end annotation


# instance fields
.field public allowDestructiveMigrationOnDowngrade:Z

.field public allowMainThreadQueries:Z

.field public autoCloseTimeUnit:Ljava/util/concurrent/TimeUnit;

.field public autoCloseTimeout:J

.field public autoMigrationSpecs:Ljava/util/List;

.field public final callbacks:Ljava/util/List;

.field public final context:Landroid/content/Context;

.field public copyFromAssetPath:Ljava/lang/String;

.field public copyFromFile:Ljava/io/File;

.field public copyFromInputStream:Ljava/util/concurrent/Callable;

.field public factory:Landroidx/sqlite/db/SupportSQLiteOpenHelper$Factory;

.field public journalMode:Landroidx/room/RoomDatabase$JournalMode;

.field public final klass:Ljava/lang/Class;

.field public final migrationContainer:Landroidx/room/RoomDatabase$MigrationContainer;

.field public migrationStartAndEndVersions:Ljava/util/Set;

.field public migrationsNotRequiredFrom:Ljava/util/Set;

.field public multiInstanceInvalidationIntent:Landroid/content/Intent;

.field public final name:Ljava/lang/String;

.field public queryExecutor:Ljava/util/concurrent/Executor;

.field public requireMigration:Z

.field public transactionExecutor:Ljava/util/concurrent/Executor;

.field public final typeConverters:Ljava/util/List;


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/Class;Ljava/lang/String;)V
    .locals 2
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "klass"    # Ljava/lang/Class;
    .param p3, "name"    # Ljava/lang/String;

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "klass"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 690
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 692
    iput-object p1, p0, Landroidx/room/RoomDatabase$Builder;->context:Landroid/content/Context;

    .line 693
    iput-object p2, p0, Landroidx/room/RoomDatabase$Builder;->klass:Ljava/lang/Class;

    .line 694
    iput-object p3, p0, Landroidx/room/RoomDatabase$Builder;->name:Ljava/lang/String;

    .line 696
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/room/RoomDatabase$Builder;->callbacks:Ljava/util/List;

    .line 700
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/room/RoomDatabase$Builder;->typeConverters:Ljava/util/List;

    .line 701
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/room/RoomDatabase$Builder;->autoMigrationSpecs:Ljava/util/List;

    .line 708
    sget-object v0, Landroidx/room/RoomDatabase$JournalMode;->AUTOMATIC:Landroidx/room/RoomDatabase$JournalMode;

    iput-object v0, p0, Landroidx/room/RoomDatabase$Builder;->journalMode:Landroidx/room/RoomDatabase$JournalMode;

    .line 710
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/room/RoomDatabase$Builder;->requireMigration:Z

    .line 712
    const-wide/16 v0, -0x1

    iput-wide v0, p0, Landroidx/room/RoomDatabase$Builder;->autoCloseTimeout:J

    .line 718
    new-instance v0, Landroidx/room/RoomDatabase$MigrationContainer;

    invoke-direct {v0}, Landroidx/room/RoomDatabase$MigrationContainer;-><init>()V

    iput-object v0, p0, Landroidx/room/RoomDatabase$Builder;->migrationContainer:Landroidx/room/RoomDatabase$MigrationContainer;

    .line 719
    new-instance v0, Ljava/util/LinkedHashSet;

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    iput-object v0, p0, Landroidx/room/RoomDatabase$Builder;->migrationsNotRequiredFrom:Ljava/util/Set;

    .line 691
    return-void
.end method


# virtual methods
.method public addCallback(Landroidx/room/RoomDatabase$Callback;)Landroidx/room/RoomDatabase$Builder;
    .locals 3
    .param p1, "callback"    # Landroidx/room/RoomDatabase$Callback;

    const-string v0, "callback"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1161
    move-object v0, p0

    .local v0, "$this$addCallback_u24lambda_u2418":Landroidx/room/RoomDatabase$Builder;
    const/4 v1, 0x0

    .line 1162
    .local v1, "$i$a$-apply-RoomDatabase$Builder$addCallback$1":I
    iget-object v2, v0, Landroidx/room/RoomDatabase$Builder;->callbacks:Ljava/util/List;

    invoke-interface {v2, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 1163
    nop

    .line 1161
    .end local v0    # "$this$addCallback_u24lambda_u2418":Landroidx/room/RoomDatabase$Builder;
    .end local v1    # "$i$a$-apply-RoomDatabase$Builder$addCallback$1":I
    nop

    .line 1163
    return-object p0
.end method

.method public varargs addMigrations([Landroidx/room/migration/Migration;)Landroidx/room/RoomDatabase$Builder;
    .locals 7
    .param p1, "migrations"    # [Landroidx/room/migration/Migration;

    const-string v0, "migrations"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 938
    move-object v0, p0

    .local v0, "$this$addMigrations_u24lambda_u247":Landroidx/room/RoomDatabase$Builder;
    const/4 v1, 0x0

    .line 939
    .local v1, "$i$a$-apply-RoomDatabase$Builder$addMigrations$1":I
    iget-object v2, v0, Landroidx/room/RoomDatabase$Builder;->migrationStartAndEndVersions:Ljava/util/Set;

    if-nez v2, :cond_0

    .line 940
    new-instance v2, Ljava/util/HashSet;

    invoke-direct {v2}, Ljava/util/HashSet;-><init>()V

    iput-object v2, v0, Landroidx/room/RoomDatabase$Builder;->migrationStartAndEndVersions:Ljava/util/Set;

    .line 942
    :cond_0
    array-length v2, p1

    const/4 v3, 0x0

    :goto_0
    if-ge v3, v2, :cond_1

    aget-object v4, p1, v3

    .line 943
    .local v4, "migration":Landroidx/room/migration/Migration;
    iget-object v5, v0, Landroidx/room/RoomDatabase$Builder;->migrationStartAndEndVersions:Ljava/util/Set;

    invoke-static {v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    iget v6, v4, Landroidx/room/migration/Migration;->startVersion:I

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-interface {v5, v6}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 944
    iget-object v5, v0, Landroidx/room/RoomDatabase$Builder;->migrationStartAndEndVersions:Ljava/util/Set;

    invoke-static {v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    iget v6, v4, Landroidx/room/migration/Migration;->endVersion:I

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-interface {v5, v6}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 942
    .end local v4    # "migration":Landroidx/room/migration/Migration;
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 946
    :cond_1
    iget-object v2, v0, Landroidx/room/RoomDatabase$Builder;->migrationContainer:Landroidx/room/RoomDatabase$MigrationContainer;

    array-length v3, p1

    invoke-static {p1, v3}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v3

    check-cast v3, [Landroidx/room/migration/Migration;

    invoke-virtual {v2, v3}, Landroidx/room/RoomDatabase$MigrationContainer;->addMigrations([Landroidx/room/migration/Migration;)V

    .line 947
    nop

    .line 938
    .end local v0    # "$this$addMigrations_u24lambda_u247":Landroidx/room/RoomDatabase$Builder;
    .end local v1    # "$i$a$-apply-RoomDatabase$Builder$addMigrations$1":I
    nop

    .line 947
    return-object p0
.end method

.method public allowMainThreadQueries()Landroidx/room/RoomDatabase$Builder;
    .locals 3

    .line 973
    move-object v0, p0

    .local v0, "$this$allowMainThreadQueries_u24lambda_u249":Landroidx/room/RoomDatabase$Builder;
    const/4 v1, 0x0

    .line 974
    .local v1, "$i$a$-apply-RoomDatabase$Builder$allowMainThreadQueries$1":I
    const/4 v2, 0x1

    iput-boolean v2, v0, Landroidx/room/RoomDatabase$Builder;->allowMainThreadQueries:Z

    .line 975
    nop

    .line 973
    .end local v0    # "$this$allowMainThreadQueries_u24lambda_u249":Landroidx/room/RoomDatabase$Builder;
    .end local v1    # "$i$a$-apply-RoomDatabase$Builder$allowMainThreadQueries$1":I
    nop

    .line 975
    return-object p0
.end method

.method public build()Landroidx/room/RoomDatabase;
    .locals 25

    .line 1249
    move-object/from16 v0, p0

    iget-object v1, v0, Landroidx/room/RoomDatabase$Builder;->queryExecutor:Ljava/util/concurrent/Executor;

    if-nez v1, :cond_0

    iget-object v1, v0, Landroidx/room/RoomDatabase$Builder;->transactionExecutor:Ljava/util/concurrent/Executor;

    if-nez v1, :cond_0

    .line 1250
    invoke-static {}, Landroidx/arch/core/executor/ArchTaskExecutor;->getIOThreadExecutor()Ljava/util/concurrent/Executor;

    move-result-object v1

    iput-object v1, v0, Landroidx/room/RoomDatabase$Builder;->transactionExecutor:Ljava/util/concurrent/Executor;

    .line 1251
    iget-object v1, v0, Landroidx/room/RoomDatabase$Builder;->transactionExecutor:Ljava/util/concurrent/Executor;

    iput-object v1, v0, Landroidx/room/RoomDatabase$Builder;->queryExecutor:Ljava/util/concurrent/Executor;

    goto :goto_0

    .line 1252
    :cond_0
    iget-object v1, v0, Landroidx/room/RoomDatabase$Builder;->queryExecutor:Ljava/util/concurrent/Executor;

    if-eqz v1, :cond_1

    iget-object v1, v0, Landroidx/room/RoomDatabase$Builder;->transactionExecutor:Ljava/util/concurrent/Executor;

    if-nez v1, :cond_1

    .line 1253
    iget-object v1, v0, Landroidx/room/RoomDatabase$Builder;->queryExecutor:Ljava/util/concurrent/Executor;

    iput-object v1, v0, Landroidx/room/RoomDatabase$Builder;->transactionExecutor:Ljava/util/concurrent/Executor;

    goto :goto_0

    .line 1254
    :cond_1
    iget-object v1, v0, Landroidx/room/RoomDatabase$Builder;->queryExecutor:Ljava/util/concurrent/Executor;

    if-nez v1, :cond_2

    .line 1255
    iget-object v1, v0, Landroidx/room/RoomDatabase$Builder;->transactionExecutor:Ljava/util/concurrent/Executor;

    iput-object v1, v0, Landroidx/room/RoomDatabase$Builder;->queryExecutor:Ljava/util/concurrent/Executor;

    .line 1257
    :cond_2
    :goto_0
    iget-object v1, v0, Landroidx/room/RoomDatabase$Builder;->migrationStartAndEndVersions:Ljava/util/Set;

    if-eqz v1, :cond_4

    .line 1258
    iget-object v1, v0, Landroidx/room/RoomDatabase$Builder;->migrationStartAndEndVersions:Ljava/util/Set;

    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    nop

    if-eqz v2, :cond_4

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    .line 1259
    .local v2, "version":I
    iget-object v3, v0, Landroidx/room/RoomDatabase$Builder;->migrationsNotRequiredFrom:Ljava/util/Set;

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v3, v4}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_3

    goto :goto_1

    :cond_3
    const/4 v1, 0x0

    .line 1260
    .local v1, "$i$a$-require-RoomDatabase$Builder$build$1":I
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Inconsistency detected. A Migration was supplied to addMigration(Migration... migrations) that has a start or end version equal to a start version supplied to fallbackToDestructiveMigrationFrom(int... startVersions). Start version: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1264
    nop

    .line 1260
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 1259
    .end local v1    # "$i$a$-require-RoomDatabase$Builder$build$1":I
    new-instance v3, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v3, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v3

    .line 1273
    .end local v2    # "version":I
    :cond_4
    nop

    .line 1269
    iget-object v1, v0, Landroidx/room/RoomDatabase$Builder;->factory:Landroidx/sqlite/db/SupportSQLiteOpenHelper$Factory;

    if-nez v1, :cond_5

    .line 1270
    new-instance v1, Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelperFactory;

    invoke-direct {v1}, Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelperFactory;-><init>()V

    goto :goto_2

    .line 1272
    :cond_5
    iget-object v1, v0, Landroidx/room/RoomDatabase$Builder;->factory:Landroidx/sqlite/db/SupportSQLiteOpenHelper$Factory;

    .line 1269
    :goto_2
    nop

    .line 1273
    const-string v2, "Required value was null."

    if-eqz v1, :cond_12

    .line 1269
    nop

    .line 1273
    nop

    .local v1, "it":Landroidx/sqlite/db/SupportSQLiteOpenHelper$Factory;
    const/4 v3, 0x0

    .line 1274
    .local v3, "$i$a$-let-RoomDatabase$Builder$build$factory$1":I
    iget-wide v4, v0, Landroidx/room/RoomDatabase$Builder;->autoCloseTimeout:J

    const-wide/16 v6, 0x0

    cmp-long v4, v4, v6

    if-lez v4, :cond_9

    .line 1275
    iget-object v4, v0, Landroidx/room/RoomDatabase$Builder;->name:Ljava/lang/String;

    if-eqz v4, :cond_8

    .line 1278
    new-instance v4, Landroidx/room/AutoCloser;

    .line 1279
    iget-wide v5, v0, Landroidx/room/RoomDatabase$Builder;->autoCloseTimeout:J

    .line 1280
    iget-object v7, v0, Landroidx/room/RoomDatabase$Builder;->autoCloseTimeUnit:Ljava/util/concurrent/TimeUnit;

    if-eqz v7, :cond_7

    .line 1281
    iget-object v8, v0, Landroidx/room/RoomDatabase$Builder;->queryExecutor:Ljava/util/concurrent/Executor;

    if-eqz v8, :cond_6

    .line 1278
    invoke-direct {v4, v5, v6, v7, v8}, Landroidx/room/AutoCloser;-><init>(JLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/Executor;)V

    .line 1283
    .local v4, "autoCloser":Landroidx/room/AutoCloser;
    new-instance v5, Landroidx/room/AutoClosingRoomOpenHelperFactory;

    invoke-direct {v5, v1, v4}, Landroidx/room/AutoClosingRoomOpenHelperFactory;-><init>(Landroidx/sqlite/db/SupportSQLiteOpenHelper$Factory;Landroidx/room/AutoCloser;)V

    .end local v4    # "autoCloser":Landroidx/room/AutoCloser;
    goto :goto_3

    .line 1281
    :cond_6
    new-instance v4, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v4, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v4

    .line 1280
    :cond_7
    new-instance v4, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v4, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v4

    .line 1275
    :cond_8
    const/4 v2, 0x0

    .line 1276
    .local v2, "$i$a$-requireNotNull-RoomDatabase$Builder$build$factory$1$1":I
    nop

    .line 1275
    .end local v2    # "$i$a$-requireNotNull-RoomDatabase$Builder$build$factory$1$1":I
    new-instance v2, Ljava/lang/IllegalArgumentException;

    const-string v4, "Cannot create auto-closing database for an in-memory database."

    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v2, v4}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v2

    .line 1285
    :cond_9
    move-object v5, v1

    .line 1274
    :goto_3
    nop

    .line 1273
    .end local v1    # "it":Landroidx/sqlite/db/SupportSQLiteOpenHelper$Factory;
    .end local v3    # "$i$a$-let-RoomDatabase$Builder$build$factory$1":I
    nop

    .line 1287
    nop

    .line 1273
    nop

    .line 1287
    nop

    .local v5, "it":Landroidx/sqlite/db/SupportSQLiteOpenHelper$Factory;
    const/4 v1, 0x0

    .line 1288
    .local v1, "$i$a$-let-RoomDatabase$Builder$build$factory$2":I
    nop

    .line 1289
    iget-object v3, v0, Landroidx/room/RoomDatabase$Builder;->copyFromAssetPath:Ljava/lang/String;

    if-nez v3, :cond_b

    .line 1290
    iget-object v3, v0, Landroidx/room/RoomDatabase$Builder;->copyFromFile:Ljava/io/File;

    if-nez v3, :cond_b

    .line 1291
    iget-object v3, v0, Landroidx/room/RoomDatabase$Builder;->copyFromInputStream:Ljava/util/concurrent/Callable;

    if-eqz v3, :cond_a

    goto :goto_4

    .line 1316
    :cond_a
    move-object v4, v5

    goto :goto_8

    .line 1293
    :cond_b
    :goto_4
    iget-object v3, v0, Landroidx/room/RoomDatabase$Builder;->name:Ljava/lang/String;

    if-eqz v3, :cond_11

    .line 1297
    iget-object v3, v0, Landroidx/room/RoomDatabase$Builder;->copyFromAssetPath:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v6, 0x1

    if-nez v3, :cond_c

    move v3, v4

    goto :goto_5

    :cond_c
    move v3, v6

    .line 1298
    .local v3, "copyFromAssetPathConfig":I
    :goto_5
    iget-object v7, v0, Landroidx/room/RoomDatabase$Builder;->copyFromFile:Ljava/io/File;

    if-nez v7, :cond_d

    move v7, v4

    goto :goto_6

    :cond_d
    move v7, v6

    .line 1299
    .local v7, "copyFromFileConfig":I
    :goto_6
    iget-object v8, v0, Landroidx/room/RoomDatabase$Builder;->copyFromInputStream:Ljava/util/concurrent/Callable;

    if-nez v8, :cond_e

    move v8, v4

    goto :goto_7

    :cond_e
    move v8, v6

    .line 1300
    .local v8, "copyFromInputStreamConfig":I
    :goto_7
    add-int v9, v3, v7

    .line 1301
    nop

    .line 1300
    add-int/2addr v9, v8

    .line 1303
    .local v9, "copyConfigurations":I
    if-ne v9, v6, :cond_f

    move v4, v6

    :cond_f
    if-eqz v4, :cond_10

    .line 1309
    new-instance v4, Landroidx/room/SQLiteCopyOpenHelperFactory;

    .line 1310
    iget-object v6, v0, Landroidx/room/RoomDatabase$Builder;->copyFromAssetPath:Ljava/lang/String;

    .line 1311
    iget-object v10, v0, Landroidx/room/RoomDatabase$Builder;->copyFromFile:Ljava/io/File;

    .line 1312
    iget-object v11, v0, Landroidx/room/RoomDatabase$Builder;->copyFromInputStream:Ljava/util/concurrent/Callable;

    .line 1313
    nop

    .line 1309
    invoke-direct {v4, v6, v10, v11, v5}, Landroidx/room/SQLiteCopyOpenHelperFactory;-><init>(Ljava/lang/String;Ljava/io/File;Ljava/util/concurrent/Callable;Landroidx/sqlite/db/SupportSQLiteOpenHelper$Factory;)V

    .line 1288
    .end local v3    # "copyFromAssetPathConfig":I
    .end local v7    # "copyFromFileConfig":I
    .end local v8    # "copyFromInputStreamConfig":I
    .end local v9    # "copyConfigurations":I
    :goto_8
    nop

    .line 1287
    .end local v1    # "$i$a$-let-RoomDatabase$Builder$build$factory$2":I
    .end local v5    # "it":Landroidx/sqlite/db/SupportSQLiteOpenHelper$Factory;
    goto :goto_9

    .line 1303
    .restart local v1    # "$i$a$-let-RoomDatabase$Builder$build$factory$2":I
    .restart local v3    # "copyFromAssetPathConfig":I
    .restart local v5    # "it":Landroidx/sqlite/db/SupportSQLiteOpenHelper$Factory;
    .restart local v7    # "copyFromFileConfig":I
    .restart local v8    # "copyFromInputStreamConfig":I
    .restart local v9    # "copyConfigurations":I
    :cond_10
    const/4 v2, 0x0

    .line 1304
    .local v2, "$i$a$-require-RoomDatabase$Builder$build$factory$2$2":I
    nop

    .line 1303
    .end local v2    # "$i$a$-require-RoomDatabase$Builder$build$factory$2$2":I
    new-instance v2, Ljava/lang/IllegalArgumentException;

    const-string v4, "More than one of createFromAsset(), createFromInputStream(), and createFromFile() were called on this Builder, but the database can only be created using one of the three configurations."

    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v2, v4}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v2

    .line 1293
    .end local v3    # "copyFromAssetPathConfig":I
    .end local v7    # "copyFromFileConfig":I
    .end local v8    # "copyFromInputStreamConfig":I
    .end local v9    # "copyConfigurations":I
    :cond_11
    const/4 v2, 0x0

    .line 1294
    .local v2, "$i$a$-requireNotNull-RoomDatabase$Builder$build$factory$2$1":I
    nop

    .line 1293
    .end local v2    # "$i$a$-requireNotNull-RoomDatabase$Builder$build$factory$2$1":I
    new-instance v2, Ljava/lang/IllegalArgumentException;

    const-string v3, "Cannot create from asset or file for an in-memory database."

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v2

    .line 1273
    .end local v1    # "$i$a$-let-RoomDatabase$Builder$build$factory$2":I
    .end local v5    # "it":Landroidx/sqlite/db/SupportSQLiteOpenHelper$Factory;
    :cond_12
    const/4 v4, 0x0

    .line 1318
    :goto_9
    nop

    .local v4, "it":Landroidx/sqlite/db/SupportSQLiteOpenHelper$Factory;
    const/4 v1, 0x0

    .line 1319
    .local v1, "$i$a$-let-RoomDatabase$Builder$build$factory$3":I
    if-eqz v4, :cond_15

    .line 1320
    nop

    .line 1327
    nop

    .line 1320
    nop

    .line 1318
    .end local v1    # "$i$a$-let-RoomDatabase$Builder$build$factory$3":I
    .end local v4    # "it":Landroidx/sqlite/db/SupportSQLiteOpenHelper$Factory;
    nop

    .line 1269
    move-object v8, v4

    .line 1330
    .local v8, "factory":Landroidx/sqlite/db/SupportSQLiteOpenHelper$Factory;
    new-instance v5, Landroidx/room/DatabaseConfiguration;

    .line 1331
    iget-object v6, v0, Landroidx/room/RoomDatabase$Builder;->context:Landroid/content/Context;

    .line 1332
    iget-object v7, v0, Landroidx/room/RoomDatabase$Builder;->name:Ljava/lang/String;

    .line 1333
    nop

    .line 1334
    iget-object v9, v0, Landroidx/room/RoomDatabase$Builder;->migrationContainer:Landroidx/room/RoomDatabase$MigrationContainer;

    .line 1335
    iget-object v10, v0, Landroidx/room/RoomDatabase$Builder;->callbacks:Ljava/util/List;

    .line 1336
    iget-boolean v11, v0, Landroidx/room/RoomDatabase$Builder;->allowMainThreadQueries:Z

    .line 1337
    iget-object v1, v0, Landroidx/room/RoomDatabase$Builder;->journalMode:Landroidx/room/RoomDatabase$JournalMode;

    iget-object v3, v0, Landroidx/room/RoomDatabase$Builder;->context:Landroid/content/Context;

    invoke-virtual {v1, v3}, Landroidx/room/RoomDatabase$JournalMode;->resolve$room_runtime_release(Landroid/content/Context;)Landroidx/room/RoomDatabase$JournalMode;

    move-result-object v12

    .line 1338
    iget-object v13, v0, Landroidx/room/RoomDatabase$Builder;->queryExecutor:Ljava/util/concurrent/Executor;

    if-eqz v13, :cond_14

    .line 1339
    iget-object v14, v0, Landroidx/room/RoomDatabase$Builder;->transactionExecutor:Ljava/util/concurrent/Executor;

    if-eqz v14, :cond_13

    .line 1340
    iget-object v15, v0, Landroidx/room/RoomDatabase$Builder;->multiInstanceInvalidationIntent:Landroid/content/Intent;

    .line 1341
    iget-boolean v1, v0, Landroidx/room/RoomDatabase$Builder;->requireMigration:Z

    .line 1342
    iget-boolean v2, v0, Landroidx/room/RoomDatabase$Builder;->allowDestructiveMigrationOnDowngrade:Z

    .line 1343
    iget-object v3, v0, Landroidx/room/RoomDatabase$Builder;->migrationsNotRequiredFrom:Ljava/util/Set;

    .line 1344
    iget-object v4, v0, Landroidx/room/RoomDatabase$Builder;->copyFromAssetPath:Ljava/lang/String;

    .line 1345
    move/from16 v16, v1

    iget-object v1, v0, Landroidx/room/RoomDatabase$Builder;->copyFromFile:Ljava/io/File;

    .line 1346
    move-object/from16 v20, v1

    iget-object v1, v0, Landroidx/room/RoomDatabase$Builder;->copyFromInputStream:Ljava/util/concurrent/Callable;

    .line 1347
    nop

    .line 1348
    move-object/from16 v21, v1

    iget-object v1, v0, Landroidx/room/RoomDatabase$Builder;->typeConverters:Ljava/util/List;

    .line 1349
    move-object/from16 v23, v1

    iget-object v1, v0, Landroidx/room/RoomDatabase$Builder;->autoMigrationSpecs:Ljava/util/List;

    .line 1330
    const/16 v22, 0x0

    move-object/from16 v24, v1

    move/from16 v17, v2

    move-object/from16 v18, v3

    move-object/from16 v19, v4

    invoke-direct/range {v5 .. v24}, Landroidx/room/DatabaseConfiguration;-><init>(Landroid/content/Context;Ljava/lang/String;Landroidx/sqlite/db/SupportSQLiteOpenHelper$Factory;Landroidx/room/RoomDatabase$MigrationContainer;Ljava/util/List;ZLandroidx/room/RoomDatabase$JournalMode;Ljava/util/concurrent/Executor;Ljava/util/concurrent/Executor;Landroid/content/Intent;ZZLjava/util/Set;Ljava/lang/String;Ljava/io/File;Ljava/util/concurrent/Callable;Landroidx/room/RoomDatabase$PrepackagedDatabaseCallback;Ljava/util/List;Ljava/util/List;)V

    .line 1351
    .local v5, "configuration":Landroidx/room/DatabaseConfiguration;
    iget-object v1, v0, Landroidx/room/RoomDatabase$Builder;->klass:Ljava/lang/Class;

    const-string v2, "_Impl"

    invoke-static {v1, v2}, Landroidx/room/Room;->getGeneratedImplementation(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/room/RoomDatabase;

    .line 1352
    .local v1, "db":Landroidx/room/RoomDatabase;
    invoke-virtual {v1, v5}, Landroidx/room/RoomDatabase;->init(Landroidx/room/DatabaseConfiguration;)V

    .line 1353
    return-object v1

    .line 1339
    .end local v1    # "db":Landroidx/room/RoomDatabase;
    .end local v5    # "configuration":Landroidx/room/DatabaseConfiguration;
    :cond_13
    new-instance v1, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 1338
    :cond_14
    new-instance v1, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 1319
    .end local v8    # "factory":Landroidx/sqlite/db/SupportSQLiteOpenHelper$Factory;
    .local v1, "$i$a$-let-RoomDatabase$Builder$build$factory$3":I
    .restart local v4    # "it":Landroidx/sqlite/db/SupportSQLiteOpenHelper$Factory;
    :cond_15
    new-instance v3, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v3, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v3
.end method

.method public fallbackToDestructiveMigration()Landroidx/room/RoomDatabase$Builder;
    .locals 3

    .line 1110
    move-object v0, p0

    .local v0, "$this$fallbackToDestructiveMigration_u24lambda_u2415":Landroidx/room/RoomDatabase$Builder;
    const/4 v1, 0x0

    .line 1111
    .local v1, "$i$a$-apply-RoomDatabase$Builder$fallbackToDestructiveMigration$1":I
    const/4 v2, 0x0

    iput-boolean v2, v0, Landroidx/room/RoomDatabase$Builder;->requireMigration:Z

    .line 1112
    const/4 v2, 0x1

    iput-boolean v2, v0, Landroidx/room/RoomDatabase$Builder;->allowDestructiveMigrationOnDowngrade:Z

    .line 1113
    nop

    .line 1110
    .end local v0    # "$this$fallbackToDestructiveMigration_u24lambda_u2415":Landroidx/room/RoomDatabase$Builder;
    .end local v1    # "$i$a$-apply-RoomDatabase$Builder$fallbackToDestructiveMigration$1":I
    nop

    .line 1113
    return-object p0
.end method

.method public openHelperFactory(Landroidx/sqlite/db/SupportSQLiteOpenHelper$Factory;)Landroidx/room/RoomDatabase$Builder;
    .locals 2
    .param p1, "factory"    # Landroidx/sqlite/db/SupportSQLiteOpenHelper$Factory;

    .line 915
    move-object v0, p0

    .local v0, "$this$openHelperFactory_u24lambda_u246":Landroidx/room/RoomDatabase$Builder;
    const/4 v1, 0x0

    .line 916
    .local v1, "$i$a$-apply-RoomDatabase$Builder$openHelperFactory$1":I
    iput-object p1, v0, Landroidx/room/RoomDatabase$Builder;->factory:Landroidx/sqlite/db/SupportSQLiteOpenHelper$Factory;

    .line 917
    nop

    .line 915
    .end local v0    # "$this$openHelperFactory_u24lambda_u246":Landroidx/room/RoomDatabase$Builder;
    .end local v1    # "$i$a$-apply-RoomDatabase$Builder$openHelperFactory$1":I
    nop

    .line 917
    return-object p0
.end method

.method public setQueryExecutor(Ljava/util/concurrent/Executor;)Landroidx/room/RoomDatabase$Builder;
    .locals 2
    .param p1, "executor"    # Ljava/util/concurrent/Executor;

    const-string v0, "executor"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1013
    move-object v0, p0

    .local v0, "$this$setQueryExecutor_u24lambda_u2411":Landroidx/room/RoomDatabase$Builder;
    const/4 v1, 0x0

    .line 1014
    .local v1, "$i$a$-apply-RoomDatabase$Builder$setQueryExecutor$1":I
    iput-object p1, v0, Landroidx/room/RoomDatabase$Builder;->queryExecutor:Ljava/util/concurrent/Executor;

    .line 1015
    nop

    .line 1013
    .end local v0    # "$this$setQueryExecutor_u24lambda_u2411":Landroidx/room/RoomDatabase$Builder;
    .end local v1    # "$i$a$-apply-RoomDatabase$Builder$setQueryExecutor$1":I
    nop

    .line 1015
    return-object p0
.end method
