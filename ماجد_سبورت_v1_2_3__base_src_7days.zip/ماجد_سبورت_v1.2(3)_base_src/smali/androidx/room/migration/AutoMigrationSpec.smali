.class public interface abstract Landroidx/room/migration/AutoMigrationSpec;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract onPostMigrate(Landroidx/sqlite/db/SupportSQLiteDatabase;)V
.end method
