(() => {
  if (window.__fbPostFilterLoaded) return;
  window.__fbPostFilterLoaded = true;

  let currentFilter = null;
  let observer = null;
  let debounceTimer = null;
  let lastResult = { shown: 0, hidden: 0, unknown: 0, total: 0, mode: "none" };
  let scrollTimer = null;
  let scrollIdle = 0;
  let lastCount = -1;
  let stopReason = "";

  const textCache = new WeakMap();
  const tsCache = new WeakMap();

  /* ---------- تطبيع النصوص ---------- */
  const AR_DIGITS = "٠١٢٣٤٥٦٧٨٩";
  function normalize(str) {
    return String(str || "")
      .replace(/[٠-٩]/g, (d) => AR_DIGITS.indexOf(d))
      .replace(/[\u064B-\u065F\u0670\u0640]/g, "")
      .replace(/[أإآ]/g, "ا")
      .replace(/ى/g, "ي")
      .replace(/ة/g, "ه")
      .replace(/[\u200B-\u200F\u202A-\u202E\u2066-\u2069]/g, "")
      .replace(/\s+/g, " ")
      .toLowerCase()
      .trim();
  }

  /* ---------- أسماء الأشهر ---------- */
  const MONTH_NAMES = {
    1: ["يناير", "كانون الثاني", "جانفي", "january", "jan"],
    2: ["فبراير", "شباط", "فيفري", "february", "feb"],
    3: ["مارس", "اذار", "march", "mar"],
    4: ["ابريل", "نيسان", "افريل", "april", "apr"],
    5: ["مايو", "ايار", "ماي", "may"],
    6: ["يونيو", "يونيه", "حزيران", "جوان", "june", "jun"],
    7: ["يوليو", "يوليه", "تموز", "جويليه", "july", "jul"],
    8: ["اغسطس", "اب", "اوت", "august", "aug"],
    9: ["سبتمبر", "ايلول", "september", "sep", "sept"],
    10: ["اكتوبر", "تشرين الاول", "october", "oct"],
    11: ["نوفمبر", "تشرين الثاني", "november", "nov"],
    12: ["ديسمبر", "كانون الاول", "december", "dec"]
  };
  const MONTH_LIST = [];
  for (const [num, names] of Object.entries(MONTH_NAMES)) {
    names.forEach((n) => MONTH_LIST.push({ name: normalize(n), month: Number(num) }));
  }
  MONTH_LIST.sort((a, b) => b.name.length - a.name.length);

  function findMonth(t) {
    for (const m of MONTH_LIST) {
      const re = new RegExp("(^|[^\\p{L}])" + m.name + "($|[^\\p{L}])", "u");
      if (re.test(t)) return m.month;
    }
    return null;
  }

  const WEEKDAYS = [
    ["sunday", "الاحد"], ["monday", "الاثنين"], ["tuesday", "الثلاثاء"],
    ["wednesday", "الاربعاء"], ["thursday", "الخميس"], ["friday", "الجمعه"], ["saturday", "السبت"]
  ];

  const UNITS = {
    sec: ["s", "sec", "secs", "second", "seconds", "ث", "ثانيه", "ثواني", "ثوان"],
    min: ["m", "min", "mins", "minute", "minutes", "د", "دقيقه", "دقايق", "دقائق", "دقيقتين"],
    hour: ["h", "hr", "hrs", "hour", "hours", "س", "ساعه", "ساعات", "ساعتين"],
    day: ["d", "day", "days", "ي", "يوم", "ايام"],
    week: ["w", "wk", "wks", "week", "weeks", "ا", "اسبوع", "اسابيع"],
    month: ["mo", "mos", "month", "months", "شهر", "اشهر", "شهور"],
    year: ["y", "yr", "yrs", "year", "years", "سنه", "سنوات", "سنين", "عام", "اعوام"]
  };
  const UNIT_LOOKUP = {};
  for (const [k, arr] of Object.entries(UNITS)) arr.forEach((u) => (UNIT_LOOKUP[normalize(u)] = k));

  function subtract(now, n, unit) {
    const d = new Date(now.getTime());
    switch (unit) {
      case "sec": d.setSeconds(d.getSeconds() - n); break;
      case "min": d.setMinutes(d.getMinutes() - n); break;
      case "hour": d.setHours(d.getHours() - n); break;
      case "day": d.setDate(d.getDate() - n); break;
      case "week": d.setDate(d.getDate() - 7 * n); break;
      case "month": d.setMonth(d.getMonth() - n); break;
      case "year": d.setFullYear(d.getFullYear() - n); break;
    }
    return d;
  }

  function parseDateText(raw) {
    const t = normalize(raw);
    if (!t || t.length > 60) return null;
    const now = new Date();

    const yearMatch = t.match(/(?:^|\D)((?:19|20)\d{2})(?!\d)/);
    const month = findMonth(t);
    if (month) {
      let year = yearMatch ? Number(yearMatch[1]) : now.getFullYear();
      if (!yearMatch && year === now.getFullYear() && month > now.getMonth() + 1) year -= 1;
      return { year, month };
    }
    if (yearMatch) return { year: Number(yearMatch[1]), month: null };

    if (/(^|[^\p{L}])(الان|just now|now|اليوم|today)($|[^\p{L}])/u.test(t)) {
      return { year: now.getFullYear(), month: now.getMonth() + 1 };
    }
    if (/(^|[^\p{L}])(امس|yesterday)($|[^\p{L}])/u.test(t)) {
      const d = subtract(now, 1, "day");
      return { year: d.getFullYear(), month: d.getMonth() + 1 };
    }

    const rel = t.match(/(\d+)\s*([a-z\u0600-\u06FF]+)/);
    if (rel) {
      const unit = UNIT_LOOKUP[rel[2]];
      if (unit) {
        const d = subtract(now, parseInt(rel[1], 10), unit);
        return { year: d.getFullYear(), month: d.getMonth() + 1 };
      }
    }

    for (let i = 0; i < WEEKDAYS.length; i++) {
      const names = WEEKDAYS[i].map(normalize);
      if (names.some((n) => new RegExp("(^|[^\\p{L}])" + n + "($|[^\\p{L}])", "u").test(t))) {
        const diff = (now.getDay() - i + 7) % 7 || 7;
        const d = subtract(now, diff, "day");
        return { year: d.getFullYear(), month: d.getMonth() + 1 };
      }
    }
    return null;
  }

  // نص قصير يشبه الطابع الزمني (يشترط رقماً أو كلمة مثل أمس/الآن)
  function looksLikeTimestamp(raw) {
    const t = normalize(raw);
    if (!t || t.length > 40) return null;
    const hasDigit = /\d/.test(t);
    const special = /(^|[^\p{L}])(الان|just now|now|اليوم|today|امس|yesterday)($|[^\p{L}])/u.test(t);
    if (!hasDigit && !special) return null;
    return parseDateText(raw);
  }

  /* ---------- طريقة 1: المنشورات ذات role=article (نسخة سطح المكتب) ---------- */
  const TIME_SELECTORS = [
    "abbr[data-utime]",
    "a[href*='/posts/']", "a[href*='/permalink']", "a[href*='story_fbid']", "a[href*='pfbid']",
    "a[href*='/videos/']", "a[href*='/photo']", "a[href*='/reel/']",
    "a[href*='/watch/']", "a[href*='fbid=']", "abbr", "time"
  ].join(",");

  function getArticleDate(post) {
    if (post.__fbfDate) return post.__fbfDate;
    let result = null;
    for (const el of post.querySelectorAll(TIME_SELECTORS)) {
      const href = el.getAttribute("href") || "";
      if (/comment_id/.test(href)) continue;
      const utime = el.getAttribute("data-utime");
      if (utime) {
        const d = new Date(parseInt(utime, 10) * 1000);
        result = { year: d.getFullYear(), month: d.getMonth() + 1 };
        break;
      }
      const texts = [el.getAttribute("aria-label"), el.innerText, el.getAttribute("title")];
      for (const txt of texts) {
        if (!txt) continue;
        const parsed = looksLikeTimestamp(txt) || (txt.length < 40 ? parseDateText(txt) : null);
        if (parsed) { result = parsed; break; }
      }
      if (result) break;
    }
    if (result) post.__fbfDate = result;
    return result;
  }

  function articleItems() {
    return Array.from(document.querySelectorAll("div[role='article']"))
      .filter((el) => !el.parentElement || !el.parentElement.closest("div[role='article']"))
      .map((post) => ({ post, date: getArticleDate(post) }));
  }

  /* ---------- طريقة 2: كشف المنشورات من الطوابع الزمنية (نسخة الجوال) ---------- */
  function scanTimestamps(selector, needDigitInTextContent) {
    const list = [];
    for (const el of document.querySelectorAll(selector)) {
      let cached = tsCache.get(el);
      if (cached === undefined) {
        cached = null;
        const tc = el.textContent || "";
        const href = el.getAttribute("href") || "";
        const okPre = tc.length > 0 && tc.length <= 120 && !/comment_id/.test(href) &&
          (!needDigitInTextContent || /[0-9٠-٩]/.test(tc));
        if (okPre) {
          const label = el.getAttribute("aria-label");
          const txt = label && label.length <= 60 ? label : el.innerText;
          cached = looksLikeTimestamp(txt || "") || null;
        }
        // لا نخزن النتيجة السلبية للروابط لأن نصها قد يتأخر في الظهور
        if (cached || needDigitInTextContent) tsCache.set(el, cached);
      }
      if (cached) list.push({ el, date: cached });
    }
    // نبقي العنصر الأعلى فقط عند التداخل
    const set = new Set(list.map((x) => x.el));
    return list.filter((x) => {
      let p = x.el.parentElement;
      while (p) { if (set.has(p)) return false; p = p.parentElement; }
      return true;
    });
  }

  const STOP_SEL = "[role='banner'],[role='navigation'],[role='tablist'],[role='main'],[role='feed']";

  function climb(el, allTs) {
    let node = el;
    for (let i = 0; i < 40; i++) {
      const p = node.parentElement;
      if (!p || p === document.body || p === document.documentElement) break;
      if (p.matches(STOP_SEL) || p.querySelector(STOP_SEL)) break;
      let n = 0;
      for (const t of allTs) { if (p.contains(t)) { n++; if (n > 1) break; } }
      if (n > 1) break;
      node = p;
    }
    return node;
  }

  function heuristicItems() {
    let list = scanTimestamps("a[href], abbr, time", false);
    if (!list.length) list = scanTimestamps("span", true);
    if (!list.length) return [];
    const allTs = list.map((x) => x.el);
    const seen = new Set();
    const items = [];
    const maxH = (window.innerHeight || 800) * 6;
    for (const { el, date } of list) {
      const root = climb(el, allTs);
      if (seen.has(root)) continue;
      seen.add(root);
      if (!root.__fbfHiddenByUs && root.getBoundingClientRect().height > maxH) continue; // حاوية ضخمة: ليست منشوراً
      items.push({ post: root, date });
    }
    return items;
  }

  function collectItems(needDate) {
    let items = articleItems();
    let mode = "article";
    if (items.length === 0 || (needDate && items.every((i) => !i.date))) {
      const h = heuristicItems();
      if (h.length) { items = h; mode = "timestamps"; }
    }
    return { items, mode };
  }

  /* ---------- مطابقة الكلمات ---------- */
  function keywordList(kw) {
    return normalize(kw)
      .split(/[\s,،;؛]+/)
      .filter(Boolean)
      .map((w) => (w.length > 3 && w.startsWith("ال") ? w.slice(2) : w));
  }

  function postText(post) {
    let t = textCache.get(post);
    if (t === undefined) {
      const raw = post.__fbfHiddenByUs ? post.textContent : post.innerText;
      t = normalize(raw);
      textCache.set(post, t);
    }
    return t;
  }

  function matchesKeyword(post, f) {
    const words = keywordList(f.keyword);
    if (!words.length) return true;
    const text = postText(post);
    return f.matchAny ? words.some((w) => text.includes(w)) : words.every((w) => text.includes(w));
  }

  function matchesDate(date, f) {
    if (!f.year && !f.month) return true;
    if (!date) return null;
    if (f.year && date.year !== f.year) return false;
    if (f.month) {
      if (date.month === null) return false;
      if (date.month !== f.month) return false;
    }
    return true;
  }

  function setHidden(post, hidden) {
    if (hidden) {
      if (!post.__fbfOriginalDisplay) {
        post.__fbfOriginalDisplay = {
          value: post.style.getPropertyValue("display"),
          priority: post.style.getPropertyPriority("display")
        };
      }
      post.style.setProperty("display", "none", "important");
      post.__fbfHiddenByUs = true;
      post.setAttribute("data-fbf-hidden", "1");
    } else {
      const original = post.__fbfOriginalDisplay;
      if (original && original.value) {
        post.style.setProperty("display", original.value, original.priority || "");
      } else {
        post.style.removeProperty("display");
      }
      delete post.__fbfOriginalDisplay;
      post.__fbfHiddenByUs = false;
      post.removeAttribute("data-fbf-hidden");
    }
  }

  function setHighlight(post, on) {
    if (on) {
      post.style.outline = "3px solid #1877f2";
      post.style.outlineOffset = "2px";
    } else {
      post.style.outline = "";
      post.style.outlineOffset = "";
    }
  }

  function applyFilter() {
    if (!currentFilter) return lastResult;
    const f = currentFilter;
    const needDate = !!(f.year || f.month);
    const { items, mode } = collectItems(needDate);
    const current = new Set(items.map((i) => i.post));

    // إظهار أي عنصر أخفيناه سابقاً ولم يعد ضمن القائمة (تغيّر أسلوب الكشف)
    document.querySelectorAll("[data-fbf-hidden]").forEach((el) => {
      if (!current.has(el)) { setHidden(el, false); setHighlight(el, false); }
    });

    let shown = 0, hidden = 0, unknown = 0;
    for (const { post, date } of items) {
      const dateResult = matchesDate(date, f);
      const kwOk = matchesKeyword(post, f);
      let keep;
      if (dateResult === null) {
        unknown++;
        keep = f.keepUnknown && kwOk;
      } else {
        keep = dateResult && kwOk;
      }
      setHidden(post, !keep);
      setHighlight(post, keep && (f.keyword || needDate));
      keep ? shown++ : hidden++;
    }
    lastResult = { shown, hidden, unknown, total: items.length, mode };
    return lastResult;
  }

  // إبطال ذاكرة النص/التاريخ للمنشور الذي تغيّر؛ فيسبوك يحدّث نصوص
  // المنشورات والطوابع الزمنية ديناميكياً دون إعادة إنشاء بطاقة المنشور.
  function invalidateChangedContent(mutations) {
    for (const mutation of mutations) {
      let node = mutation.target && mutation.target.nodeType === 1
        ? mutation.target : mutation.target && mutation.target.parentElement;
      const article = node && node.closest ? node.closest("div[role='article']") : null;
      if (article) {
        textCache.delete(article);
        delete article.__fbfDate;
      }
      if (mutation.addedNodes) {
        for (const added of mutation.addedNodes) {
          if (added.nodeType !== 1) continue;
          const nested = added.matches && added.matches("div[role='article']")
            ? added : (added.querySelector && added.querySelector("div[role='article']"));
          if (nested) {
            textCache.delete(nested);
            delete nested.__fbfDate;
          }
        }
      }
    }
  }

  function startObserver() {
    if (observer || !document.body) return;
    observer = new MutationObserver((mutations) => {
      invalidateChangedContent(mutations);
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(applyFilter, 350);
    });
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      characterData: true,
      attributes: true,
      attributeFilter: ["aria-label", "title", "data-utime", "href"]
    });
  }

  function resetFilter() {
    stopAutoScroll("");
    currentFilter = null;
    if (observer) { observer.disconnect(); observer = null; }
    clearTimeout(debounceTimer);
    document.querySelectorAll("[data-fbf-hidden]").forEach((el) => { setHidden(el, false); setHighlight(el, false); });
    document.querySelectorAll("div[role='article']").forEach((el) => setHighlight(el, false));
    lastResult = { shown: 0, hidden: 0, unknown: 0, total: 0, mode: "none" };
  }

  /* ---------- التمرير التلقائي لتحميل منشورات أقدم ---------- */
  function isOlderThanTarget(d, f) {
    if (!f.year) return false;
    if (d.year < f.year) return true;
    if (d.year === f.year && f.month && d.month !== null && d.month < f.month) return true;
    return false;
  }

  function stopAutoScroll(reason) {
    if (scrollTimer) { clearInterval(scrollTimer); scrollTimer = null; }
    stopReason = reason || "";
  }

  function startAutoScroll() {
    stopAutoScroll("");
    scrollIdle = 0;
    lastCount = -1;
    scrollTimer = setInterval(() => {
      const needDate = !!(currentFilter && (currentFilter.year || currentFilter.month));
      const { items } = collectItems(needDate);
      if (items.length === lastCount) scrollIdle++; else { scrollIdle = 0; lastCount = items.length; }

      if (needDate) {
        let older = 0;
        for (const it of items) if (it.date && isOlderThanTarget(it.date, currentFilter)) older++;
        if (older >= 3) { stopAutoScroll("وصلنا لمنشورات أقدم من التاريخ المطلوب"); return; }
      }
      if (scrollIdle >= 8) { stopAutoScroll("لم تعد تظهر منشورات جديدة"); return; }

      window.scrollTo(0, document.documentElement.scrollHeight);
      const visible = items.filter((i) => !i.post.__fbfHiddenByUs);
      const last = visible.length ? visible[visible.length - 1].post : null;
      if (last && last.scrollIntoView) last.scrollIntoView({ block: "end" });
    }, 1500);
  }

  window.__fbf = {
    apply(filter) {
      currentFilter = filter;
      const res = applyFilter();
      startObserver();
      return JSON.stringify(res);
    },
    reset() { resetFilter(); return "ok"; },
    autoscroll(on) {
      if (on) startAutoScroll(); else stopAutoScroll("تم الإيقاف");
      return JSON.stringify({ scrolling: !!scrollTimer });
    },
    stats() {
      return JSON.stringify(Object.assign({}, lastResult, { scrolling: !!scrollTimer, reason: stopReason }));
    },
    _parse: parseDateText
  };
})();
