package com.example.fbfilter;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class MainActivity extends Activity {

    private static final String DESKTOP_UA =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) "
                    + "Chrome/124.0.0.0 Safari/537.36";

    private static final String[] MONTHS = {
            "يناير (كانون الثاني)", "فبراير (شباط)", "مارس (آذار)", "أبريل (نيسان)",
            "مايو (أيار)", "يونيو (حزيران)", "يوليو (تموز)", "أغسطس (آب)",
            "سبتمبر (أيلول)", "أكتوبر (تشرين الأول)", "نوفمبر (تشرين الثاني)", "ديسمبر (كانون الأول)"
    };

    private WebView web;
    private LinearLayout panel;
    private EditText keyword;
    private Spinner yearSp;
    private Spinner monthSp;
    private CheckBox keepUnknown;
    private TextView status;
    private final List<String> years = new ArrayList<>();

    private String script = "";
    private String currentFilterJson = null;
    private boolean desktopMode = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        script = readAsset("filter.js");
        buildUi();
        setupWebView();
        web.loadUrl("https://www.facebook.com/");
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private Button makeButton(String text, int bg, int fg) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setBackgroundColor(bg);
        b.setTextColor(fg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(3), 0, dp(3), 0);
        b.setLayoutParams(lp);
        return b;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackgroundColor(Color.parseColor("#f0f2f5"));
        root.setFitsSystemWindows(true);

        // ----- الشريط العلوي -----
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setBackgroundColor(Color.parseColor("#1877f2"));
        bar.setPadding(dp(6), dp(6), dp(6), dp(6));

        Button filterBtn = makeButton("🔎 فلتر", Color.WHITE, Color.parseColor("#1877f2"));
        Button homeBtn = makeButton("🏠", Color.WHITE, Color.BLACK);
        Button reloadBtn = makeButton("↻", Color.WHITE, Color.BLACK);
        Button modeBtn = makeButton("🖥/📱", Color.WHITE, Color.BLACK);
        bar.addView(filterBtn);
        bar.addView(homeBtn);
        bar.addView(reloadBtn);
        bar.addView(modeBtn);

        // ----- لوحة الفلترة -----
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(Color.WHITE);
        panel.setPadding(dp(12), dp(10), dp(12), dp(10));
        panel.setVisibility(View.GONE);

        keyword = new EditText(this);
        keyword.setHint("الكلمة المفتاحية (اختياري)");
        keyword.setSingleLine(true);
        panel.addView(keyword, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        years.add("كل السنوات");
        int nowYear = Calendar.getInstance().get(Calendar.YEAR);
        for (int y = nowYear; y >= 2004; y--) years.add(String.valueOf(y));
        List<String> months = new ArrayList<>();
        months.add("كل الأشهر");
        for (int i = 0; i < MONTHS.length; i++) months.add((i + 1) + " - " + MONTHS[i]);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        yearSp = new Spinner(this);
        yearSp.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, years));
        monthSp = new Spinner(this);
        monthSp.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, months));
        row.addView(yearSp, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(monthSp, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        panel.addView(row);

        keepUnknown = new CheckBox(this);
        keepUnknown.setText("إبقاء المنشورات التي لم يُعرف تاريخها");
        panel.addView(keepUnknown);

        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        Button applyBtn = makeButton("بحث / فلترة", Color.parseColor("#1877f2"), Color.WHITE);
        Button resetBtn = makeButton("إلغاء الفلترة", Color.parseColor("#e4e6eb"), Color.BLACK);
        btnRow.addView(applyBtn);
        btnRow.addView(resetBtn);
        panel.addView(btnRow);

        status = new TextView(this);
        status.setPadding(0, dp(8), 0, 0);
        panel.addView(status);

        // ----- المتصفح -----
        web = new WebView(this);

        root.addView(bar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(panel, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(web, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        filterBtn.setOnClickListener(v ->
                panel.setVisibility(panel.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE));
        homeBtn.setOnClickListener(v -> web.loadUrl("https://www.facebook.com/"));
        reloadBtn.setOnClickListener(v -> web.reload());
        modeBtn.setOnClickListener(v -> {
            desktopMode = !desktopMode;
            applyViewMode();
            web.reload();
            status.setText(desktopMode
                    ? "وضع سطح المكتب (مناسب للفلترة)"
                    : "وضع الجوال (قد لا تعمل الفلترة بدقة)");
        });
        applyBtn.setOnClickListener(v -> applyFilter());
        resetBtn.setOnClickListener(v -> resetFilter());
    }

    private void applyViewMode() {
        WebSettings s = web.getSettings();
        if (desktopMode) {
            s.setUserAgentString(DESKTOP_UA);
            s.setUseWideViewPort(true);
            s.setLoadWithOverviewMode(true);
        } else {
            s.setUserAgentString(null);
            s.setUseWideViewPort(false);
            s.setLoadWithOverviewMode(false);
        }
    }

    private void setupWebView() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        applyViewMode();

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, true);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String scheme = request.getUrl().getScheme();
                // تجاهل الروابط غير http/https (مثل fb:// و intent://)
                return !("http".equals(scheme) || "https".equals(scheme));
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (currentFilterJson != null) {
                    runJs("window.__fbf.apply(" + currentFilterJson + ")", null);
                }
            }
        });
    }

    private void runJs(String code, android.webkit.ValueCallback<String> cb) {
        web.evaluateJavascript(script + "\n;" + code, cb);
    }

    private void applyFilter() {
        try {
            int yp = yearSp.getSelectedItemPosition();
            int mp = monthSp.getSelectedItemPosition();
            String kw = keyword.getText().toString().trim();
            if (kw.isEmpty() && yp == 0 && mp == 0) {
                status.setText("اختر سنة أو شهراً أو اكتب كلمة أولاً.");
                return;
            }
            JSONObject f = new JSONObject();
            f.put("keyword", kw);
            if (yp == 0) f.put("year", JSONObject.NULL);
            else f.put("year", Integer.parseInt(years.get(yp)));
            if (mp == 0) f.put("month", JSONObject.NULL);
            else f.put("month", mp);
            f.put("keepUnknown", keepUnknown.isChecked());

            currentFilterJson = f.toString();
            status.setText("جارٍ التطبيق...");
            runJs("window.__fbf.apply(" + currentFilterJson + ")", value -> {
                try {
                    Object o = new JSONTokener(value).nextValue();
                    JSONObject r = new JSONObject((String) o);
                    String msg = "✔ ظاهر: " + r.getInt("shown") + " | مخفي: " + r.getInt("hidden");
                    if (r.getInt("unknown") > 0) {
                        msg += " | تاريخه غير معروف: " + r.getInt("unknown");
                    }
                    status.setText(msg);
                } catch (Exception e) {
                    status.setText("تعذّر تطبيق الفلتر. تأكد أن الصفحة تعرض منشورات.");
                }
            });
        } catch (Exception e) {
            status.setText("خطأ: " + e.getMessage());
        }
    }

    private void resetFilter() {
        currentFilterJson = null;
        keyword.setText("");
        yearSp.setSelection(0);
        monthSp.setSelection(0);
        runJs("window.__fbf && window.__fbf.reset()", null);
        status.setText("تم إلغاء الفلترة وإظهار كل المنشورات.");
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        } catch (IOException e) {
            return "";
        }
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
