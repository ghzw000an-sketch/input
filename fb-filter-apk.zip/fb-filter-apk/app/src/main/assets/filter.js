(() => {
  if (window.__fbPostFilterLoaded) return;
  window.__fbPostFilterLoaded = true;

  let currentFilter = null;
  let observer = null;
  let debounceTimer = null;

  /* ---------- تطبيع النصوص ---------- */
  const AR_DIGITS = "٠١٢٣٤٥٦٧٨٩";
  function normalize(str) {
    return String(str || "")
      .replace(/[٠-٩]/g, (d) => AR_DIGITS.indexOf(d))
      .replace(/[\u064B-\u065F\u0670\u0640]/g, "") // تشكيل + تطويل
      .replace(/[أإآ]/g, "ا")
      .replace(/ى/g, "ي")
      .replace(/ة/g, "ه")
      .replace(/[\u200E\u200F\u202A-\u202E]/g, "")
      .replace(/\s+/g, " ")
      .toLowerCase()
      .trim();
  }

  /* ---------- أسماء الأشهر (عربي بكل اللهجات + إنجليزي) ---------- */
  const MONTH_NAMES = {
    1: ["يناير", "كانون الثاني", "جانفي", "january", "jan"],
    2: ["فبراير", "شباط", "فيفري", "february", "feb"],
    3: ["مارس", "اذار", "march", "mar"],
    4: ["ابريل", "نيسان", "افريل", "april", "apr"],
    5: ["مايو", "ايار", "ماي", "may"],
    6: ["يونيو", "يونيه", "حزيران", "جوان", "june", "jun"],
    7: ["يوليو", "يوليه", "تموز", "جويليه", "july", "jul"],
    8: ["اغسطس", "اب", "اوت", "august", "aug"],
    9: ["سبتمبر", "ايلول", "september", "sep", "sept"],
    10: ["اكتوبر", "تشرين الاول", "october", "oct"],
    11: ["نوفمبر", "تشرين الثاني", "november", "nov"],
    12: ["ديسمبر", "كانون الاول", "december", "dec"]
  };
  const MONTH_LIST = [];
  for (const [num, names] of Object.entries(MONTH_NAMES)) {
    names.forEach((n) => MONTH_LIST.push({ name: normalize(n), month: Number(num) }));
  }
  MONTH_LIST.sort((a, b) => b.name.length - a.name.length); // الأطول أولاً

  function findMonth(t) {
    for (const m of MONTH_LIST) {
      const re = new RegExp("(^|[^\\p{L}])" + m.name + "($|[^\\p{L}])", "u");
      if (re.test(t)) return m.month;
    }
    return null;
  }

  /* ---------- أيام الأسبوع ---------- */
  const WEEKDAYS = [
    ["sunday", "الاحد"], ["monday", "الاثنين"], ["tuesday", "الثلاثاء"],
    ["wednesday", "الاربعاء"], ["thursday", "الخميس"], ["friday", "الجمعه"], ["saturday", "السبت"]
  ];

  /* ---------- وحدات الوقت النسبي ---------- */
  const UNITS = {
    sec: ["s", "sec", "secs", "second", "seconds", "ث", "ثانيه", "ثواني", "ثوان"],
    min: ["m", "min", "mins", "minute", "minutes", "د", "دقيقه", "دقايق", "دقائق", "دقيقتين"],
    hour: ["h", "hr", "hrs", "hour", "hours", "س", "ساعه", "ساعات", "ساعتين"],
    day: ["d", "day", "days", "ي", "يوم", "ايام"],
    week: ["w", "wk", "wks", "week", "weeks", "ا", "اسبوع", "اسابيع"],
    month: ["mo", "mos", "month", "months", "شهر", "اشهر", "شهور"],
    year: ["y", "yr", "yrs", "year", "years", "سنه", "سنوات", "سنين", "عام", "اعوام"]
  };
  const UNIT_LOOKUP = {};
  for (const [k, arr] of Object.entries(UNITS)) arr.forEach((u) => (UNIT_LOOKUP[normalize(u)] = k));

  function subtract(now, n, unit) {
    const d = new Date(now.getTime());
    switch (unit) {
      case "sec": d.setSeconds(d.getSeconds() - n); break;
      case "min": d.setMinutes(d.getMinutes() - n); break;
      case "hour": d.setHours(d.getHours() - n); break;
      case "day": d.setDate(d.getDate() - n); break;
      case "week": d.setDate(d.getDate() - 7 * n); break;
      case "month": d.setMonth(d.getMonth() - n); break;
      case "year": d.setFullYear(d.getFullYear() - n); break;
    }
    return d;
  }

  /* ---------- تحليل نص التاريخ -> {year, month} أو null ---------- */
  function parseDateText(raw) {
    const t = normalize(raw);
    if (!t || t.length > 60) return null;
    const now = new Date();

    // 1) تاريخ صريح: (شهر) + (سنة اختيارية)
    const yearMatch = t.match(/(?:^|\D)((?:19|20)\d{2})(?!\d)/);
    const month = findMonth(t);
    if (month) {
      let year = yearMatch ? Number(yearMatch[1]) : now.getFullYear();
      // فيسبوك يحذف السنة للمنشورات الأحدث من سنة؛ لو كان الشهر مستقبلياً فهو من العام الماضي
      if (!yearMatch && (year === now.getFullYear()) && month > now.getMonth() + 1) year -= 1;
      return { year, month };
    }
    if (yearMatch) return { year: Number(yearMatch[1]), month: null };

    // 2) كلمات خاصة
    if (/(^|[^\p{L}])(الان|just now|now|اليوم|today)($|[^\p{L}])/u.test(t)) {
      return { year: now.getFullYear(), month: now.getMonth() + 1 };
    }
    if (/(^|[^\p{L}])(امس|yesterday)($|[^\p{L}])/u.test(t)) {
      const d = subtract(now, 1, "day");
      return { year: d.getFullYear(), month: d.getMonth() + 1 };
    }

    // 3) وقت نسبي: "3 س" ، "2h" ، "5 أيام" ...
    const rel = t.match(/(\d+)\s*([a-z\u0600-\u06FF]+)/);
    if (rel) {
      const unit = UNIT_LOOKUP[rel[2]];
      if (unit) {
        const d = subtract(now, parseInt(rel[1], 10), unit);
        return { year: d.getFullYear(), month: d.getMonth() + 1 };
      }
    }

    // 4) اسم يوم ("الثلاثاء عند 5:00 م")
    for (let i = 0; i < WEEKDAYS.length; i++) {
      const names = WEEKDAYS[i].map(normalize);
      if (names.some((n) => new RegExp("(^|[^\\p{L}])" + n + "($|[^\\p{L}])", "u").test(t))) {
        const diff = (now.getDay() - i + 7) % 7 || 7;
        const d = subtract(now, diff, "day");
        return { year: d.getFullYear(), month: d.getMonth() + 1 };
      }
    }
    return null;
  }

  /* ---------- استخراج تاريخ المنشور من الـ DOM ---------- */
  const TIME_SELECTORS = [
    "abbr[data-utime]",
    "a[href*='/posts/']", "a[href*='/permalink']", "a[href*='story_fbid']",
    "a[href*='/videos/']", "a[href*='/photos/']", "a[href*='/reel/']",
    "a[href*='/watch/']", "a[href*='fbid=']", "a[href*='/groups/'][href*='/permalink']",
    "abbr", "time"
  ].join(",");

  function getPostDate(post) {
    if (post.dataset.fbfDate !== undefined) {
      return post.dataset.fbfDate ? JSON.parse(post.dataset.fbfDate) : null;
    }
    let result = null;
    const candidates = post.querySelectorAll(TIME_SELECTORS);
    for (const el of candidates) {
      // الطريقة الأدق: الطابع الزمني الرقمي القديم
      const utime = el.getAttribute && el.getAttribute("data-utime");
      if (utime) {
        const d = new Date(parseInt(utime, 10) * 1000);
        result = { year: d.getFullYear(), month: d.getMonth() + 1 };
        break;
      }
      // innerText يتجاهل الأحرف المخفية التي يضعها فيسبوك لتشويش النص
      const texts = [el.getAttribute("aria-label"), el.innerText, el.getAttribute("title")];
      for (const txt of texts) {
        if (!txt) continue;
        const parsed = parseDateText(txt);
        if (parsed) { result = parsed; break; }
      }
      if (result) break;
    }
    // نخزّن النتيجة فقط إذا وُجد تاريخ (قد يتأخر ظهور التاريخ أثناء تحميل المنشور)
    if (result) post.dataset.fbfDate = JSON.stringify(result);
    return result;
  }

  /* ---------- مطابقة الكلمة المفتاحية ---------- */
  function matchesKeyword(post, keyword) {
    if (!keyword) return true;
    const text = normalize(post.innerText);
    return normalize(keyword).split(" ").filter(Boolean).every((w) => text.includes(w));
  }

  function matchesDate(date, f) {
    if (!f.year && !f.month) return true;
    if (!date) return null; // غير معروف
    if (f.year && date.year !== f.year) return false;
    if (f.month) {
      if (date.month === null) return false;
      if (date.month !== f.month) return false;
    }
    return true;
  }

  /* ---------- تطبيق الفلتر ---------- */
  function getPosts() {
    return Array.from(document.querySelectorAll("div[role='article']")).filter(
      // تجاهل التعليقات (مقالات متداخلة داخل منشور)
      (el) => !el.parentElement || !el.parentElement.closest("div[role='article']")
    );
  }

  function setHidden(post, hidden) {
    if (hidden) {
      post.style.setProperty("display", "none", "important");
      post.dataset.fbfHidden = "1";
    } else {
      post.style.removeProperty("display");
      delete post.dataset.fbfHidden;
    }
  }

  function setHighlight(post, on) {
    if (on) {
      post.style.outline = "3px solid #1877f2";
      post.style.outlineOffset = "2px";
      post.style.borderRadius = "10px";
    } else {
      post.style.outline = "";
      post.style.outlineOffset = "";
    }
  }

  function applyFilter() {
    if (!currentFilter) return { shown: 0, hidden: 0, unknown: 0 };
    const f = currentFilter;
    let shown = 0, hidden = 0, unknown = 0;

    for (const post of getPosts()) {
      const dateResult = matchesDate(getPostDate(post), f);
      const kwOk = matchesKeyword(post, f.keyword);

      let keep;
      if (dateResult === null) { // تاريخ غير معروف
        unknown++;
        keep = f.keepUnknown && kwOk;
      } else {
        keep = dateResult && kwOk;
      }
      setHidden(post, !keep);
      setHighlight(post, keep && (f.keyword || f.year || f.month));
      keep ? shown++ : hidden++;
    }
    return { shown, hidden, unknown };
  }

  function startObserver() {
    if (observer) return;
    observer = new MutationObserver(() => {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(applyFilter, 400);
    });
    observer.observe(document.body, { childList: true, subtree: true });
  }

  function resetFilter() {
    currentFilter = null;
    if (observer) { observer.disconnect(); observer = null; }
    clearTimeout(debounceTimer);
    document.querySelectorAll("[data-fbf-hidden]").forEach((el) => setHidden(el, false));
    document.querySelectorAll("div[role='article']").forEach((el) => setHighlight(el, false));
  }

  window.__fbf = {
    apply(filter) {
      currentFilter = filter;
      const res = applyFilter();
      startObserver();
      return JSON.stringify(res);
    },
    reset() {
      resetFilter();
      return "ok";
    }
  };
})();
