# FB Filter Pro

Android WebView application that opens Facebook post search after the user signs in, captures post cards rendered in the visible Facebook search feed, and presents captured text/permalinks in a native Results tab.

## Build

The GitHub Actions workflow in `.github/workflows/build-apk.yml` builds a debug APK with Gradle 8.9 and Java 17. To build locally, use Android Gradle Plugin 8.5.2, Gradle 8.9, and Android SDK platform 34.

## Important limitations

- The app does not query Facebook's private databases or bypass login, permissions, group privacy, rate limits, or other access controls.
- It can collect only post cards that Facebook actually renders in the signed-in search feed. It cannot guarantee complete coverage of all public posts.
- Post dates may be hidden or localized. When Facebook does not expose a parseable date, the app keeps the post visible rather than silently discarding it.
- Opening a result loads its Facebook permalink in the embedded browser; the user can read comments subject to their Facebook access.
- Facebook may change its web markup at any time, which can require updating the DOM collector.

## Privacy

The app does not include a separate backend or transmit captured posts to a third-party server. Facebook login and browsing occur in the embedded WebView and remain subject to Facebook's own policies.
