package com.example.employees

import android.app.Activity
import android.content.Context
import android.print.PrintAttributes
import android.print.PrintManager
import android.util.Base64
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Printer {
    private var keep: WebView? = null

    private fun esc(s: String) =
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private const val CSS = "body{font-family:sans-serif;padding:16px}h2{text-align:center}" +
        "table{width:100%;border-collapse:collapse}td,th{border:1px solid #888;padding:6px;font-size:13px}" +
        "td.k{background:#eee;width:35%;font-weight:bold}th{background:#ddd}" +
        "img{width:120px;height:120px;object-fit:cover;border-radius:60px}.c{text-align:center}" +
        ".d{color:#666;font-size:12px;text-align:center}"

    private fun today() = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(Date())

    private fun print(a: Activity, html: String, job: String) {
        val wv = WebView(a)
        keep = wv
        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String?) {
                val pm = a.getSystemService(Context.PRINT_SERVICE) as PrintManager
                pm.print(job, view.createPrintDocumentAdapter(job), PrintAttributes.Builder().build())
            }
        }
        wv.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
    }

    fun card(a: Activity, e: Employee) {
        val sb = StringBuilder("<html dir='rtl' lang='ar'><head><meta charset='utf-8'><style>$CSS</style></head><body>")
        sb.append("<h2>").append(esc(a.getString(R.string.card_title))).append("</h2>")
        if (e.photo.isNotBlank()) {
            val f = File(Files.photosDir(a), e.photo)
            if (f.exists()) {
                val b64 = Base64.encodeToString(f.readBytes(), Base64.NO_WRAP)
                sb.append("<p class='c'><img src='data:image/jpeg;base64,").append(b64).append("'></p>")
            }
        }
        sb.append("<table>")
        val rows = listOf(
            R.string.emp_no to e.empNo, R.string.name to e.name, R.string.job_title to e.title,
            R.string.dept to e.dept, R.string.branch to e.branch, R.string.salary to e.salary,
            R.string.phone to e.phone, R.string.email to e.email, R.string.hire_date to e.hireDate,
            R.string.status to e.status, R.string.notes to e.notes
        )
        for ((k, v) in rows) {
            sb.append("<tr><td class='k'>").append(esc(a.getString(k))).append("</td><td>")
                .append(esc(v).replace("\n", "<br>")).append("</td></tr>")
        }
        sb.append("</table><p class='d'>").append(today()).append("</p></body></html>")
        print(a, sb.toString(), a.getString(R.string.card_title) + " " + e.name)
    }

    fun list(a: Activity, items: List<Employee>) {
        val sb = StringBuilder("<html dir='rtl' lang='ar'><head><meta charset='utf-8'><style>$CSS</style></head><body>")
        sb.append("<h2>").append(esc(a.getString(R.string.list_title))).append("</h2><table><tr>")
        for (h in listOf("#", a.getString(R.string.emp_no), a.getString(R.string.name),
            a.getString(R.string.job_title), a.getString(R.string.dept), a.getString(R.string.phone),
            a.getString(R.string.status))) sb.append("<th>").append(esc(h)).append("</th>")
        sb.append("</tr>")
        items.forEachIndexed { i, e ->
            sb.append("<tr><td>").append(i + 1).append("</td>")
            for (v in listOf(e.empNo, e.name, e.title, e.dept, e.phone, e.status)) {
                sb.append("<td>").append(esc(v)).append("</td>")
            }
            sb.append("</tr>")
        }
        sb.append("</table><p class='d'>").append(today()).append(" - ").append(items.size)
            .append("</p></body></html>")
        print(a, sb.toString(), a.getString(R.string.list_title))
    }
}
