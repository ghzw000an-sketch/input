package com.example.employees

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class Db(ctx: Context) : SQLiteOpenHelper(ctx, "employees.db", null, 2) {

    private val appCtx = ctx.applicationContext

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE employees(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                emp_no TEXT, name TEXT NOT NULL, title TEXT, dept TEXT,
                phone TEXT, email TEXT, hire_date TEXT, status TEXT, notes TEXT,
                branch TEXT, salary TEXT, photo TEXT, doc TEXT)"""
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {
        if (o < 2) {
            for (c in listOf("branch", "salary", "photo", "doc")) {
                db.execSQL("ALTER TABLE employees ADD COLUMN $c TEXT")
            }
        }
    }

    private val cols = "id,emp_no,name,title,dept,phone,email,hire_date,status,notes,branch,salary,photo,doc"

    private fun Cursor.toEmp() = Employee(
        getLong(0), s(1), s(2), s(3), s(4), s(5), s(6), s(7), s(8), s(9), s(10), s(11), s(12), s(13)
    )

    private fun Cursor.s(i: Int) = getString(i) ?: ""

    private fun values(e: Employee) = ContentValues().apply {
        put("emp_no", e.empNo); put("name", e.name); put("title", e.title)
        put("dept", e.dept); put("phone", e.phone); put("email", e.email)
        put("hire_date", e.hireDate); put("status", e.status); put("notes", e.notes)
        put("branch", e.branch); put("salary", e.salary); put("photo", e.photo); put("doc", e.doc)
    }

    fun all(q: String = "", dept: String? = null, status: String? = null): List<Employee> {
        val like = "%$q%"
        val where = StringBuilder(
            "(name LIKE ? OR emp_no LIKE ? OR dept LIKE ? OR title LIKE ? OR phone LIKE ? OR branch LIKE ?)"
        )
        val args = mutableListOf(like, like, like, like, like, like)
        if (dept != null) { where.append(" AND dept=?"); args.add(dept) }
        if (status != null) { where.append(" AND status=?"); args.add(status) }
        val out = ArrayList<Employee>()
        readableDatabase.rawQuery(
            "SELECT $cols FROM employees WHERE $where ORDER BY name", args.toTypedArray()
        ).use { c -> while (c.moveToNext()) out.add(c.toEmp()) }
        return out
    }

    fun count(): Int =
        readableDatabase.rawQuery("SELECT COUNT(*) FROM employees", null)
            .use { c -> if (c.moveToFirst()) c.getInt(0) else 0 }

    fun departments(): List<String> {
        val out = ArrayList<String>()
        readableDatabase.rawQuery(
            "SELECT DISTINCT dept FROM employees WHERE dept IS NOT NULL AND dept<>'' ORDER BY dept", null
        ).use { c -> while (c.moveToNext()) out.add(c.getString(0)) }
        return out
    }

    fun get(id: Long): Employee? =
        readableDatabase.rawQuery("SELECT $cols FROM employees WHERE id=?", arrayOf(id.toString()))
            .use { c -> if (c.moveToFirst()) c.toEmp() else null }

    fun empNoExists(empNo: String, exceptId: Long): Boolean =
        empNo.isNotBlank() && readableDatabase.rawQuery(
            "SELECT 1 FROM employees WHERE emp_no=? AND id<>?", arrayOf(empNo, exceptId.toString())
        ).use { it.moveToFirst() }

    fun save(e: Employee) {
        if (e.id == 0L) writableDatabase.insert("employees", null, values(e))
        else writableDatabase.update("employees", values(e), "id=?", arrayOf(e.id.toString()))
    }

    fun insertMany(list: List<Employee>) {
        val d = writableDatabase
        d.beginTransaction()
        try {
            for (e in list) d.insert("employees", null, values(e))
            d.setTransactionSuccessful()
        } finally {
            d.endTransaction()
        }
    }

    fun delete(id: Long) {
        get(id)?.let { Files.delete(appCtx, it.photo, it.doc) }
        writableDatabase.delete("employees", "id=?", arrayOf(id.toString()))
    }

    fun deleteAll() {
        writableDatabase.delete("employees", null, null)
        Files.deleteAll(appCtx)
    }

    fun checkpoint() {
        writableDatabase.rawQuery("PRAGMA wal_checkpoint(FULL)", null).use { it.moveToFirst() }
    }
}
