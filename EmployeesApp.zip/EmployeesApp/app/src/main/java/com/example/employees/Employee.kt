package com.example.employees

data class Employee(
    var id: Long = 0,
    var empNo: String = "",
    var name: String = "",
    var title: String = "",
    var dept: String = "",
    var phone: String = "",
    var email: String = "",
    var hireDate: String = "",
    var status: String = "نشط",
    var notes: String = "",
    var branch: String = "",
    var salary: String = "",
    var photo: String = "",
    var doc: String = ""
)

object Status {
    val all = listOf("نشط", "إجازة", "منتهي الخدمة")
}
