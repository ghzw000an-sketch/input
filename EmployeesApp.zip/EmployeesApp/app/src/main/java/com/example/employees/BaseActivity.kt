package com.example.employees

import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity

open class BaseActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (getSharedPreferences("prefs", MODE_PRIVATE).getBoolean("secure", false)) {
            window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        }
    }

    override fun onResume() {
        super.onResume()
        val c = getSharedPreferences("prefs", MODE_PRIVATE).getInt("color", 0xFF10375C.toInt())
        supportActionBar?.setBackgroundDrawable(ColorDrawable(c))
    }
}
