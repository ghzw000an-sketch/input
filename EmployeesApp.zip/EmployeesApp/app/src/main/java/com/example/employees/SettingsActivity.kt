package com.example.employees

import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatDelegate
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class SettingsActivity : BaseActivity() {

    private lateinit var db: Db

    private val backupLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
            uri?.let { backup(it) }
        }
    private val restoreLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uri?.let { restore(it) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = getString(R.string.settings)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        db = Db(this)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        fun add(textRes: Int, action: () -> Unit) {
            root.addView(Button(this).apply {
                text = getString(textRes)
                setOnClickListener { action() }
            })
        }
        add(R.string.change_password) { changePassword() }
        add(R.string.theme_color) { pickColor() }
        add(R.string.night_mode) { pickNight() }
        add(R.string.block_screenshots) { toggleSecure() }
        add(R.string.backup) { backupLauncher.launch("employees_backup.zip") }
        add(R.string.restore) { restoreLauncher.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) }
        add(R.string.delete_all) { confirmDeleteAll() }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    private val prefs get() = getSharedPreferences("prefs", MODE_PRIVATE)

    private fun changePassword() {
        val saved = prefs.getString("pin", "") ?: ""
        val pad = (16 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, 0)
        }
        fun field(hintRes: Int) = EditText(this).apply {
            hint = getString(hintRes)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val old = field(R.string.old_password)
        val new = field(R.string.new_password)
        if (saved.isNotEmpty()) box.addView(old)
        box.addView(new)

        AlertDialog.Builder(this)
            .setTitle(R.string.change_password)
            .setMessage(R.string.password_hint)
            .setView(box)
            .setPositiveButton(R.string.save) { _, _ ->
                if (saved.isNotEmpty() && Sec.sha(old.text.toString()) != saved) {
                    Toast.makeText(this, R.string.wrong_password, Toast.LENGTH_SHORT).show()
                } else {
                    val n = new.text.toString()
                    prefs.edit().putString("pin", if (n.isEmpty()) "" else Sec.sha(n)).apply()
                    Toast.makeText(this, R.string.saved, Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(R.string.no, null)
            .show()
    }

    private fun pickColor() {
        val names = arrayOf("كحلي", "أخضر", "أحمر داكن", "بنفسجي", "رمادي")
        val colors = intArrayOf(0xFF10375C.toInt(), 0xFF1B5E20.toInt(), 0xFF8E1B1B.toInt(),
            0xFF4A148C.toInt(), 0xFF37474F.toInt())
        AlertDialog.Builder(this)
            .setTitle(R.string.theme_color)
            .setItems(names) { _, i ->
                prefs.edit().putInt("color", colors[i]).apply()
                supportActionBar?.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(colors[i]))
            }
            .show()
    }

    private fun pickNight() {
        val names = arrayOf(getString(R.string.night_system), getString(R.string.night_light), getString(R.string.night_dark))
        val modes = intArrayOf(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM, AppCompatDelegate.MODE_NIGHT_NO,
            AppCompatDelegate.MODE_NIGHT_YES)
        AlertDialog.Builder(this)
            .setTitle(R.string.night_mode)
            .setItems(names) { _, i ->
                prefs.edit().putInt("night", modes[i]).apply()
                AppCompatDelegate.setDefaultNightMode(modes[i])
            }
            .show()
    }

    private fun toggleSecure() {
        val now = !prefs.getBoolean("secure", false)
        prefs.edit().putBoolean("secure", now).apply()
        Toast.makeText(this, if (now) R.string.screenshots_blocked else R.string.screenshots_allowed,
            Toast.LENGTH_LONG).show()
    }

    private fun addFile(z: ZipOutputStream, name: String, f: File) {
        z.putNextEntry(ZipEntry(name))
        FileInputStream(f).use { it.copyTo(z) }
        z.closeEntry()
    }

    private fun backup(uri: Uri) {
        try {
            db.checkpoint()
            contentResolver.openOutputStream(uri)?.use { os ->
                ZipOutputStream(os).use { z ->
                    addFile(z, "employees.db", getDatabasePath("employees.db"))
                    for (dir in listOf("photos", "docs")) {
                        File(filesDir, dir).listFiles()?.forEach { addFile(z, "$dir/${it.name}", it) }
                    }
                }
            }
            Toast.makeText(this, R.string.backup_done, Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, e.message ?: "error", Toast.LENGTH_LONG).show()
        }
    }

    private fun restore(uri: Uri) {
        val tmp = File(cacheDir, "restore")
        try {
            tmp.deleteRecursively()
            tmp.mkdirs()
            contentResolver.openInputStream(uri)?.use { ins ->
                ZipInputStream(ins).use { z ->
                    var e = z.nextEntry
                    while (e != null) {
                        val n = e.name
                        val ok = !e.isDirectory && !n.contains("..") &&
                            (n == "employees.db" || n.startsWith("photos/") || n.startsWith("docs/"))
                        if (ok) {
                            val out = File(tmp, n)
                            out.parentFile?.mkdirs()
                            FileOutputStream(out).use { z.copyTo(it) }
                        }
                        z.closeEntry()
                        e = z.nextEntry
                    }
                }
            }
            val dbf = File(tmp, "employees.db")
            val header = "SQLite format 3".toByteArray(Charsets.US_ASCII)
            val head = ByteArray(header.size)
            val valid = dbf.exists() && dbf.length() >= 100 &&
                FileInputStream(dbf).use { it.read(head) == head.size } && head.contentEquals(header)
            if (!valid) {
                Toast.makeText(this, R.string.bad_backup, Toast.LENGTH_LONG).show()
                return
            }
            db.close()
            val target = getDatabasePath("employees.db")
            dbf.copyTo(target, overwrite = true)
            File(target.path + "-wal").delete()
            File(target.path + "-shm").delete()
            Files.deleteAll(this)
            File(tmp, "photos").takeIf { it.exists() }?.copyRecursively(Files.photosDir(this), true)
            File(tmp, "docs").takeIf { it.exists() }?.copyRecursively(Files.docsDir(this), true)
            db.count() // reopen now so an older backup is upgraded immediately
            Toast.makeText(this, R.string.restore_done, Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, e.message ?: "error", Toast.LENGTH_LONG).show()
        } finally {
            tmp.deleteRecursively()
        }
    }

    private fun confirmDeleteAll() {
        AlertDialog.Builder(this)
            .setMessage(R.string.confirm_delete_all)
            .setPositiveButton(R.string.yes) { _, _ ->
                db.deleteAll()
                Toast.makeText(this, R.string.deleted_all, Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(R.string.no, null)
            .show()
    }
}
