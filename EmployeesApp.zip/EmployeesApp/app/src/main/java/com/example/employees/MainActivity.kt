package com.example.employees

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.employees.databinding.ActivityMainBinding
import com.example.employees.databinding.ItemEmployeeBinding

class MainActivity : BaseActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var db: Db
    private val adapter = EmpAdapter { openEdit(it.id) }

    private var deptList: List<String> = emptyList()
    private var curDept: String? = null
    private var curStatus: String? = null
    private var shown: List<Employee> = emptyList()

    private val exportLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
            uri?.let { writeCsv(it) }
        }
    private val importLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uri?.let { importCsv(it) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        db = Db(this)

        b.list.layoutManager = LinearLayoutManager(this)
        b.list.adapter = adapter
        b.search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, bf: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = refreshList()
        })

        val statusItems = listOf(getString(R.string.all_statuses)) + Status.all
        b.spStatus.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, statusItems)
        b.spStatus.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                curStatus = if (pos == 0) null else Status.all[pos - 1]
                refreshList()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        b.spDept.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                curDept = if (pos == 0) null else deptList.getOrNull(pos - 1)
                refreshList()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        b.fab.setOnClickListener { openEdit(0) }
    }

    override fun onResume() {
        super.onResume()
        refreshAll()
    }

    private fun refreshAll() {
        val newDepts = db.departments()
        if (newDepts != deptList || b.spDept.adapter == null) {
            deptList = newDepts
            val items = listOf(getString(R.string.all_depts)) + deptList
            b.spDept.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
            val idx = curDept?.let { deptList.indexOf(it) } ?: -1
            if (idx < 0) curDept = null
            b.spDept.setSelection(idx + 1)
        }
        refreshList()
    }

    private fun refreshList() {
        shown = db.all(b.search.text.toString().trim(), curDept, curStatus)
        adapter.submit(shown)
        b.tvCount.text = getString(R.string.count_fmt, shown.size, db.count())
        b.emptyView.visibility = if (shown.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun openEdit(id: Long) {
        startActivity(Intent(this, EditActivity::class.java).putExtra("id", id))
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_export -> exportLauncher.launch("employees.csv")
            R.id.action_import -> importLauncher.launch(
                arrayOf("text/csv", "text/comma-separated-values", "text/plain", "application/vnd.ms-excel", "*/*")
            )
            R.id.action_print -> Printer.list(this, shown)
            R.id.action_settings -> startActivity(Intent(this, SettingsActivity::class.java))
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    private fun writeCsv(uri: Uri) {
        try {
            contentResolver.openOutputStream(uri)?.use { out ->
                out.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte())) // BOM so Excel reads Arabic
                val sb = StringBuilder(
                    "الرقم الوظيفي,الاسم,المسمى الوظيفي,القسم,الهاتف,البريد,تاريخ التعيين,الحالة,ملاحظات,الفرع,الراتب\n"
                )
                for (e in db.all()) {
                    sb.append(
                        listOf(e.empNo, e.name, e.title, e.dept, e.phone, e.email, e.hireDate,
                            e.status, e.notes, e.branch, e.salary).joinToString(",") { Csv.esc(it) }
                    ).append('\n')
                }
                out.write(sb.toString().toByteArray(Charsets.UTF_8))
            }
            Toast.makeText(this, R.string.exported, Toast.LENGTH_SHORT).show()
        } catch (ex: Exception) {
            Toast.makeText(this, ex.message ?: "error", Toast.LENGTH_LONG).show()
        }
    }

    private fun importCsv(uri: Uri) {
        try {
            val text = contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: return
            val rows = Csv.parse(text.removePrefix("\uFEFF"))
            val list = ArrayList<Employee>()
            for ((i, r) in rows.withIndex()) {
                if (i == 0 && r.firstOrNull()?.trim() == getString(R.string.emp_no)) continue
                val name = r.getOrNull(1)?.trim() ?: ""
                if (name.isEmpty()) continue
                fun g(k: Int) = r.getOrNull(k)?.trim() ?: ""
                list.add(
                    Employee(
                        0, g(0), name, g(2), g(3), g(4), g(5), g(6),
                        g(7).ifEmpty { Status.all[0] }, g(8), g(9), g(10)
                    )
                )
            }
            db.insertMany(list)
            Toast.makeText(this, getString(R.string.imported_fmt, list.size), Toast.LENGTH_LONG).show()
            refreshAll()
        } catch (ex: Exception) {
            Toast.makeText(this, ex.message ?: "error", Toast.LENGTH_LONG).show()
        }
    }

    class EmpAdapter(private val onClick: (Employee) -> Unit) : RecyclerView.Adapter<EmpAdapter.VH>() {
        private var items: List<Employee> = emptyList()

        fun submit(list: List<Employee>) {
            items = list
            notifyDataSetChanged()
        }

        class VH(val v: ItemEmployeeBinding) : RecyclerView.ViewHolder(v.root)

        override fun onCreateViewHolder(p: ViewGroup, t: Int) =
            VH(ItemEmployeeBinding.inflate(LayoutInflater.from(p.context), p, false))

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: VH, i: Int) {
            val e = items[i]
            h.v.tvName.text = e.name
            h.v.tvSub.text = listOf(e.title, e.dept).filter { it.isNotBlank() }.joinToString(" • ")
            h.v.tvMeta.text = listOf(e.empNo, e.phone, e.status).filter { it.isNotBlank() }.joinToString(" • ")
            val bmp = Files.bitmap(h.v.root.context, e.photo, 128)
            if (bmp != null) h.v.ivPhoto.setImageBitmap(bmp)
            else h.v.ivPhoto.setImageResource(android.R.drawable.ic_menu_myplaces)
            h.v.root.setOnClickListener { onClick(e) }
        }
    }
}
