package com.example.employees

import android.app.DatePickerDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.content.FileProvider
import com.example.employees.databinding.ActivityEditBinding
import java.io.File
import java.util.Calendar
import java.util.Locale

class EditActivity : BaseActivity() {

    private lateinit var b: ActivityEditBinding
    private lateinit var db: Db
    private var emp = Employee()
    private var origPhoto = ""
    private var origDoc = ""
    private var saved = false

    private val photoLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            uri ?: return@registerForActivityResult
            val name = Files.savePhoto(this, uri)
            if (name != null) {
                discardIfNew(emp.photo, origPhoto, isPhoto = true)
                emp.photo = name
                showPhoto()
            }
        }

    private val pdfLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uri ?: return@registerForActivityResult
            val name = Files.copyDoc(this, uri)
            if (name != null) {
                discardIfNew(emp.doc, origDoc, isPhoto = false)
                emp.doc = name
                showDoc()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityEditBinding.inflate(layoutInflater)
        setContentView(b.root)
        db = Db(this)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        b.spStatus.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, Status.all)

        val id = intent.getLongExtra("id", 0L)
        if (id != 0L) {
            db.get(id)?.let { emp = it }
            title = getString(R.string.edit_employee)
            b.btnDelete.visibility = View.VISIBLE
            fill()
        } else {
            title = getString(R.string.new_employee)
        }
        origPhoto = emp.photo
        origDoc = emp.doc
        showPhoto()
        showDoc()

        b.btnPhoto.setOnClickListener { photoLauncher.launch("image/*") }
        b.ivPhoto.setOnClickListener { photoLauncher.launch("image/*") }
        b.btnPdf.setOnClickListener { pdfLauncher.launch(arrayOf("application/pdf")) }
        b.btnOpenPdf.setOnClickListener { openPdf() }
        b.etDate.setOnClickListener { pickDate() }
        b.btnCall.setOnClickListener { call() }
        b.btnMail.setOnClickListener { mail() }
        b.btnPrint.setOnClickListener { Printer.card(this, collect()) }
        b.btnSave.setOnClickListener { save() }
        b.btnClear.setOnClickListener {
            listOf(b.etNo, b.etName, b.etTitle, b.etDept, b.etBranch, b.etSalary,
                b.etPhone, b.etEmail, b.etDate, b.etNotes).forEach { it.setText("") }
            b.spStatus.setSelection(0)
        }
        b.btnDelete.setOnClickListener {
            AlertDialog.Builder(this)
                .setMessage(R.string.confirm_delete)
                .setPositiveButton(R.string.yes) { _, _ ->
                    db.delete(emp.id)
                    saved = true
                    finish()
                }
                .setNegativeButton(R.string.no, null)
                .show()
        }
    }

    override fun onDestroy() {
        // leave no orphan attachments if the user backed out without saving
        if (!saved) {
            if (emp.photo != origPhoto) Files.delete(this, emp.photo, "")
            if (emp.doc != origDoc) Files.delete(this, "", emp.doc)
        }
        super.onDestroy()
    }

    private fun discardIfNew(current: String, original: String, isPhoto: Boolean) {
        if (current.isNotBlank() && current != original) {
            if (isPhoto) Files.delete(this, current, "") else Files.delete(this, "", current)
        }
    }

    private fun fill() {
        b.etNo.setText(emp.empNo); b.etName.setText(emp.name); b.etTitle.setText(emp.title)
        b.etDept.setText(emp.dept); b.etBranch.setText(emp.branch); b.etSalary.setText(emp.salary)
        b.etPhone.setText(emp.phone); b.etEmail.setText(emp.email)
        b.etDate.setText(emp.hireDate); b.etNotes.setText(emp.notes)
        b.spStatus.setSelection(Status.all.indexOf(emp.status).coerceAtLeast(0))
    }

    private fun showPhoto() {
        val bmp = Files.bitmap(this, emp.photo, 256)
        if (bmp != null) b.ivPhoto.setImageBitmap(bmp)
        else b.ivPhoto.setImageResource(android.R.drawable.ic_menu_myplaces)
    }

    private fun showDoc() {
        b.btnOpenPdf.visibility = if (emp.doc.isNotBlank()) View.VISIBLE else View.GONE
    }

    private fun openPdf() {
        val f = File(Files.docsDir(this), emp.doc)
        if (!f.exists()) return
        val uri = FileProvider.getUriForFile(this, "$packageName.files", f)
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uri, "application/pdf")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, R.string.no_pdf_viewer, Toast.LENGTH_SHORT).show()
        }
    }

    private fun call() {
        val p = b.etPhone.text.toString().trim()
        if (p.isEmpty()) { Toast.makeText(this, R.string.no_phone, Toast.LENGTH_SHORT).show(); return }
        startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(p))))
    }

    private fun mail() {
        val m = b.etEmail.text.toString().trim()
        if (m.isEmpty()) { Toast.makeText(this, R.string.no_email, Toast.LENGTH_SHORT).show(); return }
        try {
            startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + Uri.encode(m))))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, R.string.no_email, Toast.LENGTH_SHORT).show()
        }
    }

    private fun pickDate() {
        val c = Calendar.getInstance()
        DatePickerDialog(this, { _, y, m, d ->
            b.etDate.setText(String.format(Locale.ENGLISH, "%04d-%02d-%02d", y, m + 1, d))
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun collect(): Employee = emp.copy(
        empNo = b.etNo.text.toString().trim(),
        name = b.etName.text.toString().trim(),
        title = b.etTitle.text.toString().trim(),
        dept = b.etDept.text.toString().trim(),
        branch = b.etBranch.text.toString().trim(),
        salary = b.etSalary.text.toString().trim(),
        phone = b.etPhone.text.toString().trim(),
        email = b.etEmail.text.toString().trim(),
        hireDate = b.etDate.text.toString().trim(),
        status = Status.all[b.spStatus.selectedItemPosition.coerceIn(0, Status.all.size - 1)],
        notes = b.etNotes.text.toString().trim()
    )

    private fun save() {
        val e = collect()
        if (e.name.isEmpty()) {
            Toast.makeText(this, R.string.name_required, Toast.LENGTH_SHORT).show()
            return
        }
        if (db.empNoExists(e.empNo, e.id)) {
            Toast.makeText(this, R.string.dup_emp_no, Toast.LENGTH_LONG).show()
            return
        }
        db.save(e)
        // the replaced originals are no longer referenced
        if (origPhoto.isNotBlank() && origPhoto != e.photo) Files.delete(this, origPhoto, "")
        if (origDoc.isNotBlank() && origDoc != e.doc) Files.delete(this, "", origDoc)
        saved = true
        finish()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) { finish(); return true }
        return super.onOptionsItemSelected(item)
    }
}
