package com.example.employees

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class LoginActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val saved = getSharedPreferences("prefs", MODE_PRIVATE).getString("pin", "") ?: ""
        if (saved.isEmpty()) {
            goMain()
            return
        }

        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
        }
        val title = TextView(this).apply {
            text = getString(R.string.enter_password)
            textSize = 18f
            gravity = Gravity.CENTER
        }
        val pass = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            gravity = Gravity.CENTER
            maxLines = 1
        }
        val btn = Button(this).apply { text = getString(R.string.login) }
        root.addView(title)
        root.addView(pass)
        root.addView(btn)
        setContentView(root)

        val check = {
            if (Sec.sha(pass.text.toString()) == saved) goMain()
            else {
                pass.setText("")
                Toast.makeText(this, R.string.wrong_password, Toast.LENGTH_SHORT).show()
            }
        }
        btn.setOnClickListener { check() }
        pass.setOnEditorActionListener { _, _, _ -> check(); true }
    }

    private fun goMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
