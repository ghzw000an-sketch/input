package com.example.employees

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min

object Files {
    fun photosDir(c: Context) = File(c.filesDir, "photos").apply { mkdirs() }
    fun docsDir(c: Context) = File(c.filesDir, "docs").apply { mkdirs() }

    fun savePhoto(c: Context, uri: Uri): String? {
        val cr = c.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > 1024) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null

        val orientation = try {
            cr.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (e: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }
        val degrees = when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        val scale = min(1f, 512f / max(bmp.width, bmp.height))
        val m = Matrix().apply {
            if (degrees != 0f) postRotate(degrees)
            postScale(scale, scale)
        }
        val out = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        val name = "p_${System.currentTimeMillis()}.jpg"
        FileOutputStream(File(photosDir(c), name)).use { out.compress(Bitmap.CompressFormat.JPEG, 85, it) }
        return name
    }

    fun copyDoc(c: Context, uri: Uri): String? {
        val name = "d_${System.currentTimeMillis()}.pdf"
        val input = c.contentResolver.openInputStream(uri) ?: return null
        input.use { i -> FileOutputStream(File(docsDir(c), name)).use { i.copyTo(it) } }
        return name
    }

    fun bitmap(c: Context, name: String, maxPx: Int): Bitmap? {
        if (name.isBlank()) return null
        val f = File(photosDir(c), name)
        if (!f.exists()) return null
        val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, b)
        var s = 1
        while (max(b.outWidth, b.outHeight) / (s * 2) >= maxPx) s *= 2
        return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
    }

    fun delete(c: Context, photo: String, doc: String) {
        if (photo.isNotBlank()) File(photosDir(c), photo).delete()
        if (doc.isNotBlank()) File(docsDir(c), doc).delete()
    }

    fun deleteAll(c: Context) {
        photosDir(c).listFiles()?.forEach { it.delete() }
        docsDir(c).listFiles()?.forEach { it.delete() }
    }
}
