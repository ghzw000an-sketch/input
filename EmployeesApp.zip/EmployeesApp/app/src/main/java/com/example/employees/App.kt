package com.example.employees

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        val p = getSharedPreferences("prefs", MODE_PRIVATE)
        AppCompatDelegate.setDefaultNightMode(
            p.getInt("night", AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        )
    }
}
