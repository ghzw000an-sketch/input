package com.example.fbfilter;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.*;
import android.text.InputType;
import org.json.*;
import java.net.URLEncoder;
import java.util.*;

public class MainActivity extends Activity {
  private final int BLUE=Color.rgb(24,119,242), BG=Color.rgb(244,246,249), DARK=Color.rgb(28,36,48);
  private WebView web; private LinearLayout root, resultsBox, searchBox; private ScrollView resultsScroll;
  private EditText query; private Spinner year, month; private TextView status, count; private Button resultsTab, searchTab, stop;
  private final LinkedHashMap<String,JSONObject> posts=new LinkedHashMap<>();
  private boolean collecting=false, detail=false; private String lastSearchUrl="https://www.facebook.com/";
  private String[] months={"كل الأشهر","يناير","فبراير","مارس","أبريل","مايو","يونيو","يوليو","أغسطس","سبتمبر","أكتوبر","نوفمبر","ديسمبر"};
  private int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
  private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
  private Button button(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(BLUE));return b;}
  @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(BLUE); build(); setupWeb(); web.loadUrl("https://www.facebook.com/");}
  private void build(){
    root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);
    LinearLayout header=new LinearLayout(this);header.setPadding(dp(16),dp(10),dp(16),dp(10));header.setGravity( gravityCenter());header.setBackgroundColor(BLUE);
    TextView brand=text("FB Filter Pro",20,Color.WHITE);brand.setTypeface(null,1);header.addView(brand,new LinearLayout.LayoutParams(0,dp(48),1));
    stop=button("إيقاف الجمع");stop.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(190,55,55)));stop.setOnClickListener(v->{collecting=false;web.evaluateJavascript("window.FBF && FBF.stop()",null);setStatus("تم إيقاف جمع النتائج");});header.addView(stop);
    root.addView(header);
    LinearLayout tabs=new LinearLayout(this);tabs.setPadding(dp(8),dp(4),dp(8),dp(4));tabs.setBackgroundColor(Color.WHITE);
    searchTab=button("بحث");resultsTab=button("النتائج (0)");
    tabs.addView(searchTab,new LinearLayout.LayoutParams(0,dp(46),1));tabs.addView(resultsTab,new LinearLayout.LayoutParams(0,dp(46),1));root.addView(tabs);
    FrameLayout content=new FrameLayout(this);root.addView(content,new LinearLayout.LayoutParams(-1,0,1));
    searchBox=new LinearLayout(this);searchBox.setOrientation(LinearLayout.VERTICAL);searchBox.setPadding(dp(14),dp(12),dp(14),dp(12));
    TextView title=text("ابحث في المنشورات العامة",19,DARK);title.setTypeface(null,1);searchBox.addView(title);
    TextView hint=text("يُفتح بحث المنشورات الأصلي في فيسبوك. سجّل الدخول، وستُجمع المنشورات التي يعرضها فيسبوك أثناء التصفح.",13,Color.DKGRAY);hint.setPadding(0,dp(5),0,dp(12));searchBox.addView(hint);
    query=new EditText(this);query.setSingleLine(true);query.setHint("مثال: ببجي، وظائف، أخبار العراق");query.setTextSize(16);query.setInputType(InputType.TYPE_CLASS_TEXT);searchBox.addView(query,new LinearLayout.LayoutParams(-1,dp(54)));
    LinearLayout filters=new LinearLayout(this);year=new Spinner(this);List<String> ys=new ArrayList<>();ys.add("كل السنوات");for(int y=Calendar.getInstance().get(Calendar.YEAR);y>=2004;y--)ys.add(String.valueOf(y));year.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,ys));
    month=new Spinner(this);month.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,months));
    AdapterView.OnItemSelectedListener filterChanged=new AdapterView.OnItemSelectedListener(){public void onItemSelected(AdapterView<?> p,View v,int pos,long id){refreshResults();}public void onNothingSelected(AdapterView<?> p){}};
    year.setOnItemSelectedListener(filterChanged);month.setOnItemSelectedListener(filterChanged);
    filters.addView(year,new LinearLayout.LayoutParams(0,dp(52),1));filters.addView(month,new LinearLayout.LayoutParams(0,dp(52),1));searchBox.addView(filters);
    Button go=button("بحث في فيسبوك وجمع المنشورات");LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(-1,dp(54));gp.topMargin=dp(10);searchBox.addView(go,gp);
    Button open=button("فتح فيسبوك");open.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.DKGRAY));searchBox.addView(open);open.setOnClickListener(v->{detail=false;web.loadUrl("https://www.facebook.com/");showBrowser();});
    Button resume=button("استئناف جمع المنشورات");resume.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(46,125,50)));searchBox.addView(resume);resume.setOnClickListener(v->{collecting=true;web.evaluateJavascript("window.FBF && FBF.start()",null);showBrowser();setStatus("تم استئناف جمع المنشورات الظاهرة");});
    status=text("جاهز للبحث",13,Color.DKGRAY);status.setPadding(dp(4),dp(12),dp(4),dp(4));searchBox.addView(status);
    TextView limitation=text("ملاحظة: النتائج حسب ما يسمح فيسبوك بعرضه لحسابك. لا يمكن ضمان فهرسة جميع المنشورات العامة.",11,Color.GRAY);limitation.setPadding(dp(4),dp(8),dp(4),0);searchBox.addView(limitation);
    go.setOnClickListener(v->startSearch());
    resultsBox=new LinearLayout(this);resultsBox.setOrientation(LinearLayout.VERTICAL);count=text("المنشورات التي تم التقاطها",16,DARK);count.setTypeface(null,1);count.setPadding(dp(14),dp(12),dp(14),dp(8));resultsBox.addView(count);
    resultsScroll=new ScrollView(this);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);list.setPadding(dp(10),0,dp(10),dp(12));resultsScroll.addView(list);resultsBox.addView(resultsScroll,new LinearLayout.LayoutParams(-1,0,1));
    TextView empty=text("لا توجد نتائج بعد. ابدأ بحثاً من تبويب البحث.",14,Color.GRAY);empty.setGravity(17);list.addView(empty);
    content.addView(searchBox);content.addView(resultsBox);content.addView(web=new WebView(this));web.setVisibility(View.GONE);resultsBox.setVisibility(View.GONE);
    searchTab.setOnClickListener(v->{detail=false;searchBox.setVisibility(View.VISIBLE);resultsBox.setVisibility(View.GONE);web.setVisibility(View.GONE);});
    resultsTab.setOnClickListener(v->showResults());setContentView(root);
  }
  private int gravityCenter(){return android.view.Gravity.CENTER_VERTICAL;}
  private void setupWeb(){WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setDatabaseEnabled(true);s.setSupportZoom(true);s.setBuiltInZoomControls(true);s.setDisplayZoomControls(false);s.setUserAgentString("Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/130.0.0.0 Mobile Safari/537.36");CookieManager cm=CookieManager.getInstance();cm.setAcceptCookie(true);cm.setAcceptThirdPartyCookies(web,true);web.setWebChromeClient(new WebChromeClient());web.addJavascriptInterface(new Bridge(),"AndroidFBF");web.setWebViewClient(new WebViewClient(){@Override public void onPageFinished(WebView v,String url){if(collecting){injectCollector();setStatus("جارٍ جمع المنشورات التي يعرضها بحث فيسبوك…");}}});}
  private void startSearch(){String q=query.getText().toString().trim();if(q.isEmpty()){setStatus("اكتب كلمة البحث أولاً");return;}try{StringBuilder u=new StringBuilder("https://www.facebook.com/search/posts/?q=").append(URLEncoder.encode(q,"UTF-8"));lastSearchUrl=u.toString();posts.clear();refreshResults();collecting=true;detail=false;showBrowser();web.loadUrl(lastSearchUrl);setStatus("فتح نتائج البحث في فيسبوك…");}catch(Exception e){setStatus("تعذر بدء البحث: "+e.getMessage());}}
  private void showBrowser(){searchBox.setVisibility(View.GONE);resultsBox.setVisibility(View.GONE);web.setVisibility(View.VISIBLE);}
  private void showResults(){detail=false;searchBox.setVisibility(View.GONE);web.setVisibility(View.GONE);resultsBox.setVisibility(View.VISIBLE);}
  private void setStatus(String s){runOnUiThread(()->status.setText(s));}
  private void injectCollector(){
    String js = """
      (function(){
        if(!window.FBF){
          window.FBF={installed:true,seen:{},timer:null,observer:null,running:false,
            stop:function(){this.running=false;if(this.timer){clearInterval(this.timer);this.timer=null;}if(this.observer){this.observer.disconnect();this.observer=null;}},
            start:function(){if(this.running)return;this.running=true;this.scan();var self=this;
              this.timer=setInterval(function(){if(!self.running)return;self.scan();var y=window.scrollY||0;var h=Math.max(document.body.scrollHeight,document.documentElement.scrollHeight);if(y+window.innerHeight>h-850)window.scrollTo(0,h);},1800);
              this.observer=new MutationObserver(function(){if(self.running)self.scan();});
              this.observer.observe(document.documentElement,{childList:true,subtree:true});
            },
            scan:function(){if(!this.running)return;var out=[];var self=this;
              var arts=document.querySelectorAll('[role="article"],div[data-pagelet*="FeedUnit"]');
              arts.forEach(function(a){
                if(a.parentElement&&a.parentElement.closest('[role="article"]'))return;
                var raw=(a.innerText||a.textContent||'').trim();if(raw.length<25)return;
                var links=Array.from(a.querySelectorAll('a[href]'));var href='';
                for(var i=0;i<links.length;i++){var h=links[i].href||'';if(/\/(posts|permalink|videos|reel|watch)\//i.test(h)||/[?&](story_fbid|fbid)=/i.test(h)||/pfbid/i.test(h)){href=h;break;}}
                if(!href)return;try{var u=new URL(href);u.hash='';href=u.href;}catch(e){}
                if(self.seen[href])return;
                var tm=a.querySelector('abbr[data-utime],time[datetime],time,abbr');var dt='';
                if(tm){var ut=tm.getAttribute('data-utime');var iso=tm.getAttribute('datetime');
                  if(ut){var d=new Date(parseInt(ut,10)*1000);dt=d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');}
                  else if(iso){var d2=new Date(iso);if(!isNaN(d2.getTime()))dt=d2.getFullYear()+'-'+String(d2.getMonth()+1).padStart(2,'0')+'-'+String(d2.getDate()).padStart(2,'0');}
                  else dt=tm.getAttribute('aria-label')||tm.getAttribute('title')||tm.innerText||'';
                }
                self.seen[href]=true;out.push({url:href,text:raw.slice(0,3500),date:dt});
              });
              if(out.length&&window.AndroidFBF)window.AndroidFBF.onPosts(JSON.stringify(out));
            }
          };
        }
        if(window.AndroidFBF)window.FBF.start();
      })();
      """;
    web.evaluateJavascript(js,null);
  }
  public class Bridge{@JavascriptInterface public void onPosts(String json){try{JSONArray a=new JSONArray(json);synchronized(posts){for(int i=0;i<a.length();i++){JSONObject p=a.getJSONObject(i);String url=p.optString("url");if(!url.isEmpty())posts.put(url,p);}}runOnUiThread(()->refreshResults());}catch(Exception ignored){}}}
  private boolean matchesSelectedDate(String raw){
    int yp=year.getSelectedItemPosition(), mp=month.getSelectedItemPosition(); if(yp==0&&mp==0)return true;
    if(raw==null||raw.isEmpty())return false; String t=raw.toLowerCase(Locale.ROOT);
    int foundYear=-1; java.util.regex.Matcher m=java.util.regex.Pattern.compile("(19|20)\\d{2}").matcher(t); if(m.find())foundYear=Integer.parseInt(m.group());
    boolean dateKnown=foundYear!=-1||t.matches(".*\\d{4}-\\d{2}-\\d{2}.*")||t.contains("january")||t.contains("february")||t.contains("march")||t.contains("april")||t.contains("may")||t.contains("june")||t.contains("july")||t.contains("august")||t.contains("september")||t.contains("october")||t.contains("november")||t.contains("december")||t.contains("يناير")||t.contains("فبراير")||t.contains("مارس")||t.contains("أبريل")||t.contains("مايو")||t.contains("يونيو")||t.contains("يوليو")||t.contains("أغسطس")||t.contains("سبتمبر")||t.contains("أكتوبر")||t.contains("نوفمبر")||t.contains("ديسمبر");
    if(!dateKnown)return true; // احتفظ بالمنشور إذا لم يعرض فيسبوك تاريخاً قابلاً للقراءة
    if(yp>0&&foundYear!=-1&&foundYear!=Integer.parseInt(year.getSelectedItem().toString()))return false;
    if(yp>0&&foundYear==-1)return true;
    if(mp>0){String[] en={"january","february","march","april","may","june","july","august","september","october","november","december"};String[] ar={"يناير","فبراير","مارس","أبريل","مايو","يونيو","يوليو","أغسطس","سبتمبر","أكتوبر","نوفمبر","ديسمبر"};int n=mp-1;String mm=String.format(Locale.ROOT,"%02d",n+1);boolean found=t.contains(en[n])||t.contains(ar[n])||t.contains("-"+mm)||t.matches(".*(^|\\D)"+(n+1)+"[/-]"+".*");if(!found)return false;}
    return true;
  }
  private void refreshResults(){runOnUiThread(()->{count.setText("النتائج الملتقطة: "+posts.size());resultsTab.setText("النتائج ("+posts.size()+")");LinearLayout list=(LinearLayout)resultsScroll.getChildAt(0);list.removeAllViews();if(posts.isEmpty()){TextView e=text(collecting?"بانتظار تحميل المنشورات من فيسبوك…":"لا توجد نتائج بعد. ابدأ بحثاً من تبويب البحث.",14,Color.GRAY);e.setGravity(17);e.setPadding(dp(15),dp(35),dp(15),dp(35));list.addView(e);return;}ArrayList<JSONObject> arr=new ArrayList<>();for(JSONObject item:posts.values())if(matchesSelectedDate(item.optString("date")))arr.add(item);Collections.reverse(arr);if(arr.isEmpty()){TextView e=text("تم التقاط "+posts.size()+" منشوراً، لكن لا توجد نتائج تطابق الفترة المحددة أو لم يتمكن فيسبوك من إظهار تاريخها. جرّب كل السنوات والأشهر.",13,Color.GRAY);e.setPadding(dp(12),dp(20),dp(12),dp(20));list.addView(e);return;}for(JSONObject p:arr){String body=p.optString("text");String date=p.optString("date");String url=p.optString("url");LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(14),dp(12),dp(14),dp(12));card.setBackgroundTintList(null);card.setBackgroundColor(Color.WHITE);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.bottomMargin=dp(8);list.addView(card,cp);TextView tx=text(body.length()>520?body.substring(0,520)+"…":body,14,DARK);card.addView(tx);TextView meta=text((date.isEmpty()?"تاريخ غير محدد":date)+"  ·  منشور ظاهر في نتائج فيسبوك",11,Color.GRAY);meta.setPadding(0,dp(8),0,dp(5));card.addView(meta);Button open=button("فتح المنشور والتعليقات");card.addView(open);open.setOnClickListener(v->{detail=true;collecting=false;web.evaluateJavascript("window.FBF && FBF.stop()",null);showBrowser();web.loadUrl(url);});}});}
  @Override public void onBackPressed(){if(detail){detail=false;showResults();return;}if(web.getVisibility()==View.VISIBLE){showResults();return;}if(resultsBox.getVisibility()==View.VISIBLE){searchBox.setVisibility(View.VISIBLE);resultsBox.setVisibility(View.GONE);return;}super.onBackPressed();}
}
