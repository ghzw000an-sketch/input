.class public final Landroidx/media3/common/audio/ToInt16PcmAudioProcessor;
.super Landroidx/media3/common/audio/BaseAudioProcessor;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 43
    invoke-direct {p0}, Landroidx/media3/common/audio/BaseAudioProcessor;-><init>()V

    return-void
.end method


# virtual methods
.method public onConfigure(Landroidx/media3/common/audio/AudioProcessor$AudioFormat;)Landroidx/media3/common/audio/AudioProcessor$AudioFormat;
    .locals 5
    .param p1, "inputAudioFormat"    # Landroidx/media3/common/audio/AudioProcessor$AudioFormat;

    .line 48
    iget v0, p1, Landroidx/media3/common/audio/AudioProcessor$AudioFormat;->encoding:I

    .line 49
    .local v0, "encoding":I
    invoke-static {v0}, Landroidx/media3/common/util/Util;->isEncodingLinearPcm(I)Z

    move-result v1

    if-eqz v1, :cond_1

    .line 52
    const/4 v1, 0x2

    if-eq v0, v1, :cond_0

    .line 53
    new-instance v2, Landroidx/media3/common/audio/AudioProcessor$AudioFormat;

    iget v3, p1, Landroidx/media3/common/audio/AudioProcessor$AudioFormat;->sampleRate:I

    iget v4, p1, Landroidx/media3/common/audio/AudioProcessor$AudioFormat;->channelCount:I

    invoke-direct {v2, v3, v4, v1}, Landroidx/media3/common/audio/AudioProcessor$AudioFormat;-><init>(III)V

    goto :goto_0

    .line 55
    :cond_0
    sget-object v2, Landroidx/media3/common/audio/AudioProcessor$AudioFormat;->NOT_SET:Landroidx/media3/common/audio/AudioProcessor$AudioFormat;

    .line 52
    :goto_0
    return-object v2

    .line 50
    :cond_1
    new-instance v1, Landroidx/media3/common/audio/AudioProcessor$UnhandledAudioFormatException;

    invoke-direct {v1, p1}, Landroidx/media3/common/audio/AudioProcessor$UnhandledAudioFormatException;-><init>(Landroidx/media3/common/audio/AudioProcessor$AudioFormat;)V

    throw v1
.end method

.method public queueInput(Ljava/nio/ByteBuffer;)V
    .locals 19
    .param p1, "inputBuffer"    # Ljava/nio/ByteBuffer;

    .line 61
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual {v1}, Ljava/nio/Buffer;->position()I

    move-result v2

    .line 62
    .local v2, "position":I
    invoke-virtual {v1}, Ljava/nio/Buffer;->limit()I

    move-result v3

    .line 63
    .local v3, "limit":I
    sub-int v4, v3, v2

    .line 65
    .local v4, "size":I
    iget-object v5, v0, Landroidx/media3/common/audio/BaseAudioProcessor;->inputAudioFormat:Landroidx/media3/common/audio/AudioProcessor$AudioFormat;

    iget v5, v5, Landroidx/media3/common/audio/AudioProcessor$AudioFormat;->encoding:I

    sparse-switch v5, :sswitch_data_0

    .line 90
    new-instance v5, Ljava/lang/IllegalStateException;

    invoke-direct {v5}, Ljava/lang/IllegalStateException;-><init>()V

    throw v5

    .line 84
    :sswitch_0
    div-int/lit8 v5, v4, 0x4

    .line 85
    .local v5, "resampledSize":I
    goto :goto_0

    .line 70
    .end local v5    # "resampledSize":I
    :sswitch_1
    move v5, v4

    .line 71
    .restart local v5    # "resampledSize":I
    goto :goto_0

    .line 74
    .end local v5    # "resampledSize":I
    :sswitch_2
    div-int/lit8 v5, v4, 0x3

    mul-int/lit8 v5, v5, 0x2

    .line 75
    .restart local v5    # "resampledSize":I
    goto :goto_0

    .line 80
    .end local v5    # "resampledSize":I
    :sswitch_3
    div-int/lit8 v5, v4, 0x2

    .line 81
    .restart local v5    # "resampledSize":I
    goto :goto_0

    .line 67
    .end local v5    # "resampledSize":I
    :sswitch_4
    mul-int/lit8 v5, v4, 0x2

    .line 68
    .restart local v5    # "resampledSize":I
    nop

    .line 94
    :goto_0
    invoke-virtual {v0, v5}, Landroidx/media3/common/audio/BaseAudioProcessor;->replaceOutputBuffer(I)Ljava/nio/ByteBuffer;

    move-result-object v6

    .line 95
    .local v6, "buffer":Ljava/nio/ByteBuffer;
    iget-object v7, v0, Landroidx/media3/common/audio/BaseAudioProcessor;->inputAudioFormat:Landroidx/media3/common/audio/AudioProcessor$AudioFormat;

    iget v7, v7, Landroidx/media3/common/audio/AudioProcessor$AudioFormat;->encoding:I

    const v8, 0x46fffe00    # 32767.0f

    const/high16 v9, 0x3f800000    # 1.0f

    const/high16 v10, -0x40800000    # -1.0f

    const-wide v11, 0x40dfffc000000000L    # 32767.0

    sparse-switch v7, :sswitch_data_1

    .line 201
    new-instance v7, Ljava/lang/IllegalStateException;

    invoke-direct {v7}, Ljava/lang/IllegalStateException;-><init>()V

    throw v7

    .line 183
    :sswitch_5
    move v7, v2

    .local v7, "i":I
    :goto_1
    if-ge v7, v3, :cond_0

    .line 186
    nop

    .line 188
    invoke-virtual {v1, v7}, Ljava/nio/ByteBuffer;->getLong(I)J

    move-result-wide v8

    invoke-static {v8, v9}, Ljava/lang/Long;->reverseBytes(J)J

    move-result-wide v8

    invoke-static {v8, v9}, Ljava/lang/Double;->longBitsToDouble(J)D

    move-result-wide v13

    .line 187
    const-wide/high16 v15, -0x4010000000000000L    # -1.0

    const-wide/high16 v17, 0x3ff0000000000000L    # 1.0

    invoke-static/range {v13 .. v18}, Landroidx/media3/common/util/Util;->constrainValue(DDD)D

    move-result-wide v8

    .line 191
    .local v8, "doubleValue":D
    mul-double v13, v8, v11

    double-to-int v10, v13

    int-to-short v10, v10

    .line 192
    .local v10, "shortValue":S
    and-int/lit16 v13, v10, 0xff

    int-to-byte v13, v13

    invoke-virtual {v6, v13}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    .line 193
    shr-int/lit8 v13, v10, 0x8

    and-int/lit16 v13, v13, 0xff

    int-to-byte v13, v13

    invoke-virtual {v6, v13}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    .line 183
    .end local v8    # "doubleValue":D
    .end local v10    # "shortValue":S
    add-int/lit8 v7, v7, 0x8

    goto :goto_1

    :cond_0
    nop

    .line 195
    .end local v7    # "i":I
    goto/16 :goto_b

    .line 154
    :sswitch_6
    move v7, v2

    .restart local v7    # "i":I
    :goto_2
    if-ge v7, v3, :cond_1

    .line 157
    nop

    .line 159
    invoke-virtual {v1, v7}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v11

    invoke-static {v11}, Ljava/lang/Integer;->reverseBytes(I)I

    move-result v11

    invoke-static {v11}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v11

    .line 158
    invoke-static {v11, v10, v9}, Landroidx/media3/common/util/Util;->constrainValue(FFF)F

    move-result v11

    .line 162
    .local v11, "floatValue":F
    mul-float v12, v11, v8

    float-to-int v12, v12

    int-to-short v12, v12

    .line 163
    .local v12, "shortValue":S
    and-int/lit16 v13, v12, 0xff

    int-to-byte v13, v13

    invoke-virtual {v6, v13}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    .line 164
    shr-int/lit8 v13, v12, 0x8

    and-int/lit16 v13, v13, 0xff

    int-to-byte v13, v13

    invoke-virtual {v6, v13}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    .line 154
    .end local v11    # "floatValue":F
    .end local v12    # "shortValue":S
    add-int/lit8 v7, v7, 0x4

    goto :goto_2

    :cond_1
    nop

    .line 166
    .end local v7    # "i":I
    goto/16 :goto_b

    .line 170
    :sswitch_7
    move v7, v2

    .restart local v7    # "i":I
    :goto_3
    if-ge v7, v3, :cond_2

    .line 173
    nop

    .line 174
    invoke-virtual {v1, v7}, Ljava/nio/ByteBuffer;->getDouble(I)D

    move-result-wide v13

    const-wide/high16 v15, -0x4010000000000000L    # -1.0

    const-wide/high16 v17, 0x3ff0000000000000L    # 1.0

    invoke-static/range {v13 .. v18}, Landroidx/media3/common/util/Util;->constrainValue(DDD)D

    move-result-wide v8

    .line 175
    .restart local v8    # "doubleValue":D
    mul-double v13, v8, v11

    double-to-int v10, v13

    int-to-short v10, v10

    .line 176
    .restart local v10    # "shortValue":S
    and-int/lit16 v13, v10, 0xff

    int-to-byte v13, v13

    invoke-virtual {v6, v13}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    .line 177
    shr-int/lit8 v13, v10, 0x8

    and-int/lit16 v13, v13, 0xff

    int-to-byte v13, v13

    invoke-virtual {v6, v13}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    .line 170
    .end local v8    # "doubleValue":D
    .end local v10    # "shortValue":S
    add-int/lit8 v7, v7, 0x8

    goto :goto_3

    :cond_2
    nop

    .line 179
    .end local v7    # "i":I
    goto/16 :goto_b

    .line 133
    :sswitch_8
    move v7, v2

    .restart local v7    # "i":I
    :goto_4
    if-ge v7, v3, :cond_3

    .line 134
    add-int/lit8 v8, v7, 0x1

    invoke-virtual {v1, v8}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v8

    invoke-virtual {v6, v8}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    .line 135
    invoke-virtual {v1, v7}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v8

    invoke-virtual {v6, v8}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    .line 133
    add-int/lit8 v7, v7, 0x4

    goto :goto_4

    :cond_3
    nop

    .line 137
    .end local v7    # "i":I
    goto/16 :goto_b

    .line 119
    :sswitch_9
    move v7, v2

    .restart local v7    # "i":I
    :goto_5
    if-ge v7, v3, :cond_4

    .line 120
    add-int/lit8 v8, v7, 0x1

    invoke-virtual {v1, v8}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v8

    invoke-virtual {v6, v8}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    .line 121
    invoke-virtual {v1, v7}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v8

    invoke-virtual {v6, v8}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    .line 119
    add-int/lit8 v7, v7, 0x3

    goto :goto_5

    :cond_4
    nop

    .line 123
    .end local v7    # "i":I
    goto/16 :goto_b

    .line 105
    :sswitch_a
    move v7, v2

    .restart local v7    # "i":I
    :goto_6
    if-ge v7, v3, :cond_5

    .line 106
    add-int/lit8 v8, v7, 0x1

    invoke-virtual {v1, v8}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v8

    invoke-virtual {v6, v8}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    .line 107
    invoke-virtual {v1, v7}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v8

    invoke-virtual {v6, v8}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    .line 105
    add-int/lit8 v7, v7, 0x2

    goto :goto_6

    :cond_5
    nop

    .line 109
    .end local v7    # "i":I
    goto/16 :goto_b

    .line 126
    :sswitch_b
    move v7, v2

    .restart local v7    # "i":I
    :goto_7
    if-ge v7, v3, :cond_6

    .line 127
    add-int/lit8 v8, v7, 0x2

    invoke-virtual {v1, v8}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v8

    invoke-virtual {v6, v8}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    .line 128
    add-int/lit8 v8, v7, 0x3

    invoke-virtual {v1, v8}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v8

    invoke-virtual {v6, v8}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    .line 126
    add-int/lit8 v7, v7, 0x4

    goto :goto_7

    :cond_6
    nop

    .line 130
    .end local v7    # "i":I
    goto :goto_b

    .line 112
    :sswitch_c
    move v7, v2

    .restart local v7    # "i":I
    :goto_8
    if-ge v7, v3, :cond_7

    .line 113
    add-int/lit8 v8, v7, 0x1

    invoke-virtual {v1, v8}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v8

    invoke-virtual {v6, v8}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    .line 114
    add-int/lit8 v8, v7, 0x2

    invoke-virtual {v1, v8}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v8

    invoke-virtual {v6, v8}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    .line 112
    add-int/lit8 v7, v7, 0x3

    goto :goto_8

    :cond_7
    nop

    .line 116
    .end local v7    # "i":I
    goto :goto_b

    .line 141
    :sswitch_d
    move v7, v2

    .restart local v7    # "i":I
    :goto_9
    if-ge v7, v3, :cond_8

    .line 144
    nop

    .line 145
    invoke-virtual {v1, v7}, Ljava/nio/ByteBuffer;->getFloat(I)F

    move-result v11

    invoke-static {v11, v10, v9}, Landroidx/media3/common/util/Util;->constrainValue(FFF)F

    move-result v11

    .line 146
    .restart local v11    # "floatValue":F
    mul-float v12, v11, v8

    float-to-int v12, v12

    int-to-short v12, v12

    .line 147
    .restart local v12    # "shortValue":S
    and-int/lit16 v13, v12, 0xff

    int-to-byte v13, v13

    invoke-virtual {v6, v13}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    .line 148
    shr-int/lit8 v13, v12, 0x8

    and-int/lit16 v13, v13, 0xff

    int-to-byte v13, v13

    invoke-virtual {v6, v13}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    .line 141
    .end local v11    # "floatValue":F
    .end local v12    # "shortValue":S
    add-int/lit8 v7, v7, 0x4

    goto :goto_9

    :cond_8
    nop

    .line 150
    .end local v7    # "i":I
    goto :goto_b

    .line 98
    :sswitch_e
    move v7, v2

    .restart local v7    # "i":I
    :goto_a
    if-ge v7, v3, :cond_9

    .line 99
    const/4 v8, 0x0

    invoke-virtual {v6, v8}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    .line 100
    invoke-virtual {v1, v7}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v8

    and-int/lit16 v8, v8, 0xff

    add-int/lit8 v8, v8, -0x80

    int-to-byte v8, v8

    invoke-virtual {v6, v8}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    .line 98
    add-int/lit8 v7, v7, 0x1

    goto :goto_a

    :cond_9
    nop

    .line 102
    .end local v7    # "i":I
    nop

    .line 203
    :goto_b
    invoke-virtual {v1}, Ljava/nio/Buffer;->limit()I

    move-result v7

    invoke-virtual {v1, v7}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    .line 204
    invoke-virtual {v6}, Ljava/nio/ByteBuffer;->flip()Ljava/nio/Buffer;

    .line 205
    return-void

    nop

    :sswitch_data_0
    .sparse-switch
        0x3 -> :sswitch_4
        0x4 -> :sswitch_3
        0x15 -> :sswitch_2
        0x16 -> :sswitch_3
        0x10000000 -> :sswitch_1
        0x50000000 -> :sswitch_2
        0x60000000 -> :sswitch_3
        0x70000000 -> :sswitch_0
        0x71000000 -> :sswitch_3
        0x72000000 -> :sswitch_0
    .end sparse-switch

    :sswitch_data_1
    .sparse-switch
        0x3 -> :sswitch_e
        0x4 -> :sswitch_d
        0x15 -> :sswitch_c
        0x16 -> :sswitch_b
        0x10000000 -> :sswitch_a
        0x50000000 -> :sswitch_9
        0x60000000 -> :sswitch_8
        0x70000000 -> :sswitch_7
        0x71000000 -> :sswitch_6
        0x72000000 -> :sswitch_5
    .end sparse-switch
.end method
