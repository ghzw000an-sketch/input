.class public final Landroidx/media3/common/audio/AudioProcessor$StreamMetadata;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/media3/common/audio/AudioProcessor;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "StreamMetadata"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/media3/common/audio/AudioProcessor$StreamMetadata$Builder;
    }
.end annotation


# static fields
.field public static final DEFAULT:Landroidx/media3/common/audio/AudioProcessor$StreamMetadata;


# instance fields
.field public final periodUid:Ljava/lang/Object;

.field public final positionOffsetUs:J

.field public final timeline:Landroidx/media3/common/Timeline;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 140
    new-instance v0, Landroidx/media3/common/audio/AudioProcessor$StreamMetadata$Builder;

    invoke-direct {v0}, Landroidx/media3/common/audio/AudioProcessor$StreamMetadata$Builder;-><init>()V

    invoke-virtual {v0}, Landroidx/media3/common/audio/AudioProcessor$StreamMetadata$Builder;->build()Landroidx/media3/common/audio/AudioProcessor$StreamMetadata;

    move-result-object v0

    sput-object v0, Landroidx/media3/common/audio/AudioProcessor$StreamMetadata;->DEFAULT:Landroidx/media3/common/audio/AudioProcessor$StreamMetadata;

    return-void
.end method

.method public constructor <init>(Landroidx/media3/common/audio/AudioProcessor$StreamMetadata$Builder;)V
    .locals 2
    .param p1, "builder"    # Landroidx/media3/common/audio/AudioProcessor$StreamMetadata$Builder;

    .line 258
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 259
    invoke-static {p1}, Landroidx/media3/common/audio/AudioProcessor$StreamMetadata$Builder;->access$100(Landroidx/media3/common/audio/AudioProcessor$StreamMetadata$Builder;)J

    move-result-wide v0

    iput-wide v0, p0, Landroidx/media3/common/audio/AudioProcessor$StreamMetadata;->positionOffsetUs:J

    .line 260
    invoke-static {p1}, Landroidx/media3/common/audio/AudioProcessor$StreamMetadata$Builder;->access$200(Landroidx/media3/common/audio/AudioProcessor$StreamMetadata$Builder;)Landroidx/media3/common/Timeline;

    move-result-object v0

    iput-object v0, p0, Landroidx/media3/common/audio/AudioProcessor$StreamMetadata;->timeline:Landroidx/media3/common/Timeline;

    .line 261
    invoke-static {p1}, Landroidx/media3/common/audio/AudioProcessor$StreamMetadata$Builder;->access$300(Landroidx/media3/common/audio/AudioProcessor$StreamMetadata$Builder;)Ljava/lang/Object;

    move-result-object v0

    iput-object v0, p0, Landroidx/media3/common/audio/AudioProcessor$StreamMetadata;->periodUid:Ljava/lang/Object;

    .line 262
    return-void
.end method

.method public synthetic constructor <init>(Landroidx/media3/common/audio/AudioProcessor$StreamMetadata$Builder;Landroidx/media3/common/audio/AudioProcessor$1;)V
    .locals 0
    .param p1, "x0"    # Landroidx/media3/common/audio/AudioProcessor$StreamMetadata$Builder;
    .param p2, "x1"    # Landroidx/media3/common/audio/AudioProcessor$1;

    .line 137
    invoke-direct {p0, p1}, Landroidx/media3/common/audio/AudioProcessor$StreamMetadata;-><init>(Landroidx/media3/common/audio/AudioProcessor$StreamMetadata$Builder;)V

    return-void
.end method


# virtual methods
.method public buildUpon()Landroidx/media3/common/audio/AudioProcessor$StreamMetadata$Builder;
    .locals 2

    .line 266
    new-instance v0, Landroidx/media3/common/audio/AudioProcessor$StreamMetadata$Builder;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Landroidx/media3/common/audio/AudioProcessor$StreamMetadata$Builder;-><init>(Landroidx/media3/common/audio/AudioProcessor$StreamMetadata;Landroidx/media3/common/audio/AudioProcessor$1;)V

    return-object v0
.end method
