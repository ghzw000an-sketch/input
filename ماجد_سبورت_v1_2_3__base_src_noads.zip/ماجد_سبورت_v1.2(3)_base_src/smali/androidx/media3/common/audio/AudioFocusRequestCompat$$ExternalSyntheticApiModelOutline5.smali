.class public abstract synthetic Landroidx/media3/common/audio/AudioFocusRequestCompat$$ExternalSyntheticApiModelOutline5;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static bridge synthetic m(Landroid/media/AudioFocusRequest$Builder;)Landroid/media/AudioFocusRequest;
    .locals 0

    .line 0
    invoke-virtual {p0}, Landroid/media/AudioFocusRequest$Builder;->build()Landroid/media/AudioFocusRequest;

    move-result-object p0

    return-object p0
.end method
