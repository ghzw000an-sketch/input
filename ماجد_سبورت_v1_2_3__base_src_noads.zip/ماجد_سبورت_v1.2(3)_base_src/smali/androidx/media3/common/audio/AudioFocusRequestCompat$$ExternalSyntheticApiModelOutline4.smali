.class public abstract synthetic Landroidx/media3/common/audio/AudioFocusRequestCompat$$ExternalSyntheticApiModelOutline4;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static bridge synthetic m(Landroid/media/AudioFocusRequest$Builder;Z)Landroid/media/AudioFocusRequest$Builder;
    .locals 0

    .line 0
    invoke-virtual {p0, p1}, Landroid/media/AudioFocusRequest$Builder;->setAcceptsDelayedFocusGain(Z)Landroid/media/AudioFocusRequest$Builder;

    move-result-object p0

    return-object p0
.end method
