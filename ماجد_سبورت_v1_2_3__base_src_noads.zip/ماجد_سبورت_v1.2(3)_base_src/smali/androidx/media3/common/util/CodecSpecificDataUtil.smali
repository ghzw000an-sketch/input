.class public abstract Landroidx/media3/common/util/CodecSpecificDataUtil;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;
    }
.end annotation


# static fields
.field public static final HEVC_GENERAL_PROFILE_SPACE_STRINGS:[Ljava/lang/String;

.field public static final NAL_START_CODE:[B

.field public static final PROFILE_PATTERN:Ljava/util/regex/Pattern;

.field public static final expectedHagcPayloadPrefix:[B


# direct methods
.method static constructor <clinit>()V
    .locals 4

    .line 122
    const/4 v0, 0x4

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    sput-object v0, Landroidx/media3/common/util/CodecSpecificDataUtil;->NAL_START_CODE:[B

    .line 123
    const-string v0, "B"

    const-string v1, "C"

    const-string v2, ""

    const-string v3, "A"

    filled-new-array {v2, v3, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Landroidx/media3/common/util/CodecSpecificDataUtil;->HEVC_GENERAL_PROFILE_SPACE_STRINGS:[Ljava/lang/String;

    .line 202
    const-string v0, "^\\D?(\\d+)$"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    sput-object v0, Landroidx/media3/common/util/CodecSpecificDataUtil;->PROFILE_PATTERN:Ljava/util/regex/Pattern;

    .line 2367
    const/4 v0, 0x5

    new-array v0, v0, [B

    fill-array-data v0, :array_1

    sput-object v0, Landroidx/media3/common/util/CodecSpecificDataUtil;->expectedHagcPayloadPrefix:[B

    return-void

    nop

    :array_0
    .array-data 1
        0x0t
        0x0t
        0x0t
        0x1t
    .end array-data

    :array_1
    .array-data 1
        -0x4bt
        0x0t
        -0x70t
        0x0t
        0x1t
    .end array-data
.end method

.method public static ac4BitstreamAndPresentationVersionsToProfileConst(II)I
    .locals 2
    .param p0, "bitstreamVersionInteger"    # I
    .param p1, "presentationVersionInteger"    # I

    .line 2212
    const/4 v0, -0x1

    .line 2213
    .local v0, "ac4Profile":I
    const/4 v1, 0x1

    packed-switch p0, :pswitch_data_0

    goto :goto_0

    .line 2227
    :pswitch_0
    if-ne p1, v1, :cond_0

    .line 2228
    const/16 v0, 0x402

    goto :goto_0

    .line 2229
    :cond_0
    const/4 v1, 0x2

    if-ne p1, v1, :cond_2

    .line 2230
    const/16 v0, 0x404

    goto :goto_0

    .line 2220
    :pswitch_1
    if-nez p1, :cond_1

    .line 2221
    const/16 v0, 0x201

    goto :goto_0

    .line 2222
    :cond_1
    if-ne p1, v1, :cond_2

    .line 2223
    const/16 v0, 0x202

    goto :goto_0

    .line 2215
    :pswitch_2
    if-nez p1, :cond_2

    .line 2216
    const/16 v0, 0x101

    .line 2236
    :cond_2
    :goto_0
    return v0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static ac4LevelNumberToConst(I)I
    .locals 1
    .param p0, "levelNumber"    # I

    .line 2240
    packed-switch p0, :pswitch_data_0

    .line 2252
    const/4 v0, -0x1

    return v0

    .line 2250
    :pswitch_0
    const/16 v0, 0x10

    return v0

    .line 2248
    :pswitch_1
    const/16 v0, 0x8

    return v0

    .line 2246
    :pswitch_2
    const/4 v0, 0x4

    return v0

    .line 2244
    :pswitch_3
    const/4 v0, 0x2

    return v0

    .line 2242
    :pswitch_4
    const/4 v0, 0x1

    return v0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static apvLevelAndBandNumberToConst(II)I
    .locals 4
    .param p0, "levelNumber"    # I
    .param p1, "bandNumber"    # I

    .line 1540
    const-string v0, "Unrecognized APV band: "

    const/4 v1, -0x1

    const-string v2, "CodecSpecificDataUtil"

    sparse-switch p0, :sswitch_data_0

    .line 1738
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Unrecognized APV level index: "

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1739
    return v1

    .line 1724
    :sswitch_0
    packed-switch p1, :pswitch_data_0

    .line 1734
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1735
    return v1

    .line 1732
    :pswitch_0
    const v0, 0x200008

    return v0

    .line 1730
    :pswitch_1
    const v0, 0x200004

    return v0

    .line 1728
    :pswitch_2
    const v0, 0x200002

    return v0

    .line 1726
    :pswitch_3
    const v0, 0x200001

    return v0

    .line 1710
    :sswitch_1
    packed-switch p1, :pswitch_data_1

    .line 1720
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1721
    return v1

    .line 1718
    :pswitch_4
    const v0, 0x100008

    return v0

    .line 1716
    :pswitch_5
    const v0, 0x100004

    return v0

    .line 1714
    :pswitch_6
    const v0, 0x100002

    return v0

    .line 1712
    :pswitch_7
    const v0, 0x100001

    return v0

    .line 1696
    :sswitch_2
    packed-switch p1, :pswitch_data_2

    .line 1706
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1707
    return v1

    .line 1704
    :pswitch_8
    const v0, 0x80008

    return v0

    .line 1702
    :pswitch_9
    const v0, 0x80004

    return v0

    .line 1700
    :pswitch_a
    const v0, 0x80002

    return v0

    .line 1698
    :pswitch_b
    const v0, 0x80001

    return v0

    .line 1682
    :sswitch_3
    packed-switch p1, :pswitch_data_3

    .line 1692
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1693
    return v1

    .line 1690
    :pswitch_c
    const v0, 0x40008

    return v0

    .line 1688
    :pswitch_d
    const v0, 0x40004

    return v0

    .line 1686
    :pswitch_e
    const v0, 0x40002

    return v0

    .line 1684
    :pswitch_f
    const v0, 0x40001

    return v0

    .line 1668
    :sswitch_4
    packed-switch p1, :pswitch_data_4

    .line 1678
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1679
    return v1

    .line 1676
    :pswitch_10
    const v0, 0x20008

    return v0

    .line 1674
    :pswitch_11
    const v0, 0x20004

    return v0

    .line 1672
    :pswitch_12
    const v0, 0x20002

    return v0

    .line 1670
    :pswitch_13
    const v0, 0x20001

    return v0

    .line 1654
    :sswitch_5
    packed-switch p1, :pswitch_data_5

    .line 1664
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1665
    return v1

    .line 1662
    :pswitch_14
    const v0, 0x10008

    return v0

    .line 1660
    :pswitch_15
    const v0, 0x10004

    return v0

    .line 1658
    :pswitch_16
    const v0, 0x10002

    return v0

    .line 1656
    :pswitch_17
    const v0, 0x10001

    return v0

    .line 1640
    :sswitch_6
    packed-switch p1, :pswitch_data_6

    .line 1650
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1651
    return v1

    .line 1648
    :pswitch_18
    const v0, 0x8008

    return v0

    .line 1646
    :pswitch_19
    const v0, 0x8004

    return v0

    .line 1644
    :pswitch_1a
    const v0, 0x8002

    return v0

    .line 1642
    :pswitch_1b
    const v0, 0x8001

    return v0

    .line 1626
    :sswitch_7
    packed-switch p1, :pswitch_data_7

    .line 1636
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1637
    return v1

    .line 1634
    :pswitch_1c
    const/16 v0, 0x4008

    return v0

    .line 1632
    :pswitch_1d
    const/16 v0, 0x4004

    return v0

    .line 1630
    :pswitch_1e
    const/16 v0, 0x4002

    return v0

    .line 1628
    :pswitch_1f
    const/16 v0, 0x4001

    return v0

    .line 1612
    :sswitch_8
    packed-switch p1, :pswitch_data_8

    .line 1622
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1623
    return v1

    .line 1620
    :pswitch_20
    const/16 v0, 0x2008

    return v0

    .line 1618
    :pswitch_21
    const/16 v0, 0x2004

    return v0

    .line 1616
    :pswitch_22
    const/16 v0, 0x2002

    return v0

    .line 1614
    :pswitch_23
    const/16 v0, 0x2001

    return v0

    .line 1598
    :sswitch_9
    packed-switch p1, :pswitch_data_9

    .line 1608
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1609
    return v1

    .line 1606
    :pswitch_24
    const/16 v0, 0x1008

    return v0

    .line 1604
    :pswitch_25
    const/16 v0, 0x1004

    return v0

    .line 1602
    :pswitch_26
    const/16 v0, 0x1002

    return v0

    .line 1600
    :pswitch_27
    const/16 v0, 0x1001

    return v0

    .line 1584
    :sswitch_a
    packed-switch p1, :pswitch_data_a

    .line 1594
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1595
    return v1

    .line 1592
    :pswitch_28
    const/16 v0, 0x808

    return v0

    .line 1590
    :pswitch_29
    const/16 v0, 0x804

    return v0

    .line 1588
    :pswitch_2a
    const/16 v0, 0x802

    return v0

    .line 1586
    :pswitch_2b
    const/16 v0, 0x801

    return v0

    .line 1570
    :sswitch_b
    packed-switch p1, :pswitch_data_b

    .line 1580
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1581
    return v1

    .line 1578
    :pswitch_2c
    const/16 v0, 0x408

    return v0

    .line 1576
    :pswitch_2d
    const/16 v0, 0x404

    return v0

    .line 1574
    :pswitch_2e
    const/16 v0, 0x402

    return v0

    .line 1572
    :pswitch_2f
    const/16 v0, 0x401

    return v0

    .line 1556
    :sswitch_c
    packed-switch p1, :pswitch_data_c

    .line 1566
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1567
    return v1

    .line 1564
    :pswitch_30
    const/16 v0, 0x208

    return v0

    .line 1562
    :pswitch_31
    const/16 v0, 0x204

    return v0

    .line 1560
    :pswitch_32
    const/16 v0, 0x202

    return v0

    .line 1558
    :pswitch_33
    const/16 v0, 0x201

    return v0

    .line 1542
    :sswitch_d
    packed-switch p1, :pswitch_data_d

    .line 1552
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1553
    return v1

    .line 1550
    :pswitch_34
    const/16 v0, 0x108

    return v0

    .line 1548
    :pswitch_35
    const/16 v0, 0x104

    return v0

    .line 1546
    :pswitch_36
    const/16 v0, 0x102

    return v0

    .line 1544
    :pswitch_37
    const/16 v0, 0x101

    return v0

    nop

    :sswitch_data_0
    .sparse-switch
        0x1e -> :sswitch_d
        0x21 -> :sswitch_c
        0x3c -> :sswitch_b
        0x3f -> :sswitch_a
        0x5a -> :sswitch_9
        0x5d -> :sswitch_8
        0x78 -> :sswitch_7
        0x7b -> :sswitch_6
        0x96 -> :sswitch_5
        0x99 -> :sswitch_4
        0xb4 -> :sswitch_3
        0xb7 -> :sswitch_2
        0xd2 -> :sswitch_1
        0xd5 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
    .end packed-switch

    :pswitch_data_2
    .packed-switch 0x0
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
    .end packed-switch

    :pswitch_data_3
    .packed-switch 0x0
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
    .end packed-switch

    :pswitch_data_4
    .packed-switch 0x0
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
    .end packed-switch

    :pswitch_data_5
    .packed-switch 0x0
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
    .end packed-switch

    :pswitch_data_6
    .packed-switch 0x0
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
    .end packed-switch

    :pswitch_data_7
    .packed-switch 0x0
        :pswitch_1f
        :pswitch_1e
        :pswitch_1d
        :pswitch_1c
    .end packed-switch

    :pswitch_data_8
    .packed-switch 0x0
        :pswitch_23
        :pswitch_22
        :pswitch_21
        :pswitch_20
    .end packed-switch

    :pswitch_data_9
    .packed-switch 0x0
        :pswitch_27
        :pswitch_26
        :pswitch_25
        :pswitch_24
    .end packed-switch

    :pswitch_data_a
    .packed-switch 0x0
        :pswitch_2b
        :pswitch_2a
        :pswitch_29
        :pswitch_28
    .end packed-switch

    :pswitch_data_b
    .packed-switch 0x0
        :pswitch_2f
        :pswitch_2e
        :pswitch_2d
        :pswitch_2c
    .end packed-switch

    :pswitch_data_c
    .packed-switch 0x0
        :pswitch_33
        :pswitch_32
        :pswitch_31
        :pswitch_30
    .end packed-switch

    :pswitch_data_d
    .packed-switch 0x0
        :pswitch_37
        :pswitch_36
        :pswitch_35
        :pswitch_34
    .end packed-switch
.end method

.method public static av1LevelNumberToConst(I)I
    .locals 1
    .param p0, "levelNumber"    # I

    .line 2125
    packed-switch p0, :pswitch_data_0

    .line 2175
    const/4 v0, -0x1

    return v0

    .line 2173
    :pswitch_0
    const/high16 v0, 0x800000

    return v0

    .line 2171
    :pswitch_1
    const/high16 v0, 0x400000

    return v0

    .line 2169
    :pswitch_2
    const/high16 v0, 0x200000

    return v0

    .line 2167
    :pswitch_3
    const/high16 v0, 0x100000

    return v0

    .line 2165
    :pswitch_4
    const/high16 v0, 0x80000

    return v0

    .line 2163
    :pswitch_5
    const/high16 v0, 0x40000

    return v0

    .line 2161
    :pswitch_6
    const/high16 v0, 0x20000

    return v0

    .line 2159
    :pswitch_7
    const/high16 v0, 0x10000

    return v0

    .line 2157
    :pswitch_8
    const v0, 0x8000

    return v0

    .line 2155
    :pswitch_9
    const/16 v0, 0x4000

    return v0

    .line 2153
    :pswitch_a
    const/16 v0, 0x2000

    return v0

    .line 2151
    :pswitch_b
    const/16 v0, 0x1000

    return v0

    .line 2149
    :pswitch_c
    const/16 v0, 0x800

    return v0

    .line 2147
    :pswitch_d
    const/16 v0, 0x400

    return v0

    .line 2145
    :pswitch_e
    const/16 v0, 0x200

    return v0

    .line 2143
    :pswitch_f
    const/16 v0, 0x100

    return v0

    .line 2141
    :pswitch_10
    const/16 v0, 0x80

    return v0

    .line 2139
    :pswitch_11
    const/16 v0, 0x40

    return v0

    .line 2137
    :pswitch_12
    const/16 v0, 0x20

    return v0

    .line 2135
    :pswitch_13
    const/16 v0, 0x10

    return v0

    .line 2133
    :pswitch_14
    const/16 v0, 0x8

    return v0

    .line 2131
    :pswitch_15
    const/4 v0, 0x4

    return v0

    .line 2129
    :pswitch_16
    const/4 v0, 0x2

    return v0

    .line 2127
    :pswitch_17
    const/4 v0, 0x1

    return v0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static avcLevelNumberToConst(I)I
    .locals 1
    .param p0, "levelNumber"    # I

    .line 1908
    sparse-switch p0, :sswitch_data_0

    .line 1942
    const/4 v0, -0x1

    return v0

    .line 1940
    :sswitch_0
    const/high16 v0, 0x10000

    return v0

    .line 1938
    :sswitch_1
    const v0, 0x8000

    return v0

    .line 1936
    :sswitch_2
    const/16 v0, 0x4000

    return v0

    .line 1934
    :sswitch_3
    const/16 v0, 0x2000

    return v0

    .line 1932
    :sswitch_4
    const/16 v0, 0x1000

    return v0

    .line 1930
    :sswitch_5
    const/16 v0, 0x800

    return v0

    .line 1928
    :sswitch_6
    const/16 v0, 0x400

    return v0

    .line 1926
    :sswitch_7
    const/16 v0, 0x200

    return v0

    .line 1924
    :sswitch_8
    const/16 v0, 0x100

    return v0

    .line 1922
    :sswitch_9
    const/16 v0, 0x80

    return v0

    .line 1920
    :sswitch_a
    const/16 v0, 0x40

    return v0

    .line 1918
    :sswitch_b
    const/16 v0, 0x20

    return v0

    .line 1916
    :sswitch_c
    const/16 v0, 0x10

    return v0

    .line 1914
    :sswitch_d
    const/16 v0, 0x8

    return v0

    .line 1912
    :sswitch_e
    const/4 v0, 0x4

    return v0

    .line 1910
    :sswitch_f
    const/4 v0, 0x1

    return v0

    :sswitch_data_0
    .sparse-switch
        0xa -> :sswitch_f
        0xb -> :sswitch_e
        0xc -> :sswitch_d
        0xd -> :sswitch_c
        0x14 -> :sswitch_b
        0x15 -> :sswitch_a
        0x16 -> :sswitch_9
        0x1e -> :sswitch_8
        0x1f -> :sswitch_7
        0x20 -> :sswitch_6
        0x28 -> :sswitch_5
        0x29 -> :sswitch_4
        0x2a -> :sswitch_3
        0x32 -> :sswitch_2
        0x33 -> :sswitch_1
        0x34 -> :sswitch_0
    .end sparse-switch
.end method

.method public static avcProfileNumberToConst(I)I
    .locals 1
    .param p0, "profileNumber"    # I

    .line 1886
    sparse-switch p0, :sswitch_data_0

    .line 1902
    const/4 v0, -0x1

    return v0

    .line 1900
    :sswitch_0
    const/16 v0, 0x40

    return v0

    .line 1898
    :sswitch_1
    const/16 v0, 0x20

    return v0

    .line 1896
    :sswitch_2
    const/16 v0, 0x10

    return v0

    .line 1894
    :sswitch_3
    const/16 v0, 0x8

    return v0

    .line 1892
    :sswitch_4
    const/4 v0, 0x4

    return v0

    .line 1890
    :sswitch_5
    const/4 v0, 0x2

    return v0

    .line 1888
    :sswitch_6
    const/4 v0, 0x1

    return v0

    nop

    :sswitch_data_0
    .sparse-switch
        0x42 -> :sswitch_6
        0x4d -> :sswitch_5
        0x58 -> :sswitch_4
        0x64 -> :sswitch_3
        0x6e -> :sswitch_2
        0x7a -> :sswitch_1
        0xf4 -> :sswitch_0
    .end sparse-switch
.end method

.method public static buildApvCodecString([B)Ljava/lang/String;
    .locals 6
    .param p0, "initializationData"    # [B

    .line 802
    array-length v0, p0

    const/16 v1, 0x11

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-lt v0, v1, :cond_0

    move v0, v2

    goto :goto_0

    :cond_0
    move v0, v3

    :goto_0
    const-string v1, "Invalid APV CSD length: %s"

    array-length v4, p0

    invoke-static {v0, v1, v4}, Lcom/google/common/base/Preconditions;->checkArgument(ZLjava/lang/String;I)V

    .line 804
    aget-byte v0, p0, v3

    if-ne v0, v2, :cond_1

    goto :goto_1

    :cond_1
    move v2, v3

    :goto_1
    const-string v0, "Invalid APV CSD version: %s"

    aget-byte v1, p0, v3

    invoke-static {v2, v0, v1}, Lcom/google/common/base/Preconditions;->checkArgument(ZLjava/lang/String;I)V

    .line 809
    const/4 v0, 0x5

    aget-byte v0, p0, v0

    invoke-static {v0}, Lcom/google/common/primitives/UnsignedBytes;->toInt(B)I

    move-result v0

    .line 810
    .local v0, "profile":I
    const/4 v1, 0x6

    aget-byte v1, p0, v1

    invoke-static {v1}, Lcom/google/common/primitives/UnsignedBytes;->toInt(B)I

    move-result v1

    .line 811
    .local v1, "level":I
    const/4 v2, 0x7

    aget-byte v2, p0, v2

    invoke-static {v2}, Lcom/google/common/primitives/UnsignedBytes;->toInt(B)I

    move-result v2

    .line 812
    .local v2, "band":I
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    filled-new-array {v3, v4, v5}, [Ljava/lang/Object;

    move-result-object v3

    const-string v4, "apv1.apvf%d.apvl%d.apvb%d"

    invoke-static {v4, v3}, Landroidx/media3/common/util/Util;->formatInvariant(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    return-object v3
.end method

.method public static buildAvcCodecString(III)Ljava/lang/String;
    .locals 3
    .param p0, "profileIdc"    # I
    .param p1, "constraintsFlagsAndReservedZero2Bits"    # I
    .param p2, "levelIdc"    # I

    .line 758
    nop

    .line 759
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    filled-new-array {v0, v1, v2}, [Ljava/lang/Object;

    move-result-object v0

    .line 758
    const-string v1, "avc1.%02X%02X%02X"

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static buildCea708InitializationData(Z)Ljava/util/List;
    .locals 3
    .param p0, "isWideAspectRatio"    # Z

    .line 232
    const/4 v0, 0x0

    const/4 v1, 0x1

    new-array v2, v1, [B

    if-eqz p0, :cond_0

    aput-byte v1, v2, v0

    goto :goto_0

    :cond_0
    aput-byte v0, v2, v0

    :goto_0
    invoke-static {v2}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public static buildHevcCodecString(IZII[II)Ljava/lang/String;
    .locals 6
    .param p0, "generalProfileSpace"    # I
    .param p1, "generalTierFlag"    # Z
    .param p2, "generalProfileIdc"    # I
    .param p3, "generalProfileCompatibilityFlags"    # I
    .param p4, "constraintBytes"    # [I
    .param p5, "generalLevelIdc"    # I

    .line 770
    new-instance v0, Ljava/lang/StringBuilder;

    sget-object v1, Landroidx/media3/common/util/CodecSpecificDataUtil;->HEVC_GENERAL_PROFILE_SPACE_STRINGS:[Ljava/lang/String;

    aget-object v1, v1, p0

    .line 775
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    .line 776
    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    .line 777
    if-eqz p1, :cond_0

    const/16 v4, 0x48

    goto :goto_0

    :cond_0
    const/16 v4, 0x4c

    :goto_0
    invoke-static {v4}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v4

    .line 778
    invoke-static {p5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    filled-new-array {v1, v2, v3, v4, v5}, [Ljava/lang/Object;

    move-result-object v1

    .line 772
    const-string v2, "hvc1.%s%d.%X.%c%d"

    invoke-static {v2, v1}, Landroidx/media3/common/util/Util;->formatInvariant(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 780
    .local v0, "builder":Ljava/lang/StringBuilder;
    array-length v1, p4

    .line 781
    .local v1, "trailingZeroIndex":I
    :goto_1
    if-lez v1, :cond_1

    add-int/lit8 v2, v1, -0x1

    aget v2, p4, v2

    if-nez v2, :cond_1

    .line 782
    add-int/lit8 v1, v1, -0x1

    goto :goto_1

    .line 784
    :cond_1
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_2
    if-ge v2, v1, :cond_2

    .line 785
    aget v3, p4, v2

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v3

    const-string v4, ".%02X"

    invoke-static {v4, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 784
    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    :cond_2
    nop

    .line 787
    .end local v2    # "i":I
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    return-object v2
.end method

.method public static buildIamfCodecString([B)Ljava/lang/String;
    .locals 13
    .param p0, "initializationData"    # [B

    .line 244
    new-instance v0, Landroidx/media3/common/util/ParsableByteArray;

    invoke-direct {v0, p0}, Landroidx/media3/common/util/ParsableByteArray;-><init>([B)V

    .line 246
    .local v0, "parsableByteArray":Landroidx/media3/common/util/ParsableByteArray;
    const/4 v1, 0x0

    .line 247
    .local v1, "iaSequenceHeader":Ljava/lang/String;
    const/4 v2, 0x0

    .line 249
    .local v2, "codecConfigCodecId":Ljava/lang/String;
    :goto_0
    invoke-virtual {v0}, Landroidx/media3/common/util/ParsableByteArray;->bytesLeft()I

    move-result v3

    if-lez v3, :cond_9

    if-eqz v1, :cond_0

    if-nez v2, :cond_9

    .line 254
    :cond_0
    invoke-virtual {v0}, Landroidx/media3/common/util/ParsableByteArray;->readUnsignedByte()I

    move-result v3

    .line 255
    .local v3, "obuHeaderByte":I
    shr-int/lit8 v4, v3, 0x3

    .line 257
    .local v4, "obuType":I
    and-int/lit8 v5, v3, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x1

    if-eqz v5, :cond_1

    move v5, v7

    goto :goto_1

    :cond_1
    move v5, v6

    .line 258
    .local v5, "obuTrimmingStatusFlag":Z
    :goto_1
    and-int/lit8 v8, v3, 0x1

    if-eqz v8, :cond_2

    move v6, v7

    .line 260
    .local v6, "obuExtensionFlag":Z
    :cond_2
    invoke-virtual {v0}, Landroidx/media3/common/util/ParsableByteArray;->readUnsignedLeb128ToInt()I

    move-result v7

    .line 262
    .local v7, "obuSize":I
    const/4 v8, 0x4

    if-le v4, v8, :cond_3

    const/16 v9, 0x18

    if-ge v4, v9, :cond_3

    if-eqz v5, :cond_3

    .line 263
    invoke-virtual {v0}, Landroidx/media3/common/util/ParsableByteArray;->skipLeb128()V

    .line 264
    invoke-virtual {v0}, Landroidx/media3/common/util/ParsableByteArray;->skipLeb128()V

    .line 266
    :cond_3
    if-eqz v6, :cond_4

    .line 267
    nop

    .line 268
    invoke-virtual {v0}, Landroidx/media3/common/util/ParsableByteArray;->readUnsignedLeb128ToInt()I

    move-result v9

    .line 269
    .local v9, "extensionHeaderSize":I
    invoke-virtual {v0, v9}, Landroidx/media3/common/util/ParsableByteArray;->skipBytes(I)V

    .line 272
    .end local v9    # "extensionHeaderSize":I
    :cond_4
    invoke-virtual {v0}, Landroidx/media3/common/util/ParsableByteArray;->getPosition()I

    move-result v9

    add-int/2addr v9, v7

    .line 273
    .local v9, "nextObuPosition":I
    const/16 v10, 0x1f

    if-ne v4, v10, :cond_6

    .line 275
    invoke-virtual {v0, v8}, Landroidx/media3/common/util/ParsableByteArray;->skipBytes(I)V

    .line 276
    invoke-virtual {v0}, Landroidx/media3/common/util/ParsableByteArray;->readUnsignedByte()I

    move-result v8

    .line 277
    .local v8, "primaryProfile":I
    invoke-virtual {v0}, Landroidx/media3/common/util/ParsableByteArray;->readUnsignedByte()I

    move-result v10

    .line 278
    .local v10, "additionalProfile":I
    nop

    .line 279
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    filled-new-array {v11, v12}, [Ljava/lang/Object;

    move-result-object v11

    const-string v12, "iamf.%03X.%03X"

    invoke-static {v12, v11}, Landroidx/media3/common/util/Util;->formatInvariant(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    .line 280
    .end local v8    # "primaryProfile":I
    .end local v10    # "additionalProfile":I
    :cond_5
    goto :goto_2

    :cond_6
    if-nez v4, :cond_5

    .line 282
    invoke-virtual {v0}, Landroidx/media3/common/util/ParsableByteArray;->skipLeb128()V

    .line 283
    invoke-virtual {v0, v8}, Landroidx/media3/common/util/ParsableByteArray;->readString(I)Ljava/lang/String;

    move-result-object v2

    .line 285
    const-string v8, "mp4a"

    invoke-virtual {v2, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_8

    .line 286
    invoke-virtual {v0}, Landroidx/media3/common/util/ParsableByteArray;->skipLeb128()V

    .line 287
    const/4 v8, 0x2

    invoke-virtual {v0, v8}, Landroidx/media3/common/util/ParsableByteArray;->skipBytes(I)V

    .line 289
    new-instance v8, Landroidx/media3/common/util/ParsableBitArray;

    invoke-direct {v8}, Landroidx/media3/common/util/ParsableBitArray;-><init>()V

    .line 290
    .local v8, "decoderConfigBitArray":Landroidx/media3/common/util/ParsableBitArray;
    invoke-virtual {v8, v0}, Landroidx/media3/common/util/ParsableBitArray;->reset(Landroidx/media3/common/util/ParsableByteArray;)V

    .line 291
    const/4 v11, 0x5

    invoke-virtual {v8, v11}, Landroidx/media3/common/util/ParsableBitArray;->readBits(I)I

    move-result v11

    .line 294
    .local v11, "audioObjectType":I
    if-ne v11, v10, :cond_7

    .line 295
    const/4 v10, 0x6

    invoke-virtual {v8, v10}, Landroidx/media3/common/util/ParsableBitArray;->readBits(I)I

    move-result v10

    add-int/lit8 v11, v10, 0x20

    .line 297
    :cond_7
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v10, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v12, ".40."

    invoke-virtual {v10, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 301
    .end local v8    # "decoderConfigBitArray":Landroidx/media3/common/util/ParsableBitArray;
    .end local v11    # "audioObjectType":I
    :cond_8
    :goto_2
    invoke-virtual {v0, v9}, Landroidx/media3/common/util/ParsableByteArray;->setPosition(I)V

    .line 302
    .end local v3    # "obuHeaderByte":I
    .end local v4    # "obuType":I
    .end local v5    # "obuTrimmingStatusFlag":Z
    .end local v6    # "obuExtensionFlag":Z
    .end local v7    # "obuSize":I
    .end local v9    # "nextObuPosition":I
    goto/16 :goto_0

    .line 304
    :cond_9
    if-eqz v1, :cond_a

    if-eqz v2, :cond_a

    .line 305
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "."

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    return-object v3

    .line 307
    :cond_a
    const/4 v3, 0x0

    return-object v3
.end method

.method public static buildNalUnit([BII)[B
    .locals 4
    .param p0, "data"    # [B
    .param p1, "offset"    # I
    .param p2, "length"    # I

    .line 1090
    sget-object v0, Landroidx/media3/common/util/CodecSpecificDataUtil;->NAL_START_CODE:[B

    array-length v0, v0

    add-int/2addr v0, p2

    new-array v0, v0, [B

    .line 1091
    .local v0, "nalUnit":[B
    sget-object v1, Landroidx/media3/common/util/CodecSpecificDataUtil;->NAL_START_CODE:[B

    sget-object v2, Landroidx/media3/common/util/CodecSpecificDataUtil;->NAL_START_CODE:[B

    array-length v2, v2

    const/4 v3, 0x0

    invoke-static {v1, v3, v0, v3, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 1092
    sget-object v1, Landroidx/media3/common/util/CodecSpecificDataUtil;->NAL_START_CODE:[B

    array-length v1, v1

    invoke-static {p0, p1, v0, v1, p2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 1093
    return-object v0
.end method

.method public static buildVp9CodecPrivateInitializationData(BBBB)Lcom/google/common/collect/ImmutableList;
    .locals 7
    .param p0, "profile"    # B
    .param p1, "level"    # B
    .param p2, "bitDepth"    # B
    .param p3, "chromaSubsampling"    # B

    .line 340
    const/4 v0, 0x1

    .line 341
    .local v0, "profileId":B
    const/4 v1, 0x2

    .line 342
    .local v1, "levelId":B
    const/4 v2, 0x3

    .line 343
    .local v2, "bitDepthId":B
    const/4 v3, 0x4

    .line 344
    .local v3, "chromaSubsamplingId":B
    const/4 v4, 0x1

    .line 345
    .local v4, "length":B
    const/16 v5, 0xc

    new-array v5, v5, [B

    const/4 v6, 0x0

    aput-byte v0, v5, v6

    const/4 v6, 0x1

    aput-byte v4, v5, v6

    const/4 v6, 0x2

    aput-byte p0, v5, v6

    const/4 v6, 0x3

    aput-byte v1, v5, v6

    const/4 v6, 0x4

    aput-byte v4, v5, v6

    const/4 v6, 0x5

    aput-byte p1, v5, v6

    const/4 v6, 0x6

    aput-byte v2, v5, v6

    const/4 v6, 0x7

    aput-byte v4, v5, v6

    const/16 v6, 0x8

    aput-byte p2, v5, v6

    const/16 v6, 0x9

    aput-byte v3, v5, v6

    const/16 v6, 0xa

    aput-byte v4, v5, v6

    const/16 v6, 0xb

    aput-byte p3, v5, v6

    invoke-static {v5}, Lcom/google/common/collect/ImmutableList;->of(Ljava/lang/Object;)Lcom/google/common/collect/ImmutableList;

    move-result-object v5

    return-object v5
.end method

.method public static dolbyVisionStringToLevel(Ljava/lang/String;)Ljava/lang/Integer;
    .locals 5
    .param p0, "levelString"    # Ljava/lang/String;

    .line 2090
    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/16 v4, 0x8

    sparse-switch v0, :sswitch_data_0

    :cond_0
    goto/16 :goto_0

    :sswitch_0
    const-string v0, "13"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0xc

    goto/16 :goto_1

    :sswitch_1
    const-string v0, "12"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0xb

    goto/16 :goto_1

    :sswitch_2
    const-string v0, "11"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0xa

    goto/16 :goto_1

    :sswitch_3
    const-string v0, "10"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0x9

    goto/16 :goto_1

    :sswitch_4
    const-string v0, "09"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    move v0, v4

    goto :goto_1

    :sswitch_5
    const-string v0, "08"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x7

    goto :goto_1

    :sswitch_6
    const-string v0, "07"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x6

    goto :goto_1

    :sswitch_7
    const-string v0, "06"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x5

    goto :goto_1

    :sswitch_8
    const-string v0, "05"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    move v0, v3

    goto :goto_1

    :sswitch_9
    const-string v0, "04"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x3

    goto :goto_1

    :sswitch_a
    const-string v0, "03"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    move v0, v2

    goto :goto_1

    :sswitch_b
    const-string v0, "02"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    move v0, v1

    goto :goto_1

    :sswitch_c
    const-string v0, "01"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    goto :goto_1

    :goto_0
    const/4 v0, -0x1

    :goto_1
    packed-switch v0, :pswitch_data_0

    .line 2118
    const/4 v0, 0x0

    return-object v0

    .line 2116
    :pswitch_0
    const/16 v0, 0x1000

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2114
    :pswitch_1
    const/16 v0, 0x800

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2112
    :pswitch_2
    const/16 v0, 0x400

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2110
    :pswitch_3
    const/16 v0, 0x200

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2108
    :pswitch_4
    const/16 v0, 0x100

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2106
    :pswitch_5
    const/16 v0, 0x80

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2104
    :pswitch_6
    const/16 v0, 0x40

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2102
    :pswitch_7
    const/16 v0, 0x20

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2100
    :pswitch_8
    const/16 v0, 0x10

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2098
    :pswitch_9
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2096
    :pswitch_a
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2094
    :pswitch_b
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2092
    :pswitch_c
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    nop

    :sswitch_data_0
    .sparse-switch
        0x601 -> :sswitch_c
        0x602 -> :sswitch_b
        0x603 -> :sswitch_a
        0x604 -> :sswitch_9
        0x605 -> :sswitch_8
        0x606 -> :sswitch_7
        0x607 -> :sswitch_6
        0x608 -> :sswitch_5
        0x609 -> :sswitch_4
        0x61f -> :sswitch_3
        0x620 -> :sswitch_2
        0x621 -> :sswitch_1
        0x622 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static dolbyVisionStringToProfile(Ljava/lang/String;)Ljava/lang/Integer;
    .locals 6
    .param p0, "profileString"    # Ljava/lang/String;

    .line 2056
    const/4 v0, 0x0

    if-nez p0, :cond_0

    .line 2057
    return-object v0

    .line 2059
    :cond_0
    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/16 v5, 0x8

    sparse-switch v1, :sswitch_data_0

    :cond_1
    goto/16 :goto_0

    :sswitch_0
    const-string v1, "10"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    const/16 v1, 0xa

    goto/16 :goto_1

    :sswitch_1
    const-string v1, "09"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    const/16 v1, 0x9

    goto/16 :goto_1

    :sswitch_2
    const-string v1, "08"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    move v1, v5

    goto :goto_1

    :sswitch_3
    const-string v1, "07"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    const/4 v1, 0x7

    goto :goto_1

    :sswitch_4
    const-string v1, "06"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    const/4 v1, 0x6

    goto :goto_1

    :sswitch_5
    const-string v1, "05"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    const/4 v1, 0x5

    goto :goto_1

    :sswitch_6
    const-string v1, "04"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    move v1, v4

    goto :goto_1

    :sswitch_7
    const-string v1, "03"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    const/4 v1, 0x3

    goto :goto_1

    :sswitch_8
    const-string v1, "02"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    move v1, v3

    goto :goto_1

    :sswitch_9
    const-string v1, "01"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    move v1, v2

    goto :goto_1

    :sswitch_a
    const-string v1, "00"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    const/4 v1, 0x0

    goto :goto_1

    :goto_0
    const/4 v1, -0x1

    :goto_1
    packed-switch v1, :pswitch_data_0

    .line 2083
    return-object v0

    .line 2081
    :pswitch_0
    const/16 v0, 0x400

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2079
    :pswitch_1
    const/16 v0, 0x200

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2077
    :pswitch_2
    const/16 v0, 0x100

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2075
    :pswitch_3
    const/16 v0, 0x80

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2073
    :pswitch_4
    const/16 v0, 0x40

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2071
    :pswitch_5
    const/16 v0, 0x20

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2069
    :pswitch_6
    const/16 v0, 0x10

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2067
    :pswitch_7
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2065
    :pswitch_8
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2063
    :pswitch_9
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2061
    :pswitch_a
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    :sswitch_data_0
    .sparse-switch
        0x600 -> :sswitch_a
        0x601 -> :sswitch_9
        0x602 -> :sswitch_8
        0x603 -> :sswitch_7
        0x604 -> :sswitch_6
        0x605 -> :sswitch_5
        0x606 -> :sswitch_4
        0x607 -> :sswitch_3
        0x608 -> :sswitch_2
        0x609 -> :sswitch_1
        0x61f -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static findNalStartCode([BI)I
    .locals 3
    .param p0, "data"    # [B
    .param p1, "index"    # I

    .line 1269
    array-length v0, p0

    sget-object v1, Landroidx/media3/common/util/CodecSpecificDataUtil;->NAL_START_CODE:[B

    array-length v1, v1

    sub-int/2addr v0, v1

    .line 1270
    .local v0, "endIndex":I
    move v1, p1

    .local v1, "i":I
    :goto_0
    if-gt v1, v0, :cond_1

    .line 1271
    invoke-static {p0, v1}, Landroidx/media3/common/util/CodecSpecificDataUtil;->isNalStartCode([BI)Z

    move-result v2

    if-eqz v2, :cond_0

    .line 1272
    return v1

    .line 1270
    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    nop

    .line 1275
    .end local v1    # "i":I
    const/4 v1, -0x1

    return v1
.end method

.method public static getAacCodecProfileAndLevel(Ljava/lang/String;[Ljava/lang/String;)Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;
    .locals 9
    .param p0, "codec"    # Ljava/lang/String;
    .param p1, "parts"    # [Ljava/lang/String;

    .line 1746
    array-length v0, p1

    const/4 v1, 0x3

    const/4 v2, 0x0

    const-string v3, "Ignoring malformed MP4A codec string: "

    const-string v4, "CodecSpecificDataUtil"

    if-eq v0, v1, :cond_0

    .line 1747
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v4, v0}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1748
    return-object v2

    .line 1752
    :cond_0
    const/4 v0, 0x1

    :try_start_0
    aget-object v0, p1, v0

    const/16 v1, 0x10

    invoke-static {v0, v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v0

    .line 1753
    .local v0, "objectTypeIndication":I
    invoke-static {v0}, Landroidx/media3/common/MimeTypes;->getMimeTypeFromMp4ObjectType(I)Ljava/lang/String;

    move-result-object v1

    .line 1754
    .local v1, "mimeType":Ljava/lang/String;
    const-string v5, "audio/mp4a-latm"

    invoke-virtual {v5, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_2

    .line 1756
    const/4 v5, 0x2

    aget-object v5, p1, v5

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    .line 1757
    .local v5, "audioObjectTypeIndication":I
    invoke-static {v5}, Landroidx/media3/common/util/CodecSpecificDataUtil;->mp4aAudioObjectTypeToProfile(I)I

    move-result v6

    .line 1758
    .local v6, "profile":I
    const/4 v7, -0x1

    if-ne v6, v7, :cond_1

    .line 1759
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "Unrecognized MP4A profile: "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v4, v7}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1760
    sget-object v2, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;->UNSUPPORTABLE:Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    return-object v2

    .line 1765
    .end local v0    # "objectTypeIndication":I
    .end local v1    # "mimeType":Ljava/lang/String;
    .end local v5    # "audioObjectTypeIndication":I
    .end local v6    # "profile":I
    :catch_0
    move-exception v0

    goto :goto_0

    .line 1763
    .restart local v0    # "objectTypeIndication":I
    .restart local v1    # "mimeType":Ljava/lang/String;
    .restart local v5    # "audioObjectTypeIndication":I
    .restart local v6    # "profile":I
    :cond_1
    new-instance v7, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    const/4 v8, 0x0

    invoke-direct {v7, v6, v8}, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;-><init>(II)V
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v7

    .line 1754
    .end local v5    # "audioObjectTypeIndication":I
    .end local v6    # "profile":I
    :cond_2
    nop

    .line 1767
    .end local v0    # "objectTypeIndication":I
    .end local v1    # "mimeType":Ljava/lang/String;
    goto :goto_1

    .line 1765
    :goto_0
    nop

    .line 1766
    .local v0, "e":Ljava/lang/NumberFormatException;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v4, v1}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1768
    .end local v0    # "e":Ljava/lang/NumberFormatException;
    :goto_1
    return-object v2
.end method

.method public static getAc4CodecProfileAndLevel(Ljava/lang/String;[Ljava/lang/String;)Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;
    .locals 8
    .param p0, "codec"    # Ljava/lang/String;
    .param p1, "parts"    # [Ljava/lang/String;

    .line 1774
    array-length v0, p1

    const/4 v1, 0x4

    const/4 v2, 0x0

    const-string v3, "Ignoring malformed AC-4 codec string: "

    const-string v4, "CodecSpecificDataUtil"

    if-eq v0, v1, :cond_0

    .line 1775
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v4, v0}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1776
    return-object v2

    .line 1782
    :cond_0
    const/4 v0, 0x1

    :try_start_0
    aget-object v0, p1, v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    .line 1783
    .local v0, "bitstreamVersionInteger":I
    const/4 v1, 0x2

    aget-object v1, p1, v1

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    .line 1784
    .local v1, "presentationVersionInteger":I
    const/4 v5, 0x3

    aget-object v5, p1, v5

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    .line 1788
    .local v2, "levelInteger":I
    nop

    .line 1790
    nop

    .line 1791
    invoke-static {v0, v1}, Landroidx/media3/common/util/CodecSpecificDataUtil;->ac4BitstreamAndPresentationVersionsToProfileConst(II)I

    move-result v3

    .line 1793
    .local v3, "profile":I
    const/4 v5, -0x1

    if-ne v3, v5, :cond_1

    .line 1794
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "Unknown AC-4 profile: "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v6, "."

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1797
    sget-object v4, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;->UNSUPPORTABLE:Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    return-object v4

    .line 1799
    :cond_1
    invoke-static {v2}, Landroidx/media3/common/util/CodecSpecificDataUtil;->ac4LevelNumberToConst(I)I

    move-result v6

    .line 1800
    .local v6, "level":I
    if-ne v6, v5, :cond_2

    .line 1801
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "Unknown AC-4 level: "

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1802
    sget-object v4, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;->UNSUPPORTABLE:Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    return-object v4

    .line 1804
    :cond_2
    new-instance v4, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    invoke-direct {v4, v3, v6}, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;-><init>(II)V

    return-object v4

    .line 1785
    .end local v0    # "bitstreamVersionInteger":I
    .end local v1    # "presentationVersionInteger":I
    .end local v2    # "levelInteger":I
    .end local v3    # "profile":I
    .end local v6    # "level":I
    :catch_0
    move-exception v0

    .line 1786
    .local v0, "e":Ljava/lang/NumberFormatException;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v4, v1}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1787
    return-object v2
.end method

.method public static getApvProfileAndLevel(Ljava/lang/String;[Ljava/lang/String;)Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;
    .locals 7
    .param p0, "codec"    # Ljava/lang/String;
    .param p1, "parts"    # [Ljava/lang/String;

    .line 1505
    array-length v0, p1

    const/4 v1, 0x0

    const-string v2, "Ignoring malformed APV codec string: "

    const-string v3, "CodecSpecificDataUtil"

    const/4 v4, 0x4

    if-ge v0, v4, :cond_0

    .line 1506
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1507
    return-object v1

    .line 1513
    :cond_0
    const/4 v0, 0x1

    :try_start_0
    aget-object v0, p1, v0

    invoke-virtual {v0, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    .line 1514
    .local v0, "profileInteger":I
    const/4 v5, 0x2

    aget-object v5, p1, v5

    invoke-virtual {v5, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    .line 1515
    .local v5, "levelInteger":I
    const/4 v6, 0x3

    aget-object v6, p1, v6

    invoke-virtual {v6, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    .line 1519
    .local v1, "bandInteger":I
    nop

    .line 1522
    const/16 v2, 0x21

    if-ne v0, v2, :cond_1

    .line 1523
    const/4 v2, 0x1

    .local v2, "profile":I
    goto :goto_0

    .line 1524
    .end local v2    # "profile":I
    :cond_1
    const/16 v2, 0x2c

    if-ne v0, v2, :cond_3

    .line 1525
    const/16 v2, 0x2000

    .line 1530
    .restart local v2    # "profile":I
    :goto_0
    invoke-static {v5, v1}, Landroidx/media3/common/util/CodecSpecificDataUtil;->apvLevelAndBandNumberToConst(II)I

    move-result v3

    .line 1531
    .local v3, "level":I
    const/4 v4, -0x1

    if-ne v3, v4, :cond_2

    .line 1532
    sget-object v4, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;->UNSUPPORTABLE:Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    return-object v4

    .line 1534
    :cond_2
    new-instance v4, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    invoke-direct {v4, v2, v3}, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;-><init>(II)V

    return-object v4

    .line 1527
    .end local v2    # "profile":I
    .end local v3    # "level":I
    :cond_3
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Unrecognized APV profile: "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v3, v2}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1528
    sget-object v2, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;->UNSUPPORTABLE:Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    return-object v2

    .line 1516
    .end local v0    # "profileInteger":I
    .end local v1    # "bandInteger":I
    .end local v5    # "levelInteger":I
    :catch_0
    move-exception v0

    .line 1517
    .local v0, "e":Ljava/lang/NumberFormatException;
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v3, v2, v0}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 1518
    return-object v1
.end method

.method public static getAv1ProfileAndLevel(Ljava/lang/String;[Ljava/lang/String;Landroidx/media3/common/ColorInfo;)Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;
    .locals 8
    .param p0, "codec"    # Ljava/lang/String;
    .param p1, "parts"    # [Ljava/lang/String;
    .param p2, "colorInfo"    # Landroidx/media3/common/ColorInfo;

    .line 1459
    array-length v0, p1

    const/4 v1, 0x4

    const/4 v2, 0x0

    const-string v3, "Ignoring malformed AV1 codec string: "

    const-string v4, "CodecSpecificDataUtil"

    if-ge v0, v1, :cond_0

    .line 1460
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v4, v0}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1461
    return-object v2

    .line 1467
    :cond_0
    const/4 v0, 0x1

    :try_start_0
    aget-object v0, p1, v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    .line 1468
    .local v0, "profileInteger":I
    const/4 v1, 0x2

    aget-object v5, p1, v1

    const/4 v6, 0x0

    invoke-virtual {v5, v6, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    .line 1469
    .local v1, "levelInteger":I
    const/4 v5, 0x3

    aget-object v5, p1, v5

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    .line 1473
    .local v2, "bitDepthInteger":I
    nop

    .line 1475
    if-eqz v0, :cond_1

    .line 1476
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Unknown AV1 profile: "

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v4, v3}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1477
    sget-object v3, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;->UNSUPPORTABLE:Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    return-object v3

    .line 1479
    :cond_1
    const/16 v3, 0x8

    if-eq v2, v3, :cond_2

    const/16 v5, 0xa

    if-eq v2, v5, :cond_2

    .line 1480
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Unknown AV1 bit depth: "

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v4, v3}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1481
    sget-object v3, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;->UNSUPPORTABLE:Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    return-object v3

    .line 1484
    :cond_2
    if-ne v2, v3, :cond_3

    .line 1485
    const/4 v3, 0x1

    .local v3, "profile":I
    goto :goto_0

    .line 1486
    .end local v3    # "profile":I
    :cond_3
    if-eqz p2, :cond_5

    iget-object v3, p2, Landroidx/media3/common/ColorInfo;->hdrStaticInfo:[B

    if-nez v3, :cond_4

    iget v3, p2, Landroidx/media3/common/ColorInfo;->colorTransfer:I

    const/4 v5, 0x7

    if-eq v3, v5, :cond_4

    iget v3, p2, Landroidx/media3/common/ColorInfo;->colorTransfer:I

    const/4 v5, 0x6

    if-ne v3, v5, :cond_5

    .line 1490
    :cond_4
    const/16 v3, 0x1000

    .restart local v3    # "profile":I
    goto :goto_0

    .line 1492
    .end local v3    # "profile":I
    :cond_5
    const/4 v3, 0x2

    .line 1495
    .restart local v3    # "profile":I
    :goto_0
    invoke-static {v1}, Landroidx/media3/common/util/CodecSpecificDataUtil;->av1LevelNumberToConst(I)I

    move-result v5

    .line 1496
    .local v5, "level":I
    const/4 v6, -0x1

    if-ne v5, v6, :cond_6

    .line 1497
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "Unknown AV1 level: "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v4, v6}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1498
    sget-object v4, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;->UNSUPPORTABLE:Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    return-object v4

    .line 1500
    :cond_6
    new-instance v4, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    invoke-direct {v4, v3, v5}, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;-><init>(II)V

    return-object v4

    .line 1470
    .end local v0    # "profileInteger":I
    .end local v1    # "levelInteger":I
    .end local v2    # "bitDepthInteger":I
    .end local v3    # "profile":I
    .end local v5    # "level":I
    :catch_0
    move-exception v0

    .line 1471
    .local v0, "e":Ljava/lang/NumberFormatException;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v4, v1}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1472
    return-object v2
.end method

.method public static getAvcProfileAndLevel(Ljava/lang/String;[Ljava/lang/String;)Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;
    .locals 7
    .param p0, "codec"    # Ljava/lang/String;
    .param p1, "parts"    # [Ljava/lang/String;

    .line 1388
    array-length v0, p1

    const/4 v1, 0x0

    const-string v2, "Ignoring malformed AVC codec string: "

    const-string v3, "CodecSpecificDataUtil"

    const/4 v4, 0x2

    if-ge v0, v4, :cond_0

    .line 1390
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1391
    return-object v1

    .line 1396
    :cond_0
    const/4 v0, 0x1

    :try_start_0
    aget-object v5, p1, v0

    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v5

    const/4 v6, 0x6

    if-ne v5, v6, :cond_1

    .line 1398
    aget-object v5, p1, v0

    const/4 v6, 0x0

    invoke-virtual {v5, v6, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v4

    const/16 v5, 0x10

    invoke-static {v4, v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v4

    .line 1399
    .local v4, "profileInteger":I
    aget-object v0, p1, v0

    const/4 v6, 0x4

    invoke-virtual {v0, v6}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v0

    .local v0, "levelInteger":I
    goto :goto_0

    .line 1409
    .end local v0    # "levelInteger":I
    .end local v4    # "profileInteger":I
    :catch_0
    move-exception v0

    goto :goto_1

    .line 1400
    :cond_1
    array-length v5, p1

    const/4 v6, 0x3

    if-lt v5, v6, :cond_4

    .line 1402
    aget-object v0, p1, v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    .line 1403
    .local v0, "profileInteger":I
    aget-object v4, p1, v4

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    move v4, v0

    move v0, v1

    .line 1412
    .local v0, "levelInteger":I
    .restart local v4    # "profileInteger":I
    :goto_0
    nop

    .line 1414
    invoke-static {v4}, Landroidx/media3/common/util/CodecSpecificDataUtil;->avcProfileNumberToConst(I)I

    move-result v1

    .line 1415
    .local v1, "profile":I
    const/4 v2, -0x1

    if-ne v1, v2, :cond_2

    .line 1416
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Unknown AVC profile: "

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v3, v2}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1417
    sget-object v2, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;->UNSUPPORTABLE:Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    return-object v2

    .line 1419
    :cond_2
    invoke-static {v0}, Landroidx/media3/common/util/CodecSpecificDataUtil;->avcLevelNumberToConst(I)I

    move-result v5

    .line 1420
    .local v5, "level":I
    if-ne v5, v2, :cond_3

    .line 1421
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "Unknown AVC level: "

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v3, v2}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1422
    sget-object v2, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;->UNSUPPORTABLE:Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    return-object v2

    .line 1424
    :cond_3
    new-instance v2, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    invoke-direct {v2, v1, v5}, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;-><init>(II)V

    return-object v2

    .line 1406
    .end local v0    # "levelInteger":I
    .end local v1    # "profile":I
    .end local v4    # "profileInteger":I
    .end local v5    # "level":I
    :cond_4
    :try_start_1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catch Ljava/lang/NumberFormatException; {:try_start_1 .. :try_end_1} :catch_0

    .line 1407
    return-object v1

    .line 1409
    :goto_1
    nop

    .line 1410
    .local v0, "e":Ljava/lang/NumberFormatException;
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v3, v2}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1411
    return-object v1
.end method

.method public static getCodecProfileAndLevel(Landroidx/media3/common/Format;)Landroid/util/Pair;
    .locals 4
    .param p0, "format"    # Landroidx/media3/common/Format;

    .line 857
    invoke-static {p0}, Landroidx/media3/common/util/CodecSpecificDataUtil;->getMediaCodecProfileAndLevel(Landroidx/media3/common/Format;)Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    move-result-object v0

    .line 858
    .local v0, "mediaCodecProfileAndLevel":Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;
    if-eqz v0, :cond_0

    .line 859
    invoke-virtual {v0}, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;->isSupportableByMediaCodec()Z

    move-result v1

    if-eqz v1, :cond_0

    .line 860
    new-instance v1, Landroid/util/Pair;

    .line 861
    invoke-virtual {v0}, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;->getProfile()I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0}, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;->getLevel()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-direct {v1, v2, v3}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 860
    return-object v1

    .line 863
    :cond_0
    const/4 v1, 0x0

    return-object v1
.end method

.method public static getDolbyVisionBaseLayerMimeType(Landroidx/media3/common/Format;)Ljava/lang/String;
    .locals 3
    .param p0, "format"    # Landroidx/media3/common/Format;

    .line 1335
    iget-object v0, p0, Landroidx/media3/common/Format;->sampleMimeType:Ljava/lang/String;

    const-string v1, "video/dolby-vision"

    invoke-static {v0, v1}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    .line 1336
    return-object v1

    .line 1338
    :cond_0
    invoke-static {p0}, Landroidx/media3/common/util/CodecSpecificDataUtil;->getCodecProfileAndLevel(Landroidx/media3/common/Format;)Landroid/util/Pair;

    move-result-object v0

    .line 1339
    .local v0, "codecProfileAndLevel":Landroid/util/Pair;, "Landroid/util/Pair<Ljava/lang/Integer;Ljava/lang/Integer;>;"
    if-nez v0, :cond_1

    .line 1340
    return-object v1

    .line 1342
    :cond_1
    iget-object v2, v0, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    sparse-switch v2, :sswitch_data_0

    .line 1352
    return-object v1

    .line 1350
    :sswitch_0
    const-string v1, "video/av01"

    return-object v1

    .line 1348
    :sswitch_1
    const-string v1, "video/avc"

    return-object v1

    .line 1346
    :sswitch_2
    const-string v1, "video/hevc"

    return-object v1

    :sswitch_data_0
    .sparse-switch
        0x10 -> :sswitch_2
        0x20 -> :sswitch_2
        0x100 -> :sswitch_2
        0x200 -> :sswitch_1
        0x400 -> :sswitch_0
    .end sparse-switch
.end method

.method public static getDolbyVisionProfileAndLevel(Ljava/lang/String;[Ljava/lang/String;)Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;
    .locals 9
    .param p0, "codec"    # Ljava/lang/String;
    .param p1, "parts"    # [Ljava/lang/String;

    .line 1300
    array-length v0, p1

    const/4 v1, 0x3

    const-string v2, "Ignoring malformed Dolby Vision codec string: "

    const/4 v3, 0x0

    const-string v4, "CodecSpecificDataUtil"

    if-ge v0, v1, :cond_0

    .line 1302
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v4, v0}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1303
    return-object v3

    .line 1306
    :cond_0
    sget-object v0, Landroidx/media3/common/util/CodecSpecificDataUtil;->PROFILE_PATTERN:Ljava/util/regex/Pattern;

    const/4 v1, 0x1

    aget-object v5, p1, v1

    invoke-virtual {v0, v5}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v0

    .line 1307
    .local v0, "matcher":Ljava/util/regex/Matcher;
    invoke-virtual {v0}, Ljava/util/regex/Matcher;->matches()Z

    move-result v5

    if-nez v5, :cond_1

    .line 1308
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v4, v1}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1309
    return-object v3

    .line 1311
    :cond_1
    invoke-virtual {v0, v1}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .line 1312
    .local v1, "profileString":Ljava/lang/String;
    invoke-static {v1}, Landroidx/media3/common/util/CodecSpecificDataUtil;->dolbyVisionStringToProfile(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v2

    .line 1313
    .local v2, "profile":Ljava/lang/Integer;
    if-nez v2, :cond_2

    .line 1314
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Unknown Dolby Vision profile string: "

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v4, v3}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1315
    sget-object v3, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;->UNSUPPORTABLE:Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    return-object v3

    .line 1317
    :cond_2
    const/4 v5, 0x2

    aget-object v5, p1, v5

    .line 1318
    .local v5, "levelString":Ljava/lang/String;
    invoke-static {v5}, Landroidx/media3/common/util/CodecSpecificDataUtil;->dolbyVisionStringToLevel(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v6

    .line 1319
    .local v6, "level":Ljava/lang/Integer;
    if-nez v6, :cond_3

    .line 1320
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "Unknown Dolby Vision level string: "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v4, v7}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1321
    return-object v3

    .line 1323
    :cond_3
    new-instance v3, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v4

    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    move-result v7

    invoke-direct {v3, v4, v7}, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;-><init>(II)V

    return-object v3
.end method

.method public static getH263ProfileAndLevel(Ljava/lang/String;[Ljava/lang/String;)Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;
    .locals 7
    .param p0, "codec"    # Ljava/lang/String;
    .param p1, "parts"    # [Ljava/lang/String;

    .line 1359
    array-length v0, p1

    const/4 v1, 0x3

    const/4 v2, 0x0

    const-string v3, "Ignoring malformed H263 codec string: "

    const-string v4, "CodecSpecificDataUtil"

    if-ge v0, v1, :cond_0

    .line 1360
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v4, v0}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1361
    return-object v2

    .line 1367
    :cond_0
    const/4 v0, 0x1

    :try_start_0
    aget-object v0, p1, v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    .line 1368
    .local v0, "profileInteger":I
    const/4 v1, 0x2

    aget-object v1, p1, v1

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    .line 1372
    .local v1, "levelInteger":I
    nop

    .line 1373
    invoke-static {v0}, Landroidx/media3/common/util/CodecSpecificDataUtil;->h263ProfileNumberToConst(I)I

    move-result v2

    .line 1374
    .local v2, "profile":I
    const/4 v3, -0x1

    if-ne v2, v3, :cond_1

    .line 1375
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Unknown H263 profile: "

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v4, v3}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1376
    sget-object v3, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;->UNSUPPORTABLE:Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    return-object v3

    .line 1378
    :cond_1
    invoke-static {v1}, Landroidx/media3/common/util/CodecSpecificDataUtil;->h263LevelNumberToConst(I)I

    move-result v5

    .line 1379
    .local v5, "level":I
    if-ne v5, v3, :cond_2

    .line 1380
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "Unknown H263 level: "

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v4, v3}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1381
    sget-object v3, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;->UNSUPPORTABLE:Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    return-object v3

    .line 1383
    :cond_2
    new-instance v3, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    invoke-direct {v3, v2, v5}, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;-><init>(II)V

    return-object v3

    .line 1369
    .end local v0    # "profileInteger":I
    .end local v1    # "levelInteger":I
    .end local v2    # "profile":I
    .end local v5    # "level":I
    :catch_0
    move-exception v0

    .line 1370
    .local v0, "e":Ljava/lang/NumberFormatException;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v4, v1}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1371
    return-object v2
.end method

.method public static getHevcProfileAndLevel(Ljava/lang/String;[Ljava/lang/String;Landroidx/media3/common/ColorInfo;)Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;
    .locals 8
    .param p0, "codec"    # Ljava/lang/String;
    .param p1, "parts"    # [Ljava/lang/String;
    .param p2, "colorInfo"    # Landroidx/media3/common/ColorInfo;

    .line 1043
    array-length v0, p1

    const/4 v1, 0x4

    const/4 v2, 0x0

    const-string v3, "Ignoring malformed HEVC codec string: "

    const-string v4, "CodecSpecificDataUtil"

    if-ge v0, v1, :cond_0

    .line 1045
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v4, v0}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1046
    return-object v2

    .line 1049
    :cond_0
    sget-object v0, Landroidx/media3/common/util/CodecSpecificDataUtil;->PROFILE_PATTERN:Ljava/util/regex/Pattern;

    const/4 v1, 0x1

    aget-object v5, p1, v1

    invoke-virtual {v0, v5}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v0

    .line 1050
    .local v0, "matcher":Ljava/util/regex/Matcher;
    invoke-virtual {v0}, Ljava/util/regex/Matcher;->matches()Z

    move-result v5

    if-nez v5, :cond_1

    .line 1051
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v4, v1}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1052
    return-object v2

    .line 1054
    :cond_1
    invoke-virtual {v0, v1}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v1

    .line 1056
    .local v1, "profileString":Ljava/lang/String;
    const-string v2, "1"

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    .line 1057
    const/4 v2, 0x1

    .local v2, "profile":I
    goto :goto_0

    .line 1058
    .end local v2    # "profile":I
    :cond_2
    const-string v2, "2"

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_5

    .line 1059
    if-eqz p2, :cond_3

    iget v2, p2, Landroidx/media3/common/ColorInfo;->colorTransfer:I

    const/4 v3, 0x6

    if-ne v2, v3, :cond_3

    .line 1060
    const/16 v2, 0x1000

    .restart local v2    # "profile":I
    goto :goto_0

    .line 1066
    .end local v2    # "profile":I
    :cond_3
    const/4 v2, 0x2

    .line 1072
    .restart local v2    # "profile":I
    :goto_0
    const/4 v3, 0x3

    aget-object v3, p1, v3

    .line 1073
    .local v3, "levelString":Ljava/lang/String;
    invoke-static {v3}, Landroidx/media3/common/util/CodecSpecificDataUtil;->hevcCodecStringToProfileLevel(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v5

    .line 1074
    .local v5, "level":Ljava/lang/Integer;
    if-nez v5, :cond_4

    .line 1075
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "Unknown HEVC level string: "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v4, v6}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1076
    sget-object v4, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;->UNSUPPORTABLE:Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    return-object v4

    .line 1078
    :cond_4
    new-instance v4, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v6

    invoke-direct {v4, v2, v6}, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;-><init>(II)V

    return-object v4

    .line 1069
    .end local v2    # "profile":I
    .end local v3    # "levelString":Ljava/lang/String;
    .end local v5    # "level":Ljava/lang/Integer;
    :cond_5
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Unknown HEVC profile string: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v4, v2}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1070
    sget-object v2, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;->UNSUPPORTABLE:Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    return-object v2
.end method

.method public static getIamfCodecProfileAndLevel(Ljava/lang/String;[Ljava/lang/String;)Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;
    .locals 6
    .param p0, "codec"    # Ljava/lang/String;
    .param p1, "parts"    # [Ljava/lang/String;

    .line 1810
    array-length v0, p1

    const/4 v1, 0x4

    const/4 v2, 0x0

    const-string v3, "CodecSpecificDataUtil"

    if-ge v0, v1, :cond_0

    .line 1811
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Ignoring malformed IAMF codec string: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1812
    return-object v2

    .line 1817
    :cond_0
    const/4 v0, 0x1

    :try_start_0
    aget-object v1, p1, v0

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    .line 1821
    .local v0, "profileNumber":I
    nop

    .line 1822
    const/4 v1, 0x3

    aget-object v1, p1, v1

    invoke-static {v1, v0}, Landroidx/media3/common/util/CodecSpecificDataUtil;->iamfProfileNumberToConst(Ljava/lang/String;I)I

    move-result v1

    .line 1823
    .local v1, "profile":I
    const/4 v2, -0x1

    if-ne v1, v2, :cond_1

    .line 1824
    sget-object v2, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;->UNSUPPORTABLE:Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    return-object v2

    .line 1826
    :cond_1
    new-instance v2, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    const/4 v3, 0x0

    invoke-direct {v2, v1, v3}, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;-><init>(II)V

    return-object v2

    .line 1818
    .end local v0    # "profileNumber":I
    .end local v1    # "profile":I
    :catch_0
    move-exception v1

    .line 1819
    .local v1, "e":Ljava/lang/NumberFormatException;
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Ignoring malformed primary profile in IAMF codec string: "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v0, p1, v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0, v1}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 1820
    return-object v2
.end method

.method public static getMediaCodecProfileAndLevel(Landroidx/media3/common/Format;)Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;
    .locals 5
    .param p0, "format"    # Landroidx/media3/common/Format;

    .line 877
    iget-object v0, p0, Landroidx/media3/common/Format;->codecs:Ljava/lang/String;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    .line 878
    return-object v1

    .line 880
    :cond_0
    iget-object v0, p0, Landroidx/media3/common/Format;->codecs:Ljava/lang/String;

    const-string v2, "\\."

    invoke-virtual {v0, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    .line 882
    .local v0, "parts":[Ljava/lang/String;
    const-string v2, "video/dolby-vision"

    iget-object v3, p0, Landroidx/media3/common/Format;->sampleMimeType:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1

    .line 883
    iget-object v1, p0, Landroidx/media3/common/Format;->codecs:Ljava/lang/String;

    invoke-static {v1, v0}, Landroidx/media3/common/util/CodecSpecificDataUtil;->getDolbyVisionProfileAndLevel(Ljava/lang/String;[Ljava/lang/String;)Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    move-result-object v1

    return-object v1

    .line 885
    :cond_1
    const/4 v2, 0x0

    aget-object v3, v0, v2

    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    move-result v4

    sparse-switch v4, :sswitch_data_0

    :cond_2
    goto/16 :goto_0

    :sswitch_0
    const-string v2, "vvi1"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    const/4 v2, 0x7

    goto/16 :goto_1

    :sswitch_1
    const-string v2, "vvc1"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    const/4 v2, 0x6

    goto/16 :goto_1

    :sswitch_2
    const-string v2, "vp09"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    const/4 v2, 0x3

    goto/16 :goto_1

    :sswitch_3
    const-string v4, "s263"

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_2

    goto :goto_1

    :sswitch_4
    const-string v2, "mp4a"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    const/16 v2, 0xa

    goto :goto_1

    :sswitch_5
    const-string v2, "iamf"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    const/16 v2, 0xc

    goto :goto_1

    :sswitch_6
    const-string v2, "hvc1"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    const/4 v2, 0x5

    goto :goto_1

    :sswitch_7
    const-string v2, "hev1"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    const/4 v2, 0x4

    goto :goto_1

    :sswitch_8
    const-string v2, "avc2"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    const/4 v2, 0x2

    goto :goto_1

    :sswitch_9
    const-string v2, "avc1"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    const/4 v2, 0x1

    goto :goto_1

    :sswitch_a
    const-string v2, "av01"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    const/16 v2, 0x8

    goto :goto_1

    :sswitch_b
    const-string v2, "apv1"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    const/16 v2, 0x9

    goto :goto_1

    :sswitch_c
    const-string v2, "ac-4"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    const/16 v2, 0xb

    goto :goto_1

    :goto_0
    const/4 v2, -0x1

    :goto_1
    packed-switch v2, :pswitch_data_0

    .line 910
    return-object v1

    .line 908
    :pswitch_0
    iget-object v1, p0, Landroidx/media3/common/Format;->codecs:Ljava/lang/String;

    invoke-static {v1, v0}, Landroidx/media3/common/util/CodecSpecificDataUtil;->getIamfCodecProfileAndLevel(Ljava/lang/String;[Ljava/lang/String;)Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    move-result-object v1

    return-object v1

    .line 906
    :pswitch_1
    iget-object v1, p0, Landroidx/media3/common/Format;->codecs:Ljava/lang/String;

    invoke-static {v1, v0}, Landroidx/media3/common/util/CodecSpecificDataUtil;->getAc4CodecProfileAndLevel(Ljava/lang/String;[Ljava/lang/String;)Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    move-result-object v1

    return-object v1

    .line 904
    :pswitch_2
    iget-object v1, p0, Landroidx/media3/common/Format;->codecs:Ljava/lang/String;

    invoke-static {v1, v0}, Landroidx/media3/common/util/CodecSpecificDataUtil;->getAacCodecProfileAndLevel(Ljava/lang/String;[Ljava/lang/String;)Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    move-result-object v1

    return-object v1

    .line 902
    :pswitch_3
    iget-object v1, p0, Landroidx/media3/common/Format;->codecs:Ljava/lang/String;

    invoke-static {v1, v0}, Landroidx/media3/common/util/CodecSpecificDataUtil;->getApvProfileAndLevel(Ljava/lang/String;[Ljava/lang/String;)Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    move-result-object v1

    return-object v1

    .line 900
    :pswitch_4
    iget-object v1, p0, Landroidx/media3/common/Format;->codecs:Ljava/lang/String;

    iget-object v2, p0, Landroidx/media3/common/Format;->colorInfo:Landroidx/media3/common/ColorInfo;

    invoke-static {v1, v0, v2}, Landroidx/media3/common/util/CodecSpecificDataUtil;->getAv1ProfileAndLevel(Ljava/lang/String;[Ljava/lang/String;Landroidx/media3/common/ColorInfo;)Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    move-result-object v1

    return-object v1

    .line 898
    :pswitch_5
    iget-object v1, p0, Landroidx/media3/common/Format;->codecs:Ljava/lang/String;

    iget-object v2, p0, Landroidx/media3/common/Format;->colorInfo:Landroidx/media3/common/ColorInfo;

    invoke-static {v1, v0, v2}, Landroidx/media3/common/util/CodecSpecificDataUtil;->getVvcProfileAndLevel(Ljava/lang/String;[Ljava/lang/String;Landroidx/media3/common/ColorInfo;)Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    move-result-object v1

    return-object v1

    .line 895
    :pswitch_6
    iget-object v1, p0, Landroidx/media3/common/Format;->codecs:Ljava/lang/String;

    iget-object v2, p0, Landroidx/media3/common/Format;->colorInfo:Landroidx/media3/common/ColorInfo;

    invoke-static {v1, v0, v2}, Landroidx/media3/common/util/CodecSpecificDataUtil;->getHevcProfileAndLevel(Ljava/lang/String;[Ljava/lang/String;Landroidx/media3/common/ColorInfo;)Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    move-result-object v1

    return-object v1

    .line 892
    :pswitch_7
    iget-object v1, p0, Landroidx/media3/common/Format;->codecs:Ljava/lang/String;

    invoke-static {v1, v0}, Landroidx/media3/common/util/CodecSpecificDataUtil;->getVp9ProfileAndLevel(Ljava/lang/String;[Ljava/lang/String;)Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    move-result-object v1

    return-object v1

    .line 890
    :pswitch_8
    iget-object v1, p0, Landroidx/media3/common/Format;->codecs:Ljava/lang/String;

    invoke-static {v1, v0}, Landroidx/media3/common/util/CodecSpecificDataUtil;->getAvcProfileAndLevel(Ljava/lang/String;[Ljava/lang/String;)Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    move-result-object v1

    return-object v1

    .line 887
    :pswitch_9
    iget-object v1, p0, Landroidx/media3/common/Format;->codecs:Ljava/lang/String;

    invoke-static {v1, v0}, Landroidx/media3/common/util/CodecSpecificDataUtil;->getH263ProfileAndLevel(Ljava/lang/String;[Ljava/lang/String;)Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    move-result-object v1

    return-object v1

    nop

    :sswitch_data_0
    .sparse-switch
        0x2d9149 -> :sswitch_c
        0x2dcaea -> :sswitch_b
        0x2dd8f6 -> :sswitch_a
        0x2ddf23 -> :sswitch_9
        0x2ddf24 -> :sswitch_8
        0x30d038 -> :sswitch_7
        0x310dbc -> :sswitch_6
        0x3134b1 -> :sswitch_5
        0x333790 -> :sswitch_4
        0x35091c -> :sswitch_3
        0x374e43 -> :sswitch_2
        0x376aee -> :sswitch_1
        0x376ba8 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_9
        :pswitch_8
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_6
        :pswitch_5
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static getVideoResolutionFromMpeg4VideoConfig([B)Landroid/util/Pair;
    .locals 11
    .param p0, "videoSpecificConfig"    # [B

    .line 675
    const/4 v0, 0x0

    .line 676
    .local v0, "offset":I
    const/4 v1, 0x0

    .line 677
    .local v1, "foundVOL":Z
    new-instance v2, Landroidx/media3/common/util/ParsableByteArray;

    invoke-direct {v2, p0}, Landroidx/media3/common/util/ParsableByteArray;-><init>([B)V

    .line 678
    .local v2, "scratchBytes":Landroidx/media3/common/util/ParsableByteArray;
    :goto_0
    add-int/lit8 v3, v0, 0x3

    array-length v4, p0

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-ge v3, v4, :cond_2

    .line 679
    invoke-virtual {v2}, Landroidx/media3/common/util/ParsableByteArray;->readUnsignedInt24()I

    move-result v3

    if-ne v3, v6, :cond_0

    add-int/lit8 v3, v0, 0x3

    aget-byte v3, p0, v3

    and-int/lit16 v3, v3, 0xf0

    const/16 v4, 0x20

    if-eq v3, v4, :cond_1

    :cond_0
    goto :goto_1

    .line 685
    :cond_1
    const/4 v1, 0x1

    .line 686
    goto :goto_2

    .line 681
    :goto_1
    invoke-virtual {v2}, Landroidx/media3/common/util/ParsableByteArray;->getPosition()I

    move-result v3

    sub-int/2addr v3, v5

    invoke-virtual {v2, v3}, Landroidx/media3/common/util/ParsableByteArray;->setPosition(I)V

    .line 682
    add-int/lit8 v0, v0, 0x1

    .line 683
    goto :goto_0

    .line 689
    :cond_2
    :goto_2
    const-string v3, "Invalid input: VOL not found."

    invoke-static {v1, v3}, Lcom/google/common/base/Preconditions;->checkArgument(ZLjava/lang/Object;)V

    .line 691
    new-instance v3, Landroidx/media3/common/util/ParsableBitArray;

    invoke-direct {v3, p0}, Landroidx/media3/common/util/ParsableBitArray;-><init>([B)V

    .line 693
    .local v3, "scratchBits":Landroidx/media3/common/util/ParsableBitArray;
    add-int/lit8 v4, v0, 0x4

    const/16 v7, 0x8

    mul-int/2addr v4, v7

    invoke-virtual {v3, v4}, Landroidx/media3/common/util/ParsableBitArray;->skipBits(I)V

    .line 694
    invoke-virtual {v3, v6}, Landroidx/media3/common/util/ParsableBitArray;->skipBits(I)V

    .line 695
    invoke-virtual {v3, v7}, Landroidx/media3/common/util/ParsableBitArray;->skipBits(I)V

    .line 697
    invoke-virtual {v3}, Landroidx/media3/common/util/ParsableBitArray;->readBit()Z

    move-result v4

    const/4 v8, 0x4

    if-eqz v4, :cond_3

    .line 698
    invoke-virtual {v3, v8}, Landroidx/media3/common/util/ParsableBitArray;->skipBits(I)V

    .line 699
    const/4 v4, 0x3

    invoke-virtual {v3, v4}, Landroidx/media3/common/util/ParsableBitArray;->skipBits(I)V

    .line 702
    :cond_3
    invoke-virtual {v3, v8}, Landroidx/media3/common/util/ParsableBitArray;->readBits(I)I

    move-result v4

    .line 703
    .local v4, "aspectRatioInfo":I
    const/16 v8, 0xf

    if-ne v4, v8, :cond_4

    .line 704
    invoke-virtual {v3, v7}, Landroidx/media3/common/util/ParsableBitArray;->skipBits(I)V

    .line 705
    invoke-virtual {v3, v7}, Landroidx/media3/common/util/ParsableBitArray;->skipBits(I)V

    .line 708
    :cond_4
    invoke-virtual {v3}, Landroidx/media3/common/util/ParsableBitArray;->readBit()Z

    move-result v7

    if-eqz v7, :cond_5

    .line 709
    invoke-virtual {v3, v5}, Landroidx/media3/common/util/ParsableBitArray;->skipBits(I)V

    .line 710
    invoke-virtual {v3, v6}, Landroidx/media3/common/util/ParsableBitArray;->skipBits(I)V

    .line 711
    invoke-virtual {v3}, Landroidx/media3/common/util/ParsableBitArray;->readBit()Z

    move-result v7

    if-eqz v7, :cond_5

    .line 712
    const/16 v7, 0x4f

    invoke-virtual {v3, v7}, Landroidx/media3/common/util/ParsableBitArray;->skipBits(I)V

    .line 716
    :cond_5
    invoke-virtual {v3, v5}, Landroidx/media3/common/util/ParsableBitArray;->readBits(I)I

    move-result v5

    .line 717
    .local v5, "videoObjectLayerShape":I
    const/4 v7, 0x0

    if-nez v5, :cond_6

    move v8, v6

    goto :goto_3

    :cond_6
    move v8, v7

    :goto_3
    const-string v9, "Only supports rectangular video object layer shape."

    invoke-static {v8, v9}, Lcom/google/common/base/Preconditions;->checkArgument(ZLjava/lang/Object;)V

    .line 721
    invoke-virtual {v3}, Landroidx/media3/common/util/ParsableBitArray;->readBit()Z

    move-result v8

    invoke-static {v8}, Lcom/google/common/base/Preconditions;->checkArgument(Z)V

    .line 722
    const/16 v8, 0x10

    invoke-virtual {v3, v8}, Landroidx/media3/common/util/ParsableBitArray;->readBits(I)I

    move-result v8

    .line 723
    .local v8, "vopTimeIncrementResolution":I
    invoke-virtual {v3}, Landroidx/media3/common/util/ParsableBitArray;->readBit()Z

    move-result v9

    invoke-static {v9}, Lcom/google/common/base/Preconditions;->checkArgument(Z)V

    .line 725
    invoke-virtual {v3}, Landroidx/media3/common/util/ParsableBitArray;->readBit()Z

    move-result v9

    if-eqz v9, :cond_9

    .line 726
    if-lez v8, :cond_7

    move v7, v6

    :cond_7
    invoke-static {v7}, Lcom/google/common/base/Preconditions;->checkArgument(Z)V

    .line 727
    add-int/lit8 v8, v8, -0x1

    .line 728
    const/4 v7, 0x0

    .line 729
    .local v7, "numBitsToSkip":I
    :goto_4
    if-lez v8, :cond_8

    .line 730
    add-int/lit8 v7, v7, 0x1

    .line 731
    shr-int/lit8 v8, v8, 0x1

    goto :goto_4

    .line 733
    :cond_8
    invoke-virtual {v3, v7}, Landroidx/media3/common/util/ParsableBitArray;->skipBits(I)V

    .line 736
    .end local v7    # "numBitsToSkip":I
    :cond_9
    invoke-virtual {v3}, Landroidx/media3/common/util/ParsableBitArray;->readBit()Z

    move-result v7

    invoke-static {v7}, Lcom/google/common/base/Preconditions;->checkArgument(Z)V

    .line 737
    const/16 v7, 0xd

    invoke-virtual {v3, v7}, Landroidx/media3/common/util/ParsableBitArray;->readBits(I)I

    move-result v9

    .line 738
    .local v9, "videoObjectLayerWidth":I
    invoke-virtual {v3}, Landroidx/media3/common/util/ParsableBitArray;->readBit()Z

    move-result v10

    invoke-static {v10}, Lcom/google/common/base/Preconditions;->checkArgument(Z)V

    .line 739
    invoke-virtual {v3, v7}, Landroidx/media3/common/util/ParsableBitArray;->readBits(I)I

    move-result v7

    .line 740
    .local v7, "videoObjectLayerHeight":I
    invoke-virtual {v3}, Landroidx/media3/common/util/ParsableBitArray;->readBit()Z

    move-result v10

    invoke-static {v10}, Lcom/google/common/base/Preconditions;->checkArgument(Z)V

    .line 742
    invoke-virtual {v3, v6}, Landroidx/media3/common/util/ParsableBitArray;->skipBits(I)V

    .line 744
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-static {v6, v10}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    move-result-object v6

    return-object v6
.end method

.method public static getVp9ProfileAndLevel(Ljava/lang/String;[Ljava/lang/String;)Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;
    .locals 7
    .param p0, "codec"    # Ljava/lang/String;
    .param p1, "parts"    # [Ljava/lang/String;

    .line 1429
    array-length v0, p1

    const/4 v1, 0x3

    const/4 v2, 0x0

    const-string v3, "Ignoring malformed VP9 codec string: "

    const-string v4, "CodecSpecificDataUtil"

    if-ge v0, v1, :cond_0

    .line 1430
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v4, v0}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1431
    return-object v2

    .line 1436
    :cond_0
    const/4 v0, 0x1

    :try_start_0
    aget-object v0, p1, v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    .line 1437
    .local v0, "profileInteger":I
    const/4 v1, 0x2

    aget-object v1, p1, v1

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    .line 1441
    .local v1, "levelInteger":I
    nop

    .line 1443
    invoke-static {v0}, Landroidx/media3/common/util/CodecSpecificDataUtil;->vp9ProfileNumberToConst(I)I

    move-result v2

    .line 1444
    .local v2, "profile":I
    const/4 v3, -0x1

    if-ne v2, v3, :cond_1

    .line 1445
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Unknown VP9 profile: "

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v4, v3}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1446
    sget-object v3, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;->UNSUPPORTABLE:Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    return-object v3

    .line 1448
    :cond_1
    invoke-static {v1}, Landroidx/media3/common/util/CodecSpecificDataUtil;->vp9LevelNumberToConst(I)I

    move-result v5

    .line 1449
    .local v5, "level":I
    if-ne v5, v3, :cond_2

    .line 1450
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "Unknown VP9 level: "

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v4, v3}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1451
    sget-object v3, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;->UNSUPPORTABLE:Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    return-object v3

    .line 1453
    :cond_2
    new-instance v3, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    invoke-direct {v3, v2, v5}, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;-><init>(II)V

    return-object v3

    .line 1438
    .end local v0    # "profileInteger":I
    .end local v1    # "levelInteger":I
    .end local v2    # "profile":I
    .end local v5    # "level":I
    :catch_0
    move-exception v0

    .line 1439
    .local v0, "e":Ljava/lang/NumberFormatException;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v4, v1}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1440
    return-object v2
.end method

.method public static getVvcProfileAndLevel(Ljava/lang/String;[Ljava/lang/String;Landroidx/media3/common/ColorInfo;)Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;
    .locals 7
    .param p0, "codec"    # Ljava/lang/String;
    .param p1, "parts"    # [Ljava/lang/String;
    .param p2, "colorInfo"    # Landroidx/media3/common/ColorInfo;

    .line 927
    array-length v0, p1

    const/4 v1, 0x3

    const/4 v2, 0x0

    const-string v3, "Ignoring malformed VVC codec string: "

    const-string v4, "CodecSpecificDataUtil"

    if-ge v0, v1, :cond_0

    .line 928
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v4, v0}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 929
    return-object v2

    .line 934
    :cond_0
    const/4 v0, 0x1

    :try_start_0
    aget-object v1, p1, v0

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    .line 938
    .local v1, "profileIdc":I
    nop

    .line 941
    if-ne v1, v0, :cond_3

    .line 942
    if-eqz p2, :cond_1

    iget v0, p2, Landroidx/media3/common/ColorInfo;->colorTransfer:I

    const/4 v2, 0x6

    if-ne v0, v2, :cond_1

    .line 943
    const/16 v0, 0x1000

    .local v0, "profile":I
    goto :goto_0

    .line 944
    .end local v0    # "profile":I
    :cond_1
    if-eqz p2, :cond_2

    iget v0, p2, Landroidx/media3/common/ColorInfo;->lumaBitdepth:I

    const/16 v2, 0x8

    if-ne v0, v2, :cond_2

    .line 945
    const/4 v0, 0x1

    .restart local v0    # "profile":I
    goto :goto_0

    .line 947
    .end local v0    # "profile":I
    :cond_2
    const/4 v0, 0x2

    .restart local v0    # "profile":I
    goto :goto_0

    .line 949
    .end local v0    # "profile":I
    :cond_3
    const/16 v2, 0x41

    if-ne v1, v2, :cond_5

    .line 950
    const/4 v0, 0x4

    .line 956
    .restart local v0    # "profile":I
    :goto_0
    const/4 v2, 0x2

    aget-object v2, p1, v2

    .line 957
    .local v2, "levelString":Ljava/lang/String;
    invoke-static {v2}, Landroidx/media3/common/util/CodecSpecificDataUtil;->vvcCodecStringToProfileLevel(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v3

    .line 958
    .local v3, "level":Ljava/lang/Integer;
    if-nez v3, :cond_4

    .line 959
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "Unknown VVC level string: "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 960
    sget-object v4, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;->UNSUPPORTABLE:Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    return-object v4

    .line 962
    :cond_4
    new-instance v4, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v5

    invoke-direct {v4, v0, v5}, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;-><init>(II)V

    return-object v4

    .line 952
    .end local v0    # "profile":I
    .end local v2    # "levelString":Ljava/lang/String;
    .end local v3    # "level":Ljava/lang/Integer;
    :cond_5
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Unknown VVC profile IDC: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v0, p1, v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v4, v0}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 953
    sget-object v0, Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;->UNSUPPORTABLE:Landroidx/media3/common/util/CodecSpecificDataUtil$MediaCodecProfileAndLevel;

    return-object v0

    .line 935
    .end local v1    # "profileIdc":I
    :catch_0
    move-exception v0

    .line 936
    .local v0, "e":Ljava/lang/NumberFormatException;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v4, v1}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 937
    return-object v2
.end method

.method public static h263LevelNumberToConst(I)I
    .locals 1
    .param p0, "levelNumber"    # I

    .line 2284
    sparse-switch p0, :sswitch_data_0

    .line 2302
    const/4 v0, -0x1

    return v0

    .line 2300
    :sswitch_0
    const/16 v0, 0x80

    return v0

    .line 2298
    :sswitch_1
    const/16 v0, 0x40

    return v0

    .line 2296
    :sswitch_2
    const/16 v0, 0x20

    return v0

    .line 2294
    :sswitch_3
    const/16 v0, 0x10

    return v0

    .line 2292
    :sswitch_4
    const/16 v0, 0x8

    return v0

    .line 2290
    :sswitch_5
    const/4 v0, 0x4

    return v0

    .line 2288
    :sswitch_6
    const/4 v0, 0x2

    return v0

    .line 2286
    :sswitch_7
    const/4 v0, 0x1

    return v0

    :sswitch_data_0
    .sparse-switch
        0xa -> :sswitch_7
        0x14 -> :sswitch_6
        0x1e -> :sswitch_5
        0x28 -> :sswitch_4
        0x2d -> :sswitch_3
        0x32 -> :sswitch_2
        0x3c -> :sswitch_1
        0x46 -> :sswitch_0
    .end sparse-switch
.end method

.method public static h263ProfileNumberToConst(I)I
    .locals 1
    .param p0, "profileNumber"    # I

    .line 2258
    packed-switch p0, :pswitch_data_0

    .line 2278
    const/4 v0, -0x1

    return v0

    .line 2276
    :pswitch_0
    const/16 v0, 0x100

    return v0

    .line 2274
    :pswitch_1
    const/16 v0, 0x80

    return v0

    .line 2272
    :pswitch_2
    const/16 v0, 0x40

    return v0

    .line 2270
    :pswitch_3
    const/16 v0, 0x20

    return v0

    .line 2268
    :pswitch_4
    const/16 v0, 0x10

    return v0

    .line 2266
    :pswitch_5
    const/16 v0, 0x8

    return v0

    .line 2264
    :pswitch_6
    const/4 v0, 0x4

    return v0

    .line 2262
    :pswitch_7
    const/4 v0, 0x2

    return v0

    .line 2260
    :pswitch_8
    const/4 v0, 0x1

    return v0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static hevcCodecStringToProfileLevel(Ljava/lang/String;)Ljava/lang/Integer;
    .locals 6
    .param p0, "codecString"    # Ljava/lang/String;

    .line 1996
    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/16 v1, 0x10

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/16 v5, 0x8

    sparse-switch v0, :sswitch_data_0

    :cond_0
    goto/16 :goto_0

    :sswitch_0
    const-string v0, "L186"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0xc

    goto/16 :goto_1

    :sswitch_1
    const-string v0, "L183"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0xb

    goto/16 :goto_1

    :sswitch_2
    const-string v0, "L180"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0xa

    goto/16 :goto_1

    :sswitch_3
    const-string v0, "L156"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0x9

    goto/16 :goto_1

    :sswitch_4
    const-string v0, "L153"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    move v0, v5

    goto/16 :goto_1

    :sswitch_5
    const-string v0, "L150"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x7

    goto/16 :goto_1

    :sswitch_6
    const-string v0, "L123"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x6

    goto/16 :goto_1

    :sswitch_7
    const-string v0, "L120"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x5

    goto/16 :goto_1

    :sswitch_8
    const-string v0, "H186"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0x19

    goto/16 :goto_1

    :sswitch_9
    const-string v0, "H183"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0x18

    goto/16 :goto_1

    :sswitch_a
    const-string v0, "H180"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0x17

    goto/16 :goto_1

    :sswitch_b
    const-string v0, "H156"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0x16

    goto/16 :goto_1

    :sswitch_c
    const-string v0, "H153"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0x15

    goto/16 :goto_1

    :sswitch_d
    const-string v0, "H150"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0x14

    goto/16 :goto_1

    :sswitch_e
    const-string v0, "H123"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0x13

    goto/16 :goto_1

    :sswitch_f
    const-string v0, "H120"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0x12

    goto/16 :goto_1

    :sswitch_10
    const-string v0, "L93"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    move v0, v4

    goto/16 :goto_1

    :sswitch_11
    const-string v0, "L90"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x3

    goto :goto_1

    :sswitch_12
    const-string v0, "L63"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    move v0, v3

    goto :goto_1

    :sswitch_13
    const-string v0, "L60"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    move v0, v2

    goto :goto_1

    :sswitch_14
    const-string v0, "L30"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    goto :goto_1

    :sswitch_15
    const-string v0, "H93"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0x11

    goto :goto_1

    :sswitch_16
    const-string v0, "H90"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    move v0, v1

    goto :goto_1

    :sswitch_17
    const-string v0, "H63"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0xf

    goto :goto_1

    :sswitch_18
    const-string v0, "H60"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0xe

    goto :goto_1

    :sswitch_19
    const-string v0, "H30"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0xd

    goto :goto_1

    :goto_0
    const/4 v0, -0x1

    :goto_1
    packed-switch v0, :pswitch_data_0

    .line 2050
    const/4 v0, 0x0

    return-object v0

    .line 2048
    :pswitch_0
    const/high16 v0, 0x2000000

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2046
    :pswitch_1
    const/high16 v0, 0x800000

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2044
    :pswitch_2
    const/high16 v0, 0x200000

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2042
    :pswitch_3
    const/high16 v0, 0x80000

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2040
    :pswitch_4
    const/high16 v0, 0x20000

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2038
    :pswitch_5
    const v0, 0x8000

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2036
    :pswitch_6
    const/16 v0, 0x2000

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2034
    :pswitch_7
    const/16 v0, 0x800

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2032
    :pswitch_8
    const/16 v0, 0x200

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2030
    :pswitch_9
    const/16 v0, 0x80

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2028
    :pswitch_a
    const/16 v0, 0x20

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2026
    :pswitch_b
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2024
    :pswitch_c
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2022
    :pswitch_d
    const/high16 v0, 0x1000000

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2020
    :pswitch_e
    const/high16 v0, 0x400000

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2018
    :pswitch_f
    const/high16 v0, 0x100000

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2016
    :pswitch_10
    const/high16 v0, 0x40000

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2014
    :pswitch_11
    const/high16 v0, 0x10000

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2012
    :pswitch_12
    const/16 v0, 0x4000

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2010
    :pswitch_13
    const/16 v0, 0x1000

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2008
    :pswitch_14
    const/16 v0, 0x400

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2006
    :pswitch_15
    const/16 v0, 0x100

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2004
    :pswitch_16
    const/16 v0, 0x40

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2002
    :pswitch_17
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 2000
    :pswitch_18
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 1998
    :pswitch_19
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    :sswitch_data_0
    .sparse-switch
        0x114a5 -> :sswitch_19
        0x11502 -> :sswitch_18
        0x11505 -> :sswitch_17
        0x1155f -> :sswitch_16
        0x11562 -> :sswitch_15
        0x123a9 -> :sswitch_14
        0x12406 -> :sswitch_13
        0x12409 -> :sswitch_12
        0x12463 -> :sswitch_11
        0x12466 -> :sswitch_10
        0x2178e7 -> :sswitch_f
        0x2178ea -> :sswitch_e
        0x217944 -> :sswitch_d
        0x217947 -> :sswitch_c
        0x21794a -> :sswitch_b
        0x2179a1 -> :sswitch_a
        0x2179a4 -> :sswitch_9
        0x2179a7 -> :sswitch_8
        0x234a63 -> :sswitch_7
        0x234a66 -> :sswitch_6
        0x234ac0 -> :sswitch_5
        0x234ac3 -> :sswitch_4
        0x234ac6 -> :sswitch_3
        0x234b1d -> :sswitch_2
        0x234b20 -> :sswitch_1
        0x234b23 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static iamfProfileNumberToConst(Ljava/lang/String;I)I
    .locals 4
    .param p0, "codec"    # Ljava/lang/String;
    .param p1, "profileNumber"    # I

    .line 1830
    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v1, -0x1

    sparse-switch v0, :sswitch_data_0

    :cond_0
    goto :goto_0

    :sswitch_0
    const-string v0, "mp4a"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_1

    :sswitch_1
    const-string v0, "ipcm"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x3

    goto :goto_1

    :sswitch_2
    const-string v0, "fLaC"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x2

    goto :goto_1

    :sswitch_3
    const-string v0, "Opus"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    goto :goto_1

    :goto_0
    move v0, v1

    :goto_1
    const-string v2, "CodecSpecificDataUtil"

    packed-switch v0, :pswitch_data_0

    .line 1880
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Unrecognized codec identifier for IAMF auxiliary profile: "

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1881
    return v1

    .line 1868
    :pswitch_0
    packed-switch p1, :pswitch_data_1

    .line 1876
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Unrecognized IAMF PCM profile: "

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1877
    return v1

    .line 1874
    :pswitch_1
    const v0, 0x1040008

    return v0

    .line 1872
    :pswitch_2
    const v0, 0x1020008

    return v0

    .line 1870
    :pswitch_3
    const v0, 0x1010008

    return v0

    .line 1856
    :pswitch_4
    packed-switch p1, :pswitch_data_2

    .line 1864
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Unrecognized IAMF FLAC profile: "

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1865
    return v1

    .line 1862
    :pswitch_5
    const v0, 0x1040004

    return v0

    .line 1860
    :pswitch_6
    const v0, 0x1020004

    return v0

    .line 1858
    :pswitch_7
    const v0, 0x1010004

    return v0

    .line 1844
    :pswitch_8
    packed-switch p1, :pswitch_data_3

    .line 1852
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Unrecognized IAMF AAC profile: "

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1853
    return v1

    .line 1850
    :pswitch_9
    const v0, 0x1040002

    return v0

    .line 1848
    :pswitch_a
    const v0, 0x1020002

    return v0

    .line 1846
    :pswitch_b
    const v0, 0x1010002

    return v0

    .line 1832
    :pswitch_c
    packed-switch p1, :pswitch_data_4

    .line 1840
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Unrecognized IAMF Opus profile: "

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 1841
    return v1

    .line 1838
    :pswitch_d
    const v0, 0x1040001

    return v0

    .line 1836
    :pswitch_e
    const v0, 0x1020001

    return v0

    .line 1834
    :pswitch_f
    const v0, 0x1010001

    return v0

    :sswitch_data_0
    .sparse-switch
        0x259c5f -> :sswitch_3
        0x2f8728 -> :sswitch_2
        0x316bd1 -> :sswitch_1
        0x333790 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_c
        :pswitch_8
        :pswitch_4
        :pswitch_0
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
    .end packed-switch

    :pswitch_data_2
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
    .end packed-switch

    :pswitch_data_3
    .packed-switch 0x0
        :pswitch_b
        :pswitch_a
        :pswitch_9
    .end packed-switch

    :pswitch_data_4
    .packed-switch 0x0
        :pswitch_f
        :pswitch_e
        :pswitch_d
    .end packed-switch
.end method

.method public static isHagcMetadata(Ljava/nio/ByteBuffer;)Z
    .locals 5
    .param p0, "buffer"    # Ljava/nio/ByteBuffer;

    .line 2403
    invoke-virtual {p0}, Ljava/nio/Buffer;->remaining()I

    move-result v0

    sget-object v1, Landroidx/media3/common/util/CodecSpecificDataUtil;->expectedHagcPayloadPrefix:[B

    array-length v1, v1

    const/4 v2, 0x0

    if-ge v0, v1, :cond_0

    .line 2404
    return v2

    .line 2406
    :cond_0
    invoke-virtual {p0}, Ljava/nio/Buffer;->position()I

    move-result v0

    .line 2407
    .local v0, "pos":I
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_0
    sget-object v3, Landroidx/media3/common/util/CodecSpecificDataUtil;->expectedHagcPayloadPrefix:[B

    array-length v3, v3

    if-ge v1, v3, :cond_2

    .line 2408
    add-int v3, v0, v1

    invoke-virtual {p0, v3}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v3

    sget-object v4, Landroidx/media3/common/util/CodecSpecificDataUtil;->expectedHagcPayloadPrefix:[B

    aget-byte v4, v4, v1

    if-eq v3, v4, :cond_1

    .line 2409
    return v2

    .line 2407
    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    nop

    .line 2412
    .end local v1    # "i":I
    const/4 v1, 0x1

    return v1
.end method

.method public static isHagcMetadata([BI)Z
    .locals 4
    .param p0, "data"    # [B
    .param p1, "length"    # I

    .line 2385
    sget-object v0, Landroidx/media3/common/util/CodecSpecificDataUtil;->expectedHagcPayloadPrefix:[B

    array-length v0, v0

    const/4 v1, 0x0

    if-ge p1, v0, :cond_0

    .line 2386
    return v1

    .line 2388
    :cond_0
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    sget-object v2, Landroidx/media3/common/util/CodecSpecificDataUtil;->expectedHagcPayloadPrefix:[B

    array-length v2, v2

    if-ge v0, v2, :cond_2

    .line 2389
    aget-byte v2, p0, v0

    sget-object v3, Landroidx/media3/common/util/CodecSpecificDataUtil;->expectedHagcPayloadPrefix:[B

    aget-byte v3, v3, v0

    if-eq v2, v3, :cond_1

    .line 2390
    return v1

    .line 2388
    :cond_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_2
    nop

    .line 2393
    .end local v0    # "i":I
    const/4 v0, 0x1

    return v0
.end method

.method public static isHagcTrack(Landroidx/media3/common/Format;)Z
    .locals 4
    .param p0, "format"    # Landroidx/media3/common/Format;

    .line 2421
    iget-object v0, p0, Landroidx/media3/common/Format;->sampleMimeType:Ljava/lang/String;

    const-string v1, "application/x-itut-t35"

    invoke-static {v0, v1}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    .line 2422
    return v1

    .line 2424
    :cond_0
    iget-object v0, p0, Landroidx/media3/common/Format;->initializationData:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, [B

    .line 2425
    .local v2, "initData":[B
    array-length v3, v2

    invoke-static {v2, v3}, Landroidx/media3/common/util/CodecSpecificDataUtil;->isHagcMetadata([BI)Z

    move-result v3

    if-eqz v3, :cond_1

    .line 2426
    const/4 v0, 0x1

    return v0

    .line 2425
    :cond_1
    nop

    .line 2428
    .end local v2    # "initData":[B
    goto :goto_0

    .line 2429
    :cond_2
    return v1
.end method

.method public static isNalStartCode([BI)Z
    .locals 4
    .param p0, "data"    # [B
    .param p1, "index"    # I

    .line 1286
    array-length v0, p0

    sub-int/2addr v0, p1

    sget-object v1, Landroidx/media3/common/util/CodecSpecificDataUtil;->NAL_START_CODE:[B

    array-length v1, v1

    const/4 v2, 0x0

    if-gt v0, v1, :cond_0

    .line 1287
    return v2

    .line 1289
    :cond_0
    const/4 v0, 0x0

    .local v0, "j":I
    :goto_0
    sget-object v1, Landroidx/media3/common/util/CodecSpecificDataUtil;->NAL_START_CODE:[B

    array-length v1, v1

    if-ge v0, v1, :cond_2

    .line 1290
    add-int v1, p1, v0

    aget-byte v1, p0, v1

    sget-object v3, Landroidx/media3/common/util/CodecSpecificDataUtil;->NAL_START_CODE:[B

    aget-byte v3, v3, v0

    if-eq v1, v3, :cond_1

    .line 1291
    return v2

    .line 1289
    :cond_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_2
    nop

    .line 1294
    .end local v0    # "j":I
    const/4 v0, 0x1

    return v0
.end method

.method public static mp4aAudioObjectTypeToProfile(I)I
    .locals 1
    .param p0, "profileNumber"    # I

    .line 2180
    sparse-switch p0, :sswitch_data_0

    .line 2206
    const/4 v0, -0x1

    return v0

    .line 2204
    :sswitch_0
    const/16 v0, 0x2a

    return v0

    .line 2202
    :sswitch_1
    const/16 v0, 0x27

    return v0

    .line 2200
    :sswitch_2
    const/16 v0, 0x1d

    return v0

    .line 2198
    :sswitch_3
    const/16 v0, 0x17

    return v0

    .line 2196
    :sswitch_4
    const/16 v0, 0x14

    return v0

    .line 2194
    :sswitch_5
    const/16 v0, 0x11

    return v0

    .line 2192
    :sswitch_6
    const/4 v0, 0x6

    return v0

    .line 2190
    :sswitch_7
    const/4 v0, 0x5

    return v0

    .line 2188
    :sswitch_8
    const/4 v0, 0x4

    return v0

    .line 2186
    :sswitch_9
    const/4 v0, 0x3

    return v0

    .line 2184
    :sswitch_a
    const/4 v0, 0x2

    return v0

    .line 2182
    :sswitch_b
    const/4 v0, 0x1

    return v0

    nop

    :sswitch_data_0
    .sparse-switch
        0x1 -> :sswitch_b
        0x2 -> :sswitch_a
        0x3 -> :sswitch_9
        0x4 -> :sswitch_8
        0x5 -> :sswitch_7
        0x6 -> :sswitch_6
        0x11 -> :sswitch_5
        0x14 -> :sswitch_4
        0x17 -> :sswitch_3
        0x1d -> :sswitch_2
        0x27 -> :sswitch_1
        0x2a -> :sswitch_0
    .end sparse-switch
.end method

.method public static parseAlacAudioSpecificConfig([B)[I
    .locals 5
    .param p0, "audioSpecificConfig"    # [B

    .line 214
    new-instance v0, Landroidx/media3/common/util/ParsableByteArray;

    invoke-direct {v0, p0}, Landroidx/media3/common/util/ParsableByteArray;-><init>([B)V

    .line 215
    .local v0, "byteArray":Landroidx/media3/common/util/ParsableByteArray;
    const/4 v1, 0x5

    invoke-virtual {v0, v1}, Landroidx/media3/common/util/ParsableByteArray;->setPosition(I)V

    .line 216
    invoke-virtual {v0}, Landroidx/media3/common/util/ParsableByteArray;->readUnsignedByte()I

    move-result v1

    .line 217
    .local v1, "bitDepth":I
    const/16 v2, 0x9

    invoke-virtual {v0, v2}, Landroidx/media3/common/util/ParsableByteArray;->setPosition(I)V

    .line 218
    invoke-virtual {v0}, Landroidx/media3/common/util/ParsableByteArray;->readUnsignedByte()I

    move-result v2

    .line 219
    .local v2, "channelCount":I
    const/16 v3, 0x14

    invoke-virtual {v0, v3}, Landroidx/media3/common/util/ParsableByteArray;->setPosition(I)V

    .line 220
    invoke-virtual {v0}, Landroidx/media3/common/util/ParsableByteArray;->readUnsignedIntToInt()I

    move-result v3

    .line 221
    .local v3, "sampleRate":I
    filled-new-array {v3, v2, v1}, [I

    move-result-object v4

    return-object v4
.end method

.method public static parseCea708InitializationData(Ljava/util/List;)Z
    .locals 3

    .line 320
    .local p0, "initializationData":Ljava/util/List;, "Ljava/util/List<[B>;"
    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    nop

    if-ne v0, v2, :cond_0

    .line 321
    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [B

    array-length v0, v0

    nop

    if-ne v0, v2, :cond_0

    .line 322
    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [B

    aget-byte v0, v0, v1

    if-ne v0, v2, :cond_0

    move v1, v2

    goto :goto_0

    :cond_0
    nop

    .line 320
    :goto_0
    return v1
.end method

.method public static splitNalUnits([B)[[B
    .locals 9
    .param p0, "data"    # [B

    .line 1109
    const/4 v0, 0x0

    invoke-static {p0, v0}, Landroidx/media3/common/util/CodecSpecificDataUtil;->isNalStartCode([BI)Z

    move-result v1

    if-nez v1, :cond_0

    .line 1111
    const/4 v0, 0x0

    return-object v0

    .line 1113
    :cond_0
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 1114
    .local v1, "starts":Ljava/util/List;, "Ljava/util/List<Ljava/lang/Integer;>;"
    const/4 v2, 0x0

    .line 1116
    .local v2, "nalUnitIndex":I
    :cond_1
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v1, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 1117
    sget-object v3, Landroidx/media3/common/util/CodecSpecificDataUtil;->NAL_START_CODE:[B

    array-length v3, v3

    add-int/2addr v3, v2

    invoke-static {p0, v3}, Landroidx/media3/common/util/CodecSpecificDataUtil;->findNalStartCode([BI)I

    move-result v2

    .line 1118
    const/4 v3, -0x1

    if-ne v2, v3, :cond_1

    .line 1119
    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v3

    new-array v3, v3, [[B

    .line 1120
    .local v3, "split":[[B
    const/4 v4, 0x0

    .local v4, "i":I
    :goto_0
    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v5

    if-ge v4, v5, :cond_3

    .line 1121
    invoke-interface {v1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    .line 1122
    .local v5, "startIndex":I
    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v6

    add-int/lit8 v6, v6, -0x1

    if-ge v4, v6, :cond_2

    add-int/lit8 v6, v4, 0x1

    invoke-interface {v1, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Integer;

    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    move-result v6

    goto :goto_1

    :cond_2
    array-length v6, p0

    .line 1123
    .local v6, "endIndex":I
    :goto_1
    sub-int v7, v6, v5

    new-array v7, v7, [B

    .line 1124
    .local v7, "nal":[B
    array-length v8, v7

    invoke-static {p0, v5, v7, v0, v8}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 1125
    aput-object v7, v3, v4

    .line 1120
    .end local v5    # "startIndex":I
    .end local v6    # "endIndex":I
    .end local v7    # "nal":[B
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_3
    nop

    .line 1127
    .end local v4    # "i":I
    return-object v3
.end method

.method public static vp9LevelNumberToConst(I)I
    .locals 1
    .param p0, "levelNumber"    # I

    .line 1962
    sparse-switch p0, :sswitch_data_0

    .line 1990
    const/4 v0, -0x1

    return v0

    .line 1988
    :sswitch_0
    const/16 v0, 0x2000

    return v0

    .line 1986
    :sswitch_1
    const/16 v0, 0x1000

    return v0

    .line 1984
    :sswitch_2
    const/16 v0, 0x800

    return v0

    .line 1982
    :sswitch_3
    const/16 v0, 0x200

    return v0

    .line 1980
    :sswitch_4
    const/16 v0, 0x100

    return v0

    .line 1978
    :sswitch_5
    const/16 v0, 0x80

    return v0

    .line 1976
    :sswitch_6
    const/16 v0, 0x40

    return v0

    .line 1974
    :sswitch_7
    const/16 v0, 0x20

    return v0

    .line 1972
    :sswitch_8
    const/16 v0, 0x10

    return v0

    .line 1970
    :sswitch_9
    const/16 v0, 0x8

    return v0

    .line 1968
    :sswitch_a
    const/4 v0, 0x4

    return v0

    .line 1966
    :sswitch_b
    const/4 v0, 0x2

    return v0

    .line 1964
    :sswitch_c
    const/4 v0, 0x1

    return v0

    nop

    :sswitch_data_0
    .sparse-switch
        0xa -> :sswitch_c
        0xb -> :sswitch_b
        0x14 -> :sswitch_a
        0x15 -> :sswitch_9
        0x1e -> :sswitch_8
        0x1f -> :sswitch_7
        0x28 -> :sswitch_6
        0x29 -> :sswitch_5
        0x32 -> :sswitch_4
        0x33 -> :sswitch_3
        0x3c -> :sswitch_2
        0x3d -> :sswitch_1
        0x3e -> :sswitch_0
    .end sparse-switch
.end method

.method public static vp9ProfileNumberToConst(I)I
    .locals 1
    .param p0, "profileNumber"    # I

    .line 1947
    packed-switch p0, :pswitch_data_0

    .line 1957
    const/4 v0, -0x1

    return v0

    .line 1955
    :pswitch_0
    const/16 v0, 0x8

    return v0

    .line 1953
    :pswitch_1
    const/4 v0, 0x4

    return v0

    .line 1951
    :pswitch_2
    const/4 v0, 0x2

    return v0

    .line 1949
    :pswitch_3
    const/4 v0, 0x1

    return v0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static vvcCodecStringToProfileLevel(Ljava/lang/String;)Ljava/lang/Integer;
    .locals 6
    .param p0, "codecString"    # Ljava/lang/String;

    .line 978
    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/16 v1, 0x8

    const/16 v2, 0x10

    const/4 v3, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    sparse-switch v0, :sswitch_data_0

    :cond_0
    goto/16 :goto_0

    :sswitch_0
    const-string v0, "L144"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0x15

    goto/16 :goto_1

    :sswitch_1
    const-string v0, "L128"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0x13

    goto/16 :goto_1

    :sswitch_2
    const-string v0, "L112"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0x11

    goto/16 :goto_1

    :sswitch_3
    const-string v0, "H144"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0x16

    goto/16 :goto_1

    :sswitch_4
    const-string v0, "H128"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0x14

    goto/16 :goto_1

    :sswitch_5
    const-string v0, "H112"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0x12

    goto/16 :goto_1

    :sswitch_6
    const-string v0, "L96"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0xf

    goto/16 :goto_1

    :sswitch_7
    const-string v0, "L86"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0xd

    goto/16 :goto_1

    :sswitch_8
    const-string v0, "L83"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0xb

    goto/16 :goto_1

    :sswitch_9
    const-string v0, "L80"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0x9

    goto/16 :goto_1

    :sswitch_a
    const-string v0, "L67"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x7

    goto/16 :goto_1

    :sswitch_b
    const-string v0, "L64"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x5

    goto/16 :goto_1

    :sswitch_c
    const-string v0, "L51"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    move v0, v5

    goto/16 :goto_1

    :sswitch_d
    const-string v0, "L48"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x3

    goto/16 :goto_1

    :sswitch_e
    const-string v0, "L35"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    move v0, v4

    goto :goto_1

    :sswitch_f
    const-string v0, "L32"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    move v0, v3

    goto :goto_1

    :sswitch_10
    const-string v0, "L16"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    goto :goto_1

    :sswitch_11
    const-string v0, "H96"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    move v0, v2

    goto :goto_1

    :sswitch_12
    const-string v0, "H86"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0xe

    goto :goto_1

    :sswitch_13
    const-string v0, "H83"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0xc

    goto :goto_1

    :sswitch_14
    const-string v0, "H80"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0xa

    goto :goto_1

    :sswitch_15
    const-string v0, "H67"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    move v0, v1

    goto :goto_1

    :sswitch_16
    const-string v0, "H64"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x6

    goto :goto_1

    :goto_0
    const/4 v0, -0x1

    :goto_1
    packed-switch v0, :pswitch_data_0

    .line 1026
    const/4 v0, 0x0

    return-object v0

    .line 1024
    :pswitch_0
    const/high16 v0, 0x400000

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 1022
    :pswitch_1
    const/high16 v0, 0x200000

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 1020
    :pswitch_2
    const/high16 v0, 0x100000

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 1018
    :pswitch_3
    const/high16 v0, 0x80000

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 1016
    :pswitch_4
    const/high16 v0, 0x40000

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 1014
    :pswitch_5
    const/high16 v0, 0x20000

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 1012
    :pswitch_6
    const/high16 v0, 0x10000

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 1010
    :pswitch_7
    const v0, 0x8000

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 1008
    :pswitch_8
    const/16 v0, 0x4000

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 1006
    :pswitch_9
    const/16 v0, 0x2000

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 1004
    :pswitch_a
    const/16 v0, 0x1000

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 1002
    :pswitch_b
    const/16 v0, 0x800

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 1000
    :pswitch_c
    const/16 v0, 0x400

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 998
    :pswitch_d
    const/16 v0, 0x200

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 996
    :pswitch_e
    const/16 v0, 0x100

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 994
    :pswitch_f
    const/16 v0, 0x80

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 992
    :pswitch_10
    const/16 v0, 0x40

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 990
    :pswitch_11
    const/16 v0, 0x20

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 988
    :pswitch_12
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 986
    :pswitch_13
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 984
    :pswitch_14
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 982
    :pswitch_15
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 980
    :pswitch_16
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    nop

    :sswitch_data_0
    .sparse-switch
        0x11506 -> :sswitch_16
        0x11509 -> :sswitch_15
        0x11540 -> :sswitch_14
        0x11543 -> :sswitch_13
        0x11546 -> :sswitch_12
        0x11565 -> :sswitch_11
        0x12371 -> :sswitch_10
        0x123ab -> :sswitch_f
        0x123ae -> :sswitch_e
        0x123d0 -> :sswitch_d
        0x123e8 -> :sswitch_c
        0x1240a -> :sswitch_b
        0x1240d -> :sswitch_a
        0x12444 -> :sswitch_9
        0x12447 -> :sswitch_8
        0x1244a -> :sswitch_7
        0x12469 -> :sswitch_6
        0x2178ca -> :sswitch_5
        0x2178ef -> :sswitch_4
        0x217929 -> :sswitch_3
        0x234a46 -> :sswitch_2
        0x234a6b -> :sswitch_1
        0x234aa5 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
