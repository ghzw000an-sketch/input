.class public final Landroidx/media3/common/util/GlProgram$Uniform;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/media3/common/util/GlProgram;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Uniform"
.end annotation


# instance fields
.field public final floatValue:[F

.field public final intValue:[I

.field public final location:I

.field public final name:Ljava/lang/String;

.field public texMinFilter:I

.field public final type:I


# direct methods
.method public constructor <init>(Ljava/lang/String;II)V
    .locals 1
    .param p1, "name"    # Ljava/lang/String;
    .param p2, "location"    # I
    .param p3, "type"    # I

    .line 416
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 417
    iput-object p1, p0, Landroidx/media3/common/util/GlProgram$Uniform;->name:Ljava/lang/String;

    .line 418
    iput p2, p0, Landroidx/media3/common/util/GlProgram$Uniform;->location:I

    .line 419
    iput p3, p0, Landroidx/media3/common/util/GlProgram$Uniform;->type:I

    .line 420
    const/16 v0, 0x10

    new-array v0, v0, [F

    iput-object v0, p0, Landroidx/media3/common/util/GlProgram$Uniform;->floatValue:[F

    .line 421
    const/4 v0, 0x4

    new-array v0, v0, [I

    iput-object v0, p0, Landroidx/media3/common/util/GlProgram$Uniform;->intValue:[I

    .line 422
    const/16 v0, 0x2601

    iput v0, p0, Landroidx/media3/common/util/GlProgram$Uniform;->texMinFilter:I

    .line 423
    return-void
.end method

.method public static create(II)Landroidx/media3/common/util/GlProgram$Uniform;
    .locals 13
    .param p0, "programId"    # I
    .param p1, "index"    # I

    .line 379
    const/4 v1, 0x1

    new-array v11, v1, [I

    .line 380
    .local v11, "length":[I
    const v2, 0x8b87

    const/4 v12, 0x0

    invoke-static {p0, v2, v11, v12}, Landroid/opengl/GLES20;->glGetProgramiv(II[II)V

    .line 383
    new-array v7, v1, [I

    .line 384
    .local v7, "type":[I
    aget v2, v11, v12

    new-array v9, v2, [B

    .line 386
    .local v9, "nameBytes":[B
    aget v2, v11, v12

    new-array v3, v1, [I

    new-array v5, v1, [I

    const/4 v8, 0x0

    const/4 v10, 0x0

    const/4 v4, 0x0

    const/4 v6, 0x0

    move v0, p0

    move v1, p1

    invoke-static/range {v0 .. v10}, Landroid/opengl/GLES20;->glGetActiveUniform(III[II[II[II[BI)V

    .line 398
    new-instance v1, Ljava/lang/String;

    invoke-static {v9}, Landroidx/media3/common/util/GlProgram;->access$000([B)I

    move-result v2

    invoke-direct {v1, v9, v12, v2}, Ljava/lang/String;-><init>([BII)V

    .line 399
    .local v1, "name":Ljava/lang/String;
    invoke-static {p0, v1}, Landroidx/media3/common/util/GlProgram;->access$200(ILjava/lang/String;)I

    move-result v2

    .line 401
    .local v2, "location":I
    new-instance v3, Landroidx/media3/common/util/GlProgram$Uniform;

    aget v4, v7, v12

    invoke-direct {v3, v1, v2, v4}, Landroidx/media3/common/util/GlProgram$Uniform;-><init>(Ljava/lang/String;II)V

    return-object v3
.end method
