.class public abstract Landroidx/media3/common/util/ParsableByteArray$IsRunningInTestHolder;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/media3/common/util/ParsableByteArray;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "IsRunningInTestHolder"
.end annotation


# static fields
.field public static final IS_RUNNING_IN_TEST:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 67
    invoke-static {}, Landroidx/media3/common/util/ParsableByteArray;->access$000()Z

    move-result v0

    sput-boolean v0, Landroidx/media3/common/util/ParsableByteArray$IsRunningInTestHolder;->IS_RUNNING_IN_TEST:Z

    return-void
.end method
