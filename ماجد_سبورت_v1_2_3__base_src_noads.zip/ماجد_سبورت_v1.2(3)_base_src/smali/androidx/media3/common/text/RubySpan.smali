.class public final Landroidx/media3/common/text/RubySpan;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroidx/media3/common/text/LanguageFeatureSpan;


# static fields
.field public static final FIELD_POSITION:Ljava/lang/String;

.field public static final FIELD_TEXT:Ljava/lang/String;


# instance fields
.field public final position:I

.field public final rubyText:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 48
    const/4 v0, 0x0

    invoke-static {v0}, Landroidx/media3/common/util/Util;->intToStringMaxRadix(I)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Landroidx/media3/common/text/RubySpan;->FIELD_TEXT:Ljava/lang/String;

    .line 49
    const/4 v0, 0x1

    invoke-static {v0}, Landroidx/media3/common/util/Util;->intToStringMaxRadix(I)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Landroidx/media3/common/text/RubySpan;->FIELD_POSITION:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .param p1, "rubyText"    # Ljava/lang/String;
    .param p2, "position"    # I

    .line 51
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 52
    iput-object p1, p0, Landroidx/media3/common/text/RubySpan;->rubyText:Ljava/lang/String;

    .line 53
    iput p2, p0, Landroidx/media3/common/text/RubySpan;->position:I

    .line 54
    return-void
.end method

.method public static fromBundle(Landroid/os/Bundle;)Landroidx/media3/common/text/RubySpan;
    .locals 3
    .param p0, "bundle"    # Landroid/os/Bundle;

    .line 64
    new-instance v0, Landroidx/media3/common/text/RubySpan;

    sget-object v1, Landroidx/media3/common/text/RubySpan;->FIELD_TEXT:Ljava/lang/String;

    .line 65
    invoke-virtual {p0, v1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/google/common/base/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    sget-object v2, Landroidx/media3/common/text/RubySpan;->FIELD_POSITION:Ljava/lang/String;

    .line 66
    invoke-virtual {p0, v2}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v2

    invoke-direct {v0, v1, v2}, Landroidx/media3/common/text/RubySpan;-><init>(Ljava/lang/String;I)V

    .line 64
    return-object v0
.end method


# virtual methods
.method public toBundle()Landroid/os/Bundle;
    .locals 3

    .line 57
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 58
    .local v0, "bundle":Landroid/os/Bundle;
    sget-object v1, Landroidx/media3/common/text/RubySpan;->FIELD_TEXT:Ljava/lang/String;

    iget-object v2, p0, Landroidx/media3/common/text/RubySpan;->rubyText:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 59
    sget-object v1, Landroidx/media3/common/text/RubySpan;->FIELD_POSITION:Ljava/lang/String;

    iget v2, p0, Landroidx/media3/common/text/RubySpan;->position:I

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 60
    return-object v0
.end method
