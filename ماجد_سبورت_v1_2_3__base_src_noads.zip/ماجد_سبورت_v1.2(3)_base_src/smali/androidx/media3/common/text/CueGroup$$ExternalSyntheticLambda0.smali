.class public final synthetic Landroidx/media3/common/text/CueGroup$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/google/common/base/Function;


# direct methods
.method public synthetic constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, Landroidx/media3/common/text/Cue;

    invoke-static {p1}, Landroidx/media3/common/text/CueGroup;->$r8$lambda$bYB0Gn-rA6IhiQww2EWZwTdn4d4(Landroidx/media3/common/text/Cue;)Ljava/lang/Integer;

    move-result-object p1

    return-object p1
.end method
